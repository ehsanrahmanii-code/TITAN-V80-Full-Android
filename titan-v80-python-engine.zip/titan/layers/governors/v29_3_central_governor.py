# [TITAN V77 layer] governors/v29_3_central_governor - V29.3 central governor
# Original V76 source lines 12407-12444 (kept verbatim unless listed in CHANGELOG.md).
# =============================================================================
# TITAN V29.3 — CENTRAL GOVERNOR (single decision authority)
# - All upstream engines (V29..V32, CNS, patterns, AI) = evidence only
# - Central Governor = sole LONG / SHORT / WAIT publisher
# - Timestamped predictions + automatic outcome audit + component reward/penalty
# - Auto scan / learn / score — no manual button required
# - Emergency live-price cards so Android dashboard is never blank
# - Analysis only. No order execution. Signals are probabilistic, not guarantees.
# =============================================================================

TITAN_CENTRAL_VERSION = "TITAN-CENTRAL-GOVERNOR-V51.1"
TITAN_PUBLIC_AUTHORITY = TITAN_CENTRAL_VERSION
TITAN_LEGACY_ENGINES_ARE_EVIDENCE_ONLY = True

_CENTRAL_WEIGHT_LOCK = threading.RLock()
# Reweighted from realized phone-DB component stats (htf best; ltf/forecast weak)
_CENTRAL_WEIGHTS_DEFAULT = {
    "htf_trend": 1.55,
    "mtf_setup": 1.05,
    "ltf_trigger": 0.55,
    "momentum": 0.90,
    "structure": 1.25,
    "volume_flow": 0.55,
    "derivatives": 0.85,
    "pattern": 0.70,
    "forecast_path": 0.45,
    "ai_vote": 0.60,
    "data_trust": 1.35,
    "learning_v32": 0.70,
}
_CENTRAL_WEIGHTS: dict[str, float] = dict(_CENTRAL_WEIGHTS_DEFAULT)
_CENTRAL_MIN_EDGE = 0.15
_CENTRAL_MIN_MARGIN = 0.09
_CENTRAL_MIN_TRUST = 48.0
_CENTRAL_MIN_EDGE_SHORT = 0.18
_CENTRAL_MIN_MARGIN_SHORT = 0.12
