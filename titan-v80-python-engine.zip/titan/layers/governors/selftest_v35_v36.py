# [TITAN V77 layer] governors/selftest_v35_v36 - Self-test: V35/V36 fixtures
# Original V76 source lines 16978-17186 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# TITAN SELF-TEST — V35/V36 gate fixtures (no network required)
# Run:  python TITAN_V36_ANDROID_FINAL.py --self-test
# ============================================================

def _titan_self_test() -> int:
    """Return 0 on success, 1 on failure. Offline unit checks for critical gates."""
    failures: list[str] = []

    def check(name: str, cond: bool, detail: str = "") -> None:
        if not cond:
            failures.append(f"FAIL {name}: {detail}")
            print(f"  ✗ {name} — {detail}")
        else:
            print(f"  ✓ {name}")

    print("=" * 60)
    print("TITAN SELF-TEST · V35/V36/V42/V43/V44 gates + helpers")
    print("=" * 60)

    check("clamp_mid", clamp(50, 0, 100) == 50.0)
    check("clamp_hi", clamp(150, 0, 100) == 100.0)
    check("normalize_symbol", _normalize_symbol("btc") == "BTC/USDT")
    check("binance_symbol", _binance_symbol("ETH/USDT") == "ETHUSDT")

    if "_v36_horizon_agreement" in globals():
        longish = {
            "tf_scores": {"15m": 62, "1h": 64, "4h": 68, "1d": 66},
            "decision_tag": "LONG",
            "candle_forecast": {"overall_bias": "صعودی"},
            "structure": {"bias": "صعودی"},
        }
        ag = _v36_horizon_agreement(longish)
        check("v36_agree_long_dir", ag.get("direction") == "LONG", str(ag))
        check("v36_agree_aligned", ag.get("aligned_with_decision") is True, str(ag))
        check("v36_agree_score", safe_float(ag.get("agreement"), 0) > 0.3, str(ag))

        conflict = {
            "tf_scores": {"15m": 30, "1h": 28, "4h": 25, "1d": 22},
            "decision_tag": "LONG",
            "candle_forecast": {"overall_bias": "نزولی"},
            "structure": {"bias": "نزولی"},
        }
        ag2 = _v36_horizon_agreement(conflict)
        check("v36_agree_conflict_short", ag2.get("direction") == "SHORT", str(ag2))

    if "_v36_price_drift_gate" in globals():
        d0 = _v36_price_drift_gate({
            "decision_tag": "LONG", "price_raw": 100.5,
            "signal_snapshot": {"price": 100.0},
        })
        check("v36_drift_safe", d0.get("kill") is False, str(d0))
        d1 = _v36_price_drift_gate({
            "decision_tag": "LONG", "price_raw": 103.0,
            "signal_snapshot": {"price": 100.0},
        })
        check("v36_drift_kill_long", d1.get("kill") is True, str(d1))
        d2 = _v36_price_drift_gate({
            "decision_tag": "SHORT", "price_raw": 97.0,
            "signal_snapshot": {"price": 100.0},
        })
        check("v36_drift_kill_short", d2.get("kill") is True, str(d2))

    if "_v36_cross_asset_resonance" in globals():
        rows = [{"symbol": f"ALT{i}/USDT", "decision_tag": "LONG"} for i in range(7)]
        res = _v36_cross_asset_resonance("BTC/USDT", "LONG", rows)
        check("v36_cluster_penalty", safe_float(res.get("penalty"), 0) >= 5.0, str(res))
        res2 = _v36_cross_asset_resonance("BTC/USDT", "WAIT", rows)
        check("v36_cluster_wait_zero", safe_float(res2.get("penalty"), 0) == 0.0, str(res2))

    if "_v36_apply" in globals():
        item = {
            "symbol": "BTC/USDT", "decision_tag": "LONG", "decision": "LONG",
            "bias": "صعودی", "decision_confidence": 70.0,
            "price_raw": 104.0, "live_price": 104.0,
            "signal_snapshot": {"price": 100.0},
            "tf_scores": {"15m": 60, "1h": 61, "4h": 62, "1d": 63},
            "candle_forecast": {"overall_bias": "صعودی"},
            "structure": {"bias": "صعودی"},
        }
        out = _v36_apply(dict(item), [])
        check("v36_apply_kills_drift", out.get("decision_tag") == "WAIT", str(out.get("v36_resonance")))
        check("v36_apply_has_pack", isinstance(out.get("v36_resonance"), dict))

        item2 = {
            "symbol": "ETH/USDT", "decision_tag": "LONG", "decision": "LONG",
            "bias": "صعودی", "decision_confidence": 70.0,
            "price_raw": 100.2, "live_price": 100.2,
            "signal_snapshot": {"price": 100.0},
            "tf_scores": {"15m": 65, "1h": 66, "4h": 70, "1d": 68},
            "candle_forecast": {"overall_bias": "صعودی"},
            "structure": {"bias": "صعودی"},
        }
        out2 = _v36_apply(dict(item2), [])
        check("v36_apply_keeps_aligned_long", out2.get("decision_tag") == "LONG", str(out2.get("v36_resonance")))

    if "_v35_rebase_price_dependent_outputs" in globals():
        card = {
            "decision_tag": "WAIT", "decision": "WAIT",
            "price_raw": 100.0, "price": "100", "entry_raw": 100.0,
            "candle_forecast": {
                "last_price": 100.0,
                "candles": [{"open": 100, "high": 101, "low": 99, "close": 100.5,
                             "mid": 100.5, "band_low": 99, "band_high": 102}],
            },
        }
        snap = {"price": 110.0, "ts": time.time(), "age_sec": 0.5, "source": "test"}
        rebased = _v35_rebase_price_dependent_outputs(dict(card), snap)
        check("v35_rebase_price", abs(safe_float(rebased.get("price_raw"), 0) - 110.0) < 1e-9)
        check("v35_rebase_live_sync", rebased.get("live_sync") is True)
        check(
            "v35_forecast_anchor",
            abs(safe_float((rebased.get("candle_forecast") or {}).get("last_price"), 0) - 110.0) < 1e-6,
        )

    if "_v12_level_integrity" in globals():
        ok = _v12_level_integrity(100.0, 95.0, 108.0, 115.0, "LONG")
        check("v12_long_levels_ok", bool(ok.get("ok")), str(ok))
        bad = _v12_level_integrity(100.0, 105.0, 108.0, 115.0, "LONG")
        check("v12_long_levels_bad", not bool(bad.get("ok")), str(bad))

    if "_v42_integrity_seal" in globals():
        good = {
            "symbol": "BTC/USDT", "decision_tag": "LONG", "decision": "LONG",
            "price_raw": 100.0, "live_price": 100.0, "live_price_age_sec": 1.0,
            "data_quality": {"score": 80}, "stop_loss_raw": 95.0,
            "tp1_raw": 108.0, "tp2_raw": 115.0, "probability_calibration": {"samples": 0, "is_calibrated": False},
        }
        g = _v42_integrity_seal(good)
        check("v42_valid_long", g.get("decision_tag") == "LONG", str(g.get("v42_integrity")))
        bad = dict(good, live_price_age_sec=30.0)
        b = _v42_integrity_seal(bad)
        check("v42_stale_blocks", b.get("decision_tag") == "WAIT", str(b.get("v42_integrity")))
        bad2 = dict(good, stop_loss_raw=105.0)
        b2 = _v42_integrity_seal(bad2)
        check("v42_bad_levels_block", b2.get("decision_tag") == "WAIT", str(b2.get("v42_integrity")))

    if "_v43_unified_decide" in globals():
        u = _v43_unified_decide({
            "symbol":"TEST/USDT", "price_raw":100.0, "live_price":100.0, "live_price_age_sec":1.0,
            "data_quality":{"score":80}, "tf_scores":{"15m":65,"1h":68,"4h":70,"1d":66},
            "score":68, "structure":{"bias":"LONG","event":"BOS_UP","confirmation_score":75},
            "regime":{"regime":"trend_up","confidence":80}, "liquidity":{"pressure":0.25},
            "precision":{"score":72}, "neural_v9":{"neural_score":70,"confidence":75,"side":"LONG"},
            "v31_edge_suite":{"evidence_fusion":{"independence_score":0.8},"adversarial":{"robustness":75},"entry_stability":{"score":78},"uncertainty":{"uncertainty":20},"safety_wait":False},
            "v34_opportunity":{"score":72}, "v36_resonance":{"penalty":0},
            "v40_precision":{"score":75,"hard_blocks":[]}, "btc_trend":"صعودی",
            "candle_forecast":{"overall_bias":"صعودی","expected_move_pct":1.2},
            "probability_calibration":{"calibrated":65,"samples":100,"is_calibrated":True},
            "v32_learning":{"long_adjustment":2.0,"short_adjustment":0.2},
            "stop_loss_raw":98.0,"tp1_raw":104.0,"tp2_raw":108.0,
        })
        check("v43_unified_governor", u.get("decision") in {"LONG","SHORT","WAIT"} and isinstance(u.get("unified_central"),dict), str(u))
        check("v43_participation", safe_float((u.get("unified_central") or {}).get("participation",{}).get("active_components"),0) >= V43_MIN_COMPONENTS, str((u.get("unified_central") or {}).get("participation")))

    if "_v44_policy_stats" in globals():
        st = _v44_policy_stats("NO_SUCH_SYMBOL/USDT")
        check("v44_policy_default", safe_float((st.get("thresholds") or {}).get("edge"),0) == V44_BASE_EDGE, str(st))
    if "_v44_apply_opportunity_policy" in globals():
        candidate = {
            "symbol":"TEST/USDT", "decision_tag":"WAIT", "decision":"WAIT",
            "price_raw":100.0, "live_price":100.0, "live_price_age_sec":1.0,
            "data_quality":{"score":85}, "tf_scores":{"15m":68,"1h":72,"4h":74,"1d":70},
            "unified_central":{"candidate":"LONG","long_score":0.40,"short_score":0.12,"edge":0.40,"margin":0.28,"trust":80,"confidence":78,
                "participation":{"hard_vetoes":[]}},
            "v40_precision":{"score":78,"hard_blocks":[]},
            "v42_integrity":{"passed":True,"reasons":[]},
            "stop_loss_raw":95.0,"tp1_raw":108.0,"tp2_raw":115.0,
        }
        promoted = _v44_apply_opportunity_policy(candidate)
        check("v44_promotes_quality_wait", promoted.get("decision_tag") in {"LONG","WAIT"}, str(promoted.get("v44_opportunity")))
        blocked = dict(candidate, v40_precision={"hard_blocks":["invalid_levels"]})
        blocked_out = _v44_apply_opportunity_policy(blocked)
        check("v44_respects_hard_block", blocked_out.get("decision_tag") == "WAIT", str(blocked_out.get("v44_opportunity")))

    if "V44_VERSION" in globals():
        sample = {
            "symbol": "TEST/USDT", "price_raw": 100.0, "live_price": 100.0,
            "data_quality": {"score": 80}, "tf_scores": {"15m": 65, "1h": 66, "4h": 68},
            "score": 65, "taker_buy_pct": 62,
            "precision": {"score": 95}, "v40_precision": {"score": 95, "hard_blocks": []},
            "v31_edge_suite": {"adversarial": {"robustness": 90}, "entry_stability": {"score": 90}},
            "v34_opportunity": {"score": 90},
            "probability_calibration": {"calibrated": 90, "samples": 200, "is_calibrated": True},
            "candle_forecast": {"expected_move_pct": 2.0},
            "stop_loss_raw": 97.0, "tp1_raw": 105.0, "tp2_raw": 108.0,
        }
        ev, part = _v43_unified_evidence(sample)
        check("v44_quality_not_direction", all(k not in ev for k in ("precision_engine", "v31_edge_suite", "v34_opportunity", "v40_precision", "realized_calibration", "forecast_engine")), str(list(ev)))
        check("v44_unsigned_forecast_not_direction", "forecast_direction" not in ev, str(ev.get("forecast_direction")))
        check("v44_balanced_thresholds", _CENTRAL_MIN_EDGE <= 0.12 and _CENTRAL_MIN_MARGIN <= 0.055, f"edge={_CENTRAL_MIN_EDGE}, margin={_CENTRAL_MIN_MARGIN}")

    audit = titan_system_audit() if "titan_system_audit" in globals() else {"passed": False}
    check("system_audit", bool(audit.get("passed")), str(audit))

    print("-" * 60)
    if failures:
        print(f"SELF-TEST FAILED: {len(failures)} check(s)")
        for f in failures:
            print(" ", f)
        return 1
    print("SELF-TEST PASSED")
    return 0
