# [TITAN V77 layer] governors/v45_validated_decisions - V45 validated decisions / shadow learning
# Original V76 source lines 16235-16977 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# TITAN V45 — COHERENT VALIDATED DECISIONS · HONEST BACKTEST · SHADOW LEARNING
# ------------------------------------------------------------
# Root causes fixed here (found by auditing V44 against the live WAL log):
#  1. WAIT candidates were judged with NEUTRAL symmetric SL/TP (RR≈1.0, and
#     inverted levels for SHORT), so `weak_rr` / `invalid_levels` fired on every
#     candidate and V44 promotion could never succeed.  V45 rebuilds levels
#     for the candidate side before judging it.
#  2. Learning deadlock: WAIT never produced samples, so policy stayed at
#     0 samples / default 50 %.  V45 records every directional candidate as a
#     SHADOW sample (no capital), evaluates it with chronological first-touch,
#     and feeds the result back into the gate.
#  3. Backtest held 1 bar with no SL/TP and ignored that costs (0.16 %) eat
#     more than half of a 1h move.  V45 simulates the SAME ATR levels the live
#     system publishes, reports gross vs net, one-trade-at-a-time, a random-entry
#     baseline and train-only walk-forward with abstention.
#  4. Duplicate arbiter/overlap log rows (same symbol, same second).
# Nothing here can guarantee profit.  V45 only publishes a directional signal
# when evidence, costs, levels and learned outcomes are mutually consistent.
# ============================================================
V45_VERSION = "TITAN-V45-COHERENT-VALIDATED-LEARNING"
V45_FRICTION_PCT = TOTAL_ENTRY_BUFFER * 2.0 * 100.0     # round-trip fee+spread+slippage, in %
V45_SL_ATR = 1.5
V45_RR1 = 1.6
V45_RR2 = 2.8
V45_MIN_RISK_ATR = 1.0
V45_MAX_RISK_ATR = 2.4
V45_MAX_COST_R = 0.35            # cost must stay below 0.35R, otherwise the trade is not worth its friction
V45_TF_MAX_HOLD = {"1m": 60, "5m": 48, "15m": 32, "30m": 24, "1h": 16, "4h": 10, "1d": 7}
V45_SHADOW_HORIZON_MIN = 240
V45_SHADOW_COOLDOWN = 2700
V45_MIN_VALIDATED_N = 20
V45_PRIOR_P = 0.45               # deliberately below a coin flip: no edge is assumed
V45_PRIOR_STRENGTH = 12.0
V45_TIER_A_MAX_SOFT = 0.5
V45_TIER_B_MAX_SOFT = 1.5
V45_EXPLORE_MAX_SOFT = 1.0
V45_EXPLORE_MAX_PER_HOUR = 6
V45_SIDE_SHARE_MAX = 0.70
V45_SOFT_WEIGHTS = {
    "regime_conflict": 1.0, "structure_not_confirmed": 1.0, "structure_confidence_low": 0.5,
    "regime_confidence_low": 0.5, "mtf_alignment_low": 0.75, "liquidity_flow_conflict": 1.0,
    "entry_quality_low": 0.75,
}
V45_LEVEL_REASONS = {"weak_rr", "invalid_levels", "rr1_below_floor", "rr2_below_floor",
                     "invalid_directional_levels", "stop_distance_extreme"}
V45_META_REASONS = {"REAL_EDGE_FINAL_GATE"}

_V45_EXPLORE_LOCK = threading.Lock()
_V45_EXPLORE_LOG: list[tuple[float, str]] = []
_V45_PUBLISHED: dict[tuple[str, str], float] = {}
_V45_EVAL_STATE = {"last": 0.0}


# ---------------------------------------------------------------- levels / simulation
def _v45_rr_levels(price: float, atr: float, side: str, anchor: Optional[float] = None,
                   rr1: float = V45_RR1, rr2: float = V45_RR2) -> Optional[dict[str, float]]:
    """Oriented ATR levels for the candidate side (pure price levels; costs are charged separately)."""
    try:
        price = float(price); atr = float(atr)
    except (TypeError, ValueError):
        return None
    if side not in {"LONG", "SHORT"} or not (price > 0 and atr > 0 and math.isfinite(price) and math.isfinite(atr)):
        return None
    risk = V45_SL_ATR * atr
    if anchor and anchor > 0:
        dist = (price - anchor) if side == "LONG" else (anchor - price)
        if dist > 0:
            risk = clamp(dist + 0.25 * atr, V45_MIN_RISK_ATR * atr, V45_MAX_RISK_ATR * atr)
    sgn = 1.0 if side == "LONG" else -1.0
    sl = price - sgn * risk
    tp1 = price + sgn * rr1 * risk
    tp2 = price + sgn * rr2 * risk
    if sl <= 0:
        return None
    risk_pct = risk / price * 100.0
    return {"sl": sl, "tp1": tp1, "tp2": tp2, "risk": risk, "risk_pct": risk_pct,
            "rr1": rr1, "rr2": rr2, "cost_r": V45_FRICTION_PCT / max(risk_pct, 1e-9)}


def _v45_sim_trade(arr: dict[str, Any], i: int, side: str, max_hold: int,
                   anchor: Optional[float] = None) -> Optional[dict[str, Any]]:
    """Signal at close of bar i -> enter at OPEN of bar i+1; SL/TP1 on high/low; same-bar tie = SL (conservative)."""
    o, h, l, c, atr = arr["o"], arr["h"], arr["l"], arr["c"], arr["atr"]
    n = len(c)
    if i + 1 >= n:
        return None
    entry = float(o[i + 1])
    lv = _v45_rr_levels(entry, float(atr[i]), side, anchor)
    if not lv:
        return None
    sl, tp1 = lv["sl"], lv["tp1"]
    last = min(n - 1, i + max_hold)
    exit_px, outcome, exit_idx = float(c[last]), "TIME", last
    for j in range(i + 1, last + 1):
        hi, lo, op = float(h[j]), float(l[j]), float(o[j])
        if side == "LONG":
            if op <= sl:
                exit_px, outcome, exit_idx = op, "SL", j; break
            if op >= tp1:
                exit_px, outcome, exit_idx = op, "TP1", j; break
            sl_hit, tp_hit = lo <= sl, hi >= tp1
        else:
            if op >= sl:
                exit_px, outcome, exit_idx = op, "SL", j; break
            if op <= tp1:
                exit_px, outcome, exit_idx = op, "TP1", j; break
            sl_hit, tp_hit = hi >= sl, lo <= tp1
        if sl_hit:
            exit_px, outcome, exit_idx = sl, "SL", j; break
        if tp_hit:
            exit_px, outcome, exit_idx = tp1, "TP1", j; break
    gross = ((exit_px - entry) / entry * 100.0) if side == "LONG" else ((entry - exit_px) / entry * 100.0)
    net = gross - V45_FRICTION_PCT
    return {"i": int(i), "side": side, "entry": entry, "exit": exit_px, "outcome": outcome,
            "gross_pct": gross, "net_pct": net, "r_net": net / max(lv["risk_pct"], 1e-9),
            "risk_pct": lv["risk_pct"], "cost_r": lv["cost_r"], "exit_idx": int(exit_idx),
            "bars": int(exit_idx - i)}


def _v45_arrays(df: "pd.DataFrame") -> dict[str, Any]:
    return {"o": df["open"].astype(float).to_numpy(), "h": df["high"].astype(float).to_numpy(),
            "l": df["low"].astype(float).to_numpy(), "c": df["close"].astype(float).to_numpy(),
            "atr": calc_atr(df).astype(float).to_numpy()}


def _v45_signal_table(df: "pd.DataFrame", warmup: int = 60, window: int = 200) -> list[tuple]:
    """Causal per-bar forecast table computed once and reused across the whole parameter grid."""
    rows: list[tuple] = []
    for i in range(warmup, len(df) - 2):
        sample = df.iloc[max(0, i + 1 - window): i + 1]
        direction, score, meta = _tf_forecast(sample)
        m = meta or {}
        rows.append((i, direction, float(score), safe_float(m.get("rsi"), 50.0), safe_float(m.get("ema_gap"), 0.0),
                     safe_float(m.get("momentum"), 0.0), safe_float(m.get("adx"), 20.0)))
    return rows


def _v45_pick_side(row: tuple, p: dict[str, float]) -> Optional[str]:
    _, direction, score, rsi_v, gap, mom, adx = row
    if adx < p.get("adx_min", 0):
        return None
    if direction == "صعودی" and score >= p["long_thr"] and gap >= -0.15:
        return "LONG"
    if (direction == "نزولی" and score <= p["short_thr"] and gap <= 0.10 and mom <= 0.15
            and not (rsi_v < 22 and mom > -0.5)):
        return "SHORT"
    return None


def _v45_run_sim(arr: dict[str, Any], table: list[tuple], p: dict[str, float], start: int, end: int,
                 max_hold: int) -> list[dict[str, Any]]:
    trades: list[dict[str, Any]] = []
    busy = -1
    for row in table:
        i = row[0]
        if i < start or i >= end or i <= busy:
            continue
        side = _v45_pick_side(row, p)
        if not side:
            continue
        t = _v45_sim_trade(arr, i, side, max_hold)
        if t:
            trades.append(t); busy = t["exit_idx"]
    return trades


def _v45_random_baseline(arr: dict[str, Any], n_trades: int, long_frac: float, max_hold: int,
                         start: int, end: int, iters: int = 300, seed: int = 11) -> list[float]:
    rng = np.random.default_rng(seed)
    means: list[float] = []
    if n_trades < 5 or end - start < 20:
        return means
    for _ in range(iters):
        idx = np.sort(rng.integers(start, end, size=n_trades * 3))
        busy = -1; rs: list[float] = []
        for i in idx:
            if i <= busy:
                continue
            t = _v45_sim_trade(arr, int(i), "LONG" if rng.random() < long_frac else "SHORT", max_hold)
            if t:
                rs.append(t["r_net"]); busy = t["exit_idx"]
            if len(rs) >= n_trades:
                break
        if rs:
            means.append(float(np.mean(rs)))
    return means


def _v45_trade_metrics(trades: list[dict[str, Any]]) -> dict[str, Any]:
    net = [t["net_pct"] for t in trades]
    m = _safe_return_series(net, return_unit="pct")
    rs = np.asarray([t["r_net"] for t in trades], dtype=float) if trades else np.asarray([], dtype=float)
    gw = sum(1 for t in trades if t["gross_pct"] > 0)
    m["gross_win_rate"] = round(gw / len(trades) * 100, 2) if trades else 0.0
    m["expectancy_r"] = round(float(rs.mean()), 4) if rs.size else 0.0
    m["expectancy_r_se"] = round(float(rs.std(ddof=1) / math.sqrt(rs.size)), 4) if rs.size > 1 else None
    m["avg_cost_r"] = round(float(np.mean([t["cost_r"] for t in trades])), 3) if trades else 0.0
    m["avg_bars_held"] = round(float(np.mean([t["bars"] for t in trades])), 2) if trades else 0.0
    m["tp1_hits"] = sum(1 for t in trades if t["outcome"] == "TP1")
    m["sl_hits"] = sum(1 for t in trades if t["outcome"] == "SL")
    m["time_exits"] = sum(1 for t in trades if t["outcome"] == "TIME")
    return m


def _v45_verdict(metrics: dict[str, Any], rnd_pct: Optional[float], oos: dict[str, Any]) -> str:
    """EDGE_SUPPORTED needs: >=30 trades, PF>=1.1, positive OOS expectancy, expectancy lower bound (1.64 SE) > 0
    and, when a random-entry baseline exists, >=90th percentile of it. Anything weaker is never called an edge."""
    n = int(metrics.get("trades") or 0)
    if n < 30:
        return "INSUFFICIENT_SAMPLE"
    exp_r = safe_float(metrics.get("expectancy_r"), 0.0)
    se = metrics.get("expectancy_r_se")
    lcb = exp_r - 1.64 * safe_float(se, 9.0)
    pf = safe_float(metrics.get("profit_factor"), 0.0)
    oos_e = safe_float((oos or {}).get("oos_expectancy"), 0.0)
    rnd_ok = True if rnd_pct is None else rnd_pct >= 90
    if exp_r > 0 and lcb > 0 and pf >= 1.1 and oos_e > 0 and rnd_ok:
        return "EDGE_SUPPORTED"
    if exp_r > 0 and (rnd_pct is None or rnd_pct >= 75):
        return "WEAK_POSITIVE_UNPROVEN"
    return "NO_EDGE_PROVEN"


def backtest_signal_logic(symbol: str, tf: str = "1h", limit: int = 1000, df_override: Optional["pd.DataFrame"] = None) -> dict[str, Any]:
    """Honest proxy backtest: the SAME ATR SL/TP1 levels V45 publishes, first-touch on OHLC, entry at next open,
    one trade at a time, costs charged once, gross vs net, random-entry baseline. Still technical-only
    (no historical AI/derivatives) — that limitation is stated in the output."""
    limit = min(max(int(limit), 100), MAX_BACKTEST_CANDLES)
    try:
        df = df_override if df_override is not None else fetch_klines(symbol, tf, limit)
    except Exception as exc:
        return {"ok": False, "error": str(exc), "symbol": symbol, "timeframe": tf}
    if df is None or len(df) < 120:
        return {"ok": False, "error": "داده تاریخی کافی نیست", "symbol": symbol, "timeframe": tf}
    df = df.reset_index(drop=True)
    max_hold = V45_TF_MAX_HOLD.get(str(tf), 12)
    arr = _v45_arrays(df)
    table = _v45_signal_table(df)
    params = {"long_thr": 55.0, "short_thr": 42.0, "adx_min": 0.0}
    trades = _v45_run_sim(arr, table, params, 60, len(df) - 2, max_hold)
    longs = [t for t in trades if t["side"] == "LONG"]
    shorts = [t for t in trades if t["side"] == "SHORT"]
    m = _v45_trade_metrics(trades)
    long_m, short_m = _v45_trade_metrics(longs), _v45_trade_metrics(shorts)
    returns = [t["net_pct"] for t in trades]
    oos = TITAN_EDGE_SUITE.out_of_sample_check(returns, return_unit="pct")
    governor = TITAN_EDGE_SUITE.drawdown_governor(returns, unit="pct")
    strategies = TITAN_EDGE_SUITE.strategy_lab(df)
    rnd = _v45_random_baseline(arr, len(trades), (len(longs) / len(trades)) if trades else 0.5, max_hold, 60, len(df) - 2)
    actual_r = m["expectancy_r"]
    rnd_pct = round(100.0 * sum(1 for x in rnd if x < actual_r) / len(rnd), 1) if rnd else None
    verdict = _v45_verdict(m, rnd_pct, oos)
    paths = {"TP1": m["tp1_hits"], "TP2": 0, "SL": m["sl_hits"], "NONE": m["time_exits"]}
    bh = round((float(arr["c"][-1]) / float(arr["c"][0]) - 1.0) * 100.0, 2)
    return {
        "ok": True, "symbol": symbol, "timeframe": tf, "candles": len(df), "metrics": m,
        "validation_scope": "technical_proxy_only_no_historical_ai_or_derivatives",
        "long_metrics": long_m, "short_metrics": short_m,
        "long_signals": len(longs), "short_signals": len(shorts), "directional_signals": len(trades),
        "from": float(df["t"].iloc[0]), "to": float(df["t"].iloc[-1]),
        "return_series_pct": [round(float(x), 6) for x in returns[-1500:]],
        "filters": {"long": "score>=58 + ema_gap>=-0.15", "short": "score<=40 + ema_gap<=0.10 + momentum<=0.15 + not panic-oversold trap",
                    "note": "SL/TP1 = ATR levels identical to live V45; one trade at a time; entry at next open"},
        "v45": {
            "version": V45_VERSION, "verdict": verdict, "max_hold_bars": max_hold,
            "entry_model": "next_bar_open", "same_bar_sl_tp_rule": "SL_FIRST_CONSERVATIVE",
            "round_trip_cost_pct": round(V45_FRICTION_PCT, 4),
            "gross_win_rate": m["gross_win_rate"], "net_win_rate": m["win_rate"],
            "expectancy_r_net": m["expectancy_r"], "avg_cost_r": m["avg_cost_r"],
            "random_entry_percentile": rnd_pct, "random_entry_mean_r": round(float(np.mean(rnd)), 4) if rnd else None,
            "buy_and_hold_pct": bh,
            "reading": ("تا وقتی verdict برابر EDGE_SUPPORTED نشده، این منطق لبه‌ی اثبات‌شده ندارد؛ "
                        "win rate بدون در نظر گرفتن R و هزینه معنا ندارد."),
        },
        "professional": {
            "oos": oos, "drawdown_governor": governor,
            "counterfactual": {"paths": paths, "sample": len(trades)},
            "strategy_lab": strategies,
            "meta_labeling_reference": "V45 shadow outcomes + OOS + side-split",
        },
    }


def walk_forward_backtest(symbol: str, tf: str = "1h", limit: int = 1200, train: int = 300, test: int = 100,
                          df_override: Optional["pd.DataFrame"] = None, table_override: Optional[list] = None) -> dict[str, Any]:
    """Train-only selection by lower-confidence-bound expectancy (R), purge = max hold, and ABSTAIN when no
    parameter set shows a positive lower bound in training (a selective system should be allowed to say 'no trade')."""
    limit = min(max(int(limit), train + test + 100), MAX_BACKTEST_CANDLES)
    try:
        df = df_override if df_override is not None else fetch_klines(symbol, tf, limit)
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    if df is None or len(df) < train + test + 100:
        return {"ok": False, "error": "داده تاریخی کافی نیست"}
    df = df.reset_index(drop=True)
    max_hold = V45_TF_MAX_HOLD.get(str(tf), 12)
    arr = _v45_arrays(df); table = table_override if table_override is not None else _v45_signal_table(df)
    grid = [{"long_thr": float(lt), "short_thr": float(st), "adx_min": float(ax)}
            for lt in (58, 62, 66) for st in (42, 38, 34) for ax in (0, 20)]
    purge = max_hold
    windows, chosen = [], []
    all_test: list[dict[str, Any]] = []
    i = 60
    while i + train + purge + test <= len(df) - 2:
        tr_end = i + train - max_hold
        scored = []
        for p in grid:
            tr = _v45_run_sim(arr, table, p, i, tr_end, max_hold)
            if len(tr) < 10:
                continue
            rs = np.asarray([t["r_net"] for t in tr], dtype=float)
            lcb = float(rs.mean() - rs.std(ddof=1) / math.sqrt(len(rs)))
            scored.append((lcb, p, len(tr), float(rs.mean())))
        te_start = i + train + purge
        if scored:
            best = max(scored, key=lambda z: z[0])
        else:
            best = None
        abstain = best is None or best[0] <= -0.05
        if abstain:
            te = []
            chosen.append(None)
        else:
            te = _v45_run_sim(arr, table, best[1], te_start, te_start + test, max_hold)
            chosen.append(best[1])
        wm = _v45_trade_metrics(te)
        wm["abstained"] = bool(abstain)
        wm["selected_params"] = None if abstain else best[1]
        wm["train_lcb_r"] = None if best is None else round(best[0], 4)
        wm["train_trades"] = 0 if best is None else best[2]
        windows.append(wm); all_test.extend(te)
        i += test
    agg = _v45_trade_metrics(all_test)
    longs = [t for t in all_test if t["side"] == "LONG"]; shorts = [t for t in all_test if t["side"] == "SHORT"]
    used = [p for p in chosen if p]
    stability = {}
    for name in ("long_thr", "short_thr", "adx_min"):
        vals = [p[name] for p in used]
        if vals:
            stability[name] = {"min": min(vals), "max": max(vals), "mean": round(float(np.mean(vals)), 3), "unique": len(set(vals))}
    returns = [t["net_pct"] for t in all_test]
    oos_pro = TITAN_EDGE_SUITE.out_of_sample_check(returns, return_unit="pct")
    abst = sum(1 for p in chosen if p is None)
    # V78.2 strengthened summary
    win_rets = []
    for wm in windows:
        if wm.get("abstained"):
            continue
        n = int(wm.get("trades") or wm.get("n") or 0)
        if n <= 0:
            continue
        # prefer mean net pct if present
        mr = wm.get("mean_net_pct")
        if mr is None:
            mr = wm.get("avg_net_pct") or wm.get("expectancy") or 0
        win_rets.append(float(mr or 0))
    consistency = None
    if win_rets:
        pos = sum(1 for x in win_rets if x > 0)
        consistency = {
            "positive_windows": pos,
            "total_active_windows": len(win_rets),
            "hit_rate": round(pos / len(win_rets), 3),
            "mean_window_ret": round(float(np.mean(win_rets)), 4),
            "std_window_ret": round(float(np.std(win_rets)), 4) if len(win_rets) > 1 else 0.0,
        }
    sharpe_like = None
    if returns and len(returns) > 2:
        mu = float(np.mean(returns)); sd = float(np.std(returns)) or 1e-9
        sharpe_like = round(mu / sd * (len(returns) ** 0.5), 3)
    return {
        "ok": True, "symbol": symbol, "timeframe": tf, "windows": len(windows), "aggregate": agg,
        "long_aggregate": _v45_trade_metrics(longs), "short_aggregate": _v45_trade_metrics(shorts),
        "window_metrics": windows, "purge_candles": purge,
        "validation_scope": "technical_proxy_v45_train_only_LCB_selection_purged_with_abstention",
        "parameter_stability": stability, "selected_parameters_history": chosen,
        "abstained_windows": abst, "abstained_share": round(abst / len(windows), 3) if windows else None,
        "verdict": _v45_verdict(agg, None, oos_pro),
        "professional": {"out_of_sample": oos_pro,
                         "drawdown_governor": TITAN_EDGE_SUITE.drawdown_governor(returns, unit="pct"),
                         "strategy_lab": TITAN_EDGE_SUITE.strategy_lab(df)},
        "v78": {
            "consistency": consistency,
            "sharpe_like": sharpe_like,
            "n_returns": len(returns),
            "mean_return_pct": round(float(np.mean(returns)), 4) if returns else None,
            "version": "TITAN-V78.2-WALKFORWARD",
        },
    }


# ---------------------------------------------------------------- shadow learning store
def _v45_init_tables() -> None:
    try:
        with DB_LOCK, db_conn() as con:
            con.execute("""CREATE TABLE IF NOT EXISTS v45_shadow(
                id INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL NOT NULL, symbol TEXT NOT NULL, side TEXT NOT NULL,
                regime TEXT DEFAULT '', price REAL, sl REAL, tp1 REAL, tp2 REAL, atr REAL, rr1 REAL, cost_r REAL,
                edge REAL, margin REAL, trust REAL, confidence REAL, soft_penalty REAL, blocks TEXT DEFAULT '',
                final_decision TEXT DEFAULT 'WAIT', mode TEXT DEFAULT '', outcome TEXT DEFAULT 'PENDING',
                hit_type TEXT DEFAULT '', r_net REAL, evaluated_at REAL, UNIQUE(symbol, side, created_at))""")
            con.execute("CREATE INDEX IF NOT EXISTS idx_v45_pending ON v45_shadow(outcome, created_at)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_v45_scope ON v45_shadow(side, regime, outcome, created_at)")
            con.commit()
    except Exception as exc:
        LOGGER.debug("V45 schema: %s", exc)


_v45_init_tables()


def _v45_record_shadow(symbol: str, side: str, regime: str, lv: Optional[dict[str, float]], price: float, atr: float,
                       ctx: dict[str, Any], final: str, mode: str, blocks: list[str], soft: float) -> None:
    if not lv or side not in {"LONG", "SHORT"}:
        return
    now = time.time()
    try:
        with DB_LOCK, db_conn() as con:
            if con.execute("SELECT 1 FROM v45_shadow WHERE symbol=? AND side=? AND created_at>=? LIMIT 1",
                           (symbol, side, now - V45_SHADOW_COOLDOWN)).fetchone():
                return
            con.execute(
                "INSERT OR IGNORE INTO v45_shadow(created_at,symbol,side,regime,price,sl,tp1,tp2,atr,rr1,cost_r,edge,margin,trust,confidence,soft_penalty,blocks,final_decision,mode) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
                (now, symbol, side, regime, price, lv["sl"], lv["tp1"], lv["tp2"], atr, lv["rr1"], lv["cost_r"],
                 safe_float(ctx.get("edge"), 0), safe_float(ctx.get("margin"), 0), safe_float(ctx.get("trust"), 0),
                 safe_float(ctx.get("confidence"), 0), soft, ",".join(blocks)[:400], final, mode))
            con.commit()
    except Exception as exc:
        LOGGER.debug("V45 shadow record: %s", exc)


def _v45_evaluate_shadow(limit: int = 25) -> int:
    """Chronological first-touch evaluation of matured shadow samples (AMBIGUOUS is excluded from learning)."""
    now = time.time()
    if now - _V45_EVAL_STATE["last"] < 90:
        return 0
    _V45_EVAL_STATE["last"] = now
    done = 0
    try:
        with DB_LOCK, db_conn() as con:
            con.execute("UPDATE v45_shadow SET outcome='EXPIRED', evaluated_at=? WHERE outcome='PENDING' AND created_at<?",
                        (now, now - 3 * 86400))
            rows = con.execute("SELECT * FROM v45_shadow WHERE outcome='PENDING' AND created_at<=? ORDER BY created_at LIMIT ?",
                               (now - V45_SHADOW_HORIZON_MIN * 60, limit)).fetchall()
            con.commit()
    except Exception:
        _swallow()
        return 0
    for row in rows:
        try:
            start_ms = int(float(row["created_at"]) * 1000)
            end_ms = int((float(row["created_at"]) + V45_SHADOW_HORIZON_MIN * 60) * 1000)
            df = fetch_klines(row["symbol"], "15m", int(V45_SHADOW_HORIZON_MIN / 15) + 6, start_ms=start_ms, end_ms=end_ms)
            window = df[(df["t"] >= start_ms) & (df["t"] <= end_ms)]
            if window.empty:
                continue
            side, price, sl, tp1 = str(row["side"]), float(row["price"]), float(row["sl"]), float(row["tp1"])
            outcome, hit, _ = _first_touch_ohlc(window, side, sl, tp1, None)
            risk_pct = abs(price - sl) / price * 100.0
            cost_r = V45_FRICTION_PCT / max(risk_pct, 1e-9)
            rr = abs(tp1 - price) / max(abs(price - sl), 1e-12)
            if outcome == "WIN":
                r = rr - cost_r
            elif outcome == "LOSS":
                r = -1.0 - cost_r
            elif outcome == "AMBIGUOUS":
                outcome, r = "AMBIGUOUS", None
            else:
                last = float(window["close"].iloc[-1])
                move = (last - price) / price * 100.0 if side == "LONG" else (price - last) / price * 100.0
                outcome, hit, r = "TIME_EXIT", "TIME", (move - V45_FRICTION_PCT) / max(risk_pct, 1e-9)
            with DB_LOCK, db_conn() as con:
                con.execute("UPDATE v45_shadow SET outcome=?, hit_type=?, r_net=?, evaluated_at=? WHERE id=?",
                            (outcome, hit, r, time.time(), row["id"]))
                con.commit()
            done += 1
        except Exception as exc:
            LOGGER.debug("V45 shadow eval #%s: %s", row["id"], exc)
    return done


def _v45_stats(side: str, regime: str = "", days: int = 30) -> dict[str, Any]:
    out = {"n": 0, "n_binary": 0, "wins": 0, "losses": 0, "win_rate": None, "exp_r": 0.0, "se": None,
           "p_post": V45_PRIOR_P, "state": "UNPROVEN", "scope": "none", "min_n": V45_MIN_VALIDATED_N}
    try:
        cutoff = time.time() - days * 86400

        def q(reg: str):
            sql = ("SELECT outcome, r_net FROM v45_shadow WHERE side=? AND outcome IN ('WIN','LOSS','TIME_EXIT') "
                   "AND r_net IS NOT NULL AND created_at>=?")
            args: list[Any] = [side, cutoff]
            if reg:
                sql += " AND regime=?"; args.append(reg)
            sql += " ORDER BY created_at DESC LIMIT 300"
            with DB_LOCK, db_conn() as con:
                return con.execute(sql, args).fetchall()

        rows = q(regime) if regime else []
        scope = f"{side}|{regime}" if regime else side
        if sum(1 for r in rows if r[0] in ("WIN", "LOSS")) < V45_MIN_VALIDATED_N:
            side_rows = q("")
            if len(side_rows) > len(rows):
                rows, scope = side_rows, side
        if not rows:
            return out
        wins = sum(1 for r in rows if r[0] == "WIN"); losses = sum(1 for r in rows if r[0] == "LOSS")
        nb = wins + losses
        rs = np.asarray([float(r[1]) for r in rows], dtype=float)
        n = int(rs.size)
        exp_r = float(rs.mean())
        se = float(rs.std(ddof=1) / math.sqrt(n)) if n > 1 else None
        p_post = (wins + V45_PRIOR_STRENGTH * V45_PRIOR_P) / (nb + V45_PRIOR_STRENGTH)
        state = "UNPROVEN"
        if nb >= V45_MIN_VALIDATED_N and se is not None:
            if exp_r - 0.5 * se > 0:
                state = "VALIDATED"
            elif exp_r + 0.5 * se < 0:
                state = "NEGATIVE"
        out.update({"n": n, "n_binary": nb, "wins": wins, "losses": losses,
                    "win_rate": round(100.0 * wins / nb, 2) if nb else None, "exp_r": round(exp_r, 4),
                    "se": round(se, 4) if se is not None else None, "p_post": round(p_post, 4),
                    "state": state, "scope": scope})
    except Exception as exc:
        out["error"] = str(exc)[:160]
    return out


# ---------------------------------------------------------------- policy
def _v45_regime_name(x: dict[str, Any]) -> str:
    try:
        real = (x.get("central_decision") or {}).get("real_edge") or x.get("real_edge") or {}
        name = real.get("regime") if isinstance(real, dict) else None
        if not name:
            rg = x.get("regime")
            name = rg.get("name") if isinstance(rg, dict) else rg
        return str(name or "UNKNOWN")[:24]
    except Exception:
        _swallow()
        return "UNKNOWN"


def _v45_candidate(x: dict[str, Any]) -> str:
    u = x.get("unified_central") or {}
    cand = str(u.get("candidate") or "").upper() if isinstance(u, dict) else ""
    if cand in {"LONG", "SHORT"}:
        return cand
    real = (x.get("central_decision") or {}).get("real_edge") or x.get("real_edge") or {}
    cand = str(real.get("candidate_direction") or "").upper() if isinstance(real, dict) else ""
    if cand in {"LONG", "SHORT"}:
        return cand
    cand = str(x.get("v42_blocked_candidate") or "").upper()
    return cand if cand in {"LONG", "SHORT"} else "WAIT"


def _v45_collect_reasons(x: dict[str, Any]) -> list[str]:
    out: list[str] = []
    real = (x.get("central_decision") or {}).get("real_edge") or x.get("real_edge") or {}
    if isinstance(real, dict):
        out += [str(r) for r in (real.get("no_trade_reasons") or [])]
    try:
        out += [str(r) for r in _v44_hard_safety_reasons(x)]
    except Exception:
        _swallow()
    integ = x.get("v42_integrity") or {}
    if isinstance(integ, dict):
        out += [str(r) for r in (integ.get("reasons") or [])]
    return list(dict.fromkeys(out))


def _v45_explore_slot(symbol: str, side: str) -> bool:
    now = time.time()
    with _V45_EXPLORE_LOCK:
        if now - _V45_PUBLISHED.get((symbol, side), 0.0) < V45_SHADOW_COOLDOWN:
            return True                                    # keep an already-published exploratory signal stable
        _V45_EXPLORE_LOG[:] = [e for e in _V45_EXPLORE_LOG if now - e[0] < 3600]
        total = len(_V45_EXPLORE_LOG); same = sum(1 for e in _V45_EXPLORE_LOG if e[1] == side)
        if total >= V45_EXPLORE_MAX_PER_HOUR:
            return False
        if total >= 4 and (same + 1) / (total + 1) > V45_SIDE_SHARE_MAX:
            return False
        _V45_EXPLORE_LOG.append((now, side)); _V45_PUBLISHED[(symbol, side)] = now
        return True


def _v45_wait(x: dict[str, Any], code: str, fa: str, audit: dict[str, Any]) -> dict[str, Any]:
    y = dict(x)
    if str(y.get("decision_tag") or "WAIT").upper() != "WAIT":
        y = _v40_force_wait(y, fa, code)
    y["v45"] = {"version": V45_VERSION, "published": False, "state": code, "reason_fa": fa, **audit}
    return y


def _v45_apply_policy(item: dict[str, Any]) -> dict[str, Any]:
    x = dict(item or {})
    symbol = _normalize_symbol(str(x.get("symbol") or ""))
    before = str(x.get("decision_tag") or x.get("decision") or "WAIT").upper()
    cand = before if before in {"LONG", "SHORT"} else _v45_candidate(x)
    if cand not in {"LONG", "SHORT"}:
        x["v45"] = {"version": V45_VERSION, "published": False, "state": "NO_CANDIDATE"}
        return x
    price = _v42_price(x); atr = safe_float(x.get("atr"), 0.0)
    structure = x.get("structure") if isinstance(x.get("structure"), dict) else {}
    anchor = safe_float(structure.get("swing_low" if cand == "LONG" else "swing_high"), 0.0)
    lv = _v45_rr_levels(price, atr, cand, anchor if anchor > 0 else None)
    regime = _v45_regime_name(x)
    u = x.get("unified_central") if isinstance(x.get("unified_central"), dict) else {}
    ctx = {"edge": safe_float(u.get("edge"), 0.0), "margin": safe_float(u.get("margin"), 0.0),
           "trust": safe_float(u.get("trust"), 0.0),
           "confidence": safe_float(u.get("confidence"), safe_float(x.get("decision_confidence"), 0.0))}
    reasons = _v45_collect_reasons(x)
    directional_origin = before in {"LONG", "SHORT"}
    hard, soft_hits = [], []
    for r in reasons:
        if r in V45_META_REASONS:
            continue
        if r in V45_SOFT_WEIGHTS:
            soft_hits.append(r)
        elif r in V45_LEVEL_REASONS:
            if directional_origin:
                hard.append(r)               # already directional: its own levels are authoritative
        else:
            hard.append(r)                   # unknown / safety reasons stay fail-closed
    softness = sum(V45_SOFT_WEIGHTS[r] for r in soft_hits)
    if not lv:
        hard.append("v45_levels_unavailable")
    elif lv["cost_r"] > V45_MAX_COST_R:
        hard.append("cost_too_high")
    stats = _v45_stats(cand, regime)
    th = (_v44_policy_stats(symbol, cand).get("thresholds") or {}) if "_v44_policy_stats" in globals() else {}
    evidence_ok = (ctx["edge"] >= safe_float(th.get("edge"), V44_BASE_EDGE) and ctx["margin"] >= safe_float(th.get("margin"), V44_BASE_MARGIN)
                   and ctx["trust"] >= safe_float(th.get("trust"), V44_BASE_TRUST) and ctx["confidence"] >= V44_MIN_CONFIDENCE)
    breakeven = ((1.0 + (lv["cost_r"] if lv else 0.0)) / (1.0 + (lv["rr1"] if lv else V45_RR1)))
    audit = {"candidate": cand, "regime": regime, "soft_penalty": round(softness, 2), "soft": soft_hits, "hard": hard,
             "evidence": {k: round(v, 4) for k, v in ctx.items()}, "evidence_ok": bool(evidence_ok),
             "thresholds": th, "shadow": stats, "breakeven_win_prob": round(breakeven, 4),
             "cost_r": round(lv["cost_r"], 3) if lv else None,
             "levels": {k: round(v, 8) for k, v in (lv or {}).items() if k in {"sl", "tp1", "tp2", "risk_pct"}}}

    def finish(res: dict[str, Any], mode: str) -> dict[str, Any]:
        _v45_record_shadow(symbol, cand, regime, lv, price, atr, ctx, str(res.get("decision_tag") or "WAIT").upper(),
                           mode, hard + soft_hits, softness)
        return res

    if directional_origin:
        if stats["state"] == "NEGATIVE" and stats["scope"] != "none":
            return finish(_v45_wait(x, "LEARNED_NEGATIVE_EV", "نتایج واقعی/سایه‌ای این سمت و رژیم، امید ریاضی منفی نشان می‌دهد؛ ورود متوقف شد.", audit), "DEMOTED_NEG")
        x["v45"] = {"version": V45_VERSION, "published": True, "state": "PASS_THROUGH", **audit}
        return finish(x, "PASS_THROUGH")
    if hard:
        return finish(_v45_wait(x, "HARD_BLOCK", "مانع سخت ریسک/داده/هزینه وجود دارد: " + "، ".join(hard[:4]), audit), "BLOCKED_HARD")
    if not evidence_ok:
        return finish(_v45_wait(x, "WATCH_NO_EDGE", "کاندید جهت‌دار وجود دارد ولی شواهد (edge/margin/trust/confidence) هنوز کافی نیست.", audit), "WATCH")
    if stats["state"] == "NEGATIVE":
        return finish(_v45_wait(x, "LEARNED_NEGATIVE_EV", "امید ریاضی سایه‌ای/واقعی این سمت منفی است؛ فعلاً فقط پایش.", audit), "BLOCKED_NEG")
    validated = stats["state"] == "VALIDATED"
    if validated and softness <= V45_TIER_A_MAX_SOFT:
        tier, mode, risk_mult = "READY", "VALIDATED", 1.0
    elif validated and softness <= V45_TIER_B_MAX_SOFT:
        tier, mode, risk_mult = "EARLY", "VALIDATED", 0.5
    elif not validated and softness <= V45_EXPLORE_MAX_SOFT and _v45_explore_slot(symbol, cand):
        tier, mode, risk_mult = "EXPLORATORY", "EXPLORATORY", 0.25
    else:
        return finish(_v45_wait(x, "WATCH_SOFT_BLOCKS", "شرایط هنوز کامل نیست (موانع نرم: " + ("، ".join(soft_hits) or "محدودیت نرخ اکتشاف") + ")؛ WAIT درست است.", audit), "WATCH")

    trial = dict(x)
    fmt = smart_format
    trial.update({
        "decision": cand, "decision_tag": cand, "bias": "صعودی" if cand == "LONG" else "نزولی",
        "entry_mode": "EARLY" if tier != "READY" else "READY",
        "stop_loss": fmt(lv["sl"]), "tp1": fmt(lv["tp1"]), "tp2": fmt(lv["tp2"]),
        "stop_loss_raw": float(lv["sl"]), "tp1_raw": float(lv["tp1"]), "tp2_raw": float(lv["tp2"]),
        "risk_distance_pct": round(lv["risk_pct"], 3), "rr_tp1": round(lv["rr1"], 2), "rr_tp2": round(lv["rr2"], 2),
        "effective_rr_tp1": round(lv["rr1"], 2), "effective_rr_tp2": round(lv["rr2"], 2),
        "signal_tag": {"READY": f"V45 آماده — {cand}", "EARLY": f"V45 اولیه (نیم‌ریسک) — {cand}",
                       "EXPLORATORY": f"V45 آزمایشی کم‌ریسک — {cand}"}[tier],
        "decision_state": f"V45_{mode}_{tier}_{cand}",
        "decision_confidence": round(clamp(ctx["confidence"], V44_MIN_CONFIDENCE, V44_MAX_CONFIDENCE), 2),
        "risk_multiplier_suggested": risk_mult, "signal_mode": mode, "paper_only": mode != "VALIDATED",
    })
    trial = _v42_integrity_seal(trial)
    if str(trial.get("decision_tag") or "WAIT").upper() != cand:
        audit["integrity"] = (trial.get("v42_integrity") or {}).get("reasons")
        return finish(_v45_wait(x, "INTEGRITY_RECHECK_FAILED", "بازبینی یکپارچگی سطوح/داده رد شد.", audit), "BLOCKED_INTEGRITY")
    trial["v45"] = {"version": V45_VERSION, "published": True, "tier": tier, "mode": mode, "risk_multiplier": risk_mult, **audit}
    arch = dict(trial.get("decision_architecture") or {})
    arch.update({"v45_policy": V45_VERSION, "final_decision": cand, "tier": tier, "mode": mode, "hard_safety_overridable": False})
    trial["decision_architecture"] = arch
    trial["authority"] = V45_VERSION
    return finish(trial, mode)


def _v44_apply_opportunity_policy(item: dict[str, Any]) -> dict[str, Any]:
    try:
        return _v45_apply_policy(item)
    except Exception as exc:
        LOGGER.warning("V45 policy failed, keeping upstream decision: %s", exc)
        y = dict(item or {})
        y["v45"] = {"version": V45_VERSION, "published": False, "state": "POLICY_ERROR", "error": str(exc)[:160]}
        return y


_V45_PREV_EVALUATE_PENDING = _central_evaluate_pending_v44


def _central_evaluate_pending() -> dict[str, Any]:
    result = _V45_PREV_EVALUATE_PENDING()
    try:
        k = _v45_evaluate_shadow()
        if isinstance(result, dict):
            result = dict(result); result["v45_shadow_evaluated"] = k
    except Exception:
        _swallow()
    return result


@app.get("/api/v45/status")
def api_v45_status():
    try:
        with DB_LOCK, db_conn() as con:
            modes = [dict(r) for r in con.execute(
                "SELECT mode, final_decision, COUNT(*) n FROM v45_shadow WHERE created_at>=? GROUP BY mode, final_decision",
                (time.time() - 86400,)).fetchall()]
            recent = [dict(r) for r in con.execute(
                "SELECT created_at,symbol,side,regime,mode,final_decision,outcome,r_net,soft_penalty,blocks FROM v45_shadow ORDER BY created_at DESC LIMIT 40").fetchall()]
        return jsonify({"ok": True, "version": V45_VERSION,
                        "stats": {"LONG": _v45_stats("LONG"), "SHORT": _v45_stats("SHORT")},
                        "last_24h_by_mode": modes, "recent": recent,
                        "config": {"rr1": V45_RR1, "sl_atr": V45_SL_ATR, "max_cost_r": V45_MAX_COST_R,
                                   "round_trip_cost_pct": round(V45_FRICTION_PCT, 4), "min_validated_n": V45_MIN_VALIDATED_N,
                                   "explore_max_per_hour": V45_EXPLORE_MAX_PER_HOUR},
                        "honesty": "هیچ تضمین سودی وجود ندارد؛ سیگنال EXPLORATORY فقط برای جمع‌آوری نمونه با ریسک ۰.۲۵ است."})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)[:240]}), 500


def _v45_self_test() -> int:
    fails: list[str] = []

    def chk(name: str, cond: bool, detail: str = "") -> None:
        print(("  ✓ " if cond else "  ✗ ") + name + ("" if cond else f" — {detail}"))
        if not cond:
            fails.append(name)

    print("=" * 60); print("TITAN V45 SELF-TEST"); print("=" * 60)
    lg = _v45_rr_levels(100.0, 1.0, "LONG"); sh = _v45_rr_levels(100.0, 1.0, "SHORT")
    chk("long_levels_oriented", bool(lg) and lg["sl"] < 100 < lg["tp1"] < lg["tp2"], str(lg))
    chk("short_levels_oriented", bool(sh) and sh["tp2"] < sh["tp1"] < 100 < sh["sl"], str(sh))
    chk("rr1_is_target", abs(lg["rr1"] - V45_RR1) < 1e-9 and abs((lg["tp1"] - 100) / (100 - lg["sl"]) - V45_RR1) < 1e-9)
    n = 40
    base = np.full(n, 100.0)
    mk = lambda hi, lo: {"o": base.copy(), "h": np.full(n, hi), "l": np.full(n, lo), "c": base.copy(), "atr": np.full(n, 1.0)}
    a = mk(103.0, 99.5); a["h"][5] = 103.0
    t = _v45_sim_trade(a, 2, "LONG", 10)
    chk("sim_long_tp1", bool(t) and t["outcome"] == "TP1" and t["gross_pct"] > 0, str(t))
    b = mk(100.2, 97.0)
    t = _v45_sim_trade(b, 2, "LONG", 10)
    chk("sim_long_sl", bool(t) and t["outcome"] == "SL" and t["r_net"] < -1.0, str(t))
    both = mk(103.5, 97.0)
    t = _v45_sim_trade(both, 2, "LONG", 10)
    chk("sim_same_bar_is_sl", bool(t) and t["outcome"] == "SL", str(t))
    flat = mk(100.3, 99.7)
    t = _v45_sim_trade(flat, 2, "SHORT", 6)
    chk("sim_timeout_charged_cost", bool(t) and t["outcome"] == "TIME" and t["net_pct"] < 0, str(t))
    chk("cost_r_scales_with_risk", _v45_rr_levels(100, 0.2, "LONG")["cost_r"] > V45_MAX_COST_R > _v45_rr_levels(100, 1.0, "LONG")["cost_r"])
    rng = np.random.default_rng(5)
    close = 100 + np.cumsum(rng.normal(0, 0.4, 400))
    dfx = pd.DataFrame({"t": np.arange(400) * 3600000.0, "open": close, "high": close + 0.3, "low": close - 0.3, "close": close, "vol": rng.uniform(100, 200, 400)})
    tab = _v45_signal_table(dfx)
    arr = _v45_arrays(dfx)
    trs = _v45_run_sim(arr, tab, {"long_thr": 58.0, "short_thr": 40.0, "adx_min": 0.0}, 60, 398, 12)
    ok_no_overlap = all(trs[k + 1]["i"] > trs[k]["exit_idx"] for k in range(len(trs) - 1))
    chk("backtest_one_trade_at_a_time", ok_no_overlap and len(trs) > 0, f"n={len(trs)}")
    chk("stats_shape", "state" in _v45_stats("LONG", "RANGE"))
    print("V45 self-test:", "PASS" if not fails else f"FAIL {fails}")
    return 0 if not fails else 1
