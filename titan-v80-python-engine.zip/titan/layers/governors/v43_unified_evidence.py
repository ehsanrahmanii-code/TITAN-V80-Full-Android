# [TITAN V77 layer] governors/v43_unified_evidence - V43 unified evidence coordinator
# Original V76 source lines 14962-15757 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# TITAN V43 — UNIFIED EVIDENCE COORDINATOR / ONE-BRAIN DECISION
# ============================================================
# This layer is the final decision coordinator.  It runs AFTER the evidence
# enrichment layers (V31/V34/V35/V36/V40), so those modules are not merely
# post-decision safety filters: their outputs become evidence for the same
# central arbiter.  No legacy/candidate decision is treated as a vote.
V43_VERSION = "TITAN-V43-UNIFIED-EVIDENCE-COORDINATOR"
V43_MIN_COMPONENTS = 8
V43_MIN_ACTIVE_GROUPS = 4


def _v43_side_from_score(score: float, deadband: float = 0.08) -> tuple[float, float, str]:
    lean = clamp((safe_float(score, 50.0) - 50.0) / 50.0, -1.0, 1.0)
    conf = clamp(abs(lean), 0.0, 1.0)
    side = "LONG" if lean > deadband else "SHORT" if lean < -deadband else "WAIT"
    return lean, conf, side


def _v43_add_vote(votes: dict, name: str, score: float, label: str, group: str,
                  available: bool = True, confidence: float | None = None) -> None:
    if not available:
        return
    lean, conf, side = _v43_side_from_score(score)
    if confidence is not None:
        conf = clamp(safe_float(confidence, conf), 0.0, 1.0)
    votes[name] = {
        "lean": lean, "confidence": conf, "side": side,
        "raw": round(safe_float(score, 50.0), 4), "label": label,
        "group": group, "v43": True,
    }


def _v43_unified_evidence_base(item: dict[str, Any]) -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    """Build one auditable evidence map from all available downstream modules.

    The function intentionally converts *module outputs* into evidence rather
    than copying their prior decisions.  This prevents circular reinforcement
    while still making the complete analytical stack visible to the governor.
    """
    votes = _central_votes(item)
    registry: list[dict[str, Any]] = []

    def reg(name: str, group: str, used: bool, note: str = ""):
        registry.append({"module": name, "group": group, "used": bool(used), "note": note})

    # Neural intelligence -------------------------------------------------
    neural = item.get("neural_v9") or (item.get("fusion") or {}).get("neural_v9") or {}
    if isinstance(neural, dict) and neural:
        nscore = safe_float(neural.get("neural_score"), 50.0)
        nconf = clamp(safe_float(neural.get("confidence"), 0.0) / 100.0, 0.0, 1.0)
        _v43_add_vote(votes, "neural_v9", nscore, "سیناپس عصبی V9", "AI_NEURAL", True, max(nconf, 0.05))
        reg("TitanNeuralSynapseV9", "AI_NEURAL", True)
    else:
        reg("TitanNeuralSynapseV9", "AI_NEURAL", False, "no runtime output")

    # Market regime / structure / liquidity / precision ------------------
    regime = item.get("regime") if isinstance(item.get("regime"), dict) else {}
    rname = str(regime.get("regime") or item.get("market_regime") or "").lower()
    rconf = clamp(safe_float(regime.get("confidence"), 0.0) / 100.0, 0.0, 1.0)
    if rname:
        rscore = 65.0 if "up" in rname or rname == "breakout_watch" else 35.0 if "down" in rname else 50.0
        _v43_add_vote(votes, "regime_engine", rscore, "رژیم بازار", "MARKET_CONTEXT", True, max(rconf, 0.20))
        reg("regime", "MARKET_CONTEXT", True, rname)
    else:
        reg("regime", "MARKET_CONTEXT", False)

    structure = item.get("structure") if isinstance(item.get("structure"), dict) else {}
    se = str(structure.get("event") or "").upper()
    sb = str(structure.get("bias") or "").upper()
    if se or sb:
        if se in {"BOS_UP", "BULL_STRUCTURE"} or sb in {"LONG", "صعودی"}: sscore = 68.0
        elif se in {"BOS_DOWN", "BEAR_STRUCTURE"} or sb in {"SHORT", "نزولی"}: sscore = 32.0
        else: sscore = 50.0
        sc = clamp(safe_float(structure.get("confirmation_score"), 50.0) / 100.0, 0.0, 1.0)
        _v43_add_vote(votes, "structure_engine", sscore, "موتور ساختار", "MARKET_CONTEXT", True, max(sc, 0.15))
        reg("structure", "MARKET_CONTEXT", True, se or sb)
    else:
        reg("structure", "MARKET_CONTEXT", False)

    liquidity = item.get("liquidity") if isinstance(item.get("liquidity"), dict) else {}
    if liquidity:
        pressure = clamp(safe_float(liquidity.get("pressure"), 0.0), -1.0, 1.0)
        _v43_add_vote(votes, "liquidity_engine", 50.0 + pressure * 35.0, "نقدشوندگی/فشار", "FLOW", True, clamp(abs(pressure) + 0.15, 0, 1))
        reg("liquidity", "FLOW", True)
    else:
        reg("liquidity", "FLOW", False)

    precision = item.get("precision") if isinstance(item.get("precision"), dict) else {}
    if precision:
        ps = safe_float(precision.get("score"), 50.0)
        _v43_add_vote(votes, "precision_engine", ps, "دقت ورود", "ENTRY_RISK", True, 0.75)
        reg("precision", "ENTRY_RISK", True)
    else:
        reg("precision", "ENTRY_RISK", False)

    # V31 complete suite: use the suite-level independent evidence score and
    # explicitly expose all its internal modules as participating metadata.
    v31 = item.get("v31_edge_suite") if isinstance(item.get("v31_edge_suite"), dict) else {}
    if v31:
        ev = v31.get("evidence_fusion") or {}
        adv = v31.get("adversarial") or {}
        ent = v31.get("entry_stability") or {}
        unc = v31.get("uncertainty") or {}
        robust = safe_float(adv.get("robustness"), 50.0)
        entry = safe_float(ent.get("score"), 50.0)
        indep = clamp(safe_float(ev.get("independence_score"), 0.5), 0.0, 1.0)
        uncertainty = clamp(safe_float(unc.get("uncertainty"), 50.0), 0.0, 100.0)
        v31_score = clamp(0.40 * robust + 0.35 * entry + 25.0 * indep + 0.15 * (100.0 - uncertainty), 0, 100)
        _v43_add_vote(votes, "v31_edge_suite", v31_score, "مجموعه 21 ماژول V31", "ROBUSTNESS_LEARNING", True, 0.75)
        for k, val in v31.items():
            reg("V31." + k, "ROBUSTNESS_LEARNING", isinstance(val, dict) or isinstance(val, (bool, int, float)))
    else:
        reg("V31.edge_suite", "ROBUSTNESS_LEARNING", False)

    # V34 adaptive trust / opportunity -----------------------------------
    v34 = item.get("v34_opportunity") if isinstance(item.get("v34_opportunity"), dict) else {}
    if v34:
        opp = safe_float(v34.get("score"), safe_float(v34.get("opportunity_score"), 50.0))
        _v43_add_vote(votes, "v34_opportunity", opp, "اعتماد تطبیقی/فرصت", "ROBUSTNESS_LEARNING", True, 0.70)
        reg("V34.adaptive_trust", "ROBUSTNESS_LEARNING", True)
    else:
        reg("V34.adaptive_trust", "ROBUSTNESS_LEARNING", False)

    # V36 horizon agreement + cross-asset resonance ---------------------
    v36 = item.get("v36_resonance") if isinstance(item.get("v36_resonance"), dict) else {}
    fusion = item.get("fusion") if isinstance(item.get("fusion"), dict) else {}
    horizon = v36.get("horizon_agreement") if isinstance(v36.get("horizon_agreement"), dict) else {}
    if not horizon:
        horizon = item.get("horizon_agreement") if isinstance(item.get("horizon_agreement"), dict) else {}
    if horizon:
        ag = clamp(safe_float(horizon.get("agreement"), 0.5), 0.0, 1.0)
        direction = str(horizon.get("direction") or "WAIT").upper()
        hscore = 50.0 + (ag * 40.0 if direction == "LONG" else -ag * 40.0 if direction == "SHORT" else 0.0)
        _v43_add_vote(votes, "v36_horizon", hscore, "توافق افق‌های زمانی V36", "MTF_CROSS_ASSET", True, max(ag, 0.15))
        reg("V36.horizon_agreement", "MTF_CROSS_ASSET", True)
    else:
        reg("V36.horizon_agreement", "MTF_CROSS_ASSET", False)
    if v36:
        penalty = safe_float(v36.get("penalty"), 0.0)
        resonance = clamp(50.0 - penalty * 2.0, 0.0, 100.0)
        _v43_add_vote(votes, "v36_resonance", resonance, "رزونانس بین‌دارایی V36", "MTF_CROSS_ASSET", True, 0.65)
        reg("V36.cross_asset_resonance", "MTF_CROSS_ASSET", True)
    else:
        reg("V36.cross_asset_resonance", "MTF_CROSS_ASSET", False)

    # V40 precision is a gate AND an evidence source.  Hard blocks remain
    # authoritative vetoes below, while its score participates in consensus.
    v40 = item.get("v40_precision") if isinstance(item.get("v40_precision"), dict) else {}
    if v40:
        v40_score = safe_float(v40.get("score"), 50.0)
        _v43_add_vote(votes, "v40_precision", v40_score, "گیت دقت V40", "ENTRY_RISK", True, 0.80)
        reg("V40.precision_gate", "ENTRY_RISK", True)
    else:
        reg("V40.precision_gate", "ENTRY_RISK", False)

    # Macro / BTC context -------------------------------------------------
    btc = str(item.get("btc_trend") or "").strip()
    if btc:
        bscore = 65.0 if btc in {"صعودی", "LONG", "UP"} else 35.0 if btc in {"نزولی", "SHORT", "DOWN"} else 50.0
        _v43_add_vote(votes, "btc_macro_context", bscore, "رژیم BTC/ماکرو", "MARKET_CONTEXT", True, 0.55)
        reg("BTC/macro", "MARKET_CONTEXT", True, btc)
    else:
        reg("BTC/macro", "MARKET_CONTEXT", False)

    # Forecast, calibration, learning, research and performance ------------
    fc = item.get("candle_forecast") or item.get("forecast") or {}
    if isinstance(fc, dict) and fc:
        bias = str(fc.get("overall_bias") or "")
        move = safe_float(fc.get("expected_move_pct"), 0.0)
        fscore = 50.0 + clamp(move * 4.0, -20.0, 20.0)
        if bias == "صعودی": fscore = max(fscore, 53.0)
        elif bias == "نزولی": fscore = min(fscore, 47.0)
        _v43_add_vote(votes, "forecast_engine", fscore, "پیش‌بینی مسیر", "FORECAST", True, 0.60)
        reg("forecast", "FORECAST", True)
    else:
        reg("forecast", "FORECAST", False)

    cal = item.get("probability_calibration") if isinstance(item.get("probability_calibration"), dict) else {}
    if cal:
        cval = safe_float(cal.get("calibrated"), 50.0)
        cn = int(safe_float(cal.get("samples"), 0))
        cconf = clamp(cn / 100.0, 0.15, 1.0)
        _v43_add_vote(votes, "realized_calibration", cval, "کالیبراسیون realized", "ROBUSTNESS_LEARNING", True, cconf)
        reg("realized_calibration", "ROBUSTNESS_LEARNING", True, f"samples={cn}")
    else:
        reg("realized_calibration", "ROBUSTNESS_LEARNING", False)

    learning = item.get("v32_learning") or {}
    if isinstance(learning, dict) and learning:
        ladj = safe_float(learning.get("long_adjustment"), 0.0)
        sadj = safe_float(learning.get("short_adjustment"), 0.0)
        lscore = 50.0 + clamp((ladj - sadj) * 2.0, -20.0, 20.0)
        _v43_add_vote(votes, "learning_engine", lscore, "یادگیری تاریخی", "ROBUSTNESS_LEARNING", True, 0.55)
        reg("learning", "ROBUSTNESS_LEARNING", True)
    else:
        reg("learning", "ROBUSTNESS_LEARNING", False)

    # Hard veto aggregation from every downstream safety layer.
    vetoes: list[str] = []
    if v40:
        vetoes.extend([str(v) for v in (v40.get("hard_blocks") or []) if str(v)])
    if v31 and bool(v31.get("safety_wait")):
        vetoes.append("V31 safety_wait")
    if v36 and bool(v36.get("kill")):
        vetoes.append("V36 kill")
    if v36 and bool(v36.get("blocked")):
        vetoes.append("V36 blocked")

    active = [v for v in votes.values() if v.get("v43")]
    groups = {str(v.get("group")) for v in active if v.get("group")}
    participation = {
        "active_components": len(active),
        "active_groups": len(groups),
        "required_components": V43_MIN_COMPONENTS,
        "required_groups": V43_MIN_ACTIVE_GROUPS,
        "sufficient": len(active) >= V43_MIN_COMPONENTS and len(groups) >= V43_MIN_ACTIVE_GROUPS,
        "registry": registry,
        "hard_vetoes": vetoes,
    }
    return votes, participation


def _v43_unified_decide_base(item: dict[str, Any]) -> dict[str, Any]:
    """Re-arbitrate the fully enriched snapshot through one central brain."""
    x = dict(item or {})
    votes, participation = _v43_unified_evidence(x)
    with _CENTRAL_WEIGHT_LOCK:
        weights = dict(_CENTRAL_WEIGHTS)
    # New coordinator weights are intentionally bounded and lower than the
    # primary TF/structure spine to avoid double-counting correlated evidence.
    extra_defaults = {
        "neural_v9": 1.00, "regime_engine": 0.85, "structure_engine": 0.95,
        "liquidity_engine": 0.55, "precision_engine": 0.70, "v31_edge_suite": 0.80,
        "v34_opportunity": 0.70, "v36_horizon": 0.75, "v36_resonance": 0.55,
        "v40_precision": 0.80, "btc_macro_context": 0.55, "forecast_engine": 0.50,
        "realized_calibration": 0.60, "learning_engine": 0.55,
    }
    for k, v in extra_defaults.items():
        weights.setdefault(k, v)

    long_num = short_num = den = 0.0
    details = []
    for name, v in votes.items():
        if name == "data_trust":
            continue
        w = safe_float(weights.get(name), 1.0)
        eff = w * clamp(safe_float(v.get("confidence"), 0.0), 0.0, 1.0)
        lean = clamp(safe_float(v.get("lean"), 0.0), -1.0, 1.0)
        den += eff
        if lean > 0: long_num += eff * lean
        elif lean < 0: short_num += eff * abs(lean)
        details.append({"component": name, "group": v.get("group", "CORE"), "side": v.get("side"),
                        "lean": round(lean, 4), "confidence": round(safe_float(v.get("confidence"), 0), 4),
                        "weight": round(w, 4), "contribution": round(eff * lean, 4), "raw": v.get("raw")})
    long_score = long_num / max(den, 1e-9)
    short_score = short_num / max(den, 1e-9)
    edge = max(long_score, short_score)
    margin = abs(long_score - short_score)
    trust = safe_float((votes.get("data_trust") or {}).get("trust"), 70.0)
    candidate = "LONG" if long_score > short_score else "SHORT" if short_score > long_score else "WAIT"
    reasons = []
    if not participation["sufficient"]:
        reasons.append("اجماع ناکافی: مشارکت ماژول‌ها کم است")
    if trust < _CENTRAL_MIN_TRUST: reasons.append(f"اعتماد داده پایین ({trust:.0f})")
    if edge < _CENTRAL_MIN_EDGE: reasons.append(f"لبه تصمیم ناکافی ({edge:.3f})")
    if margin < _CENTRAL_MIN_MARGIN: reasons.append(f"حاشیه تصمیم کم ({margin:.3f})")
    reasons.extend(participation["hard_vetoes"])

    # Existing overlap gate remains a portfolio-level veto.
    overlap = _edge_overlap_gate(_normalize_symbol(x.get("symbol") or ""), candidate)
    if candidate in {"LONG", "SHORT"} and not overlap.get("ok", True):
        reasons.append(str(overlap.get("reason") or "overlap risk"))

    # Directional level contract is not allowed to be invented at this stage.
    price = _v42_price(x)
    sl = safe_float(x.get("stop_loss_raw"), safe_float(x.get("stop_loss"), 0.0))
    tp1 = safe_float(x.get("tp1_raw"), safe_float(x.get("tp1"), 0.0))
    tp2 = safe_float(x.get("tp2_raw"), safe_float(x.get("tp2"), 0.0))
    if candidate in {"LONG", "SHORT"} and not _v42_levels_ok(price, sl, tp1, tp2, candidate):
        reasons.append("سطوح نهایی با جهت اجماع منطبق نیست")

    decision = candidate if not reasons and candidate in {"LONG", "SHORT"} else "WAIT"
    conf = clamp(50.0 + edge * 38.0 + margin * 28.0 + (trust - 50.0) * 0.12, 5.0, 94.0)
    if decision == "WAIT": conf = min(conf, 55.0)
    scorecard = []
    for d in details:
        scorecard.append({**d, "aligned": decision in {"LONG", "SHORT"} and d["side"] == decision,
                          "opposed": decision in {"LONG", "SHORT"} and d["side"] in {"LONG", "SHORT"} and d["side"] != decision})

    x["decision"] = decision
    x["decision_tag"] = decision
    x["bias"] = "صعودی" if decision == "LONG" else "نزولی" if decision == "SHORT" else "خنثی"
    x["entry_mode"] = "EARLY" if decision in {"LONG", "SHORT"} else "WAIT"
    x["signal_tag"] = f"UNIFIED-CENTRAL — {decision}"
    x["decision_state"] = f"UNIFIED_CENTRAL_{decision}"
    x["decision_confidence"] = round(conf, 2)
    x["directional_bias"] = round((long_score - short_score) * 100.0, 2)
    x["unified_central"] = {
        "version": V43_VERSION, "decision": decision,
        "candidate": candidate, "long_score": round(long_score, 5), "short_score": round(short_score, 5),
        "edge": round(edge, 5), "margin": round(margin, 5), "confidence": round(conf, 2),
        "trust": round(trust, 2), "components": scorecard,
        "weights": {k: round(v, 4) for k, v in weights.items()},
        "participation": participation, "overlap": overlap,
        "reasons": reasons, "authoritative": True, "timestamp": time.time(),
    }
    x["decision_reasons"] = reasons
    x["central_reason_fa"] = " · ".join(reasons[:6]) if reasons else "اجماع کامل شواهد"
    x["decision_architecture"] = {
        **(dict(x.get("decision_architecture") or {}) if isinstance(x.get("decision_architecture"), dict) else {}),
        "type": "ONE_BRAIN_MANY_EVIDENCE_CHANNELS",
        "authoritative_source": V43_VERSION,
        "final_decision": decision,
        "all_available_modules_are_evidence": True,
        "circular_previous_decisions_excluded": True,
        "module_participation": participation,
    }
    x["authority"] = V43_VERSION
    return x

# ---- Public gateways ----
_CENTRAL_PREV_ANALYZE = _analyze_asset_v32_impl
_CENTRAL_PREV_UPDATE = _update_cache_base


def _analyze_asset_central(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:
    """Sole public analyzer — evidence stack, then V40 precision seal."""
    try:
        base = _CENTRAL_PREV_ANALYZE(symbol, btc_trend)
        if not base:
            return None
        if btc_trend and not base.get("btc_trend"):
            base["btc_trend"] = btc_trend
        sealed = _central_seal(base)
        sealed = _v31_apply(sealed)
        sealed = _v34_apply(sealed)
        snapshot = _v35_get_live_snapshot(symbol)
        sealed = _v35_rebase_price_dependent_outputs(sealed, snapshot)
        try:
            with CACHE_LOCK:
                _rows = list(CACHE.get("data") or [])
        except Exception:
            _swallow()
            _rows = []
        sealed = _v36_apply(sealed, _rows)
        sealed = _v40_precision_gate(sealed, _rows)
        # V43 is the actual final arbiter: every enriched module votes here.
        sealed = _v43_unified_decide(sealed)
        sealed = _v42_integrity_seal(sealed)
        try:
            _central_record_prediction(sealed)
        except Exception as rec_exc:
            LOGGER.debug("record after V40: %s", rec_exc)
        return sealed
    except Exception as exc:
        LOGGER.exception("Central analyze failed %s: %s", symbol, exc)
        try:
            if "base" in locals() and base:
                _fb = _v40_precision_gate(_central_seal(base), [])
                _fb = _v43_unified_decide(_fb)
                return _v42_integrity_seal(_fb)
        except Exception:
            _swallow()
        return None


def _update_cache_central(force: bool = False) -> tuple[list[dict[str, Any]], str, dict[str, Any]]:
    """Central-owned scan with progress heartbeat + emergency fallback."""
    coins = list(USER_SETTINGS.get("active_coins") or DEFAULT_COINS)
    total = max(1, len(coins))
    scan_started = time.time()
    with CACHE_LOCK:
        cached_n = len(CACHE.get("data") or [])
        cache_age = time.time() - safe_float(CACHE.get("timestamp"), 0.0)
        cached_data = list(CACHE.get("data") or [])
        cached_summary = CACHE.get("gemini_summary") or ""
        cached_macro = dict(CACHE.get("macro") or {})
    ttl = float(globals().get("MARKET_CACHE_TTL", 40))
    do_force = bool(force) or cached_n <= 0 or cache_age >= ttl

    if not do_force and cached_n > 0:
        _scan_progress_update(
            status="complete", phase="داده از کش", completed=cached_n,
            total=max(total, cached_n), percent=100,
            last_success_at=time.time() - cache_age if cache_age < 1e9 else time.time(),
            message=f"کش تازه · {cached_n} ارز · سن {cache_age:.0f}s", fresh=False,
        )
        return cached_data, cached_summary, cached_macro

    _scan_progress_update(
        status="running", phase="آماده‌سازی داور مرکزی", started_at=scan_started,
        finished_at=0.0, completed=0, total=total, percent=3,
        message=f"داور مرکزی · اسکن {total} ارز…", fresh=False,
    )
    hb_stop = threading.Event()

    def _hb():
        # Fast heartbeat (~0.6s): advances bar from real completed count + mild time blend
        # so the UI never sits at 3% for tens of seconds on a phone.
        while not hb_stop.wait(0.6):
            try:
                snap = _scan_progress_snapshot()
                if str(snap.get("status") or "") != "running":
                    break
                started = safe_float(snap.get("started_at"), scan_started)
                elapsed = max(0.0, time.time() - started)
                completed = int(snap.get("completed") or 0)
                tot = max(1, int(snap.get("total") or total or 1))
                # Completion dominates; time only fills the gap while waiting on first results.
                by_done = 12.0 + (completed / tot) * 78.0
                by_time = 12.0 + min(55.0, elapsed * 4.5)  # ~12s to ~67% if stuck before first finish
                soft = min(94.0, max(by_done, by_time if completed == 0 else by_done))
                cur = safe_float(snap.get("percent"), 0)
                if soft > cur + 0.4:
                    _scan_progress_update(
                        percent=round(soft, 1),
                        message=snap.get("message") or f"تحلیل زنده · {completed}/{tot}",
                    )
            except Exception:
                _swallow()
                break

    threading.Thread(target=_hb, name="titan-progress-hb", daemon=True).start()
    try:
        try:
            _central_evaluate_pending()
        except Exception:
            _swallow()
        try:
            if "v32_evaluate_pending" in globals():
                v32_evaluate_pending()
        except Exception:
            _swallow()

        data, summary, macro = _CENTRAL_PREV_UPDATE(True)
        sealed: list[dict[str, Any]] = []
        n_items = max(1, len(data or []))
        for idx, item in enumerate(data or [], 1):
            try:
                if str(item.get("authority", "")) == TITAN_CENTRAL_VERSION:
                    sealed.append(item)
                else:
                    sealed.append(_central_seal(item))
            except Exception:
                _swallow()
                if item:
                    sealed.append(item)
            if idx == n_items or idx % 3 == 0:
                _scan_progress_update(
                    completed=idx, total=max(total, n_items),
                    percent=min(98, 85 + int(12 * idx / n_items)),
                    phase="مهر داور مرکزی", message=f"مهر مرکزی {idx}/{n_items}",
                )
        finished = time.time()
        with CACHE_LOCK:
            CACHE["data"] = sealed
            if sealed:
                CACHE["timestamp"] = finished
                if summary is not None:
                    CACHE["gemini_summary"] = summary
                if macro is not None:
                    CACHE["macro"] = macro
        if sealed:
            _scan_progress_update(
                status="complete", phase="اسکن کامل شد", completed=len(sealed),
                total=max(total, len(sealed)), percent=100, finished_at=finished,
                last_success_at=finished, elapsed_sec=round(finished - scan_started, 1),
                message=f"داور مرکزی · {len(sealed)} ارز · {round(finished - scan_started, 1)}s",
                fresh=True,
            )
            try:
                if "store_forecasts" in globals():
                    store_forecasts(sealed)
            except Exception:
                _swallow()
            return sealed, summary, macro

        emergency = _emergency_live_cards(coins)
        if emergency:
            with CACHE_LOCK:
                CACHE["data"] = emergency
                CACHE["timestamp"] = finished
            _scan_progress_update(
                status="complete", phase="قیمت زنده اضطراری", completed=len(emergency),
                total=max(total, len(emergency)), percent=100, finished_at=finished,
                last_success_at=finished,
                message=f"اسکن کامل ناموفق؛ {len(emergency)} قیمت زنده",
                fresh=False,
            )
            return emergency, summary or "", macro or {}
        if cached_n > 0:
            _scan_progress_update(
                status="complete", phase="بازیابی کش", completed=cached_n,
                total=max(total, cached_n), percent=100, finished_at=finished,
                message=f"نمایش {cached_n} ارز از کش", fresh=False,
            )
            return cached_data, cached_summary, cached_macro
        _scan_progress_update(
            status="failed", phase="اسکن بدون نتیجه", percent=100, finished_at=finished,
            message="نتیجه‌ای برنگشت؛ اسکن بعدی خودکار است", fresh=False,
        )
        return [], summary or "", macro or {}
    except Exception as exc:
        LOGGER.exception("Central update_cache: %s", exc)
        finished = time.time()
        try:
            emergency = _emergency_live_cards(coins)
        except Exception:
            _swallow()
            emergency = []
        if emergency:
            with CACHE_LOCK:
                CACHE["data"] = emergency
                CACHE["timestamp"] = finished
            _scan_progress_update(
                status="complete", phase="بازیابی اضطراری", percent=100,
                completed=len(emergency), finished_at=finished,
                message=f"خطا در اسکن · {len(emergency)} قیمت زنده", fresh=False,
            )
            return emergency, "", {}
        _scan_progress_update(
            status="failed", phase="خطای اسکن", percent=100, finished_at=finished,
            message=f"خطا: {str(exc)[:200]}", fresh=False,
        )
        with CACHE_LOCK:
            return list(CACHE.get("data") or []), CACHE.get("gemini_summary") or "", CACHE.get("macro") or {}
    finally:
        hb_stop.set()


# Patch index to never serve blank Android shell
_CENTRAL_PREV_INDEX = _index_base


@app.route("/")
def index():
    try:
        # Always recover a stuck gate before painting the dashboard
        try:
            _scan_supervisor_tick()
        except Exception:
            pass
        with CACHE_LOCK:
            n = len(CACHE.get("data") or [])
            cache_ts = float(CACHE.get("timestamp") or 0)
        # Kick a scan whenever the cache is empty OR the gate is idle for too long
        need_scan = n <= 0
        try:
            snap = _scan_progress_snapshot() or {}
            st = str(snap.get("status") or "idle")
            if st in {"idle", "error", "stalled", "failed", "no-data", "complete"}:
                age = time.time() - float(snap.get("finished_at") or snap.get("last_success_at") or cache_ts or 0)
                if age > 30 or n <= 0:
                    need_scan = True
        except Exception:
            need_scan = True
        if n <= 0:
            try:
                emergency = _emergency_live_cards()
                if emergency:
                    with CACHE_LOCK:
                        if not CACHE.get("data"):
                            CACHE["data"] = emergency
                            CACHE["timestamp"] = time.time()
                    _scan_progress_update(
                        status="running", phase="قیمت زنده موقت", percent=8,
                        message=f"{len(emergency)} ارز · تحلیل کامل در صف",
                        completed=0, total=len(USER_SETTINGS.get("active_coins") or DEFAULT_COINS),
                        started_at=time.time(), fresh=False,
                    )
            except Exception as exc:
                LOGGER.warning("index emergency: %s", exc)
        if need_scan:
            try:
                threading.Thread(target=lambda: _background_market_refresh(True), name="titan-force-scan", daemon=True).start()
            except Exception:
                _swallow()
        return _CENTRAL_PREV_INDEX()
    except Exception as exc:
        LOGGER.exception("index wrapper: %s", exc)
        try:
            return _CENTRAL_PREV_INDEX()
        except Exception:
            from flask import Response
            return Response(
                "<!doctype html><html lang=fa dir=rtl><meta charset=utf-8>"
                "<body style='background:#050812;color:#eef2ff;font-family:Tahoma;padding:24px'>"
                "<h2>TITAN PRO</h2><p>داشبورد در حال بارگذاری است. چند ثانیه صبر کنید و صفحه را رفرش کنید.</p>"
                "<p>اگر اسکن شروع نمی‌شود، اینترنت/VPN را بررسی کنید و روی دکمه Rescan بزنید.</p>"
                "</body></html>",
                mimetype="text/html; charset=utf-8",
            )


@app.get("/api/system-audit")
def api_system_audit():
    """Runtime integrity contract: components, DB schema, and final seal."""
    try:
        return jsonify(titan_system_audit())
    except Exception as exc:
        return jsonify({"passed": False, "version": V42_VERSION, "error": str(exc)[:240]}), 500


@app.get("/api/central-brain")
def api_central_brain():
    try:
        with DB_LOCK, db_conn() as con:
            pending = int(con.execute("SELECT COUNT(*) FROM central_predictions WHERE outcome='PENDING'").fetchone()[0])
            done = con.execute(
                "SELECT outcome,COUNT(*) FROM central_predictions WHERE outcome!='PENDING' GROUP BY outcome"
            ).fetchall()
            comps = con.execute(
                "SELECT component,samples,wins,losses,reward_sum,penalty_sum,weight FROM central_component_stats ORDER BY component"
            ).fetchall()
        return jsonify({
            "ok": True,
            "version": TITAN_CENTRAL_VERSION,
            "pending": pending,
            "outcomes": {str(r[0]): int(r[1]) for r in done},
            "components": [
                {"component": r[0], "samples": r[1], "wins": r[2], "losses": r[3],
                 "reward": r[4], "penalty": r[5], "weight": r[6]}
                for r in comps
            ],
            "live_weights": dict(_CENTRAL_WEIGHTS),
            "mode": "CENTRAL_GOVERNOR_ONLY",
            "note": "سیگنال‌ها احتمالی هستند و تضمین سود نیست.",
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)[:240]}), 500


@app.get("/api/v31-edge")
def api_v31_edge():
    """Expose the 21-module Edge Suite without changing the existing dashboard contract."""
    try:
        with CACHE_LOCK:
            rows=list(CACHE.get("data") or [])
        suite=[]
        for item in rows:
            e=item.get("v31_edge_suite") or {}
            suite.append({"symbol":item.get("symbol"),"decision":item.get("decision_tag") or item.get("decision"),
                          "safety_wait":e.get("safety_wait",False),"uncertainty":(e.get("uncertainty") or {}).get("uncertainty"),
                          "robustness":(e.get("adversarial") or {}).get("robustness"),
                          "entry_stability":(e.get("entry_stability") or {}).get("score"),
                          "data_quality":(e.get("data_quality") or {}).get("score"),
                          "explainability":e.get("explainability") or {}})
        return jsonify({"ok":True,"version":V31_EDGE_VERSION,"count":len(suite),"items":suite})
    except Exception as exc:
        return jsonify({"ok":False,"error":str(exc)[:240]}),500

@app.get("/api/v36-resonance")
def api_v36_resonance():
    """Dashboard summary of Quantum Resonance Edge state per symbol."""
    try:
        with CACHE_LOCK:
            rows = list(CACHE.get("data") or [])
        items = []
        killed = boosted = 0
        for item in rows:
            r = item.get("v36_resonance") or {}
            ha = r.get("horizon_agreement") or {}
            pd_ = r.get("price_drift") or {}
            ca = r.get("cross_asset") or {}
            if r.get("killed"):
                killed += 1
            if r.get("boosted"):
                boosted += 1
            items.append({
                "symbol": item.get("symbol"),
                "decision": item.get("decision_tag") or item.get("decision"),
                "confidence": item.get("decision_confidence"),
                "agreement": ha.get("agreement"),
                "horizon_direction": ha.get("direction"),
                "aligned": ha.get("aligned_with_decision"),
                "drift_pct": pd_.get("drift_pct"),
                "drift_kill": pd_.get("kill"),
                "same_side_cluster": ca.get("same_side"),
                "cluster_penalty": ca.get("penalty"),
                "killed": bool(r.get("killed")),
                "boosted": bool(r.get("boosted")),
                "notes": r.get("notes") or [],
                "live_sync": item.get("live_sync"),
                "live_age_sec": item.get("live_price_age_sec"),
                "v34": (item.get("v34_opportunity") or {}).get("state"),
            })
        return jsonify({
            "ok": True,
            "version": globals().get("V36_VERSION", "V36"),
            "param_version": TITAN_PARAM_VERSION,
            "count": len(items),
            "killed": killed,
            "boosted": boosted,
            "items": items,
            "note": "رزونانس کوانتومی فقط کیفیت/ایمنی سیگنال را تنظیم می‌کند؛ احتمال برد تضمینی نیست.",
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)[:240]}), 500



@app.get("/api/v40-precision")
def api_v40_precision():
    """History bans, live precision status, self-heal report endpoint."""
    try:
        hist = _v40_refresh_hist(force=True)
        with CACHE_LOCK:
            rows = list(CACHE.get("data") or [])
        live = []
        for item in rows:
            p = item.get("v40_precision") or {}
            live.append({
                "symbol": item.get("symbol"),
                "decision": item.get("decision_tag") or item.get("decision"),
                "confidence": item.get("decision_confidence"),
                "passed": p.get("passed"),
                "demoted": item.get("v40_demoted"),
                "code": item.get("v40_demote_code"),
                "horizon": (p.get("horizon") or {}).get("agreement"),
                "history_wr": (p.get("history") or {}).get("wr"),
                "history_n": (p.get("history") or {}).get("samples"),
            })
        by_key = hist.get("by_key") or {}
        banned = [k for k, st in by_key.items()
                  if st.get("samples", 0) >= V40_BAN_N and st.get("wr", 50) < V40_BAN_WR]
        with DB_LOCK, db_conn() as con:
            totals = {r[0]: r[1] for r in con.execute(
                "SELECT outcome, COUNT(*) FROM central_predictions GROUP BY outcome").fetchall()}
        w, l = int(totals.get("WIN", 0) or 0), int(totals.get("LOSS", 0) or 0)
        return jsonify({
            "ok": True,
            "version": V40_VERSION,
            "param_version": TITAN_PARAM_VERSION,
            "decided_win_rate": round(100.0 * w / (w + l), 1) if (w + l) else None,
            "central_totals": totals,
            "global_short": hist.get("g_short"),
            "global_long": hist.get("g_long"),
            "banned_keys": banned,
            "live": live,
            "note": "V40 فقط سیگنال با اجماع، RR قوی، سابقه قابل قبول و رژیم سازگار را منتشر می‌کند.",
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)[:240]}), 500


@app.get("/api/edge-lab")
def api_edge_lab():
    try:
        return jsonify(_edge_api_report())
    except Exception as exc:
        return jsonify({"ok":False,"error":str(exc)[:240]}),500


def _central_learner_loop():
    while not LIVE_STOP.is_set():
        try:
            _central_evaluate_pending()
            _central_load_weights()
        except Exception as exc:
            LOGGER.debug("central learner: %s", exc)
        LIVE_STOP.wait(40)


def _shutdown_runtime() -> None:
    """Stop background loops and close reusable worker pools on process exit."""
    LIVE_STOP.set()
    for pool_name in ("_ANALYSIS_POOL", "_KLINE_POOL", "_AI_POOL"):
        pool = globals().get(pool_name)
        if pool is not None:
            try:
                pool.shutdown(wait=False, cancel_futures=True)
            except TypeError:
                try:
                    pool.shutdown(wait=False)
                except Exception:
                    _swallow()
            except Exception:
                _swallow()


import atexit
atexit.register(_shutdown_runtime)


def _open_dashboard_browser() -> None:
    """Open the local dashboard after the HTTP server becomes reachable."""
    try:
        import webbrowser
        url = f"http://127.0.0.1:{PORT}/"
        for _ in range(30):
            try:
                with socket.create_connection(("127.0.0.1", PORT), timeout=0.25):
                    # Android/Termux: prefer the system browser intent when available.
                    try:
                        import shutil as _sh, subprocess as _sp
                        _tou = _sh.which("termux-open-url")
                        if _tou:
                            _sp.Popen([_tou, url], stdout=_sp.DEVNULL, stderr=_sp.DEVNULL)
                            return
                    except Exception:
                        _swallow()
                    webbrowser.open(url, new=1, autoraise=True)
                    return
            except OSError:
                LIVE_STOP.wait(0.5)
                if LIVE_STOP.is_set():
                    return
    except Exception as exc:
        LOGGER.debug("Dashboard browser launch skipped: %s", exc)


# continuous learner started with main
_CENTRAL_LEARNER_STARTED = False


def _ensure_central_learner():
    global _CENTRAL_LEARNER_STARTED
    if _CENTRAL_LEARNER_STARTED:
        return
    try:
        threading.Thread(target=_central_learner_loop, name="titan-central-learner", daemon=True).start()
        _CENTRAL_LEARNER_STARTED = True
    except Exception:
        _swallow()
