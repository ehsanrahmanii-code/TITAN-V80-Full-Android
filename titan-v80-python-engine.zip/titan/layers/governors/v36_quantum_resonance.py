# [TITAN V77 layer] governors/v36_quantum_resonance - V36 resonance edge
# Original V76 source lines 14202-14387 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# TITAN V36 — QUANTUM RESONANCE EDGE (magical upgrade layer)
# ------------------------------------------------------------
# Cross-asset resonance, drift-aware confidence decay, and
# multi-horizon agreement score. Analysis-only; never invents
# win probability. Can only demote unsafe signals or modestly
# boost a coherent multi-horizon edge that is already present.
# ============================================================
V36_VERSION = "TITAN-V36-QUANTUM-RESONANCE-EDGE"
V36_DRIFT_KILL_PCT = 1.85
V36_RESONANCE_BOOST_MIN = 0.62
V36_MAX_CONF_BOOST = 6.0
_V36_RESONANCE_CACHE: dict[str, Any] = {"ts": 0.0, "matrix": {}}
_V36_RESONANCE_LOCK = threading.RLock()


def _v36_horizon_agreement(item: dict[str, Any]) -> dict[str, Any]:
    """Score agreement across HTF/MTF/LTF + forecast path + structure."""
    tf = item.get("tf_scores") or item.get("tfs") or {}
    s15 = safe_float(tf.get("15m"), 50.0)
    s1h = safe_float(tf.get("1h"), 50.0)
    s4h = safe_float(tf.get("4h"), 50.0)
    s1d = safe_float(tf.get("1d"), 50.0)
    decision = str(item.get("decision_tag") or item.get("decision") or "WAIT").upper()

    def lean(sc: float) -> float:
        return clamp((sc - 50.0) / 50.0, -1.0, 1.0)

    leans = [lean(s15), lean(s1h), lean(s4h), lean(s1d)]
    fc = item.get("candle_forecast") or {}
    fc_bias = str(fc.get("overall_bias") or "")
    if fc_bias == "صعودی":
        leans.append(0.45)
    elif fc_bias == "نزولی":
        leans.append(-0.45)
    struct = item.get("structure") if isinstance(item.get("structure"), dict) else {}
    sb = str(struct.get("bias") or item.get("structure_bias") or "")
    if sb == "صعودی":
        leans.append(0.40)
    elif sb == "نزولی":
        leans.append(-0.40)

    if not leans:
        return {"agreement": 0.0, "direction": "WAIT", "n": 0}
    mean = sum(leans) / len(leans)
    var = sum((x - mean) ** 2 for x in leans) / max(1, len(leans))
    cohesion = float(clamp(1.0 - (var ** 0.5) * 1.8, 0.0, 1.0))
    magnitude = abs(mean)
    agreement = float(clamp(cohesion * (0.45 + 0.55 * magnitude), 0.0, 1.0))
    direction = "LONG" if mean > 0.08 else "SHORT" if mean < -0.08 else "WAIT"
    aligned = direction == decision if decision in {"LONG", "SHORT"} else False
    return {
        "agreement": round(agreement, 4),
        "mean_lean": round(mean, 4),
        "cohesion": round(cohesion, 4),
        "direction": direction,
        "aligned_with_decision": aligned,
        "n": len(leans),
    }


def _v36_price_drift_gate(item: dict[str, Any]) -> dict[str, Any]:
    """Kill directional signals when live price has run away from the scan snapshot."""
    snap = item.get("signal_snapshot") if isinstance(item.get("signal_snapshot"), dict) else {}
    snap_px = safe_float(snap.get("price"), 0.0)
    live = safe_float(item.get("price_raw") or item.get("live_price"), 0.0)
    decision = str(item.get("decision_tag") or item.get("decision") or "WAIT").upper()
    if snap_px <= 0 or live <= 0 or decision not in {"LONG", "SHORT"}:
        return {"drift_pct": 0.0, "kill": False, "reason": ""}
    drift = (live / snap_px - 1.0) * 100.0
    adverse = (decision == "LONG" and drift > V36_DRIFT_KILL_PCT) or (
        decision == "SHORT" and drift < -V36_DRIFT_KILL_PCT
    )
    extreme = abs(drift) > V36_DRIFT_KILL_PCT * 1.6
    kill = bool(adverse or extreme)
    reason = ""
    if adverse:
        reason = f"adverse_drift_{drift:+.2f}%"
    elif extreme:
        reason = f"extreme_drift_{drift:+.2f}%"
    return {"drift_pct": round(drift, 3), "kill": kill, "reason": reason, "snap": snap_px, "live": live}


def _v36_cross_asset_resonance(symbol: str, decision: str, cache_rows: list) -> dict[str, Any]:
    """Soft portfolio resonance: same-side cluster reduces edge quality."""
    if decision not in {"LONG", "SHORT"} or not cache_rows:
        return {"same_side": 0, "penalty": 0.0, "note": ""}
    majors = {"BTC/USDT", "ETH/USDT", "BNB/USDT", "SOL/USDT", "XRP/USDT"}
    sym = _normalize_symbol(symbol)
    same = 0
    for row in cache_rows:
        other = _normalize_symbol(row.get("symbol") or "")
        if other == sym:
            continue
        od = str(row.get("decision_tag") or row.get("decision") or "").upper()
        if od == decision:
            same += 1
    penalty = 0.0
    note = ""
    if same >= 6:
        penalty = 10.0
        note = f"رزونانس سبد: {same} سیگنال هم‌جهت فعال"
    elif same >= 4:
        penalty = 5.0
        note = f"فشار خوشه‌ای: {same} سیگنال هم‌جهت"
    if sym in majors and same >= 3:
        penalty = max(penalty, 4.0)
    return {"same_side": same, "penalty": penalty, "note": note}


def _v36_apply(item: dict[str, Any], cache_rows: Optional[list] = None) -> dict[str, Any]:
    """Quantum Resonance final polish — demote on drift, modest boost on pure agreement."""
    try:
        decision = str(item.get("decision_tag") or item.get("decision") or "WAIT").upper()
        agree = _v36_horizon_agreement(item)
        drift = _v36_price_drift_gate(item)
        resonance = _v36_cross_asset_resonance(
            str(item.get("symbol") or ""), decision, list(cache_rows or [])
        )
        killed = False
        boosted = False
        notes: list[str] = []

        if decision in {"LONG", "SHORT"} and drift.get("kill"):
            item["decision_tag"] = "WAIT"
            item["decision"] = "WAIT"
            item["bias"] = "خنثی"
            item["entry_mode"] = "WAIT"
            item["signal_tag"] = "V36 RESONANCE WAIT — PRICE DRIFT"
            item["central_reason_fa"] = (
                f"قیمت از اسنپ‌شات سیگنال بیش از حد فاصله گرفته ({drift.get('reason')}); "
                "سیگنال جهت‌دار باطل شد."
            )
            killed = True
            notes.append(str(drift.get("reason") or "drift_kill"))

        if not killed and decision in {"LONG", "SHORT"}:
            if (
                agree.get("direction") in {"LONG", "SHORT"}
                and agree.get("direction") != decision
                and agree.get("agreement", 0) >= 0.55
            ):
                item["decision_tag"] = "WAIT"
                item["decision"] = "WAIT"
                item["bias"] = "خنثی"
                item["entry_mode"] = "WAIT"
                item["signal_tag"] = "V36 RESONANCE WAIT — HORIZON DISCORD"
                item["central_reason_fa"] = "اجماع افق‌های زمانی با جهت سیگنال در تضاد است."
                killed = True
                notes.append("horizon_discord")
            elif agree.get("aligned_with_decision") and agree.get("agreement", 0) >= V36_RESONANCE_BOOST_MIN:
                conf = safe_float(item.get("decision_confidence"), 50.0)
                boost = min(V36_MAX_CONF_BOOST, (agree["agreement"] - V36_RESONANCE_BOOST_MIN) * 18.0)
                boost = max(0.0, boost - safe_float(resonance.get("penalty"), 0.0) * 0.35)
                if boost >= 1.0:
                    item["decision_confidence"] = round(clamp(conf + boost, 0.0, 96.0), 1)
                    boosted = True
                    notes.append(f"resonance_boost_+{boost:.1f}")
            if resonance.get("penalty", 0) >= 8 and not killed:
                conf = safe_float(item.get("decision_confidence"), 50.0)
                item["decision_confidence"] = round(max(35.0, conf - resonance["penalty"]), 1)
                notes.append(resonance.get("note") or "cluster_pressure")

        item["v36_resonance"] = {
            "version": V36_VERSION,
            "horizon_agreement": agree,
            "price_drift": drift,
            "cross_asset": resonance,
            "killed": killed,
            "boosted": boosted,
            "notes": notes,
        }
        item.setdefault("fusion", {})["v36_resonance"] = item["v36_resonance"]
        arch = item.get("decision_architecture") if isinstance(item.get("decision_architecture"), dict) else {}
        arch = dict(arch)
        arch["resonance_layer"] = V36_VERSION
        arch["final_decision"] = item.get("decision_tag", "WAIT")
        item["decision_architecture"] = arch
        return item
    except Exception as exc:
        LOGGER.debug("V36 resonance failed: %s", exc)
        item["v36_resonance"] = {"version": V36_VERSION, "error": str(exc)[:180]}
        return item
