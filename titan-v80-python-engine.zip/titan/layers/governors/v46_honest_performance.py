# [TITAN V77 layer] governors/v46_honest_performance - V46 honest performance / calibration
# Original V76 source lines 17187-17988 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# TITAN V46 — HONEST PERFORMANCE / CALIBRATION / LEARNING PATCH
# ============================================================
# This section is intentionally the LAST authority layer.
#
# Fixes:
# 1) Removes the previous simplistic final decision layer that could overwrite
#    the V45 validated governor with a weaker score-only rule.
# 2) Fixes runtime typos in the old final patch (USERSETTINGS/normalizesymbol).
# 3) Adds an explicit prediction ledger for BOTH published signals and shadow
#    directional candidates. Shadow samples never execute orders.
# 4) Evaluates outcomes chronologically using the exact prediction horizon.
# 5) Uses SL/TP first-touch; same-bar SL+TP is AMBIGUOUS, never a fabricated win.
# 6) Charges round-trip friction and reports gross/net returns and R.
# 7) Adds honest Bayesian posterior metrics. No "50% win rate" is shown for N=0.
# 8) Adds confidence calibration buckets and Wilson lower confidence bound.
# 9) Adds LONG/SHORT + regime + timeframe attribution.
# 10) Adds component/agent attribution and bounded Bayesian weighting.
# 11) Adds walk-forward/OOS audit metadata and leakage guards.
# 12) Adds a production self-test and rich /api/v46/audit endpoint.
#
# Analysis only. No real-order execution is introduced here.
# ============================================================

V46_VERSION = "TITAN-V46-HONEST-LEDGER-CALIBRATED-OOS"

def _ff(v: Any, default: float = 0.0) -> float:
    try:
        x = float(v)
        return x if math.isfinite(x) else default
    except (TypeError, ValueError):
        return default




def _unified_stance(item: dict) -> dict:
    """Single coherent opinion for the whole dashboard.

    Hierarchy:
      1) V51 published LONG/SHORT  -> authoritative trade stance
      2) Strong multi-TF quant lean -> LEAN_LONG / LEAN_SHORT (advisory, not published)
      3) Otherwise WAIT

    Scalp window, breadth, cards, and opportunity center MUST all read this.
    """
    if not isinstance(item, dict):
        return {
            "stance": "WAIT", "stance_family": "WAIT", "published": False,
            "label_fa": "انتظار", "bias": "خنثی", "confidence": 40.0,
            "reason": "no-item",
        }
    tag = str(item.get("decision_tag") or item.get("decision") or "WAIT").upper()
    quant = safe_float(item.get("quant_score"), safe_float(item.get("score"), 50.0))
    tfs = item.get("tf_scores") or item.get("tfs") or {}
    if not isinstance(tfs, dict):
        tfs = {}
    s15 = safe_float(tfs.get("15m"), quant)
    s1h = safe_float(tfs.get("1h"), quant)
    s4h = safe_float(tfs.get("4h"), quant)
    sq = safe_float(item.get("signal_quality"), abs(quant - 50.0) * 1.2 + 40.0)
    # Alignment of short TFs with quant
    long_align = (s15 >= 52) + (s1h >= 50) + (s4h >= 52) + (quant >= 55)
    short_align = (s15 <= 48) + (s1h <= 50) + (s4h <= 48) + (quant <= 45)

    if tag == "LONG":
        return {
            "stance": "LONG", "stance_family": "LONG", "published": True,
            "label_fa": "لانگ فعال", "bias": "صعودی",
            "confidence": float(clamp(max(sq, quant), 55, 95)),
            "reason": "v51-published",
        }
    if tag == "SHORT":
        return {
            "stance": "SHORT", "stance_family": "SHORT", "published": True,
            "label_fa": "شورت فعال", "bias": "نزولی",
            "confidence": float(clamp(max(sq, 100 - quant), 55, 95)),
            "reason": "v51-published",
        }

    # Lean thresholds: balanced — more real leans, still require TF agreement (no fake flips)
    strong_long = quant >= 62 and long_align >= 2 and s15 >= 53
    strong_short = quant <= 38 and short_align >= 2 and s15 <= 47
    mild_long = quant >= 55 and long_align >= 2 and (s15 >= 50 or s1h >= 50)
    mild_short = quant <= 45 and short_align >= 2 and (s15 <= 50 or s1h <= 50)

    if strong_long:
        return {
            "stance": "LEAN_LONG", "stance_family": "LONG", "published": False,
            "label_fa": "تمایل صعودی", "bias": "صعودی",
            "confidence": float(clamp(50 + (quant - 50) * 0.9 + long_align * 3, 55, 88)),
            "reason": "quant-strong-long",
        }
    if strong_short:
        return {
            "stance": "LEAN_SHORT", "stance_family": "SHORT", "published": False,
            "label_fa": "تمایل نزولی", "bias": "نزولی",
            "confidence": float(clamp(50 + (50 - quant) * 0.9 + short_align * 3, 55, 88)),
            "reason": "quant-strong-short",
        }
    if mild_long:
        return {
            "stance": "LEAN_LONG", "stance_family": "LONG", "published": False,
            "label_fa": "تمایل صعودی ملایم", "bias": "صعودی",
            "confidence": float(clamp(48 + (quant - 50) * 0.7, 50, 75)),
            "reason": "quant-mild-long",
        }
    if mild_short:
        return {
            "stance": "LEAN_SHORT", "stance_family": "SHORT", "published": False,
            "label_fa": "تمایل نزولی ملایم", "bias": "نزولی",
            "confidence": float(clamp(48 + (50 - quant) * 0.7, 50, 75)),
            "reason": "quant-mild-short",
        }
    return {
        "stance": "WAIT", "stance_family": "WAIT", "published": False,
        "label_fa": "انتظار / خنثی", "bias": "خنثی",
        "confidence": float(clamp(40 + (20 - abs(quant - 50)) * 0.5, 35, 55)),
        "reason": "neutral",
    }


def _dashboard_finalize_item(item):
    """Last-mile card hygiene: identity + numeric TF scores + non-collapsed display score."""
    if not isinstance(item, dict):
        return item
    x = dict(item)
    sym = _normalize_symbol(str(x.get("symbol") or ""))
    if sym:
        base = sym.split("/")[0].upper()
        meta = COIN_META.get(base, (base, "●"))
        x["symbol"] = sym
        x["base_symbol"] = str(x.get("base_symbol") or base)
        x["coin_name"] = str(x.get("coin_name") or meta[0] or base)
        x["coin_icon"] = str(x.get("coin_icon") or meta[1] or "●")
        x["tv_symbol"] = str(x.get("tv_symbol") or _binance_symbol(sym))
    numeric = {}
    for src_key in ("tf_scores", "tfscores", "tfs"):
        src = x.get(src_key)
        if not isinstance(src, dict):
            continue
        for k, v in src.items():
            try:
                fv = float(v)
                if math.isfinite(fv) and 0.0 <= fv <= 100.0:
                    # Prefer non-neutral values when merging sources
                    prev = numeric.get(str(k))
                    if prev is None or (abs(prev - 50.0) < 0.5 and abs(fv - 50.0) >= 0.5):
                        numeric[str(k)] = float(fv)
                    elif prev is None:
                        numeric[str(k)] = float(fv)
            except (TypeError, ValueError):
                continue
    for tf, flat in (("15m", "tfs15m"), ("1h", "tfs1h"), ("4h", "tfs4h"), ("1d", "tfs1d")):
        if tf not in numeric:
            try:
                fv = float(x.get(flat))
                if math.isfinite(fv):
                    numeric[tf] = float(clamp(fv, 0, 100))
            except (TypeError, ValueError):
                _swallow()
    quant = safe_float(x.get("quant_score"), safe_float(x.get("score"), 50.0))
    if numeric:
        try:
            wavg = float(sum(numeric.get(t, quant) * TF_CFG[t]["weight"] for t in TF_CFG))
        except Exception:
            _swallow()
            wavg = float(sum(numeric.values()) / max(1, len(numeric)))
        # If stored quant is neutral but TF map is not, trust the TF map
        if abs(quant - 50.0) < 0.5 and abs(wavg - 50.0) >= 0.5:
            quant = wavg
        elif abs(quant - 50.0) < 0.5:
            quant = wavg
    else:
        numeric = {"15m": quant, "1h": quant, "4h": quant, "1d": quant}
    for tf in ("15m", "1h", "4h", "1d"):
        numeric.setdefault(tf, quant)
        x["tfs" + tf] = round(float(numeric[tf]), 1)
    x["tfs"] = {k: round(float(numeric[k]), 1) for k in ("15m", "1h", "4h", "1d")}
    x["tf_scores"] = dict(x["tfs"])
    x["tfscores"] = dict(x["tfs"])
    quant = float(clamp(quant, 0, 100))
    x["quant_score"] = int(round(quant))
    x["score"] = int(round(quant))
    x["score_bar"] = int(round(quant))
    x["score_color"] = "#4ade80" if quant >= 60 else "#f43f5e" if quant <= 40 else "#fbbf24"
    sq = safe_float(x.get("signal_quality"), 0.0)
    if sq <= 1.0 or (sq == 40.0 and abs(quant - 50.0) >= 1.0):
        x["signal_quality"] = round(clamp(abs(quant - 50.0) * 1.5 + 35.0, 5, 95), 1)
    if not x.get("decision_tag"):
        x["decision_tag"] = str(x.get("decision") or "WAIT").upper()
    if not x.get("bias") or x.get("bias") == "خنثی":
        tag = str(x.get("decision_tag") or "WAIT").upper()
        if tag == "LONG":
            x["bias"] = "صعودی"
        elif tag == "SHORT":
            x["bias"] = "نزولی"
        elif quant >= 58:
            x["bias"] = "صعودی"
        elif quant <= 42:
            x["bias"] = "نزولی"
        else:
            x["bias"] = "خنثی"
    # Ensure fusion/edge/titan_analysis are maps (prevents Jinja str.get crashes)
    for key in ("fusion", "edge", "titan_analysis", "data_quality", "patterns", "candle_forecast", "signal_grade", "macd", "stoch_rsi", "session", "buy_sell"):
        if key in x and not isinstance(x.get(key), dict):
            x[key] = {}
    # Unified central stance — one opinion for cards / breadth / scalp / opportunity
    st = _unified_stance(x)
    x["stance"] = st["stance"]
    x["stance_family"] = st["stance_family"]
    x["stance_published"] = bool(st["published"])
    x["stance_label"] = st["label_fa"]
    x["stance_confidence"] = round(float(st["confidence"]), 1)
    x["stance_reason"] = st["reason"]
    x["bias"] = st["bias"]
    # Display decision: published tags stay; leans show as LEAN_*; pure wait stays WAIT
    if st["published"]:
        x["decision_display"] = st["stance"]
        x["decision_tag"] = st["stance"]
    else:
        x["decision_display"] = st["stance"]  # LEAN_LONG / LEAN_SHORT / WAIT
        # Keep authority decision_tag as WAIT when not published (ledger safety)
        if str(x.get("decision_tag") or "").upper() not in {"LONG", "SHORT"}:
            x["decision_tag"] = "WAIT"
    # Card chrome
    if st["stance_family"] == "LONG":
        x["score_color"] = "#4ade80" if quant >= 60 else "#86efac"
    elif st["stance_family"] == "SHORT":
        x["score_color"] = "#f43f5e" if quant <= 40 else "#fb7185"
    else:
        x["score_color"] = "#fbbf24"
    # Grade reflects stance so middle/bottom boards match top
    if st["published"]:
        x["grade"] = x.get("grade") if x.get("grade") in {"A+", "A", "B"} else "A"
    elif st["stance"] in {"LEAN_LONG", "LEAN_SHORT"}:
        # Strong lean -> B (watch/active), mild stays C
        if st["reason"] in {"quant-strong-long", "quant-strong-short"}:
            x["grade"] = "B"
        else:
            x["grade"] = x.get("grade") if x.get("grade") not in {None, "", "—"} else "C"
        # opportunity state for boards
        x["opportunity_state"] = "EARLY_" + st["stance_family"]
        x["opportunity_score"] = max(safe_float(x.get("opportunity_score"), 0), float(st["confidence"]))
    else:
        if str(x.get("grade") or "") in {"A+", "A"}:
            x["grade"] = "C"  # no fake A on pure WAIT
    # signal_grade map stay consistent
    sg = x.get("signal_grade") if isinstance(x.get("signal_grade"), dict) else {}
    sg = dict(sg)
    sg["grade"] = x.get("grade") or sg.get("grade") or "C"
    sg["label_fa"] = st["label_fa"]
    sg["action"] = "PUBLISH" if st["published"] else ("LEAN" if st["stance_family"] in {"LONG", "SHORT"} else "WAIT")
    sg["trust_index"] = round(float(st["confidence"]), 1)
    x["signal_grade"] = sg
    x["signal_tag"] = f"STANCE {st['stance']} · {st['label_fa']}"
    try:
        x = _v61_attach_flow(x) or x
    except Exception:
        _swallow()
    return x


def _normalise_dashboard(rows):
    """Ensure every dashboard card has display identity + numeric TF scores + safe AI block."""
    out=[]
    for raw in rows or []:
        if not isinstance(raw, dict):
            continue
        x = _dashboard_finalize_item(dict(raw)) or dict(raw)
        # AI opinions safety for template
        ai = x.get("ai_opinions")
        if not isinstance(ai, dict):
            ai = {}
        else:
            ai = dict(ai)
        status = ai.get("ai_status")
        if not isinstance(status, dict):
            status = {
                "gemini": str(status) if status else "در انتظار تحلیل",
                "openai": "در انتظار تحلیل",
                "grok": "در انتظار تحلیل",
                "claude": "در انتظار تحلیل",
                "deepseek": "در انتظار تحلیل",
            }
        ai["ai_status"] = status
        if not ai.get("internal"):
            ta = x.get("titan_analysis")
            ai["internal"] = str((ta or {}).get("summary") or "") if isinstance(ta, dict) else ""
        x["ai_opinions"] = ai
        if not x.get("price") and x.get("price_raw"):
            x["price"] = smart_format(x.get("price_raw"))
        out.append(x)
    return out


V46_LEDGER_HORIZON_MIN = 240
V46_MIN_SAMPLES_FOR_RELIABILITY = 20
V46_MIN_SAMPLES_FOR_PROMOTION = 30
V46_PRIOR_ALPHA = 4.0
V46_PRIOR_BETA = 6.0       # prior mean = 40%, deliberately conservative
V46_MAX_SHADOW_PER_SYMBOL_HOUR = 6
V46_SHADOW_COOLDOWN = 2700.0
V46_MIN_PUBLISH_CONFIDENCE = 62.0
V46_MIN_PUBLISH_DQ = 60.0
V46_MIN_PUBLISH_PF = 1.02
V46_MIN_PUBLISH_EXPECTANCY = 0.0
V46_MIN_PUBLISH_RR = 1.25

def _v46_init_schema() -> None:
    """Create additive, migration-safe V46 tables."""
    try:
        with DB_LOCK, db_conn() as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS titan_prediction_ledger(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at REAL NOT NULL,
                    symbol TEXT NOT NULL,
                    timeframe TEXT NOT NULL DEFAULT '15m',
                    candidate_side TEXT NOT NULL,
                    published_side TEXT NOT NULL DEFAULT 'WAIT',
                    is_shadow INTEGER NOT NULL DEFAULT 1,
                    entry REAL NOT NULL,
                    stop_loss REAL,
                    tp1 REAL,
                    tp2 REAL,
                    confidence REAL DEFAULT 0,
                    data_quality REAL DEFAULT 0,
                    score REAL DEFAULT 0,
                    margin REAL DEFAULT 0,
                    regime TEXT DEFAULT 'unknown',
                    components_json TEXT DEFAULT '{}',
                    weights_json TEXT DEFAULT '{}',
                    reasons_json TEXT DEFAULT '[]',
                    horizon_minutes INTEGER DEFAULT 240,
                    status TEXT DEFAULT 'PENDING',
                    outcome TEXT DEFAULT 'PENDING',
                    exit_price REAL,
                    return_gross_pct REAL,
                    return_net_pct REAL,
                    r_multiple REAL,
                    mae_pct REAL,
                    mfe_pct REAL,
                    time_to_event_min REAL,
                    evaluated_at REAL,
                    param_version TEXT,
                    source TEXT DEFAULT 'V46_SHADOW'
                )
            """)
            con.execute("CREATE INDEX IF NOT EXISTS idx_v46_ledger_pending ON titan_prediction_ledger(status,created_at)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_v46_ledger_symbol ON titan_prediction_ledger(symbol,candidate_side,created_at)")
            con.execute("""
                CREATE TABLE IF NOT EXISTS titan_component_outcomes(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ledger_id INTEGER NOT NULL,
                    component TEXT NOT NULL,
                    side TEXT,
                    lean REAL DEFAULT 0,
                    confidence REAL DEFAULT 0,
                    weight_at_prediction REAL DEFAULT 1,
                    outcome TEXT NOT NULL,
                    reward REAL DEFAULT 0,
                    created_at REAL NOT NULL,
                    UNIQUE(ledger_id,component)
                )
            """)
            con.execute("CREATE INDEX IF NOT EXISTS idx_v46_component ON titan_component_outcomes(component,outcome)")
            con.execute("""
                CREATE TABLE IF NOT EXISTS titan_calibration_buckets(
                    bucket INTEGER PRIMARY KEY,
                    samples INTEGER DEFAULT 0,
                    wins INTEGER DEFAULT 0,
                    losses INTEGER DEFAULT 0,
                    updated_at REAL DEFAULT 0
                )
            """)
            con.execute("""
                CREATE TABLE IF NOT EXISTS titan_oos_runs(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at REAL NOT NULL,
                    symbol TEXT,
                    timeframe TEXT,
                    train_start REAL,
                    train_end REAL,
                    test_start REAL,
                    test_end REAL,
                    purge_bars INTEGER DEFAULT 0,
                    train_samples INTEGER DEFAULT 0,
                    test_samples INTEGER DEFAULT 0,
                    test_win_rate REAL,
                    test_expectancy REAL,
                    test_profit_factor REAL,
                    test_max_drawdown REAL,
                    test_sharpe REAL,
                    leakage_guard INTEGER DEFAULT 1,
                    param_hash TEXT,
                    notes TEXT
                )
            """)
            con.commit()
    except Exception as exc:
        LOGGER.debug("V46 schema init: %s", exc)

_v46_init_schema()

def _v46_wilson_lower(wins: int, n: int, z: float = 1.96) -> Optional[float]:
    if n <= 0:
        return None
    p = wins / n
    den = 1.0 + z*z/n
    centre = p + z*z/(2*n)
    margin = z * math.sqrt((p*(1-p) + z*z/(4*n))/n)
    return max(0.0, (centre - margin) / den) * 100.0

def _v46_beta_posterior(wins: int, losses: int) -> dict[str, Any]:
    n = max(0, int(wins) + int(losses))
    a = V46_PRIOR_ALPHA + max(0, int(wins))
    b = V46_PRIOR_BETA + max(0, int(losses))
    mean = a / max(a+b, 1e-12) * 100.0
    # Approximate 95% interval without scipy.
    sd = math.sqrt((a*b) / max((a+b)**2 * (a+b+1), 1e-12))
    lo = max(0.0, (a/(a+b) - 1.96*sd) * 100.0)
    hi = min(100.0, (a/(a+b) + 1.96*sd) * 100.0)
    return {
        "samples": n,
        "wins": int(wins),
        "losses": int(losses),
        "posterior_mean": round(mean, 2),
        "credible_low_95": round(lo, 2),
        "credible_high_95": round(hi, 2),
        "raw_win_rate": round((wins/n)*100.0, 2) if n else None,
        "status": "RELIABLE" if n >= V46_MIN_SAMPLES_FOR_RELIABILITY else "INSUFFICIENT",
    }


def _v46_query_rows(where: str = "", params: tuple = (), limit: int = 10000) -> list[dict[str, Any]]:
    try:
        sql = """SELECT * FROM titan_prediction_ledger"""
        if where:
            sql += " WHERE " + where
        if "PENDING" in str(where).upper():
            sql += " ORDER BY created_at ASC LIMIT ?"          # evaluate oldest pending first
        else:                                                    # stats/learning: most recent N, chronological
            sql = "SELECT * FROM (" + sql + " ORDER BY created_at DESC LIMIT ?) ORDER BY created_at ASC"
        with DB_LOCK, db_conn() as con:
            cur=con.execute(sql, tuple(params)+(int(limit),))
            cols=[d[0] for d in cur.description]
            return [dict(zip(cols,r)) for r in cur.fetchall()]
    except Exception as exc:
        LOGGER.debug("V46 query rows: %s", exc)
        return []

def _v46_candidate_levels(item: dict[str, Any], side: str) -> Optional[dict[str,float]]:
    """Prefer the validated V45 levels; otherwise rebuild causal ATR levels."""
    px=_ff(item.get("price_raw"),_ff(item.get("live_price"),0.0))
    sl=_ff(item.get("stop_loss_raw"),0.0)
    tp1=_ff(item.get("tp1_raw"),0.0)
    tp2=_ff(item.get("tp2_raw"),0.0)
    if px>0 and sl>0 and tp1>0 and tp2>0:
        valid=(side=="LONG" and sl<px<tp1<tp2) or (side=="SHORT" and tp2<tp1<px<sl)
        if valid:
            risk=abs(px-sl)
            return {"entry":px,"sl":sl,"tp1":tp1,"tp2":tp2,"risk":risk,
                    "rr1":abs(tp1-px)/max(risk,1e-12),"rr2":abs(tp2-px)/max(risk,1e-12)}
    atr=_ff(item.get("atr_raw"),0.0)
    if atr<=0:
        # Convert ATR percentage to absolute ATR when available.
        atr_pct=_ff(item.get("atr_pct"),0.0)
        if atr_pct>0 and px>0:
            atr=px*atr_pct/100.0
    if px<=0 or atr<=0:
        return None
    try:
        lv=_v45_rr_levels(px,atr,side)
        if not lv: return None
        return {"entry":px,"sl":float(lv["sl"]),"tp1":float(lv["tp1"]),"tp2":float(lv["tp2"]),
                "risk":float(lv["risk"]),"rr1":float(lv["rr1"]),"rr2":float(lv["rr2"])}
    except Exception:
        _swallow()
        return None

def _v46_record_candidate(item: dict[str, Any]) -> Optional[int]:
    """Record distinct directional candidates, including WAIT shadow candidates."""
    try:
        sym=_normalize_symbol(item.get("symbol") or "")
        if not sym: return None
        published=str(item.get("decision_tag") or item.get("decision") or "WAIT").upper()
        central=item.get("central_decision") or {}
        candidate=str(
            central.get("candidate") or
            (item.get("v45") or {}).get("candidate") or
            item.get("candidate_direction") or
            published
        ).upper()
        if candidate not in {"LONG","SHORT"}:
            return None
        lv=_v46_candidate_levels(item,candidate)
        if not lv or lv["rr1"] < 1.05:
            return None
        now=time.time()
        # Prevent scan frequency from becoming fake sample size.
        with DB_LOCK, db_conn() as con:
            recent=con.execute(
                """SELECT 1 FROM titan_prediction_ledger
                   WHERE symbol=? AND candidate_side=? AND created_at>=?
                   LIMIT 1""",(sym,candidate,now-V46_SHADOW_COOLDOWN)
            ).fetchone()
            if recent: return None
            cnt=con.execute(
                """SELECT COUNT(*) FROM titan_prediction_ledger
                   WHERE symbol=? AND created_at>=?""",(sym,now-3600)
            ).fetchone()[0]
            if int(cnt)>=V46_MAX_SHADOW_PER_SYMBOL_HOUR:
                return None
            dq=item.get("data_quality") or {}
            conf=_ff(item.get("decision_confidence"),_ff(central.get("confidence"),50))
            score=_ff(item.get("score"),50)
            margin=_ff(central.get("margin"),_ff(item.get("margin"),0))
            regime=str(item.get("market_regime") or item.get("regime") or
                       (item.get("real_edge") or {}).get("regime") or "unknown")
            components=central.get("components") or (item.get("central_decision") or {}).get("components") or []
            weights=central.get("weights") or {}
            reasons=item.get("decision_reasons") or central.get("reasons") or []
            timeframe=str(item.get("timeframe") or "15m")
            cur=con.execute(
                """INSERT INTO titan_prediction_ledger(
                    created_at,symbol,timeframe,candidate_side,published_side,is_shadow,
                    entry,stop_loss,tp1,tp2,confidence,data_quality,score,margin,regime,
                    components_json,weights_json,reasons_json,horizon_minutes,status,outcome,
                    param_version,source)
                   VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (now,sym,timeframe,candidate,published,1 if published!=candidate else 0,
                 lv["entry"],lv["sl"],lv["tp1"],lv["tp2"],conf,_ff(dq.get("score"),0),
                 score,margin,regime,json.dumps(components,ensure_ascii=False,default=str),
                 json.dumps(weights,ensure_ascii=False,default=str),
                 json.dumps(reasons,ensure_ascii=False,default=str),
                 V46_LEDGER_HORIZON_MIN,"PENDING","PENDING",V46_VERSION,"V46")
            )
            rid=cur.lastrowid
            con.commit()
            return int(rid)
    except Exception as exc:
        LOGGER.debug("V46 record candidate: %s",exc)
        return None

def _v46_first_touch(df: pd.DataFrame, side: str, sl: float, tp1: float) -> tuple[str,Optional[float],Optional[float]]:
    """Chronological first-touch (vectorised). Same-candle SL+TP is ambiguous, not a win."""
    return _ft_simple(df, side == "LONG", sl, tp1, guard_positive=True)

def _v46_evaluate_pending(limit: int = 120) -> int:
    """Evaluate only after the exact horizon; no future leakage."""
    now=time.time(); done=0
    rows=_v46_query_rows("status='PENDING' AND created_at <= ?",(now-V46_LEDGER_HORIZON_MIN*60.0,),limit)
    for r in rows:
        rid=int(r["id"]); created=float(r["created_at"]); horizon=int(r.get("horizon_minutes") or V46_LEDGER_HORIZON_MIN)
        end=created+horizon*60.0
        if now<end: continue
        sym=str(r["symbol"]); side=str(r["candidate_side"])
        entry=_ff(r.get("entry"),0); sl=_ff(r.get("stop_loss"),0); tp1=_ff(r.get("tp1"),0)
        if entry<=0 or side not in {"LONG","SHORT"}: continue
        try:
            bars=max(8,min(1000,int(math.ceil(horizon/15.0))+4))
            df=fetch_klines(sym,"15m",bars,start_ms=int(created*1000),end_ms=int(end*1000))
            if df is None or df.empty or "t" not in df.columns: continue
            w=df[(df["t"].astype(float)>=created*1000)&(df["t"].astype(float)<end*1000)].sort_values("t")
            if w.empty: continue
            outcome,exit_px,event_ts=_v46_first_touch(w,side,sl,tp1)
            last=_ff(w["close"].iloc[-1],entry)
            if exit_px is None: exit_px=last
            gross=((exit_px/entry-1)*100) if side=="LONG" else ((entry/exit_px-1)*100 if exit_px>0 else 0)
            net=gross-V45_FRICTION_PCT
            risk_pct=abs(entry-sl)/max(entry,1e-12)*100
            rmult=net/max(risk_pct,1e-12)
            highs=w["high"].astype(float); lows=w["low"].astype(float)
            if side=="LONG":
                mae=(float(lows.min())/entry-1)*100; mfe=(float(highs.max())/entry-1)*100
            else:
                mae=(entry/float(highs.max())-1)*100; mfe=(entry/float(lows.min())-1)*100
            regime,_,_= _edge_regime_from_window(w)
            tte=((event_ts-created)/60.0) if event_ts else None
            with DB_LOCK,db_conn() as con:
                con.execute("""UPDATE titan_prediction_ledger SET status='EVALUATED',outcome=?,
                    exit_price=?,return_gross_pct=?,return_net_pct=?,r_multiple=?,mae_pct=?,mfe_pct=?,
                    time_to_event_min=?,regime=?,evaluated_at=? WHERE id=?""",
                    (outcome,exit_px,gross,net,rmult,mae,mfe,tte,regime,now,rid))
                # Attribute each component only if it had a directional vote.
                try:
                    comps=json.loads(r.get("components_json") or "[]")
                except Exception: comps=[]
                try: weights=json.loads(r.get("weights_json") or "{}")
                except Exception: weights={}
                if isinstance(comps,list):
                    for c in comps:
                        if not isinstance(c,dict): continue
                        name=str(c.get("component") or "")
                        if not name: continue
                        lean=_ff(c.get("lean"),0); conf=_ff(c.get("confidence"),0)
                        vote_side="LONG" if lean>0 else "SHORT" if lean<0 else "WAIT"
                        reward=0.0
                        if outcome=="WIN" and vote_side==side: reward=1.0*conf
                        elif outcome=="LOSS" and vote_side==side: reward=-1.0*conf
                        elif outcome=="WIN" and vote_side in {"LONG","SHORT"} and vote_side!=side: reward=-0.35*conf
                        con.execute("""INSERT OR IGNORE INTO titan_component_outcomes(
                            ledger_id,component,side,lean,confidence,weight_at_prediction,outcome,reward,created_at)
                            VALUES(?,?,?,?,?,?,?,?,?)""",
                            (rid,name,vote_side,lean,conf,_ff(weights.get(name),1),
                             outcome,reward,now))
                con.commit()
            done+=1
        except Exception as exc:
            LOGGER.debug("V46 evaluate #%s: %s",rid,exc)
    return done

def _v46_component_weights() -> dict[str,float]:
    """Bounded Bayesian/empirical component weights. Small N cannot dominate."""
    out=dict(_CENTRAL_WEIGHTS_DEFAULT)
    try:
        with DB_LOCK,db_conn() as con:
            rows=con.execute("""SELECT component,
                SUM(CASE WHEN outcome='WIN' AND reward>0 THEN 1 ELSE 0 END) w,
                SUM(CASE WHEN outcome='LOSS' AND reward<0 THEN 1 ELSE 0 END) l,
                COUNT(*) n, AVG(reward) ar
                FROM titan_component_outcomes
                WHERE outcome IN ('WIN','LOSS')
                GROUP BY component""").fetchall()
        for name,w,l,n,ar in rows:
            if name not in out: continue
            w=int(w or 0); l=int(l or 0); n=int(n or 0)
            # Bayesian posterior centered at 40%, shrunk toward neutral.
            post=_v46_beta_posterior(w,l)["posterior_mean"]/100.0
            shrink=min(1.0,n/60.0)
            reliability=0.75+0.65*post
            reward_tilt=1.0+clamp(_ff(ar,0)*0.10,-0.15,0.15)
            candidate=out[name]*(1.0+shrink*(reliability-1.0))*reward_tilt
            out[name]=clamp(candidate,0.35,1.8)
    except Exception as exc:
        LOGGER.debug("V46 component weights: %s",exc)
    return out

def _v46_calibration() -> dict[str,Any]:
    rows=_v46_query_rows("status='EVALUATED' AND outcome IN ('WIN','LOSS')",(),20000)
    buckets={}
    for r in rows:
        p=_ff(r.get("confidence"),50)
        b=int(min(95,max(5,math.floor(p/10)*10)))
        buckets.setdefault(b,[]).append(r)
    out=[]
    for b,rs in sorted(buckets.items()):
        s=_v46_stats(rs)
        out.append({"bucket_min":b,"bucket_max":b+9,"samples":s["trades"],
                    "actual_win_rate":s["win_rate"],"wilson_lower_95":s["win_rate_lower_95"]})
    return {"buckets":out,"samples":len(rows),
            "calibrated":len(rows)>=V46_MIN_SAMPLES_FOR_RELIABILITY}

def _v46_group_stats(field: str) -> dict[str,Any]:
    rows=_v46_query_rows("status='EVALUATED'",(),20000)
    groups={}
    for r in rows:
        key=str(r.get(field) or "unknown")
        groups.setdefault(key,[]).append(r)
    return {k:_v46_stats(v) for k,v in groups.items()}

def _v46_audit() -> dict[str,Any]:
    rows=_v46_query_rows("status='EVALUATED'",(),30000)
    decisive=[r for r in rows if str(r.get("outcome")) in {"WIN","LOSS"}]
    overall=_v46_stats(decisive)
    long=_v46_stats([r for r in decisive if r.get("candidate_side")=="LONG"])
    short=_v46_stats([r for r in decisive if r.get("candidate_side")=="SHORT"])
    shadow=[r for r in rows if int(r.get("is_shadow") or 0)==1]
    published=[r for r in rows if int(r.get("is_shadow") or 0)==0]
    return {
        "version":V46_VERSION,
        "scope":"V46 prediction ledger only; not a claim about unseen external history",
        "overall":overall,
        "long":long,"short":short,
        "by_regime":_v46_group_stats("regime"),
        "by_timeframe":_v46_group_stats("timeframe"),
        "shadow":_v46_stats([r for r in shadow if r in decisive]),
        "published":_v46_stats([r for r in published if r in decisive]),
        "pending":len([r for r in rows if r.get("status")=="PENDING"]),
        "calibration":_v46_calibration(),
        "component_weights":_v46_component_weights(),
        "rules":{
            "no_fake_50pct":True,"ambiguous_excluded_from_win_rate":True,
            "cost_aware":True,"same_bar_tie":"AMBIGUOUS",
            "chronological_first_touch":True,"shadow_no_execution":True,
            "walk_forward_required_for_promotion":True,
            "minimum_promotion_samples":V46_MIN_SAMPLES_FOR_PROMOTION,
        },
    }

# Keep the mature V45 governor as the directional authority. V46 only records,
# audits, calibrates and applies hard safety corrections. It must not replace a
# validated LONG/SHORT with a simplistic weighted-average score.
_V46_PREV_ANALYZE = _analyze_asset_v44

def _analyze_asset_v46(symbol: str, btc_trend: str) -> Optional[dict[str,Any]]:
    try:
        x=_V46_PREV_ANALYZE(symbol,btc_trend)
    except Exception as exc:
        LOGGER.exception("V46 analyze wrapper failed for %s: %s",symbol,exc)
        return None
    if not x: return x
    # Correct stale live price and decision metadata without inventing values.
    try:
        x=_normalise_dashboard([x])[0] if "_normalise_dashboard" in globals() else x
    except Exception:
        _swallow()
    try:
        _v46_record_candidate(x)
    except Exception:
        _swallow()
    return x

# Fix legacy typo aliases defensively; these names were present only in the
# previous final patch and are intentionally no longer authoritative.
USERSETTINGS = USER_SETTINGS
normalizesymbol = _normalize_symbol

_V46_PREV_UPDATE = _update_cache_central

def _update_cache_v46(force: bool=False):
    try:
        # Evaluate due samples before producing the next scan, so learning never
        # uses information from the future.
        _v46_evaluate_pending(limit=80)
    except Exception:
        _swallow()
    data,summary,macro=_V46_PREV_UPDATE(force)
    try:
        data=_normalise_dashboard(data) if "_normalise_dashboard" in globals() else data
    except Exception:
        _swallow()
    return data,summary,macro

@app.get("/api/v46/audit")
def api_v46_audit():
    try:
        return jsonify({"ok":True,**_v46_audit()})
    except Exception as exc:
        return jsonify({"ok":False,"error":str(exc)[:240]}),500

@app.get("/api/v46/metrics")
def api_v46_metrics():
    try:
        symbol=_normalize_symbol(request.args.get("symbol") or "")
        side=str(request.args.get("side") or "").upper()
        where="status='EVALUATED'"
        params=[]
        if symbol:
            where+=" AND symbol=?";params.append(symbol)
        if side in {"LONG","SHORT"}:
            where+=" AND candidate_side=?";params.append(side)
        rows=_v46_query_rows(where,tuple(params),20000)
        return jsonify({"ok":True,"version":V46_VERSION,"stats":_v46_stats(rows),
                        "calibration":_v46_calibration(),
                        "component_weights":_v46_component_weights()})
    except Exception as exc:
        return jsonify({"ok":False,"error":str(exc)[:240]}),500

@app.get("/api/v46/learning")
def api_v46_learning():
    try:
        with DB_LOCK,db_conn() as con:
            lessons=con.execute("""SELECT symbol,candidate_side,outcome,confidence,regime,return_net_pct,
                    r_multiple,mae_pct,mfe_pct,created_at,evaluated_at
                    FROM titan_prediction_ledger WHERE status='EVALUATED'
                    ORDER BY evaluated_at DESC LIMIT 200""").fetchall()
        return jsonify({"ok":True,"version":V46_VERSION,
                        "lessons":[dict(r) for r in lessons],
                        "component_weights":_v46_component_weights()})
    except Exception as exc:
        return jsonify({"ok":False,"error":str(exc)[:240]}),500

def _v46_self_test() -> int:
    failures=[]
    def chk(name,cond,detail=""):
        if cond: print("  ✓",name)
        else:
            print("  ✗",name,"—",detail);failures.append(name)
    print("="*64);print("TITAN V46 SELF-TEST");print("="*64)
    lg=_v45_rr_levels(100,1,"LONG");sh=_v45_rr_levels(100,1,"SHORT")
    chk("levels_long",bool(lg) and lg["sl"]<100<lg["tp1"]<lg["tp2"],str(lg))
    chk("levels_short",bool(sh) and sh["tp2"]<sh["tp1"]<100<sh["sl"],str(sh))
    chk("no_fake_zero_sample",_v46_stats([])["win_rate"] is None)
    chk("bayesian_prior_is_conservative",_v46_beta_posterior(0,0)["posterior_mean"]==40.0)
    chk("wilson_none_zero",_v46_wilson_lower(0,0) is None)
    chk("component_weights_bounded",all(0.35<=v<=1.8 for v in _v46_component_weights().values()))
    # Same-bar ambiguity fixture.
    d=pd.DataFrame({"t":[0,900000],"open":[100,100],"high":[100,104],
                    "low":[100,96],"close":[100,100]})
    chk("same_bar_ambiguous",_v46_first_touch(d,"LONG",98,102)[0]=="AMBIGUOUS")
    # First touch fixture.
    d2=pd.DataFrame({"t":[0,900000],"open":[100,100],"high":[101,103],
                     "low":[99,100],"close":[100,102]})
    chk("first_touch_win",_v46_first_touch(d2,"LONG",98,102)[0]=="WIN")
    # Ensure legacy typo names no longer affect the gateway.
    chk("settings_alias_fixed",USERSETTINGS is USER_SETTINGS)
    chk("symbol_alias_fixed",normalizesymbol("btc")=="BTC/USDT")
    # AST/compile is checked externally before release.
    print("V46 SELF-TEST:", "PASS" if not failures else f"FAIL {failures}")
    return 0 if not failures else 1
