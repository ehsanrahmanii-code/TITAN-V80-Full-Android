# [TITAN V77 layer] governors/v44_error_learning - V44 balanced opportunity + error learning
# Original V76 source lines 15758-16234 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# TITAN V44 — BALANCED OPPORTUNITY + HONEST OUTCOME LEARNING
# ============================================================
V44_VERSION = "TITAN-V44-BALANCED-LEARNING"
# A modestly more opportunity-aware operating point. V42 hard safety checks
# remain authoritative; these values never override stale/bad data or invalid levels.
_CENTRAL_MIN_EDGE = 0.12
_CENTRAL_MIN_MARGIN = 0.055
_CENTRAL_MIN_TRUST = 48.0

_V44_PREV_EVIDENCE = _v43_unified_evidence_base

def _v43_unified_evidence(item: dict[str, Any]) -> tuple[dict[str, dict[str, Any]], dict[str, Any]]:
    """Keep directional evidence separate from quality/reliability evidence.

    Precision, robustness, opportunity, calibration and forecast magnitude are
    not direction votes. Counting them as LONG/SHORT was a source of bias.
    They remain visible in the audit registry and are applied as quality context.
    """
    votes, participation = _V44_PREV_EVIDENCE(item)
    quality_only = {"precision_engine", "v31_edge_suite", "v34_opportunity",
                    "v40_precision", "realized_calibration", "forecast_engine"}
    quality = {}
    for name in list(votes):
        if name in quality_only:
            quality[name] = votes.pop(name)
    # Re-add forecast only when its direction is explicit; never infer direction
    # from a positive expected move alone (which can be an unsigned magnitude).
    fc = item.get("candle_forecast") or item.get("forecast") or {}
    if isinstance(fc, dict):
        bias = str(fc.get("overall_bias") or "").strip().lower()
        if bias in {"صعودی", "bullish", "up", "long"}:
            _v43_add_vote(votes, "forecast_direction", 68.0, "جهت پیش‌بینی", "FORECAST", True, 0.40)
        elif bias in {"نزولی", "bearish", "down", "short"}:
            _v43_add_vote(votes, "forecast_direction", 32.0, "جهت پیش‌بینی", "FORECAST", True, 0.40)
    directional = [v for v in votes.values() if v.get("side") in {"LONG", "SHORT"}
                   and safe_float(v.get("confidence"), 0.0) >= 0.08]
    groups = {str(v.get("group") or "CORE") for v in directional}
    required_components, required_groups = 5, 3
    sufficient = len(directional) >= required_components and len(groups) >= required_groups
    participation.update({
        "active_components": len(directional), "active_groups": len(groups),
        "required_components": required_components, "required_groups": required_groups,
        "sufficient": sufficient,
        "directional_components": [k for k,v in votes.items() if v in directional],
        "quality_only_channels": quality,
        "policy": "direction votes are separated from quality/calibration channels",
    })
    return votes, participation

_V44_PREV_DECIDE = _v43_unified_decide_base

def _v43_unified_decide(item: dict[str, Any]) -> dict[str, Any]:
    x = _V44_PREV_DECIDE(item)
    pack = x.get("unified_central") if isinstance(x.get("unified_central"), dict) else {}
    # Transparent quality modifiers; do not manufacture direction or bypass hard vetoes.
    quality = pack.get("participation", {}).get("quality_only_channels", {})
    v40 = quality.get("v40_precision") or {}
    v31 = quality.get("v31_edge_suite") or {}
    cal = quality.get("realized_calibration") or {}
    modifiers = []
    if v40:
        q = safe_float(v40.get("raw"), 50.0)
        modifiers.append({"module":"V40 precision", "score":q, "role":"quality-only"})
    if v31:
        q = safe_float(v31.get("raw"), 50.0)
        modifiers.append({"module":"V31 robustness", "score":q, "role":"quality-only"})
    if cal:
        modifiers.append({"module":"realized calibration", "score":safe_float(cal.get("raw"),50),
                          "samples":safe_float((x.get("probability_calibration") or {}).get("samples"),0),
                          "role":"probability calibration, not direction"})
    if isinstance(pack, dict):
        pack["quality_modifiers"] = modifiers
        pack["opportunity_policy"] = {
            "version": V44_VERSION,
            "edge_floor": _CENTRAL_MIN_EDGE,
            "margin_floor": _CENTRAL_MIN_MARGIN,
            "wait_is_not_a_target": True,
            "hard_safety_vetoes_preserved": True,
            "quality_channels_not_counted_as_direction": True,
        }
        x["unified_central"] = pack
        arch = x.get("decision_architecture") if isinstance(x.get("decision_architecture"),dict) else {}
        arch.update({"balanced_opportunity_policy": V44_VERSION,
                    "quality_channels_separate_from_direction": True,
                    "outcome_learning_required": True})
        x["decision_architecture"] = arch
        x["authority"] = V44_VERSION
    return x

# Detailed read-only evaluation endpoint. It reports observed history rather than
# claiming that a model has learned correctly merely because a loop is running.
@app.get("/api/decision-quality")
def api_decision_quality():
    try:
        with DB_LOCK, db_conn() as con:
            rows = con.execute("""SELECT outcome, confidence FROM central_predictions
                WHERE outcome IN ('WIN','LOSS') ORDER BY created_at DESC LIMIT 5000""").fetchall()
            total = int(con.execute("SELECT COUNT(*) FROM central_predictions").fetchone()[0])
            pending = int(con.execute("SELECT COUNT(*) FROM central_predictions WHERE outcome='PENDING'").fetchone()[0])
            # Optional trade metrics table is present in newer DB schemas.
            metrics = []
            try:
                metrics = con.execute("""SELECT m.r_multiple,m.net_return_pct,p.outcome
                    FROM central_trade_metrics m JOIN central_predictions p ON p.id=m.prediction_id
                    WHERE p.outcome IN ('WIN','LOSS') ORDER BY m.evaluated_at DESC LIMIT 5000""").fetchall()
            except Exception:
                _swallow()
                metrics = []
        wins = sum(1 for r in rows if str(r[0]) == 'WIN')
        losses = sum(1 for r in rows if str(r[0]) == 'LOSS')
        confs = [safe_float(r[1], 0.0) for r in rows if r[1] is not None]
        rs = [safe_float(r[0], 0.0) for r in metrics if r[0] is not None]
        returns = [safe_float(r[1], 0.0) for r in metrics if r[1] is not None]
        return jsonify({"ok": True, "version": V44_VERSION,
            "history": {"recorded_predictions": total, "pending": pending,
                "resolved": len(rows), "wins": wins, "losses": losses,
                "observed_win_rate_pct": round(100*wins/max(1,wins+losses), 2) if rows else None,
                "mean_recorded_confidence": round(sum(confs)/len(confs),2) if confs else None,
                "mean_r_multiple": round(sum(rs)/len(rs),4) if rs else None,
                "mean_net_return_pct": round(sum(returns)/len(returns),4) if returns else None,
                "trade_metric_samples": len(metrics)},
            "learning_status": {"outcome_based": True,
                "insufficient_history": len(rows) < 30,
                "minimum_resolved_for_reliable_calibration": 30,
                "note": "این آمار گذشته است؛ به‌تنهایی تضمین‌کننده عملکرد آینده نیست."},
            "audit": {"last_5000_resolved_outcomes_used": len(rows),
                "confidence_is_not_win_probability": True,
                "win_rate_excludes_pending": True}})
    except Exception as exc:
        return jsonify({"ok": False, "version": V44_VERSION, "error": str(exc)[:240]}), 500


# ============================================================
# TITAN V44 — ADAPTIVE OPPORTUNITY + CONTINUOUS ERROR-LEARNING BRAIN
# ============================================================
# V44 does not promise zero errors.  Its job is to reduce avoidable errors,
# distinguish unsafe WAITs from merely weak-consensus WAITs, and adapt bounded
# thresholds from realized outcomes without allowing a short bad/good streak to
# destabilize the governor.
V44_VERSION = "TITAN-V44-ADAPTIVE-OPPORTUNITY-LEARNING"
V44_POLICY_MIN_SAMPLES = 12
V44_POLICY_WINDOW = 80
V44_BASE_EDGE = 0.135
V44_BASE_MARGIN = 0.075
V44_BASE_TRUST = 46.0
V44_MIN_EDGE = 0.105
V44_MAX_EDGE = 0.205
V44_MIN_MARGIN = 0.055
V44_MAX_MARGIN = 0.135
V44_MIN_TRUST = 42.0
V44_MAX_TRUST = 55.0
V44_MIN_CONFIDENCE = 58.0
V44_MAX_CONFIDENCE = 90.0


def _v44_learning_schema() -> None:
    try:
        with DB_LOCK, db_conn() as con:
            con.execute("""CREATE TABLE IF NOT EXISTS central_learning_events(
                prediction_id INTEGER PRIMARY KEY,
                created_at REAL,
                symbol TEXT,
                direction TEXT,
                outcome TEXT,
                return_pct REAL,
                error_class TEXT,
                lesson TEXT,
                regime TEXT,
                confidence REAL,
                edge REAL,
                margin REAL,
                policy_edge REAL,
                policy_margin REAL,
                policy_trust REAL,
                learned_at REAL
            )""")
            con.execute("""CREATE TABLE IF NOT EXISTS central_policy_state(
                scope TEXT PRIMARY KEY,
                samples INTEGER DEFAULT 0,
                wins INTEGER DEFAULT 0,
                losses INTEGER DEFAULT 0,
                time_exits INTEGER DEFAULT 0,
                avg_return REAL DEFAULT 0,
                win_rate REAL DEFAULT 50,
                edge_threshold REAL DEFAULT 0.135,
                margin_threshold REAL DEFAULT 0.075,
                trust_threshold REAL DEFAULT 46,
                last_update REAL,
                lesson TEXT
            )""")
            con.execute("CREATE INDEX IF NOT EXISTS idx_learning_symbol ON central_learning_events(symbol,learned_at)")
            con.commit()
    except Exception as exc:
        LOGGER.debug("V44 learning schema: %s", exc)


_v44_learning_schema()


def _v44_policy_stats(symbol: str = "", direction: str = "") -> dict[str, Any]:
    """Read realized outcomes; never treat PENDING/AMBIGUOUS as wins/losses."""
    try:
        clauses = ["outcome IN ('WIN','LOSS','TIME_EXIT')"]
        args: list[Any] = []
        if symbol:
            clauses.append("symbol=?")
            args.append(_normalize_symbol(symbol))
        if direction in {"LONG", "SHORT"}:
            clauses.append("decision=?")
            args.append(direction)
        where = " AND ".join(clauses)
        with DB_LOCK, db_conn() as con:
            rows = con.execute(
                f"SELECT outcome,return_pct,confidence,created_at FROM central_predictions WHERE {where} ORDER BY created_at DESC LIMIT ?",
                (*args, V44_POLICY_WINDOW),
            ).fetchall()
        if not rows:
            return {"samples": 0, "wins": 0, "losses": 0, "time_exits": 0, "win_rate": 50.0,
                    "avg_return": 0.0, "thresholds": {"edge": V44_BASE_EDGE, "margin": V44_BASE_MARGIN, "trust": V44_BASE_TRUST}}
        usable = [r for r in rows if str(r[0]) in {"WIN", "LOSS", "TIME_EXIT"}]
        wins = sum(str(r[0]) == "WIN" for r in usable)
        losses = sum(str(r[0]) == "LOSS" for r in usable)
        exits = sum(str(r[0]) == "TIME_EXIT" for r in usable)
        n_bin = wins + losses
        wr = 100.0 * wins / n_bin if n_bin else 50.0
        returns = [safe_float(r[1], 0.0) for r in usable]
        avg_ret = sum(returns) / len(returns) if returns else 0.0
        # Bounded adaptation: good realized edge opens the gate slightly;
        # weak realized edge tightens it.  The adjustment is deliberately small.
        edge = V44_BASE_EDGE
        margin = V44_BASE_MARGIN
        trust = V44_BASE_TRUST
        if len(usable) >= V44_POLICY_MIN_SAMPLES:
            if wr >= 62.0 and avg_ret > 0:
                edge -= 0.018; margin -= 0.012; trust -= 1.5
            elif wr >= 56.0 and avg_ret >= 0:
                edge -= 0.010; margin -= 0.007; trust -= 0.8
            elif wr <= 42.0 or avg_ret < -0.10:
                edge += 0.028; margin += 0.018; trust += 2.5
            elif wr <= 47.0:
                edge += 0.015; margin += 0.010; trust += 1.2
        return {
            "samples": len(usable), "wins": wins, "losses": losses, "time_exits": exits,
            "win_rate": round(wr, 2), "avg_return": round(avg_ret, 5),
            "thresholds": {"edge": clamp(edge, V44_MIN_EDGE, V44_MAX_EDGE),
                           "margin": clamp(margin, V44_MIN_MARGIN, V44_MAX_MARGIN),
                           "trust": clamp(trust, V44_MIN_TRUST, V44_MAX_TRUST)},
        }
    except Exception as exc:
        return {"samples": 0, "wins": 0, "losses": 0, "time_exits": 0, "win_rate": 50.0,
                "avg_return": 0.0, "thresholds": {"edge": V44_BASE_EDGE, "margin": V44_BASE_MARGIN, "trust": V44_BASE_TRUST},
                "error": str(exc)[:160]}


def _v44_hard_safety_reasons(item: dict[str, Any]) -> list[str]:
    """Reasons that must never be overridden merely to capture opportunity."""
    hard: list[str] = []
    u = item.get("unified_central") or {}
    for r in u.get("participation", {}).get("hard_vetoes", []) if isinstance(u, dict) else []:
        hard.append(str(r))
    v40 = item.get("v40_precision") or {}
    if isinstance(v40, dict):
        hard.extend(str(x) for x in (v40.get("hard_blocks") or []) if x)
        if bool(v40.get("veto")) or bool(v40.get("hard_block")):
            hard.append("V40_HARD_VETO")
    real = (item.get("central_decision") or {}).get("real_edge") or item.get("real_edge") or {}
    if isinstance(real, dict):
        for r in real.get("no_trade_reasons") or []:
            # quality-only reasons are soft; structural/risk violations remain hard.
            rs = str(r)
            if rs in {"invalid_levels", "weak_rr", "correlation_risk", "regime_conflict", "structure_not_confirmed",
                      "liquidity_flow_conflict", "late_entry"}:
                hard.append(rs)
    integ = item.get("v42_integrity") or {}
    if isinstance(integ, dict) and not integ.get("passed", True):
        for r in integ.get("reasons") or []:
            hard.append(str(r))
    return list(dict.fromkeys(hard))


def _v44_should_promote(item: dict[str, Any]) -> tuple[bool, dict[str, Any]]:
    """Turn only *soft* WAITs into opportunities when evidence is strong enough."""
    x = item or {}
    u = x.get("unified_central") or {}
    candidate = str(u.get("candidate") or "WAIT").upper()
    if candidate not in {"LONG", "SHORT"}:
        return False, {"reason": "no_directional_candidate"}
    hard = _v44_hard_safety_reasons(x)
    if hard:
        return False, {"reason": "hard_safety", "hard_reasons": hard}
    stats = _v44_policy_stats(str(x.get("symbol") or ""), candidate)
    th = stats.get("thresholds") or {}
    edge = safe_float(u.get("edge"), 0.0)
    margin = safe_float(u.get("margin"), 0.0)
    trust = safe_float(u.get("trust"), 0.0)
    conf = safe_float(u.get("confidence"), safe_float(x.get("decision_confidence"), 0.0))
    # Require two independent dimensions above gate plus usable confidence.
    ok = edge >= safe_float(th.get("edge"), V44_BASE_EDGE) and \
         margin >= safe_float(th.get("margin"), V44_BASE_MARGIN) and \
         trust >= safe_float(th.get("trust"), V44_BASE_TRUST) and \
         conf >= V44_MIN_CONFIDENCE
    return ok, {
        "candidate": candidate, "edge": round(edge, 5), "margin": round(margin, 5), "trust": round(trust, 2),
        "confidence": round(conf, 2), "thresholds": th, "policy_stats": stats,
        "hard_reasons": hard, "promoted": bool(ok),
    }


def _v44_apply_opportunity_policy_base(item: dict[str, Any]) -> dict[str, Any]:
    """Adaptive final policy: preserve V42 safety, recover only quality WAITs."""
    x = dict(item or {})
    before = str(x.get("decision_tag") or x.get("decision") or "WAIT").upper()
    if before != "WAIT":
        x["v44_opportunity"] = {"version": V44_VERSION, "promoted": False, "reason": "already_directional"}
        return x
    ok, audit = _v44_should_promote(x)
    if not ok:
        x["v44_opportunity"] = {"version": V44_VERSION, **audit}
        return x

    candidate = audit["candidate"]
    # Re-run the integrity contract on the candidate before publishing it.
    trial = dict(x)
    trial["decision"] = candidate
    trial["decision_tag"] = candidate
    trial["bias"] = "صعودی" if candidate == "LONG" else "نزولی"
    trial["entry_mode"] = "EARLY"
    trial["signal_tag"] = f"ADAPTIVE-CENTRAL — {candidate}"
    trial["decision_state"] = f"ADAPTIVE_CENTRAL_{candidate}"
    trial = _v42_integrity_seal(trial)
    if str(trial.get("decision_tag") or "WAIT") != candidate:
        audit["promoted"] = False
        audit["reason"] = "integrity_recheck_failed"
        audit["integrity"] = trial.get("v42_integrity") or {}
        x["v44_opportunity"] = audit
        return x

    x.update({
        "decision": candidate, "decision_tag": candidate,
        "bias": "صعودی" if candidate == "LONG" else "نزولی",
        "entry_mode": "EARLY",
        "signal_tag": f"ADAPTIVE-CENTRAL — {candidate}",
        "decision_state": f"ADAPTIVE_CENTRAL_{candidate}",
        "decision_confidence": round(clamp(safe_float((x.get("unified_central") or {}).get("confidence"), 0.0), V44_MIN_CONFIDENCE, V44_MAX_CONFIDENCE), 2),
        "v44_opportunity": {"version": V44_VERSION, **audit},
    })
    arch = dict(x.get("decision_architecture") or {})
    arch.update({"adaptive_opportunity_policy": V44_VERSION, "final_decision": candidate,
                 "soft_wait_recovered": True, "hard_safety_overridable": False})
    x["decision_architecture"] = arch
    x["authority"] = V44_VERSION
    return x


def _v44_learn_realized_outcomes() -> int:
    """Create explicit error/lesson records and persistent policy state."""
    done = 0
    try:
        with DB_LOCK, db_conn() as con:
            rows = con.execute(
                """SELECT p.id,p.created_at,p.symbol,p.decision,p.outcome,p.return_pct,p.confidence,p.margin,p.reasons_json,
                          m.regime
                   FROM central_predictions p LEFT JOIN central_trade_metrics m ON m.prediction_id=p.id
                   WHERE p.outcome IN ('WIN','LOSS','TIME_EXIT','AMBIGUOUS')
                     AND NOT EXISTS (SELECT 1 FROM central_learning_events e WHERE e.prediction_id=p.id)
                   ORDER BY p.evaluated_at LIMIT 250"""
            ).fetchall()
        for row in rows:
            rid, created, symbol, direction, outcome, ret, conf, margin, reasons_json, regime = row
            try:
                reasons = json.loads(reasons_json or "[]")
            except Exception:
                _swallow()
                reasons = []
            if outcome == "WIN":
                error_class = "NONE"
                lesson = "تصمیم تحقق‌یافته موفق بود؛ وزن شواهد هم‌جهت حفظ و فقط در صورت تکرار تقویت شود."
            elif outcome == "LOSS":
                error_class = "FALSE_DIRECTION"
                lesson = "تصمیم اشتباه بود؛ عوامل هم‌جهت با تصمیم باید در نمونه‌های بعدی وزن کمتری بگیرند و شرایط شکست بررسی شود."
            elif outcome == "TIME_EXIT":
                error_class = "NO_RESOLUTION"
                lesson = "حرکت کافی برای تحقق هدف/حدضرر رخ نداد؛ این نمونه برای کالیبراسیون باینری ضعیف است و نباید برد محسوب شود."
            else:
                error_class = "AMBIGUOUS_PATH"
                lesson = "ترتیب لمس سطوح نامشخص بود؛ نمونه از یادگیری برد/باخت حذف می‌شود."
            with DB_LOCK, db_conn() as con:
                con.execute(
                    """INSERT OR IGNORE INTO central_learning_events(
                       prediction_id,created_at,symbol,direction,outcome,return_pct,error_class,lesson,regime,confidence,edge,margin,policy_edge,policy_margin,policy_trust,learned_at)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (rid,created, symbol,direction,outcome,safe_float(ret,0),error_class,lesson,regime,
                     safe_float(conf,0),0.0,safe_float(margin,0),V44_BASE_EDGE,V44_BASE_MARGIN,V44_BASE_TRUST,time.time())
                )
                con.commit()
            done += 1
        # Persist current bounded policy for global/LONG/SHORT and symbols with data.
        scopes = [("GLOBAL", ""), ("LONG", "LONG"), ("SHORT", "SHORT")]
        try:
            with DB_LOCK, db_conn() as con:
                syms = [r[0] for r in con.execute("SELECT DISTINCT symbol FROM central_predictions WHERE symbol IS NOT NULL LIMIT 200").fetchall()]
        except Exception:
            _swallow()
            syms = []
        for scope, direction in scopes + [(f"SYMBOL:{s}", "") for s in syms]:
            sym = scope.split(":",1)[1] if scope.startswith("SYMBOL:") else ""
            st = _v44_policy_stats(sym, direction)
            th = st.get("thresholds") or {}
            with DB_LOCK, db_conn() as con:
                con.execute(
                    """INSERT INTO central_policy_state(scope,samples,wins,losses,time_exits,avg_return,win_rate,edge_threshold,margin_threshold,trust_threshold,last_update,lesson)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
                       ON CONFLICT(scope) DO UPDATE SET samples=excluded.samples,wins=excluded.wins,losses=excluded.losses,time_exits=excluded.time_exits,
                       avg_return=excluded.avg_return,win_rate=excluded.win_rate,edge_threshold=excluded.edge_threshold,margin_threshold=excluded.margin_threshold,
                       trust_threshold=excluded.trust_threshold,last_update=excluded.last_update,lesson=excluded.lesson""",
                    (scope,st.get("samples",0),st.get("wins",0),st.get("losses",0),st.get("time_exits",0),st.get("avg_return",0),st.get("win_rate",50),
                     safe_float(th.get("edge"),V44_BASE_EDGE),safe_float(th.get("margin"),V44_BASE_MARGIN),safe_float(th.get("trust"),V44_BASE_TRUST),time.time(),
                     "bounded adaptive policy from realized outcomes"),
                )
                con.commit()
        return done
    except Exception as exc:
        LOGGER.debug("V44 learner: %s", exc)
        return done


# Wrap the existing evaluator so realized outcomes automatically feed the
# adaptive policy without changing its careful chronological first-touch logic.
_V44_PREV_EVALUATE_PENDING = _central_evaluate_pending_base

def _central_evaluate_pending_v44() -> dict[str, Any]:
    result = _V44_PREV_EVALUATE_PENDING()
    try:
        learned = _v44_learn_realized_outcomes()
        if isinstance(result, dict):
            result = dict(result)
            result["v44_learning_events"] = learned
    except Exception:
        _swallow()
    return result


# Final public gateway: V43 remains the one-brain evidence arbiter; V44 only
# recovers high-quality soft WAITs and can never bypass V42 hard integrity.
_V44_PREV_ANALYZE = _analyze_asset_central

def _analyze_asset_v44(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:
    x = _V44_PREV_ANALYZE(symbol, btc_trend)
    if not x:
        return x
    out = _v44_apply_opportunity_policy(x)
    try:
        _central_record_prediction(out)
    except Exception:
        _swallow()
    return out


@app.get("/api/adaptive-learning")
def api_adaptive_learning():
    try:
        global_stats = _v44_policy_stats()
        long_stats = _v44_policy_stats(direction="LONG")
        short_stats = _v44_policy_stats(direction="SHORT")
        with DB_LOCK, db_conn() as con:
            lessons = con.execute(
                "SELECT symbol,direction,outcome,error_class,lesson,confidence,created_at,learned_at FROM central_learning_events ORDER BY learned_at DESC LIMIT 100"
            ).fetchall()
        return jsonify({
            "ok": True, "version": V44_VERSION,
            "global": global_stats, "long": long_stats, "short": short_stats,
            "lessons": [dict(symbol=r[0],direction=r[1],outcome=r[2],error_class=r[3],lesson=r[4],confidence=r[5],created_at=r[6],learned_at=r[7]) for r in lessons],
            "policy": {"soft_wait_recovery": True, "hard_safety_override": False,
                       "bounded_adaptation": True, "zero_error_claim": False},
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)[:240]}), 500
