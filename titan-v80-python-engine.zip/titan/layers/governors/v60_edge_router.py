# [TITAN V77 layer] governors/v60_edge_router - V60 edge router
# Original V76 source lines 20405-21005 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# TITAN V60 — EDGE ROUTER (Coin × TF × Side × Setup × Regime)
# Reads REAL performance_snapshots from MMM SQLite only.
# Never fabricates win-rate or expectancy. Routes action weight
# by historical cell evidence while preserving hard safety gates.
# ============================================================
V60_VERSION = "TITAN-V60-EDGE-ROUTER"
V60_BUILD_ID = "V60-EDGE-2026-10"
V60_ROUTER_LOCK = threading.RLock()
_V60_MATRIX_CACHE: dict[str, Any] = {"ts": 0.0, "cells": {}, "tf_priors": {}, "symbol_priors": {}}
_V60_MATRIX_TTL = 120.0  # refresh from DB every 2 minutes

# Prior from measured snapshots (fallback only when DB cell sparse).
# Values are expectancy_pct-like; router never treats them as guaranteed profit.
V60_TF_PRIOR = {
    "15m": {"exp": -0.22, "wr": 34.0, "weight": 0.35, "policy": "DEFENSIVE"},
    "1h":  {"exp": -0.10, "wr": 41.0, "weight": 0.70, "policy": "CAUTIOUS"},
    "4h":  {"exp": -0.02, "wr": 41.0, "weight": 1.05, "policy": "STANDARD"},
    "1d":  {"exp": +0.28, "wr": 47.0, "weight": 1.25, "policy": "PREFERRED"},
}

def _v60_norm_sym(symbol: str) -> str:
    return _normalize_symbol(symbol)


def _v60_load_matrix_from_db() -> dict[str, Any]:
    """Build Coin×TF cells from latest performance_snapshots (real rows only)."""
    cells: dict[str, dict[str, Any]] = {}
    tf_acc: dict[str, list[float]] = {}
    sym_acc: dict[str, list[float]] = {}
    try:
        with DB_LOCK, db_conn() as con:
            rows = con.execute(
                """
                SELECT symbol, timeframe, trades, wins, losses, win_rate, expectancy,
                       profit_factor, sharpe, max_drawdown, metrics_json, created_at
                FROM performance_snapshots
                WHERE id IN (
                    SELECT MAX(id) FROM performance_snapshots GROUP BY symbol, timeframe
                )
                """
            ).fetchall()
        for r in rows:
            sym = _v60_norm_sym(r["symbol"] if isinstance(r, sqlite3.Row) else r[0])
            tf = str(r["timeframe"] if isinstance(r, sqlite3.Row) else r[1])
            trades = int(r["trades"] if isinstance(r, sqlite3.Row) else r[2] or 0)
            wr = safe_float(r["win_rate"] if isinstance(r, sqlite3.Row) else r[5], float("nan"))
            exp = safe_float(r["expectancy"] if isinstance(r, sqlite3.Row) else r[6], float("nan"))
            pf = safe_float(r["profit_factor"] if isinstance(r, sqlite3.Row) else r[7], float("nan"))
            sh = safe_float(r["sharpe"] if isinstance(r, sqlite3.Row) else r[8], float("nan"))
            mdd = safe_float(r["max_drawdown"] if isinstance(r, sqlite3.Row) else r[9], float("nan"))
            if not math.isfinite(exp):
                continue
            key = f"{sym}|{tf}"
            # Edge score: combine expectancy, PF, sample size honesty
            n_factor = min(1.0, trades / 60.0) if trades > 0 else 0.0
            pf_term = 0.0
            if math.isfinite(pf) and pf > 0:
                pf_term = float(np.clip((pf - 1.0) * 0.35, -0.35, 0.55))
            edge = exp * 0.55 + pf_term + (0.0 if not math.isfinite(wr) else (wr - 45.0) * 0.004)
            edge *= (0.45 + 0.55 * n_factor)  # shrink sparse cells
            # Classify cell
            if trades < 25:
                grade = "SPARSE"
            elif edge >= 0.25 and (not math.isfinite(pf) or pf >= 1.05):
                grade = "STRONG"
            elif edge >= 0.05:
                grade = "POSITIVE"
            elif edge >= -0.08:
                grade = "NEUTRAL"
            elif edge >= -0.25:
                grade = "WEAK"
            else:
                grade = "TOXIC"
            cells[key] = {
                "symbol": sym, "timeframe": tf, "trades": trades,
                "win_rate": round(wr, 2) if math.isfinite(wr) else None,
                "expectancy": round(exp, 4),
                "profit_factor": round(pf, 3) if math.isfinite(pf) else None,
                "sharpe": round(sh, 3) if math.isfinite(sh) else None,
                "max_drawdown": round(mdd, 2) if math.isfinite(mdd) else None,
                "edge_score": round(edge, 4),
                "grade": grade,
                "source": "performance_snapshots",
            }
            tf_acc.setdefault(tf, []).append(exp)
            sym_acc.setdefault(sym, []).append(exp)
        tf_priors = {}
        for tf, vals in tf_acc.items():
            base = dict(V60_TF_PRIOR.get(tf, V60_TF_PRIOR["1h"]))
            if vals:
                base["exp"] = float(sum(vals) / len(vals))
                base["samples"] = len(vals)
            tf_priors[tf] = base
        sym_priors = {s: {"exp": float(sum(v) / len(v)), "n": len(v)} for s, v in sym_acc.items() if v}
        return {"cells": cells, "tf_priors": tf_priors or dict(V60_TF_PRIOR), "symbol_priors": sym_priors}
    except Exception as exc:
        LOGGER.warning("V60 matrix load failed: %s", exc)
        return {"cells": {}, "tf_priors": dict(V60_TF_PRIOR), "symbol_priors": {}}


def v60_get_matrix(force: bool = False) -> dict[str, Any]:
    now = time.time()
    with V60_ROUTER_LOCK:
        if (not force) and _V60_MATRIX_CACHE.get("cells") and (now - float(_V60_MATRIX_CACHE.get("ts") or 0) < _V60_MATRIX_TTL):
            return _V60_MATRIX_CACHE
        data = _v60_load_matrix_from_db()
        _V60_MATRIX_CACHE.clear()
        _V60_MATRIX_CACHE.update(data)
        _V60_MATRIX_CACHE["ts"] = now
        return _V60_MATRIX_CACHE


def v60_cell_lookup(symbol: str, timeframe: str = "1h") -> dict[str, Any]:
    m = v60_get_matrix()
    sym = _v60_norm_sym(symbol)
    tf = str(timeframe or "1h")
    cell = dict((m.get("cells") or {}).get(f"{sym}|{tf}") or {})
    if not cell:
        prior = dict((m.get("tf_priors") or V60_TF_PRIOR).get(tf, V60_TF_PRIOR["1h"]))
        cell = {
            "symbol": sym, "timeframe": tf, "trades": 0,
            "win_rate": prior.get("wr"), "expectancy": prior.get("exp"),
            "profit_factor": None, "sharpe": None, "max_drawdown": None,
            "edge_score": float(prior.get("exp") or 0) * 0.5,
            "grade": "PRIOR", "source": "tf_prior",
        }
    cell["tf_weight"] = float((m.get("tf_priors") or V60_TF_PRIOR).get(tf, {}).get("weight", 1.0))
    cell["tf_policy"] = str((m.get("tf_priors") or V60_TF_PRIOR).get(tf, {}).get("policy", "STANDARD"))
    return cell


def v60_route_decision(
    *,
    symbol: str,
    candidate: str,
    proposed: str,
    hard_reasons: list[str],
    soft_reasons: Optional[list[str]] = None,
    timeframe: str = "1h",
    setup: str = "",
    regime: str = "",
    confidence: float = 50.0,
    effective_rr1: float = 0.0,
    data_quality: float = 50.0,
) -> dict[str, Any]:
    """Classify HARD_WAIT / SOFT_WAIT / ROUTED_ACTION from real edge cells.

    Hard safety never overridden. Strong historical cells can rescue soft waits.
    """
    soft_reasons = list(soft_reasons or [])
    hard = [str(r) for r in (hard_reasons or []) if r]
    cand = str(candidate or "").upper()
    prop = str(proposed or "").upper()
    side = prop if prop in {"LONG", "SHORT"} else (cand if cand in {"LONG", "SHORT"} else "WAIT")

    # Primary TF cell + HTF support cells
    cell = v60_cell_lookup(symbol, timeframe)
    cell_4h = v60_cell_lookup(symbol, "4h")
    cell_1d = v60_cell_lookup(symbol, "1d")
    cell_15 = v60_cell_lookup(symbol, "15m")

    # Composite edge: prefer higher TF evidence
    edge = (
        0.15 * safe_float(cell_15.get("edge_score"), 0)
        + 0.25 * safe_float(cell.get("edge_score"), 0)
        + 0.30 * safe_float(cell_4h.get("edge_score"), 0)
        + 0.30 * safe_float(cell_1d.get("edge_score"), 0)
    )
    tf_w = float(cell.get("tf_weight") or 1.0)
    # 15m defensive: shrink route weight when toxic/weak
    if timeframe == "15m" and cell.get("grade") in {"TOXIC", "WEAK", "SPARSE", "PRIOR"}:
        tf_w *= 0.45
    elif timeframe == "1h" and cell.get("grade") in {"TOXIC", "WEAK"}:
        tf_w *= 0.70
    elif timeframe in {"4h", "1d"} and cell.get("grade") in {"STRONG", "POSITIVE"}:
        tf_w *= 1.15

    route_score = float(clamp(50.0 + edge * 40.0 * tf_w + (confidence - 50.0) * 0.25, 0, 100))

    # HARD gates — absolute
    HARD_KEYS = (
        "invalid_price_levels", "invalid_long_level_orientation", "invalid_short_level_orientation",
        "effective_rr_below_floor", "live_price_required", "data_quality_hard",
        "extreme_volatility", "correlation_cluster", "liquidity_conflict",
        "entry_too_late", "mandatory_htf_data_missing",
    )
    is_hard = any(any(k in str(h) for k in HARD_KEYS) for h in hard) or bool(hard and side == "WAIT" and "hard" in " ".join(hard).lower())
    # Explicit hard from list
    hard_hit = [h for h in hard if any(k in str(h) for k in HARD_KEYS)] or list(hard[:4])

    if hard and side in {"LONG", "SHORT"} and (
        "invalid_" in " ".join(hard)
        or "effective_rr_below" in " ".join(hard)
        or "live_price_required" in " ".join(hard)
        or "extreme_volatility" in " ".join(hard)
    ):
        return {
            "route": "HARD_WAIT",
            "action": "WAIT",
            "side": "WAIT",
            "route_score": round(min(route_score, 40), 1),
            "reason": "گیت سخت ایمنی فعال",
            "hard_blocks": hard_hit,
            "soft_blocks": soft_reasons[:6],
            "cell": cell,
            "edge_composite": round(edge, 4),
            "tf_weight": round(tf_w, 3),
            "version": V60_VERSION,
        }

    if hard and not hard_hit:
        # Treat remaining hard list as soft-capable unless economic/level break
        soft_reasons = soft_reasons + hard
        hard = []

    # Strong historical edge can promote soft wait → routed action
    strong_hist = (
        cell.get("grade") in {"STRONG", "POSITIVE"}
        or cell_1d.get("grade") in {"STRONG", "POSITIVE"}
        or cell_4h.get("grade") in {"STRONG"}
    ) and safe_float(cell_1d.get("expectancy"), -1) > 0.05

    toxic_hist = cell.get("grade") == "TOXIC" or (
        timeframe in {"15m", "1h"} and safe_float(cell.get("expectancy"), 0) < -0.20
    )

    if side not in {"LONG", "SHORT"}:
        # No directional candidate
        if strong_hist and route_score >= 58 and data_quality >= 44:
            return {
                "route": "SOFT_WAIT",
                "action": "WATCH",
                "side": "WAIT",
                "route_score": round(route_score, 1),
                "reason": "لبه تاریخی مثبت اما کاندید جهت‌دار نیست — رصد",
                "hard_blocks": [],
                "soft_blocks": soft_reasons[:6],
                "cell": cell,
                "edge_composite": round(edge, 4),
                "tf_weight": round(tf_w, 3),
                "version": V60_VERSION,
            }
        return {
            "route": "SOFT_WAIT" if soft_reasons else "HARD_WAIT",
            "action": "WAIT",
            "side": "WAIT",
            "route_score": round(route_score, 1),
            "reason": "بدون کاندید جهت‌دار",
            "hard_blocks": hard_hit,
            "soft_blocks": soft_reasons[:6],
            "cell": cell,
            "edge_composite": round(edge, 4),
            "tf_weight": round(tf_w, 3),
            "version": V60_VERSION,
        }

    if toxic_hist and timeframe in {"15m", "1h"} and not strong_hist:
        return {
            "route": "SOFT_WAIT",
            "action": "WAIT",
            "side": side,  # keep lean visible
            "route_score": round(min(route_score, 48), 1),
            "reason": f"سلول تاریخی {timeframe} ضعیف/سمی — وزن کاهش یافت",
            "hard_blocks": [],
            "soft_blocks": soft_reasons[:6] + [f"toxic_cell_{timeframe}"],
            "cell": cell,
            "edge_composite": round(edge, 4),
            "tf_weight": round(tf_w, 3),
            "version": V60_VERSION,
        }

    # Routed action when side exists, DQ ok, RR ok, and (hist strong OR score high)
    rr_ok = effective_rr1 >= (V49_MIN_EFFECTIVE_RR * 0.95) if effective_rr1 else True
    dq_ok = data_quality >= max(40.0, MIN_DATA_QUALITY_SCORE - 4)
    promote = (
        side in {"LONG", "SHORT"}
        and dq_ok
        and rr_ok
        and (
            (strong_hist and route_score >= 52)
            or (route_score >= 60 and cell.get("grade") not in {"TOXIC"})
            or (timeframe in {"4h", "1d"} and route_score >= 55 and cell.get("grade") in {"STRONG", "POSITIVE", "NEUTRAL"})
        )
    )

    if promote and not hard:
        return {
            "route": "ROUTED_ACTION",
            "action": side,
            "side": side,
            "route_score": round(route_score, 1),
            "reason": (
                f"مسیریابی V60: سلول {cell.get('grade')} · TF={timeframe} · "
                f"edge={edge:+.3f} · وزن={tf_w:.2f}"
            ),
            "hard_blocks": [],
            "soft_blocks": soft_reasons[:4],
            "cell": cell,
            "htf_cells": {"4h": cell_4h.get("grade"), "1d": cell_1d.get("grade")},
            "edge_composite": round(edge, 4),
            "tf_weight": round(tf_w, 3),
            "version": V60_VERSION,
        }

    # Soft wait — keep side lean for UI
    return {
        "route": "SOFT_WAIT",
        "action": "WAIT",
        "side": side,
        "route_score": round(route_score, 1),
        "reason": "انتظار نرم — لبه/کیفیت برای انتشار کافی نیست",
        "hard_blocks": hard_hit,
        "soft_blocks": soft_reasons[:6],
        "cell": cell,
        "edge_composite": round(edge, 4),
        "tf_weight": round(tf_w, 3),
        "version": V60_VERSION,
    }


def v60_apply_to_item(item: dict[str, Any]) -> dict[str, Any]:
    """Attach V60 route to an analysis item and adjust publish stance."""
    if not isinstance(item, dict):
        return item
    v49 = item.get("v49") if isinstance(item.get("v49"), dict) else {}
    candidate = str(v49.get("candidate") or item.get("decision_tag") or item.get("decision") or "WAIT")
    proposed = str(v49.get("decision") or item.get("decision_tag") or "WAIT")
    hard = list(v49.get("hard_blocks") or item.get("hard_blocks") or [])
    soft = list(item.get("soft_blocks") or [])
    # Infer primary TF from scores if present
    tfs = item.get("tf_scores") if isinstance(item.get("tf_scores"), dict) else {}
    primary_tf = "1h"
    if tfs:
        # pick TF with max |score-50| among 1h/4h/1d for routing preference
        best, gap = "1h", -1.0
        for tf in ("1h", "4h", "1d", "15m"):
            if tf not in tfs:
                continue
            g = abs(safe_float(tfs.get(tf), 50) - 50)
            if g > gap:
                best, gap = tf, g
        primary_tf = best
    lv = v49.get("levels") if isinstance(v49.get("levels"), dict) else {}
    route = v60_route_decision(
        symbol=str(item.get("symbol") or ""),
        candidate=candidate,
        proposed=proposed,
        hard_reasons=hard,
        soft_reasons=soft,
        timeframe=primary_tf,
        setup=str(v49.get("setup") or item.get("setup") or ""),
        regime=str(item.get("regime") or v49.get("regime") or ""),
        confidence=safe_float(v49.get("confidence"), safe_float(item.get("confidence"), 50)),
        effective_rr1=safe_float(lv.get("effective_rr1"), safe_float(item.get("rr_tp1"), 0)),
        data_quality=safe_float(v49.get("data_quality"), safe_float((item.get("data_quality") or {}).get("score") if isinstance(item.get("data_quality"), dict) else 50, 50)),
    )
    item["v60"] = route
    item["v60_route"] = route.get("route")
    item["v60_edge"] = route.get("edge_composite")
    # Soft wait keeps lean; routed action may publish
    if route.get("route") == "ROUTED_ACTION" and route.get("action") in {"LONG", "SHORT"}:
        item["stance"] = route["action"]
        item["stance_family"] = route["action"]
        item["stance_published"] = True
        item["decision_tag"] = route["action"]
        item["decision"] = route["action"]
        item["bias"] = "صعودی" if route["action"] == "LONG" else "نزولی"
    elif route.get("route") == "SOFT_WAIT" and route.get("side") in {"LONG", "SHORT"}:
        item["stance"] = f"LEAN_{route['side']}"
        item["stance_family"] = route["side"]
        item["stance_published"] = False
        # do not force decision_tag to WAIT if already lean — UI shows LEAN
        if str(item.get("decision_tag") or "WAIT") == "WAIT":
            item["decision_display"] = f"LEAN_{route['side']}"
    elif route.get("route") == "HARD_WAIT":
        item["stance"] = "WAIT"
        item["stance_family"] = "WAIT"
        item["stance_published"] = False
        item["decision_tag"] = "WAIT"
        item["decision"] = "WAIT"
    return item



def _v51_finalize_decision(x: dict[str,Any]) -> dict[str,Any]:
    """Final V51 policy seal: V49 proposes, V51 validates/publishes, legacy layers cannot promote WAIT."""
    out=dict(x or {})
    v=dict(out.get("v49") or {})
    candidate=str(v.get("candidate") or "").upper()
    proposed=str(v.get("decision") or "WAIT").upper()
    final="WAIT"
    reasons=[]
    warnings=[]
    live_age=_v49_num(out.get("live_price_age_sec"),float("nan"))
    price_source=str(out.get("price_source") or "")
    dq=_v49_num(v.get("data_quality"),0)
    hard=list(v.get("hard_blocks") or [])
    presence=v.get("data_presence") or {}
    lv=v.get("levels") or {}
    side_valid=(candidate in {"LONG","SHORT"} and proposed in {"LONG","SHORT"} and proposed==candidate)
    closed_1h=_v49_num(out.get("closed_1h_candle_close_ms"),0)
    closed_15m=_v49_num(out.get("closed_15m_candle_close_ms"),0)
    now=time.time()*1000
    # Data causality / freshness gates. Indicators must be built from closed bars; current price must be live.
    if price_source != "LIVE": reasons.append("live_price_required")
    if not math.isfinite(live_age) or live_age > MAX_LIVE_PRICE_AGE_SEC: reasons.append("live_price_stale_or_unknown")
    if dq < max(V49_HARD_DQ, MIN_DATA_QUALITY_SCORE): reasons.append("data_quality_gate")
    if len(hard)>0: reasons.extend(hard[:6])
    if not ({"1h","4h"}.issubset(set(presence.get("observed_tf") or []))): reasons.append("mandatory_htf_data_missing")
    if int(presence.get("observed_indicator_count") or 0) < 3: reasons.append("insufficient_observed_indicators")
    if not (closed_1h>0 and closed_15m>0 and closed_1h<=now and closed_15m<=now): reasons.append("invalid_closed_candle_timestamps")
    if v.get("probability_status") != "CALIBRATED": warnings.append("probability_not_calibrated")
    # Level orientation and economic sanity. Cost model is already embedded in effective RR.
    price=_v49_num(out.get("price_raw",out.get("live_price",out.get("price"))),0)
    entry=_v49_num(lv.get("entry"),0); sl=_v49_num(lv.get("sl"),0); tp1=_v49_num(lv.get("tp1"),0); tp2=_v49_num(lv.get("tp2"),0)
    if not (price>0 and entry>0 and sl>0 and tp1>0 and tp2>0): reasons.append("invalid_price_levels")
    if candidate=="LONG" and not (sl<entry<tp1<tp2): reasons.append("invalid_long_level_orientation")
    if candidate=="SHORT" and not (tp2<tp1<entry<sl): reasons.append("invalid_short_level_orientation")
    if _v49_num(lv.get("effective_rr1"),0) < V49_MIN_EFFECTIVE_RR: reasons.append("effective_rr_below_floor")
    # A live signal should not publish if the market moved materially beyond the proposed entry zone.
    ep=v.get("entry_plan") or {}
    zlo=_v49_num(ep.get("zone_low"),0); zhi=_v49_num(ep.get("zone_high"),0)
    if zlo>0 and zhi>0 and price>0 and not (zlo <= price <= zhi):
        warnings.append("price_outside_entry_zone")
        reasons.append("late_entry_zone")
    # Only V49 can promote; legacy V47/V48/V32 outputs are audits.
    if not side_valid: reasons.append("v49_policy_not_actionable")
    if str(v.get("mode") or "WATCH") == "WATCH": reasons.append("v49_mode_watch")
    # Portfolio overlap is applied once, here — not independently by multiple decision engines.
    if side_valid and not reasons:
        ok,why=_v51_portfolio_gate(candidate,str(out.get("symbol") or ""))
        if not ok: reasons.append(why)
    if not reasons:
        final=candidate
    else:
        final="WAIT"
    # Risk plan is a budget recommendation, not a position instruction. Include costs and drawdown state.
    risk_mult=clamp(_v49_num(v.get("risk_multiplier"),0.0),0.0,1.0)
    governor=(out.get("edge") or {}).get("governor") if isinstance(out.get("edge"),dict) else {}
    gov_mult=clamp(_v49_num((governor or {}).get("risk_multiplier"),1.0),0.20,1.0)
    if final=="WAIT": risk_pct=0.0
    else: risk_pct=clamp(1.0*risk_mult*gov_mult,0.10,1.25)
    friction_pct=_v49_num(v.get("levels",{}).get("cost_r"),0.0) * max(_v49_num(v.get("levels",{}).get("risk_pct"),0.0),1e-9)
    calibrated_prob=v.get("probability_calibrated") if v.get("probability_status")=="CALIBRATED" else None
    out["v51"]={
        "version":TITAN_PARAM_VERSION, "authority":"TITAN-V51-FINAL-GOVERNOR",
        "candidate":candidate, "proposed":proposed, "decision":final,
        "state":"PUBLISHED" if final in {"LONG","SHORT"} else "BLOCKED_WAIT",
        "reasons":reasons, "warnings":warnings,
        "probability":calibrated_prob, "probability_status":v.get("probability_status"),
        "probability_calibration_samples":int(v.get("calibration_samples") or out.get("v49_calibration_samples") or 0),
        "effective_rr1":round(_v49_num(lv.get("effective_rr1"),0),4),
        "risk_plan":{"recommended_risk_pct":round(risk_pct,3),"v49_risk_multiplier":round(risk_mult,3),"drawdown_governor_multiplier":round(gov_mult,3),"round_trip_friction_pct":round(friction_pct,4)},
        "data_contract":{"price_source":price_source,"live_age_sec":round(live_age,3) if math.isfinite(live_age) else None,"closed_1h_ms":int(closed_1h) if closed_1h else None,"closed_15m_ms":int(closed_15m) if closed_15m else None,"indicators_closed_only":True},
        "legacy_layers_are_evidence_only":True,
    }
    # --- V60 Edge Router: hard/soft/routed classification from real snapshots ---
    try:
        _v60_hard = list(reasons or [])
        _v60_soft = list(warnings or [])
        _v60_tf = "1h"
        _tfs = out.get("tf_scores") if isinstance(out.get("tf_scores"), dict) else {}
        if _tfs:
            _best, _gap = "1h", -1.0
            for _tf in ("1h", "4h", "1d", "15m"):
                if _tf not in _tfs: continue
                _g = abs(_v49_num(_tfs.get(_tf), 50) - 50)
                if _g > _gap: _best, _gap = _tf, _g
            _v60_tf = _best
        _v60_route = v60_route_decision(
            symbol=str(out.get("symbol") or ""),
            candidate=candidate,
            proposed=proposed if side_valid else candidate,
            hard_reasons=_v60_hard,
            soft_reasons=_v60_soft,
            timeframe=_v60_tf,
            setup=str(v.get("setup") or ""),
            regime=str(out.get("regime") or v.get("regime") or ""),
            confidence=_v49_num(v.get("confidence"), 50),
            effective_rr1=_v49_num(lv.get("effective_rr1"), 0),
            data_quality=_v49_num(v.get("data_quality"), dq),
        )
        out["v60"] = _v60_route
        out["v60_route"] = _v60_route.get("route")
        out["v60_edge"] = _v60_route.get("edge_composite")
        # Promote only ROUTED_ACTION; never override pure hard safety already in reasons
        if _v60_route.get("route") == "ROUTED_ACTION" and _v60_route.get("action") in {"LONG", "SHORT"}:
            if not any(k in " ".join(_v60_hard) for k in ("invalid_", "effective_rr_below", "live_price_required", "extreme_volatility")):
                final = str(_v60_route["action"])
                warnings.append("v60_routed_action")
        elif _v60_route.get("route") == "HARD_WAIT":
            final = "WAIT"
        elif _v60_route.get("route") == "SOFT_WAIT":
            # keep final WAIT for publish, but expose lean
            if _v60_route.get("side") in {"LONG", "SHORT"}:
                out["stance"] = f"LEAN_{_v60_route['side']}"
                out["stance_family"] = _v60_route["side"]
                out["stance_published"] = False
                out["decision_display"] = f"LEAN_{_v60_route['side']}"
    except Exception:
        _swallow()
    out["decision"]=final
    out["decision_tag"]=final
    out["bias"]="صعودی" if final=="LONG" else "نزولی" if final=="SHORT" else "خنثی"
    out["authority"]="TITAN-V51-FINAL-GOVERNOR+V60-EDGE-ROUTER"
    out["decision_state"]="V51_PUBLISHED" if final in {"LONG","SHORT"} else "V51_BLOCKED_WAIT"
    out["decision_confidence"]=_v49_num(v.get("confidence"),0) if final in {"LONG","SHORT"} else min(_v49_num(v.get("confidence"),50),55)
    out["signal_tag"]=f"V51 FINAL — {final}"
    # Display score = multi-TF quant spine. Edge score is separate evidence for publish.
    quant_score = _v49_num(out.get("quant_score"), _v49_num(out.get("score"), 50.0))
    edge_raw = _v49_num(v.get("edge"), 0.0)
    edge_score = int(round(clamp(50.0 + 50.0 * edge_raw, 0, 100)))
    # Prefer whichever diverges more from neutral so WAIT cards still show real lean.
    if abs(quant_score - 50.0) >= abs(edge_score - 50.0):
        display_score = int(round(clamp(quant_score, 0, 100)))
    else:
        display_score = edge_score
    # Never collapse a meaningful quant lean back to exactly 50 unless both are neutral.
    out["score"] = display_score
    out["score_bar"] = display_score
    out["quant_score"] = int(round(clamp(quant_score, 0, 100)))
    out["edge_score"] = edge_score
    q_feat = _v49_num(out.get("signal_quality"), 0.0)
    q_v49 = _v49_num(v.get("quality"), 0.0)
    out["signal_quality"] = round(max(q_feat, q_v49, abs(display_score - 50.0) * 1.2), 1)
    out["opportunity_score"] = round(max(q_v49, float(display_score)), 1)
    mode=str(v.get("mode") or "WATCH")
    grade_map={"CORE":"A+","STANDARD":"A","TACTICAL":"B","WATCH":"C"}
    out["grade"]=grade_map.get(mode,"C") if final in {"LONG","SHORT"} else "C"
    out["signal_grade"]={"grade":out["grade"],"label_fa":mode,"action":"PUBLISH" if final in {"LONG","SHORT"} else "WAIT","trust_index":round(_v49_num(v.get("confidence"),0),1),"checklist":[{"ok":False,"name":str(r),"detail":""} for r in list(reasons or [])]}
    if isinstance(lv,dict) and lv:
        out["entry_valid"]=smart_format(entry) if entry>0 else out.get("entry_valid")
        out["stop_loss"]=smart_format(sl) if sl>0 else out.get("stop_loss")
        out["tp1"]=smart_format(tp1) if tp1>0 else out.get("tp1")
        out["tp2"]=smart_format(tp2) if tp2>0 else out.get("tp2")
        out["price_raw"]=price if price>0 else out.get("price_raw")
        out["stop_loss_raw"]=sl;out["tp1_raw"]=tp1;out["tp2_raw"]=tp2
        out["entry_mode"]=str((v.get("entry_plan") or {}).get("mode") or "NOW") if final in {"LONG","SHORT"} else "WAIT"
    out["success_probability"]=calibrated_prob
    out["success_probability_is_calibrated"]=bool(calibrated_prob is not None)
    out["decision_reasons"]=reasons
    out["decision_architecture"]={
        "type":"FEATURE_SPINE -> V49_POLICY -> V51_FINAL_GOVERNOR",
        "authoritative_source":"TITAN-V51-FINAL-GOVERNOR",
        "direction_source":"V49_CURRENT_EVIDENCE",
        "legacy_decision_engines":"AUDIT_ONLY",
        "ai_can_create_direction":False,
        "open_candle_used_for_indicators":False,
        "repaint_protection":"CAUSAL_CLOSED_BAR",
        "lookahead_protection":"CAUSAL_FEATURES + CHRONOLOGICAL_OUTCOME_EVAL",
    }
    return out


_V51_PREV_ANALYZE = _analyze_asset_base

def _v51_build_authoritative(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:
    """Build the V51 candidate only; publication is deferred to V52 Trust Gate."""
    try:
        base=_V51_PREV_ANALYZE(symbol,btc_trend,feature_only=True)
        if not base:return base
        out=_v49_apply(base)
        out=_v51_finalize_decision(out)
        out["publication_deferred"] = True
        out["decision_state"] = "V51_CANDIDATE_READY" if str(out.get("decision_tag") or "WAIT") in {"LONG","SHORT"} else out.get("decision_state")
        return out
    except Exception as exc:
        LOGGER.exception("V51 analyze failed for %s: %s",symbol,exc)
        return None


_V51_PREV_UPDATE = _update_cache_base

def _v52_update_cache_base(force: bool=False):
    """Refresh market data and evaluate only the authoritative V49 ledger outcomes."""
    try:_v49_evaluate_pending(limit=120)
    except Exception as exc: LOGGER.debug("V49 pending evaluation failed: %s",exc)
    return _V51_PREV_UPDATE(force)

def _v49_self_test():
    failures=[]
    def ck(name,cond,detail=""):
        if not cond:failures.append(name);print("  ✗",name,detail)
        else:print("  ✓",name)
    ck("version", V49_VERSION.endswith("DATA-AWARE"))
    ck("horizons",V49_PRIMARY_HORIZON_MIN==1440 and V49_EXTENDED_HORIZON_MIN==2880)
    ck("execution_tf",V49_EXECUTION_TF=="5m")
    ck("wilson_zero",_v49_wilson(0,0) is None)
    ck("beta_prior",abs(_v49_beta(0,0)-40.0)<1e-9)
    ck("level_rr",V49_TARGET_RR2>V49_TARGET_RR1>1)
    ck("no_fake_history",_v49_historical("NOPE/USDT","LONG","UNKNOWN","unknown").get("bayes_probability") is None)
    stats=_v49_stats([{"outcome_24h":"AMBIGUOUS","return_net_24h":1},{"outcome_24h":"WIN","return_net_24h":1,"r_multiple_24h":1.5},{"outcome_24h":"LOSS","return_net_24h":-1,"r_multiple_24h":-1}],"24h")
    ck("ambiguous_excluded",stats["ambiguous"]==1 and stats["decisive_trades"]==2)
    ck("no_raw_wr_without_decisive",_v49_stats([],"24h")["win_rate"] is None)
    sparse={"tf_scores":{},"edge":{},"rsi":None,"macd_cross":"none","macd_hist":None,"taker_buy_pct":None,"long_short_ratio":None}
    dp=_v50_data_presence(sparse)
    ck("missing_data_not_counted",dp["observed_tf_count"]==0 and dp["observed_indicator_count"]==0)
    return 0 if not failures else 1
