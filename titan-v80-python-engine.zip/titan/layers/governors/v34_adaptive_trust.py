# [TITAN V77 layer] governors/v34_adaptive_trust - V34 adaptive trust / calibration
# Original V76 source lines 13880-14035 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# TITAN V34 — ADAPTIVE TRUST / OPPORTUNITY / CALIBRATION CORE
# ------------------------------------------------------------
# Additive evidence layer. It does not execute trades and does not invent
# probabilities. It learns only from realized outcomes already stored by TITAN.
# Goals:
#   1) distinguish "not enough evidence" from "almost actionable"
#   2) reduce unnecessary WAIT near a coherent edge
#   3) calibrate trust using realized history with Bayesian shrinkage
#   4) adapt evidence weight by symbol/direction without overfitting
#   5) expose a transparent scorecard for performance and audit
# ============================================================
V34_VERSION = "TITAN-V34-ADAPTIVE-TRUST-OPPORTUNITY"
V34_MIN_MARGIN = 0.07
V34_PROMOTE_SCORE = 70.0
V34_MIN_DQ = 52.0
V34_MIN_QUALITY = 50.0
V34_MIN_RR = 1.10
V34_MAX_CONTRADICTION = 0.68
V34_MIN_HISTORY = 12
V34_HISTORY_SHRINK = 10.0


def _v34_history(symbol: str, side: str) -> dict[str, Any]:
    """Outcome history with Bayesian shrinkage; tiny samples never dominate."""
    wins = losses = 0
    try:
        with DB_LOCK, db_conn() as con:
            row = con.execute(
                """SELECT
                     SUM(CASE WHEN outcome='WIN' THEN 1 ELSE 0 END),
                     SUM(CASE WHEN outcome='LOSS' THEN 1 ELSE 0 END)
                   FROM central_predictions
                   WHERE symbol=? AND decision=? AND outcome IN ('WIN','LOSS')""",
                (symbol, side),
            ).fetchone()
            wins = int(row[0] or 0)
            losses = int(row[1] or 0)
    except Exception:
        _swallow()
    n = wins + losses
    # Beta(2,2) prior: stable at small samples and converges toward reality.
    posterior = (wins + 2.0) / (n + 4.0) if n else 0.5
    raw_wr = 100.0 * wins / n if n else 50.0
    return {
        "wins": wins, "losses": losses, "samples": n,
        "raw_win_rate": round(raw_wr, 2),
        "posterior_win_rate": round(100.0 * posterior, 2),
        "reliable": n >= V34_MIN_HISTORY,
    }


def _v34_opportunity(item: dict[str, Any]) -> dict[str, Any]:
    """Score a near-actionable WAIT without pretending it is a profit probability."""
    debate = item.get("deep_consensus_v30") or {}
    long = debate.get("long") or {}
    short = debate.get("short") or {}
    ls = safe_float(long.get("score"), 0.0)
    ss = safe_float(short.get("score"), 0.0)
    margin = ls - ss
    side = "LONG" if margin >= V34_MIN_MARGIN else "SHORT" if margin <= -V34_MIN_MARGIN else "WAIT"
    chosen = long if side == "LONG" else short if side == "SHORT" else {}
    if not chosen:
        return {"version": V34_VERSION, "state": "NO_EDGE", "score": 0.0, "candidate": "WAIT"}

    dq = safe_float(chosen.get("data_quality"), 0.0)
    quality = safe_float(chosen.get("quality"), 0.0)
    rr = safe_float(chosen.get("rr"), 0.0)
    contradiction = safe_float(chosen.get("contradiction"), 1.0)
    support = int(chosen.get("support", 0) or 0)
    oppose = int(chosen.get("oppose", 0) or 0)
    hard = list(chosen.get("hard_blocks") or [])
    history = _v34_history(_normalize_symbol(item.get("symbol") or ""), side)

    # Each component is bounded. This is an evidence score, not win probability.
    margin_score = clamp((abs(margin) - V34_MIN_MARGIN) / 0.14 * 100.0, 0.0, 100.0)
    dq_score = clamp((dq - V34_MIN_DQ) / 35.0 * 100.0, 0.0, 100.0)
    quality_score = clamp((quality - V34_MIN_QUALITY) / 35.0 * 100.0, 0.0, 100.0)
    rr_score = clamp((rr - V34_MIN_RR) / 0.90 * 100.0, 0.0, 100.0)
    support_score = clamp(support * 25.0 - oppose * 15.0, 0.0, 100.0)
    contradiction_score = clamp((V34_MAX_CONTRADICTION - contradiction) / V34_MAX_CONTRADICTION * 100.0, 0.0, 100.0)
    history_score = history["posterior_win_rate"] if history["reliable"] else 50.0

    score = (
        margin_score * 0.25 + quality_score * 0.20 + dq_score * 0.15 +
        support_score * 0.15 + rr_score * 0.10 + contradiction_score * 0.10 +
        history_score * 0.05
    )
    safety_block = (
        bool(hard) or dq < V34_MIN_DQ or quality < V34_MIN_QUALITY or
        rr < V34_MIN_RR or contradiction >= V34_MAX_CONTRADICTION
    )
    promote = side in {"LONG", "SHORT"} and score >= V34_PROMOTE_SCORE and not safety_block
    return {
        "version": V34_VERSION,
        "state": "PROMOTE_EARLY" if promote else "WATCH",
        "candidate": side,
        "score": round(clamp(score, 0.0, 100.0), 1),
        "margin": round(margin, 4),
        "data_quality": round(dq, 1),
        "signal_quality": round(quality, 1),
        "rr": round(rr, 2),
        "support": support,
        "opposition": oppose,
        "contradiction": round(contradiction, 3),
        "history": history,
        "safety_block": safety_block,
        "components": {
            "margin": round(margin_score, 1), "quality": round(quality_score, 1),
            "data": round(dq_score, 1), "support": round(support_score, 1),
            "rr": round(rr_score, 1), "contradiction": round(contradiction_score, 1),
            "history": round(history_score, 1),
        },
        "note": "Evidence score only; not a guaranteed probability of profit.",
    }


def _v34_apply(item: dict[str, Any]) -> dict[str, Any]:
    """Final opportunity layer above the canonical evidence stack."""
    try:
        opp = _v34_opportunity(item)
        item["v34_opportunity"] = opp
        item.setdefault("fusion", {})["v34_opportunity"] = opp
        current = str(item.get("decision_tag") or item.get("decision") or "WAIT").upper()
        # Only promote a WAIT that is already supported by the existing central
        # debate. Never flip a valid LONG/SHORT and never bypass hard safety blocks.
        if current == "WAIT" and opp.get("state") == "PROMOTE_EARLY":
            decision = str(opp.get("candidate") or "WAIT")
            item["decision_tag"] = decision
            item["decision"] = decision
            item["bias"] = "صعودی" if decision == "LONG" else "نزولی"
            item["entry_mode"] = "EARLY"
            item["decision_state"] = "CENTRAL_V34_EARLY"
            item["signal_tag"] = f"CENTRAL V34 OPPORTUNITY — {decision}"
            # Confidence is increased modestly by evidence quality, never to 100.
            old = safe_float(item.get("decision_confidence"), 50.0)
            boost = min(8.0, max(2.0, (safe_float(opp.get("score"), 66.0) - 60.0) * 0.20))
            item["decision_confidence"] = round(clamp(max(old, 50.0) + boost, 0.0, 96.0), 1)
            item["central_reason_fa"] = "فرصت نزدیک به فعال‌شدن با اجماع شواهد، Data quality و RR معتبر؛ V34 آن را از WAIT به EARLY ارتقا داد."
            item["v34_promoted"] = True
        else:
            item["v34_promoted"] = False
        item["decision_architecture"] = {
            "type": "SINGLE_CENTRAL_GOVERNOR_WITH_ADAPTIVE_EVIDENCE",
            "authoritative_source": TITAN_CENTRAL_VERSION,
            "opportunity_layer": V34_VERSION,
            "final_decision": item.get("decision_tag", "WAIT"),
            "legacy_engines_are_evidence_only": True,
        }
        return item
    except Exception as exc:
        LOGGER.debug("V34 adaptive trust failed: %s", exc)
        item["v34_opportunity"] = {"version": V34_VERSION, "state": "DEGRADED", "score": 0.0}
        item["v34_promoted"] = False
        return item
