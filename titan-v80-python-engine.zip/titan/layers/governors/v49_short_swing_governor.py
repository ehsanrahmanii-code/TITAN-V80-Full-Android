# [TITAN V77 layer] governors/v49_short_swing_governor - V49 short-swing governor
# Original V76 source lines 19548-20404 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# TITAN V49 — ADAPTIVE SHORT-SWING GOVERNOR
# ============================================================
# Purpose:
# - Optimize for actionable 1–2 day setups without turning every scan into a trade.
# - Separate hard safety from soft opportunity thresholds.
# - Learn from realized V49 outcomes by symbol/side/setup/regime and by technical pillar.
# - Use causal 5m evaluation for 6h / 24h / 48h horizons.
# - Treat conditional pullback entries as unfilled until the planned entry is actually touched.
# - Never fabricate missing data, never let AI invent direction, never execute real orders.
V49_VERSION = "TITAN-V51-ADAPTIVE-SHORT-SWING-DATA-AWARE"
V49_FAST_HORIZON_MIN = 360
V49_PRIMARY_HORIZON_MIN = 1440
V49_EXTENDED_HORIZON_MIN = 2880
V49_EXECUTION_TF = "5m"
V49_STALE_PRICE_SEC = 35.0
V49_HARD_DQ = 42.0
V49_SOFT_DQ = 50.0
V49_MIN_PILLARS = 2
V49_MAX_STOP_PCT = 6.5
V49_MIN_EFFECTIVE_RR = 1.15
V49_MIN_RR1 = 1.25
V49_TARGET_RR1 = 1.60
V49_TARGET_RR2 = 2.80
V49_BREAKOUT_RR1 = 1.45
V49_PULLBACK_RR1 = 1.60
V49_TACTICAL_EDGE = 0.050
V49_STANDARD_EDGE = 0.065
V49_CORE_EDGE = 0.110
V49_TRANSITION_EDGE = 0.045
V49_TACTICAL_MARGIN = 0.015
V49_STANDARD_MARGIN = 0.023
V49_CORE_MARGIN = 0.040
V49_TRANSITION_MARGIN = 0.020
V49_TACTICAL_CONF = 48.0
V49_STANDARD_CONF = 51.0
V49_CORE_CONF = 60.0
V49_TRANSITION_CONF = 49.0
V49_MAX_SIGNALS_PER_SYMBOL_DAY = 8
V49_SIGNAL_COOLDOWN_SEC = 3 * 60 * 60
V49_ACTIVE_LOCK_HOURS = 48
V49_ENTRY_TTL_MIN = 180
V49_HARD_EXTREME_VOL_PCT = 14.0
V49_FRICTION_PCT = safe_float(globals().get("V45_FRICTION_PCT"), TOTAL_ENTRY_BUFFER * 2.0 * 100.0)
V49_MIN_LEARN_N = 12
V49_STRONG_LEARN_N = 25
V49_HARD_LEARN_N = 40
V49_PRIOR_ALPHA = 4.0
V49_PRIOR_BETA = 6.0
V49_NEGATIVE_PF = 0.85
V49_NEGATIVE_EXP_R = -0.10
V49_POSITIVE_PF = 1.15
V49_POSITIVE_EXP_R = 0.03
V49_POSITIVE_LCB = 48.0
V49_MC_PATHS = 500
V49_CALIB_MIN_BUCKET = 12
V49_NOW_FILL_WAIT_MIN = 10
V49_WF_PURGE_MIN = 24 * 60
V49_MC_BLOCK = 5


def _v49_num(v, default=0.0):
    try:
        x = float(v)
        return x if math.isfinite(x) else default
    except Exception:
        _swallow()
        return default


def _v49_json(v, default):
    try:
        return json.loads(v) if isinstance(v, str) else (v if v is not None else default)
    except Exception:
        _swallow()
        return default


def _v49_beta(wins, losses):
    a = V49_PRIOR_ALPHA + max(0, int(wins))
    b = V49_PRIOR_BETA + max(0, int(losses))
    return 100.0 * a / max(a + b, 1e-9)


def _v49_wilson(wins, n, z=1.96):
    n = int(n or 0)
    if n <= 0:
        return None
    p = wins / n
    den = 1.0 + z * z / n
    centre = p + z * z / (2.0 * n)
    margin = z * math.sqrt(max(0.0, (p * (1.0 - p) + z * z / (4.0 * n)) / n))
    return max(0.0, (centre - margin) / den) * 100.0


def _v49_init_schema():
    try:
        with DB_LOCK, db_conn() as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS titan_v49_ledger(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at REAL NOT NULL,
                    symbol TEXT NOT NULL,
                    timeframe TEXT NOT NULL DEFAULT '1h',
                    side TEXT NOT NULL,
                    published INTEGER NOT NULL DEFAULT 0,
                    mode TEXT NOT NULL DEFAULT 'WATCH',
                    setup TEXT NOT NULL DEFAULT 'UNKNOWN',
                    entry_mode TEXT NOT NULL DEFAULT 'NOW',
                    entry REAL NOT NULL,
                    entry_preferred REAL,
                    stop_loss REAL NOT NULL,
                    tp1 REAL NOT NULL,
                    tp2 REAL NOT NULL,
                    risk_pct REAL DEFAULT 0,
                    rr1 REAL DEFAULT 0,
                    rr2 REAL DEFAULT 0,
                    effective_rr1 REAL DEFAULT 0,
                    effective_rr2 REAL DEFAULT 0,
                    confidence REAL DEFAULT 0,
                    probability_raw REAL,
                    probability_calibrated REAL,
                    edge REAL DEFAULT 0,
                    margin REAL DEFAULT 0,
                    quality REAL DEFAULT 0,
                    data_quality REAL DEFAULT 0,
                    coverage REAL DEFAULT 0,
                    regime TEXT DEFAULT 'unknown',
                    fill_status TEXT DEFAULT 'UNFILLED',
                    fill_price REAL,
                    fill_at REAL,
                    expires_at REAL,
                    outcome_6h TEXT DEFAULT 'PENDING',
                    outcome_24h TEXT DEFAULT 'PENDING',
                    outcome_48h TEXT DEFAULT 'PENDING',
                    exit_6h REAL,
                    exit_24h REAL,
                    exit_48h REAL,
                    return_net_6h REAL,
                    return_net_24h REAL,
                    return_net_48h REAL,
                    r_multiple_6h REAL,
                    r_multiple_24h REAL,
                    r_multiple_48h REAL,
                    mae_6h REAL,
                    mfe_6h REAL,
                    mae_24h REAL,
                    mfe_24h REAL,
                    mae_48h REAL,
                    mfe_48h REAL,
                    tte_6h REAL,
                    tte_24h REAL,
                    tte_48h REAL,
                    components_json TEXT DEFAULT '{}',
                    reasons_json TEXT DEFAULT '[]',
                    thresholds_json TEXT DEFAULT '{}',
                    param_version TEXT NOT NULL
                )""")
            con.execute("CREATE INDEX IF NOT EXISTS idx_v49_pending ON titan_v49_ledger(outcome_6h,outcome_24h,outcome_48h,created_at)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_v49_symbol ON titan_v49_ledger(symbol,side,setup,created_at)")
            # V53 lineage column: every published decision is traceable to one immutable Decision DNA hash.
            try:
                cols={str(r[1]) for r in con.execute("PRAGMA table_info(titan_v49_ledger)").fetchall()}
                if "decision_hash" not in cols:
                    con.execute("ALTER TABLE titan_v49_ledger ADD COLUMN decision_hash TEXT")
                con.execute("CREATE INDEX IF NOT EXISTS idx_v49_decision_hash ON titan_v49_ledger(decision_hash)")
            except Exception as exc:
                LOGGER.debug("V53 ledger lineage migration skipped: %s",exc)
            con.execute("""
                CREATE TABLE IF NOT EXISTS titan_v49_component_stats(
                    component TEXT PRIMARY KEY,
                    samples INTEGER NOT NULL DEFAULT 0,
                    reward_sum REAL NOT NULL DEFAULT 0,
                    reward_ema REAL NOT NULL DEFAULT 0,
                    weight REAL NOT NULL DEFAULT 1.0,
                    updated_at REAL
                )""")
            for comp in ("trend", "structure", "momentum", "flow", "context"):
                con.execute("INSERT OR IGNORE INTO titan_v49_component_stats(component,weight,updated_at) VALUES(?,?,?)", (comp,1.0,time.time()))
            con.commit()
    except Exception as exc:
        LOGGER.debug("V49 schema init: %s", exc)


_v49_init_schema()


def _v49_component_weights():
    defaults = {"trend": 0.29, "structure": 0.23, "momentum": 0.18, "flow": 0.16, "context": 0.14}
    try:
        with DB_LOCK, db_conn() as con:
            rows = con.execute("SELECT component,samples,reward_ema,weight FROM titan_v49_component_stats").fetchall()
        raw = {str(r[0]): _v49_num(r[3],1.0) for r in rows if str(r[0]) in defaults}
        out = {k: defaults[k] * max(0.65,min(1.35,raw.get(k,1.0))) for k in defaults}
        z = sum(out.values()) or 1.0
        return {k: v/z for k,v in out.items()}
    except Exception:
        _swallow()
        return defaults


def _v49_update_component_learning(row, outcome, r_multiple):
    try:
        comps = _v49_json(row.get("components_json"), {})
        if not isinstance(comps, dict):
            comps = {}
        reward = _v49_num(r_multiple,0.0)
        if outcome == "LOSS":
            reward = min(reward,0.0)
        elif outcome == "WIN":
            reward = max(reward,0.0)
        reward = float(np.clip(reward,-2.0,2.0))
        now=time.time()
        with DB_LOCK, db_conn() as con:
            for name,val in comps.items():
                if name not in {"trend","structure","momentum","flow","context"}:
                    continue
                direction = 1.0 if _v49_num(val,0.0) >= 0 else -1.0
                shaped = reward * direction
                old = con.execute("SELECT samples,reward_sum,reward_ema,weight FROM titan_v49_component_stats WHERE component=?",(name,)).fetchone()
                if old:
                    n=int(old[0] or 0)+1
                    rs=_v49_num(old[1],0)+shaped
                    ema=0.92*_v49_num(old[2],0)+0.08*shaped
                    # Small, bounded online update. Never lets one outcome dominate.
                    weight=float(np.clip(_v49_num(old[3],1.0)*(1.0+0.025*np.tanh(ema)),0.65,1.35))
                else:
                    n=1;rs=shaped;ema=shaped;weight=float(np.clip(1.0+0.025*np.tanh(ema),0.65,1.35))
                con.execute("UPDATE titan_v49_component_stats SET samples=?,reward_sum=?,reward_ema=?,weight=?,updated_at=? WHERE component=?",(n,rs,ema,weight,now,name))
            con.commit()
    except Exception as exc:
        LOGGER.debug("V49 component learning failed: %s",exc)


def _v49_recompute_score(pillar_pack):
    pillars = pillar_pack.get("pillars") or []
    base = _v49_component_weights()
    vals=[]
    for p in pillars:
        label=str(p.get("label") or "")
        if not p.get("available") or label not in base:
            continue
        v=_v49_num(p.get("value"),0.0)
        c=max(0.15,min(1.0,_v49_num(p.get("confidence"),0.15)))
        vals.append((label,v,c,base[label]))
    if not vals:
        return 0.0, base
    den=sum(w*c for _,_,c,w in vals)
    score=sum(v*c*w for _,v,c,w in vals)/max(den,1e-9)
    return float(np.clip(score,-1.0,1.0)),base


def _v49_historical(symbol, side, setup, regime):
    try:
        with DB_LOCK, db_conn() as con:
            rows=[dict(r) for r in con.execute("""
                SELECT * FROM titan_v49_ledger
                WHERE published=1 AND symbol=? AND side=? AND setup=? AND regime=? AND outcome_24h IN ('WIN','LOSS','TIME_EXIT','AMBIGUOUS')
                ORDER BY created_at DESC LIMIT 250
            """,(symbol,side,setup,regime)).fetchall()]
            if len(rows) < 10:
                rows=[dict(r) for r in con.execute("""
                    SELECT * FROM titan_v49_ledger
                    WHERE published=1 AND symbol=? AND side=? AND outcome_24h IN ('WIN','LOSS','TIME_EXIT','AMBIGUOUS')
                    ORDER BY created_at DESC LIMIT 250
                """,(symbol,side)).fetchall()]
        clean=[r for r in rows if str(r.get("outcome_24h")) in {"WIN","LOSS","TIME_EXIT"} and str(r.get("fill_status") or "") == "FILLED"]
        wins=sum(1 for r in clean if r.get("outcome_24h")=="WIN")
        losses=sum(1 for r in clean if r.get("outcome_24h")=="LOSS")
        rets=np.asarray([_v49_num(r.get("return_net_24h"),float("nan")) for r in clean],dtype=float)
        rets=rets[np.isfinite(rets)]
        pos=rets[rets>0];neg=rets[rets<0]
        pf=float(pos.sum()/abs(neg.sum())) if neg.size else (math.inf if pos.size else None)
        exp=float(rets.mean()) if rets.size else None
        rr=np.asarray([_v49_num(r.get("r_multiple_24h"),float("nan")) for r in clean],dtype=float);rr=rr[np.isfinite(rr)]
        exp_r=float(rr.mean()) if rr.size else None
        lcb=_v49_wilson(wins,wins+losses)
        n=wins+losses
        threshold_delta=0.0; hard=False
        if n>=V49_STRONG_LEARN_N and ((pf is not None and pf<V49_NEGATIVE_PF) or (exp_r is not None and exp_r<V49_NEGATIVE_EXP_R)):
            threshold_delta=0.025
        elif n>=V49_MIN_LEARN_N and exp_r is not None and exp_r<0:
            threshold_delta=0.010
        if n>=V49_STRONG_LEARN_N and pf is not None and pf>=V49_POSITIVE_PF and exp_r is not None and exp_r>=V49_POSITIVE_EXP_R and (lcb or 0)>=V49_POSITIVE_LCB:
            threshold_delta=-0.010
        if n>=V49_HARD_LEARN_N and ((pf is not None and pf<0.70) or (exp_r is not None and exp_r<-0.20 and (lcb or 0)<40)):
            hard=True
        return {
            "samples":int(n),"status":"RELIABLE" if n>=V49_MIN_LEARN_N else "INSUFFICIENT",
            "bayes_probability":round(_v49_beta(wins,losses),2) if n or clean else None,
            "win_rate":round(wins/max(n,1)*100,2) if n else None,
            "win_rate_lcb95":round(lcb,2) if lcb is not None else None,
            "profit_factor":round(pf,3) if pf is not None and math.isfinite(pf) else pf,
            "expectancy_pct":round(exp,5) if exp is not None else None,
            "expectancy_r":round(exp_r,4) if exp_r is not None else None,
            "threshold_delta":threshold_delta,"hard_negative":hard,
        }
    except Exception as exc:
        LOGGER.debug("V49 historical failed: %s",exc)
        return {"samples":0,"status":"INSUFFICIENT","bayes_probability":None,"win_rate":None,"win_rate_lcb95":None,"profit_factor":None,"expectancy_pct":None,"expectancy_r":None,"threshold_delta":0.0,"hard_negative":False}


def _v49_setup(ctx, side, score):
    s=ctx.get("structure") or {}; event=str(s.get("event") or "")
    rg=str((ctx.get("regime") or {}).get("regime") or "unknown").lower()
    tf=ctx.get("tf") or {}; rsi=_v49_num(ctx.get("rsi"),50)
    if ((side=="LONG" and event=="BOS_UP") or (side=="SHORT" and event=="BOS_DOWN")) and bool(ctx.get("volume_spike")):
        return "BREAKOUT"
    trend_ok=(side=="LONG" and tf.get("4h",50)>=53 and tf.get("1h",50)>=51) or (side=="SHORT" and tf.get("4h",50)<=47 and tf.get("1h",50)<=49)
    if trend_ok and ((side=="LONG" and 34<=rsi<=55) or (side=="SHORT" and 45<=rsi<=66)) and abs(score)>=0.07:
        return "PULLBACK"
    if rg in {"range","sideways","mean_reversion"} and ((side=="LONG" and rsi<=33) or (side=="SHORT" and rsi>=67)):
        return "MEAN_REVERSION"
    # Transition entry: HTF neutral, LTF has begun to turn, and at least one flow source agrees.
    if 45<=tf.get("4h",50)<=55 and ((side=="LONG" and tf.get("1h",50)>=53 and tf.get("15m",50)>=54) or (side=="SHORT" and tf.get("1h",50)<=47 and tf.get("15m",50)<=46)) and abs(score)>=V49_TRANSITION_EDGE:
        return "TRANSITION"
    return "TREND_CONTINUATION"


def _v49_thresholds(ctx, setup, hist):
    rg=str((ctx.get("regime") or {}).get("regime") or "unknown").lower()
    if setup=="BREAKOUT": e,m,c=0.070,0.022,52.0
    elif setup=="PULLBACK": e,m,c=0.070,0.022,52.0
    elif setup=="MEAN_REVERSION": e,m,c=0.070,0.024,53.0
    elif setup=="TRANSITION": e,m,c=V49_TRANSITION_EDGE,V49_TRANSITION_MARGIN,V49_TRANSITION_CONF
    else: e,m,c=V49_STANDARD_EDGE,V49_STANDARD_MARGIN,V49_STANDARD_CONF
    if rg in {"trend_up","trend_down"}:
        e-=0.005;m-=0.002;c-=1.0
    elif rg=="breakout_watch":
        e-=0.007;c-=1.5
    elif rg in {"range","sideways","mean_reversion"}:
        e=min(e,0.078);c=max(c,53.0)
    elif "transition" in rg or "high_vol" in rg:
        e+=0.010;m+=0.004;c+=1.5
    e+=_v49_num(hist.get("threshold_delta"),0.0)
    return {"edge":max(0.055,e),"margin":max(0.016,m),"confidence":max(50.0,c)}


def _v49_build_levels(x, side, ctx, setup):
    base=_v47_price_level_plan(x,side,ctx)
    if not base:return None
    desired=V49_BREAKOUT_RR1 if setup=="BREAKOUT" else V49_PULLBACK_RR1 if setup=="PULLBACK" else V49_TARGET_RR1
    if base.get("effective_rr1",0)<desired:
        anchor=_v49_num((ctx.get("structure") or {}).get("swing_low" if side=="LONG" else "swing_high"),0)
        alt=_v45_rr_levels(ctx.get("price"),base.get("atr",0),side,anchor if anchor>0 else None,rr1=desired,rr2=V49_TARGET_RR2)
        if alt:
            old_atr=_v49_num(base.get("atr"),0.0)
            sl,tp1,tp2=float(alt["sl"]),float(alt["tp1"]),float(alt["tp2"])
            risk=abs(ctx["price"]-sl);rp=risk/max(ctx["price"],1e-12)*100
            cr=V49_FRICTION_PCT/max(rp,1e-9)
            base={"entry":ctx["price"],"sl":sl,"tp1":tp1,"tp2":tp2,"risk":risk,"risk_pct":rp,
                  "rr1":abs(tp1-ctx["price"])/max(risk,1e-12),"rr2":abs(tp2-ctx["price"])/max(risk,1e-12),
                  "cost_r":cr,"effective_rr1":abs(tp1-ctx["price"])/max(risk,1e-12)-cr,
                  "effective_rr2":abs(tp2-ctx["price"])/max(risk,1e-12)-cr,"atr":old_atr}
    if base.get("risk_pct",99)>V49_MAX_STOP_PCT or base.get("effective_rr1",0)<V49_MIN_EFFECTIVE_RR:return None
    return base


def _v50_data_presence(x):
    """Return a strict audit of observed vs default-filled inputs used by V49."""
    raw_tf = x.get("tf_scores") if isinstance(x.get("tf_scores"), dict) else {}
    tf_obs = [k for k in ("15m", "1h", "4h", "1d") if k in raw_tf and math.isfinite(_v49_num(raw_tf.get(k), float("nan")))]
    indicators = {
        "rsi": math.isfinite(_v49_num(x.get("rsi_value", x.get("rsi")), float("nan"))),
        "macd_cross": str(x.get("macd_cross") or "").lower() in {"bull", "bear"},
        "macd_hist": math.isfinite(_v49_num(x.get("macd_hist"), float("nan"))),
        "volume_spike": "volume_spike" in x,
        "taker_buy_pct": math.isfinite(_v49_num(x.get("taker_buy_pct"), float("nan"))),
        "long_short_ratio": math.isfinite(_v49_num(x.get("long_short_ratio"), float("nan"))) and _v49_num(x.get("long_short_ratio"), 0) > 0,
        "structure": bool((x.get("edge") or {}).get("structure") if isinstance(x.get("edge"), dict) else False),
        "regime": bool((x.get("edge") or {}).get("regime") if isinstance(x.get("edge"), dict) else False),
    }
    return {"observed_tf": tf_obs, "observed_tf_count": len(tf_obs), "indicators": indicators,
            "observed_indicator_count": sum(1 for v in indicators.values() if v)}


def _v49_apply(x):
    x=dict(x or {})
    ctx=_v47_get_context(x)
    raw_candidates={s:_v47_build_pillars(x,s) for s in ("LONG","SHORT")}
    rescored={}
    for s,p in raw_candidates.items():
        sc,w=_v49_recompute_score(p)
        p=dict(p);p["score"]=sc;p["quality"]=round(clamp(50+50*sc,0,100),2);p["weights"]=w
        rescored[s]=p
    best=max(("LONG","SHORT"),key=lambda s:rescored[s]["score"])
    legacy_upstream = str(x.get("decision_tag") or "").upper()
    best_score=float(rescored[best].get("score",0.0))
    # V51 decision direction is generated only from the current V49 evidence fusion.
    # Older decision engines are retained as audit metadata, never as a directional input.
    side = best
    other="SHORT" if side=="LONG" else "LONG"
    p=rescored[side];po=rescored[other]
    edge=float(p["score"]); other_edge=float(po["score"]); margin=edge-other_edge
    setup=_v49_setup(ctx,side,edge)
    regime=str((ctx.get("regime") or {}).get("regime") or "unknown").lower()
    hist=_v49_historical(_normalize_symbol(str(x.get("symbol") or "")),side,setup,regime)
    thr=_v49_thresholds(ctx,setup,hist)
    dq=_v49_num((ctx.get("dq") or {}).get("score"),0)
    age=_v49_num(x.get("live_price_age_sec"),0)
    hard=[];notes=[]
    presence=_v50_data_presence(x)
    price=_v49_num(ctx.get("price"),0)
    if price<=0:hard.append("invalid_price")
    if age>V49_STALE_PRICE_SEC:hard.append("stale_price")
    if dq<V49_HARD_DQ:hard.append("data_quality_hard")
    if _v49_num(ctx.get("vol_pct"),0)>=V49_HARD_EXTREME_VOL_PCT:hard.append("extreme_volatility")
    if p.get("available_count",0)<V49_MIN_PILLARS:hard.append("insufficient_pillars")
    if presence["observed_tf_count"] == 0 and not presence["indicators"]["structure"]:hard.append("no_primary_market_evidence")
    if p.get("strong_opposition"):hard.append("strong_structural_opposition")
    if side=="LONG" and ctx["tf"]["4h"]<=43 and ctx["tf"]["1h"]<=45:hard.append("htf_double_conflict")
    if side=="SHORT" and ctx["tf"]["4h"]>=57 and ctx["tf"]["1h"]>=55:hard.append("htf_double_conflict")
    lv=_v49_build_levels(x,side,ctx,setup)
    if not lv:hard.append("invalid_levels")
    v45=x.get("v45") if isinstance(x.get("v45"),dict) else {}
    if str(v45.get("state") or "").upper() in {"HARD_BLOCK","BLOCKED_HARD","LEARNED_NEGATIVE_EV","DEMOTED_NEG"}:hard.append("upstream_hard_block")
    if hist.get("hard_negative"):hard.append("learned_negative_setup")

    quality=p["quality"]
    coverage=100.0*min(5,p.get("available_count",0))/5.0
    # Probability is explicitly a calibrated estimate, not a promise and not the directional trigger.
    setup_bonus={"BREAKOUT":4.0,"PULLBACK":3.0,"MEAN_REVERSION":1.5,"TRANSITION":0.0,"TREND_CONTINUATION":0.5}.get(setup,0.0)
    prob_raw=50.0 + 21.0*edge + 12.0*margin + 0.08*(quality-50.0) + 0.04*(dq-50.0) + setup_bonus
    if hist.get("bayes_probability") is not None:
        prob_raw=0.78*prob_raw+0.22*_v49_num(hist.get("bayes_probability"),50.0)
    prob_raw=float(clamp(prob_raw,43.0,78.0))
    # Calibration from realized confidence buckets.
    cal=prob_raw
    cal_samples=0
    try:
        bucket_lo=int(prob_raw//5*5);bucket_hi=bucket_lo+5
        with DB_LOCK,db_conn() as con:
            br=[dict(r) for r in con.execute("""
                SELECT outcome_24h,return_net_24h FROM titan_v49_ledger
                WHERE published=1 AND confidence>=? AND confidence<? AND outcome_24h IN ('WIN','LOSS')
                ORDER BY created_at DESC LIMIT 120
            """,(bucket_lo,bucket_hi)).fetchall()]
        cal_samples=len(br)
        if cal_samples>=V49_CALIB_MIN_BUCKET:
            bw=sum(1 for r in br if r.get("outcome_24h")=="WIN")
            cal=0.70*prob_raw+0.30*(100.0*bw/cal_samples)
    except Exception:
        _swallow()
    if hist.get("samples",0) < V49_MIN_LEARN_N:
        cal=min(cal,64.0)
        notes.append("probability_cap_until_history")
    conf=0.45*quality+0.20*_v49_num(x.get("signal_quality"),50)+0.18*_v49_num(ctx.get("alignment"),50)+0.10*dq+0.07*min(100.0,max(0.0,50+edge*50))
    if setup=="BREAKOUT" and ctx.get("volume_spike"):conf+=3.0
    if setup=="TRANSITION":conf+=1.0
    if hist.get("threshold_delta",0)>0:conf-=2.0
    conf=clamp(conf,48.0,90.0)

    # Context / trigger logic.
    setup_ok=False
    if setup=="BREAKOUT":
        setup_ok=bool(ctx.get("volume_spike")) and ((side=="LONG" and ctx["structure"].get("event")=="BOS_UP") or (side=="SHORT" and ctx["structure"].get("event")=="BOS_DOWN"))
    elif setup=="PULLBACK":
        setup_ok=((side=="LONG" and ctx["tf"]["4h"]>=52) or (side=="SHORT" and ctx["tf"]["4h"]<=48)) and edge>=0.055
    elif setup=="MEAN_REVERSION":
        setup_ok=regime in {"range","sideways","mean_reversion"}
    elif setup=="TRANSITION":
        setup_ok=True
    else:
        setup_ok=abs(edge)>=0.055 and not (side=="LONG" and ctx["tf"]["15m"]<40) and not (side=="SHORT" and ctx["tf"]["15m"]>60)

    # Independent-support guard: avoid a false directional edge created only by BTC/flow/context.
    core_direction_support = any(
        pp.get("available") and pp.get("label") in {"trend","structure"} and pp.get("support")
        for pp in (p.get("pillars") or [])
    )
    secondary_direction_support = any(
        pp.get("available") and pp.get("label") in {"momentum","flow"} and pp.get("support")
        for pp in (p.get("pillars") or [])
    )
    if not core_direction_support:
        notes.append("missing_core_directional_support")
    if not secondary_direction_support:
        notes.append("missing_secondary_confirmation")
    # Expected-R is a separate economic sanity check; probability never creates direction.
    eff_rr1 = _v49_num((lv or {}).get("effective_rr1"),0.0)
    ev_r = (((cal/100.0) * eff_rr1) - (1.0 - cal/100.0)) if (eff_rr1>0 and cal_samples>=V49_CALIB_MIN_BUCKET) else None
    ev_gate_tactical = 0.02
    ev_gate_standard = 0.08
    ev_ok_tactical = ev_r is None or ev_r >= ev_gate_tactical
    ev_ok_standard = ev_r is None or ev_r >= ev_gate_standard
    tactical=(not hard and setup_ok and core_direction_support and secondary_direction_support and edge>=V49_TACTICAL_EDGE and margin>=V49_TACTICAL_MARGIN and conf>=V49_TACTICAL_CONF and ev_ok_tactical and lv is not None)
    standard=(not hard and setup_ok and core_direction_support and secondary_direction_support and edge>=thr["edge"] and margin>=thr["margin"] and conf>=thr["confidence"] and ev_ok_standard and lv is not None)
    core=(standard and edge>=V49_CORE_EDGE and margin>=V49_CORE_MARGIN and conf>=V49_CORE_CONF and hist.get("samples",0)>=V49_MIN_LEARN_N and not hist.get("hard_negative"))
    # Do not require historical samples to open a first qualified trade. Historical data changes strictness only after it exists.
    publish=standard or tactical
    mode="CORE" if core else "STANDARD" if standard else "TACTICAL" if tactical else "WATCH"
    if not publish:
        # One controlled transition/breakout relief path prevents WAIT saturation without removing hard guards.
        relief=(not hard and setup in {"BREAKOUT","TRANSITION","PULLBACK"} and setup_ok and core_direction_support and secondary_direction_support and edge>=V49_TRANSITION_EDGE and margin>=V49_TRANSITION_MARGIN and conf>=V49_TRANSITION_CONF and (ev_r is None or ev_r>=0.0) and lv is not None and p.get("support_count",0)>=2 and p.get("opposition_count",0)<=1)
        if relief:
            publish=True;mode="TACTICAL"
            notes.append("controlled_opportunity_relief")
    decision=side if publish else "WAIT"
    wait_reasons=[]
    if not publish:
        if hard: wait_reasons.extend(hard)
        if not setup_ok: wait_reasons.append("setup_not_confirmed")
        if not core_direction_support: wait_reasons.append("core_direction_missing")
        if not secondary_direction_support: wait_reasons.append("secondary_confirmation_missing")
        if edge < V49_TACTICAL_EDGE: wait_reasons.append("edge_below_action_threshold")
        if margin < V49_TACTICAL_MARGIN: wait_reasons.append("side_margin_too_small")
        if conf < V49_TACTICAL_CONF: wait_reasons.append("confidence_below_action_threshold")
        if ev_r is not None and ev_r < ev_gate_tactical: wait_reasons.append("negative_or_weak_expected_r")
    entry_plan=_v47_entry_plan(ctx,lv,side,setup) if lv else {}
    risk_mult={"CORE":1.0,"STANDARD":0.70,"TACTICAL":0.45,"BREAKOUT":0.60,"PULLBACK":0.75,"MEAN_REVERSION":0.40,"TRANSITION":0.45}.get(mode,0.0)
    if dq<V49_SOFT_DQ:risk_mult*=0.75
    if hist.get("threshold_delta",0)>0:risk_mult*=0.80
    if cal_samples < V49_CALIB_MIN_BUCKET:
        risk_mult*=0.80
    elif cal < 56:
        risk_mult*=0.65
    elif cal >= 66:
        risk_mult*=1.05
    risk_mult=clamp(risk_mult,0.25,1.0)
    v={
        "version":V49_VERSION,"decision":decision,"candidate":side,"mode":mode,"setup":setup,
        "confidence":round(conf,1),"probability_raw":round(prob_raw,1),"probability_calibrated":round(cal,1),
        "expected_r":(round(ev_r,3) if ev_r is not None else None),"edge":round(edge,4),"other_edge":round(other_edge,4),"margin":round(margin,4),"quality":round(quality,1),
        "data_quality":round(dq,1),"coverage":round(coverage,1),"available_pillars":p.get("available_count",0),
        "data_presence":presence,"wait_reasons":wait_reasons,
        "support_count":p.get("support_count",0),"opposition_count":p.get("opposition_count",0),
        "core_direction_support":core_direction_support,"secondary_confirmation":secondary_direction_support,
        "regime":regime,"historical":hist,"thresholds":thr,"hard_blocks":hard,"notes":notes,
        "risk_multiplier":round(risk_mult,3),"entry_plan":entry_plan,
        "levels":({k:round(float(lv[k]),8) for k in ("entry","sl","tp1","tp2","risk_pct","rr1","rr2","effective_rr1","effective_rr2","cost_r")} if lv else {}),
        "horizons":{"fast_hours":6,"primary_hours":24,"extended_hours":48},
        "execution_tf":V49_EXECUTION_TF,
        "calibration_samples":int(cal_samples),
        "component_weights":_v49_component_weights(),
        "components":{str(pp.get("label")):round(_v49_num(pp.get("value"),0),4) for pp in p.get("pillars",[]) if pp.get("available")},
        "explanation":[f"setup={setup}",f"edge={edge:.3f}",f"margin={margin:.3f}",f"confidence={conf:.1f}",
                       f"calibration_samples={cal_samples}",f"pillars={p.get('support_count',0)}/{p.get('available_count',0)}",f"regime={regime}"],
        "legacy_upstream_candidate": legacy_upstream if legacy_upstream in {"LONG","SHORT"} else None,
        "analysis_only":True,
    }
    x["v49"]=v;x["v49_status"]="ACTIVE" if decision in {"LONG","SHORT"} else "WATCH";x["v49_candidate"]=side;x["v49_mode"]=mode
    x["v49_data_presence"]=presence;x["v49_wait_reasons"]=wait_reasons
    x["v49_confidence"]=round(conf,1)
    x["v49_probability"]=round(cal,1) if cal_samples>=V49_CALIB_MIN_BUCKET else None
    x["v49_probability_status"]="CALIBRATED" if cal_samples>=V49_CALIB_MIN_BUCKET else "UNAVAILABLE"
    x["v49_calibration_samples"]=int(cal_samples)
    x["v49_horizon"]="6h telemetry / 24h primary / 48h extended"
    if decision in {"LONG","SHORT"} and lv:
        x["decision"]=decision;x["decision_tag"]=decision;x["bias"]="صعودی" if decision=="LONG" else "نزولی"
        x["decision_state"]=f"V49_{mode}_{setup}_{decision}";x["authority"]=V49_VERSION
        x["signal_tag"]=f"V49 {mode} — {setup} — {decision}"
        x["decision_confidence"]=round(conf,1)
        x["entry_now"]=smart_format(lv["entry"]);x["entry_valid"]=smart_format(lv["entry"]);x["entry_raw"]=float(lv["entry"])
        x["entry_preferred"]=smart_format(entry_plan.get("preferred"));x["entry_zone_low"]=smart_format(entry_plan.get("zone_low"));x["entry_zone_high"]=smart_format(entry_plan.get("zone_high"))
        x["entry_mode"]=str(entry_plan.get("mode") or "NOW")
        x["stop_loss"]=smart_format(lv["sl"]);x["tp1"]=smart_format(lv["tp1"]);x["tp2"]=smart_format(lv["tp2"])
        x["stop_loss_raw"]=float(lv["sl"]);x["tp1_raw"]=float(lv["tp1"]);x["tp2_raw"]=float(lv["tp2"])
        x["risk_distance_pct"]=round(lv["risk_pct"],3);x["rr_tp1"]=round(lv["rr1"],2);x["rr_tp2"]=round(lv["rr2"],2)
        x["effective_rr_tp1"]=round(lv["effective_rr1"],2);x["effective_rr_tp2"]=round(lv["effective_rr2"],2)
        cost_buffer=_v49_num(lv.get("cost_r"),0.0)*lv["risk"]
        x["trade_management"]={"after_tp1":"move_stop_to_entry_plus_cost_buffer","trail_atr":1.4,"cost_buffer_price":round(cost_buffer,8)}
        x["tradeability"]="IMMEDIATE" if str(entry_plan.get("mode"))=="NOW" else "CONDITIONAL_PULLBACK"
    return x


def _v49_record(x):
    try:
        v=x.get("v49") if isinstance(x.get("v49"),dict) else {}
        side=str(v.get("candidate") or "").upper();symbol=_normalize_symbol(str(x.get("symbol") or ""))
        lv=v.get("levels") or {}; entry_plan=v.get("entry_plan") or {}
        if side not in {"LONG","SHORT"} or not symbol or not lv:return None
        now=time.time()
        pub=1 if str(x.get("decision_tag") or x.get("decision") or v.get("decision") or "WAIT").upper() in {"LONG","SHORT"} else 0
        # Published trades and exploratory shadows have different locks. A WAIT shadow must never
        # freeze the symbol and prevent a later qualified trade.
        with DB_LOCK,db_conn() as con:
            if pub:
                active=con.execute("""SELECT id FROM titan_v49_ledger WHERE symbol=? AND published=1 AND created_at>? AND
                    (outcome_24h='PENDING' OR outcome_48h='PENDING' OR fill_status='UNFILLED') LIMIT 1""",(symbol,now-V49_ACTIVE_LOCK_HOURS*3600)).fetchone()
                if active:return None
                recent=con.execute("SELECT 1 FROM titan_v49_ledger WHERE symbol=? AND published=1 AND created_at>? LIMIT 1",(symbol,now-V49_SIGNAL_COOLDOWN_SEC)).fetchone()
                if recent:return None
                day=con.execute("SELECT COUNT(*) FROM titan_v49_ledger WHERE symbol=? AND published=1 AND created_at>?",(symbol,now-86400)).fetchone()[0]
                portfolio=con.execute("SELECT COUNT(*) FROM titan_v49_ledger WHERE published=1 AND side=? AND created_at>? AND outcome_24h='PENDING'",(side,now-V49_ACTIVE_LOCK_HOURS*3600)).fetchone()[0]
                if int(portfolio or 0)>=MAX_PORTFOLIO_SAME_SIDE:
                    return None
            else:
                # Record only meaningful near-miss candidates. This is counterfactual research, not a trade.
                if _v49_num(v.get("edge"),0) < 0.055 or int(v.get("support_count",0)) < 2:return None
                recent=con.execute("SELECT 1 FROM titan_v49_ledger WHERE symbol=? AND published=0 AND setup=? AND created_at>? LIMIT 1",(symbol,str(v.get("setup") or "UNKNOWN"),now-6*3600)).fetchone()
                if recent:return None
                day=con.execute("SELECT COUNT(*) FROM titan_v49_ledger WHERE symbol=? AND published=0 AND created_at>?",(symbol,now-86400)).fetchone()[0]
            if int(day or 0)>=V49_MAX_SIGNALS_PER_SYMBOL_DAY:return None
            entry_mode=str(entry_plan.get("mode") or "NOW").upper()
            fill_status="UNFILLED"
            cur=con.execute("""INSERT INTO titan_v49_ledger(
                created_at,symbol,timeframe,side,published,mode,setup,entry_mode,entry,entry_preferred,stop_loss,tp1,tp2,
                risk_pct,rr1,rr2,effective_rr1,effective_rr2,confidence,probability_raw,probability_calibrated,edge,margin,quality,
                data_quality,coverage,regime,fill_status,fill_price,fill_at,expires_at,components_json,reasons_json,thresholds_json,param_version,decision_hash)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (now,symbol,"1h",side,pub,str(v.get("mode") or "WATCH"),str(v.get("setup") or "UNKNOWN"),entry_mode,
                 _v49_num(lv.get("entry"),0),_v49_num(entry_plan.get("preferred"),_v49_num(lv.get("entry"),0)),_v49_num(lv.get("sl"),0),_v49_num(lv.get("tp1"),0),_v49_num(lv.get("tp2"),0),
                 _v49_num(lv.get("risk_pct"),0),_v49_num(lv.get("rr1"),0),_v49_num(lv.get("rr2"),0),_v49_num(lv.get("effective_rr1"),0),_v49_num(lv.get("effective_rr2"),0),
                 _v49_num(v.get("confidence"),0),_v49_num(v.get("probability_raw"),0),_v49_num(v.get("probability_calibrated"),0),_v49_num(v.get("edge"),0),_v49_num(v.get("margin"),0),_v49_num(v.get("quality"),0),
                 _v49_num(v.get("data_quality"),0),_v49_num(v.get("coverage"),0),str(v.get("regime") or "unknown"),fill_status,None,None,
                 now+V49_ENTRY_TTL_MIN*60 if entry_mode!="NOW" else now+V49_NOW_FILL_WAIT_MIN*60, json.dumps(v.get("components") or {},ensure_ascii=False),json.dumps(v.get("hard_blocks") or [],ensure_ascii=False),json.dumps(v.get("thresholds") or {},ensure_ascii=False),V49_VERSION,str(x.get("decision_hash") or "")))
            con.commit();return int(cur.lastrowid)
    except Exception as exc:
        LOGGER.debug("V49 record failed: %s",exc);return None


def _v49_load_bars(symbol, start_ms, end_ms):
    try:
        # 5m gives a materially better first-touch audit for a short-swing strategy than 15m.
        df=fetch_klines(symbol,V49_EXECUTION_TF,limit=min(700,max(40,int(math.ceil((end_ms-start_ms)/300000.0))+8)),start_ms=int(start_ms),end_ms=int(end_ms))
        if df is None or df.empty:return None
        return df[(df["t"].astype(float)>=start_ms)&(df["t"].astype(float)<end_ms)].sort_values("t")
    except Exception as exc:
        LOGGER.debug("V49 bars failed %s: %s",symbol,exc);return None


def _v49_first_touch(window,side,sl,tp):
    """Evaluate barriers chronologically with explicit opening-gap handling (vectorised)."""
    if window is None or len(window)==0: return "TIME_EXIT",None,None
    w=window.sort_values("t", kind="stable")
    hi=_fast_col(w,"high"); lo=_fast_col(w,"low"); op=_fast_col(w,"open"); t=_fast_col(w,"t")
    valid=(hi>0)&(lo>0)&(op>0)
    if side=="LONG":
        gl=op<=sl; gw=op>=tp; slh=lo<=sl; tph=hi>=tp
    else:
        gl=op>=sl; gw=op<=tp; slh=hi>=sl; tph=lo<=tp
    hit=valid&(gl|gw|slh|tph)
    if not hit.any(): return "TIME_EXIT",None,None
    i=int(hit.argmax()); ts=float(t[i])/1000.0
    if gl[i]: return "LOSS",float(op[i]),ts
    if gw[i]: return "WIN",float(op[i]),ts
    if slh[i] and tph[i]: return "AMBIGUOUS",None,ts
    if slh[i]: return "LOSS",sl,ts
    return "WIN",tp,ts


def _v49_fill_if_needed(row, df):
    entry_mode=str(row.get("entry_mode") or "NOW").upper()
    created=_v49_num(row.get("created_at"),0)
    expires=_v49_num(row.get("expires_at"),created+V49_NOW_FILL_WAIT_MIN*60)
    if entry_mode=="NOW":
        # Conservative/causal reference fill: first 5m bar that starts AFTER signal creation.
        # Never reuse the already-open bar, because its OHLC may contain post-signal prices.
        w=df.sort_values("t", kind="stable")
        ts=_fast_col(w,"t")/1000.0; op=_fast_col(w,"open")
        m=(ts>created)&(ts<=expires)&(op>0)
        if m.any():
            i=int(m.argmax()); return "FILLED",float(op[i]),float(ts[i])
        if time.time() <= expires: return "UNFILLED",None,None
        return "EXPIRED_ENTRY",None,None
    preferred=_v49_num(row.get("entry_preferred"),0)
    if preferred<=0:return "FILL_INVALID",None,None
    ts=_fast_col(df,"t")/1000.0; hi=_fast_col(df,"high"); lo=_fast_col(df,"low")
    m=(ts>=created)&(ts<=expires)&(lo<=preferred)&(preferred<=hi)
    if m.any():
        i=int(m.argmax()); return "FILLED",preferred,float(ts[i])
    if time.time()>expires:
        return "EXPIRED_ENTRY",None,None
    return "UNFILLED",None,None


def _v49_eval_horizon(row,horizon,outcome_col,exit_col,ret_col,rm_col,mae_col,mfe_col,tte_col,eval_col,target):
    created=_v49_num(row.get("created_at"),0);symbol=str(row.get("symbol") or "");side=str(row.get("side") or "");
    sl=_v49_num(row.get("stop_loss"),0);tp=_v49_num(target,0)
    if not(created and symbol and side in {"LONG","SHORT"} and sl>0 and tp>0):return False
    try:
        end=created+horizon*60.0
        df=_v49_load_bars(symbol,int(created*1000),int(end*1000+V49_ENTRY_TTL_MIN*60*1000))
        if df is None or df.empty:return False
        fill,fill_px,fill_ts=_v49_fill_if_needed(row,df)
        now=time.time()
        if fill=="UNFILLED" and now<_v49_num(row.get("expires_at"),0):return False
        if fill=="UNFILLED": return False
        if fill in {"EXPIRED_ENTRY","FILL_INVALID"}:
            with DB_LOCK,db_conn() as con:
                con.execute("""UPDATE titan_v49_ledger SET fill_status=?,outcome_6h=?,outcome_24h=?,outcome_48h=? WHERE id=?""",(fill,"EXPIRED_ENTRY","EXPIRED_ENTRY","EXPIRED_ENTRY",int(row["id"])))
                con.commit()
            return True
        # Evaluate only from actual fill time, never from signal creation for conditional entries.
        w=df[(df["t"].astype(float)>=fill_ts*1000)&(df["t"].astype(float)<=(fill_ts+horizon*60)*1000)].sort_values("t")
        if w.empty:return False
        out,exitpx,event_ts=_v49_first_touch(w,side,sl,tp)
        last=_v49_num(w["close"].iloc[-1],fill_px)
        if exitpx is None:exitpx=last
        gross=((exitpx-fill_px)/fill_px*100) if side=="LONG" else ((fill_px-exitpx)/fill_px*100 if exitpx>0 else 0)
        net=gross-V49_FRICTION_PCT
        risk_pct=abs(fill_px-sl)/max(fill_px,1e-12)*100
        rm=net/max(risk_pct,1e-12)
        hi=w["high"].astype(float);lo=w["low"].astype(float)
        mae=((float(lo.min())/fill_px-1)*100) if side=="LONG" else ((fill_px/float(hi.max())-1)*100)
        mfe=((float(hi.max())/fill_px-1)*100) if side=="LONG" else ((fill_px/float(lo.min())-1)*100)
        tte=((event_ts-fill_ts)/60.0) if event_ts else None
        with DB_LOCK,db_conn() as con:
            con.execute(f"UPDATE titan_v49_ledger SET fill_status=?,fill_price=?,fill_at=?,{outcome_col}=?,{exit_col}=?,{ret_col}=?,{rm_col}=?,{mae_col}=?,{mfe_col}=?,{tte_col}=?,{eval_col}=? WHERE id=?",(fill,fill_px,fill_ts,out,exitpx,net,rm,mae,mfe,tte,now,int(row["id"])))
            con.commit()
        if outcome_col=="outcome_24h" and int(row.get("published") or 0) == 1:
            try:_v49_update_component_learning(row,out,rm)
            except Exception:_swallow()
        return True
    except Exception as exc:
        LOGGER.debug("V49 eval failed #%s: %s",row.get("id"),exc);return False


def _v49_evaluate_pending(limit=100):
    now=time.time();done=0
    rows=_v49_query(limit=max(20,int(limit)))
    for r in rows:
        age=now-_v49_num(r.get("created_at"),now)
        if r.get("outcome_6h")=="PENDING" and age>=V49_FAST_HORIZON_MIN*60:
            done+=int(_v49_eval_horizon(r,V49_FAST_HORIZON_MIN,"outcome_6h","exit_6h","return_net_6h","r_multiple_6h","mae_6h","mfe_6h","tte_6h","evaluated_6h_at",r.get("tp1")) or 0)
    rows=_v49_query(limit=max(20,int(limit)))
    for r in rows:
        age=now-_v49_num(r.get("created_at"),now)
        if r.get("outcome_24h")=="PENDING" and age>=V49_PRIMARY_HORIZON_MIN*60:
            done+=int(_v49_eval_horizon(r,V49_PRIMARY_HORIZON_MIN,"outcome_24h","exit_24h","return_net_24h","r_multiple_24h","mae_24h","mfe_24h","tte_24h","evaluated_24h_at",r.get("tp1")) or 0)
    rows=_v49_query(limit=max(20,int(limit)))
    for r in rows:
        age=now-_v49_num(r.get("created_at"),now)
        if r.get("outcome_48h")=="PENDING" and age>=V49_EXTENDED_HORIZON_MIN*60:
            done+=int(_v49_eval_horizon(r,V49_EXTENDED_HORIZON_MIN,"outcome_48h","exit_48h","return_net_48h","r_multiple_48h","mae_48h","mfe_48h","tte_48h","evaluated_48h_at",r.get("tp2")) or 0)
    return done


def _v49_query(limit=5000,symbol="",side="",setup="",regime=""):
    try:
        wh=[];pa=[]
        if symbol:wh.append("symbol=?");pa.append(symbol)
        if side in {"LONG","SHORT"}:wh.append("side=?");pa.append(side)
        if setup:wh.append("setup=?");pa.append(setup)
        if regime:wh.append("regime=?");pa.append(regime)
        sql="SELECT * FROM (SELECT * FROM titan_v49_ledger"+(" WHERE "+" AND ".join(wh) if wh else "")+" ORDER BY created_at DESC LIMIT ?) ORDER BY created_at ASC";pa.append(max(1,min(int(limit),50000)))
        with DB_LOCK,db_conn() as con:return [dict(r) for r in con.execute(sql,tuple(pa)).fetchall()]
    except Exception as exc:
        LOGGER.debug("V49 query failed: %s",exc);return []


def _v49_stats(rows,horizon="24h"):
    oc="outcome_"+horizon;rc="return_net_"+horizon;rmc="r_multiple_"+horizon
    decisive=[];rets=[];rms=[];amb=0;times=0
    for r in rows or []:
        out=str(r.get(oc) or "");ret=_v49_num(r.get(rc),float("nan"));rm=_v49_num(r.get(rmc),float("nan"))
        if out=="AMBIGUOUS":amb+=1;continue
        if out in {"WIN","LOSS"} and math.isfinite(ret):
            decisive.append(1 if out=="WIN" else 0);rets.append(ret);rms.append(rm if math.isfinite(rm) else np.nan)
        elif out=="TIME_EXIT" and math.isfinite(ret):
            times+=1;rets.append(ret);rms.append(rm if math.isfinite(rm) else np.nan)
    re=np.asarray(rets,dtype=float);re=re[np.isfinite(re)];rmarr=np.asarray(rms,dtype=float);rmarr=rmarr[np.isfinite(rmarr)]
    wins=sum(decisive);losses=len(decisive)-wins
    pos=re[re>0];neg=re[re<0]
    pf=float(pos.sum()/abs(neg.sum())) if neg.size else (math.inf if pos.size else None)
    exp=float(re.mean()) if re.size else None
    exp_r=float(rmarr.mean()) if rmarr.size else None
    eq=np.cumprod(1+np.clip(re/100,-0.999,10)) if re.size else np.asarray([])
    dd=0.0
    if eq.size:
        pk=np.maximum.accumulate(eq);dd=float(np.max((pk-eq)/np.maximum(pk,1e-12))*100)
    sharpe=float(re.mean()/re.std(ddof=1)*math.sqrt(len(re))) if len(re)>1 and re.std(ddof=1)>0 else None
    resolved_records=len([r for r in (rows or []) if str(r.get(oc) or "") not in {"PENDING","EXPIRED_ENTRY","FILL_INVALID"}])
    return {"records":resolved_records,"decisive_trades":len(decisive),"wins":wins,"losses":losses,
            "time_exits":times,"ambiguous":amb,"win_rate":round(100*wins/max(wins+losses,1),2) if wins+losses else None,
            "win_rate_lcb95":round(_v49_wilson(wins,wins+losses),2) if wins+losses else None,
            "profitable_exit_rate":round(100*sum(1 for v in re if v>0)/len(re),2) if len(re) else None,
            "profit_factor":round(pf,3) if pf is not None and math.isfinite(pf) else pf,"expectancy_pct":round(exp,5) if exp is not None else None,
            "expectancy_r":round(exp_r,4) if exp_r is not None else None,"avg_win_pct":round(float(pos.mean()),4) if pos.size else 0.0,
            "avg_loss_pct":round(float(neg.mean()),4) if neg.size else 0.0,"max_drawdown_pct":round(dd,4),"sharpe":round(sharpe,3) if sharpe is not None else None}


def _v49_walk_forward(rows):
    rows=sorted([r for r in rows if str(r.get("outcome_24h") or "") in {"WIN","LOSS"} and int(r.get("published") or 0)==1],key=lambda r:_v49_num(r.get("created_at"),0))
    n=len(rows)
    if n<30:return {"status":"INSUFFICIENT","samples":n}
    cut=max(15,int(n*0.70))
    cut_ts=_v49_num(rows[cut].get("created_at"),0)
    train=[r for r in rows[:cut] if _v49_num(r.get("created_at"),0) + V49_PRIMARY_HORIZON_MIN*60.0 <= cut_ts]
    test=rows[cut:]
    if len(train)<15 or len(test)<10:
        return {"status":"INSUFFICIENT_AFTER_PURGE","samples":n,"train_samples":len(train),"test_samples":len(test),"chronological":True,"purge_minutes":V49_WF_PURGE_MIN}
    tr=_v49_stats(train,"24h");te=_v49_stats(test,"24h")
    return {"status":"OOS_READY","train_samples":len(train),"test_samples":len(test),"train":tr,"test_oos":te,"chronological":True,"purge_minutes":V49_WF_PURGE_MIN,"leakage_guard":"chronological split + horizon purge; test outcomes never used for train"}


def _v49_monte_carlo(rows,horizon="24h",paths=V49_MC_PATHS,steps=50):
    oc="outcome_"+horizon;rc="return_net_"+horizon
    vals=[]
    for r in rows:
        o=str(r.get(oc) or "");ret=_v49_num(r.get(rc),float("nan"))
        if o in {"WIN","LOSS","TIME_EXIT"} and math.isfinite(ret):vals.append(ret)
    if len(vals)<20:return {"status":"INSUFFICIENT","samples":len(vals)}
    a=np.asarray(vals,dtype=float);rng=np.random.default_rng(4901+len(a));max_dd=[];finals=[]
    n_steps=max(10,int(steps)); block=max(1,min(int(V49_MC_BLOCK),len(a)))
    for _ in range(int(paths)):
        sampled=[]
        while len(sampled)<n_steps:
            start=int(rng.integers(0,max(1,len(a)-block+1)))
            sampled.extend(a[start:start+block].tolist())
        sample=np.asarray(sampled[:n_steps],dtype=float)
        eq=np.cumprod(1+np.clip(sample/100,-.999,5.0));pk=np.maximum.accumulate(eq);dd=float(np.max((pk-eq)/np.maximum(pk,1e-12))*100)
        finals.append(float(eq[-1]-1));max_dd.append(dd)
    finals=np.asarray(finals);max_dd=np.asarray(max_dd)
    return {"status":"OK","samples":len(vals),"paths":int(paths),"median_final_pct":round(float(np.median(finals))*100,2),"p05_final_pct":round(float(np.quantile(finals,0.05))*100,2),"p95_final_pct":round(float(np.quantile(finals,0.95))*100,2),"median_max_drawdown_pct":round(float(np.median(max_dd)),2),"p95_max_drawdown_pct":round(float(np.quantile(max_dd,0.95)),2),"loss_probability":round(float(np.mean(finals<0))*100,2)}


def _v49_audit():
    rows=_v49_query(limit=50000);pub=[r for r in rows if int(r.get("published") or 0)==1];sh=[r for r in rows if int(r.get("published") or 0)==0]
    return {"version":V49_VERSION,"scope":"V51 causal short-swing ledger; no claim about unseen history",
            "signal_mix":{"published":len(pub),"shadow":len(sh)},
            "all":{"6h":_v49_stats(rows,"6h"),"24h":_v49_stats(rows,"24h"),"48h":_v49_stats(rows,"48h")},
            "published":{"24h":_v49_stats(pub,"24h"),"48h":_v49_stats(pub,"48h")},
            "walk_forward_24h":_v49_walk_forward(rows),"monte_carlo_24h":_v49_monte_carlo(pub,"24h"),
            "component_weights":_v49_component_weights(),
            "pending":{"6h":sum(1 for r in rows if r.get("outcome_6h")=="PENDING"),"24h":sum(1 for r in rows if r.get("outcome_24h")=="PENDING"),"48h":sum(1 for r in rows if r.get("outcome_48h")=="PENDING")},
            "rules":{"primary_hours":24,"extended_hours":48,"execution_tf":"5m","min_pillars":V49_MIN_PILLARS,"hard_dq":V49_HARD_DQ,"min_effective_rr":V49_MIN_EFFECTIVE_RR,
                     "conditional_entry_requires_fill":True,"same_bar":"AMBIGUOUS","ai_can_create_direction":False,"analysis_only":True}}


@app.get("/api/v49/status")
def api_v49_status():
    try:return jsonify({"ok":True,**_v49_audit()})
    except Exception as exc:return jsonify({"ok":False,"error":str(exc)[:240]}),500


@app.get("/api/v49/metrics")
def api_v49_metrics():
    try:
        sym=_normalize_symbol(request.args.get("symbol") or "");side=str(request.args.get("side") or "").upper();setup=str(request.args.get("setup") or "");reg=str(request.args.get("regime") or "");h=str(request.args.get("horizon") or "24h")
        if h not in {"6h","24h","48h"}:h="24h"
        return jsonify({"ok":True,"version":V49_VERSION,"horizon":h,"stats":_v49_stats(_v49_query(20000,sym,side,setup,reg),h)})
    except Exception as exc:return jsonify({"ok":False,"error":str(exc)[:240]}),500


@app.get("/api/v49/ledger")
def api_v49_ledger():
    try:return jsonify({"ok":True,"version":V49_VERSION,"rows":_v49_query(limit=500)})
    except Exception as exc:return jsonify({"ok":False,"error":str(exc)[:240]}),500


def _v51_portfolio_gate(side: str, symbol: str) -> tuple[bool, str]:
    """Single portfolio-level concurrency gate for published V51 candidates."""
    if side not in {"LONG", "SHORT"}:
        return True, ""
    try:
        now=time.time()
        with DB_LOCK,db_conn() as con:
            count=con.execute("""SELECT COUNT(*) FROM titan_v49_ledger
                                WHERE published=1 AND side=? AND created_at>?
                                  AND outcome_24h='PENDING'""",(side,now-V49_ACTIVE_LOCK_HOURS*3600)).fetchone()[0]
        if int(count)>=MAX_PORTFOLIO_SAME_SIDE:
            return False, "portfolio_same_side_limit"
    except Exception:
        _swallow()
        # Fail closed only at the portfolio gate when state cannot be verified.
        return False, "portfolio_state_unavailable"
    return True, ""
