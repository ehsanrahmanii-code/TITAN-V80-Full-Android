# [TITAN V77 layer] governors/v47_swing_edge - V47 swing edge
# Original V76 source lines 17989-19053 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# TITAN V47 — SWING EDGE / 24-48H / REGIME-ADAPTIVE OPPORTUNITY ENGINE
# ------------------------------------------------------------
# Purpose:
#   - Optimize the existing V45/V46 stack for short-term 1–2 day setups.
#   - Keep the mature central governor as evidence, but add a dedicated
#     tactical opportunity layer that is less WAIT-heavy without fabricating edge.
#   - Separate 24h and 48h outcome evaluation from the older 240-minute V46 ledger.
#   - Use five relatively independent evidence pillars to reduce double counting:
#       trend / structure / momentum / flow / context.
#   - AI is advisory only and can never create a direction by itself.
#   - Historical probability is shown only when a sufficient V47 sample exists.
#   - Same-bar SL+TP = AMBIGUOUS and is excluded from win-rate denominator.
#   - All results remain analysis/paper only. No order execution is added.
# ============================================================
V47_VERSION = "TITAN-V47-SWING-EDGE-1D2D"
V47_PRIMARY_HORIZON_MIN = 24 * 60
V47_EXTENDED_HORIZON_MIN = 48 * 60
V47_SIGNAL_COOLDOWN_SEC = 90 * 60
V47_MAX_SHADOW_PER_SYMBOL_DAY = 12
V47_MIN_DQ = 58.0
V47_MIN_CONFIDENCE = 56.0
V47_MIN_RR1 = 1.45
V47_TARGET_RR1 = 1.65
V47_TARGET_RR2 = 2.80
V47_MAX_COST_R = 0.28
V47_MIN_PILLARS = 3
V47_MIN_DIRECTIONAL_EDGE = 0.09
V47_MIN_SIDE_MARGIN = 0.055
V47_EXTREME_VOL_PCT = 8.0
V47_STALE_PRICE_SEC = 20.0
V47_LEARN_MIN_N = 20
V47_LEARN_BLOCK_N = 30
V47_NEGATIVE_PF_BLOCK = 0.88
V47_NEGATIVE_EXP_BLOCK = -0.035
V47_PROMOTION_PF = 1.08
V47_PROMOTION_EXP = 0.02
V47_PROMOTION_LCB = 46.0
V47_ENTRY_EXTREME_ATR = 1.75
V47_ENTRY_PULLBACK_ATR = 0.45
V47_ENTRY_TTL_MIN = 360
V47_FRICTION_PCT = safe_float(globals().get("V45_FRICTION_PCT"), TOTAL_ENTRY_BUFFER * 2.0 * 100.0)


def _v47_num(v, default=0.0):
    try:
        x = float(v)
        return x if math.isfinite(x) else default
    except (TypeError, ValueError):
        return default


def _v47_parse_price(v):
    if isinstance(v, (int, float)):
        return _v47_num(v, 0.0)
    try:
        s = str(v or "").replace(",", "").replace("$", "").strip()
        return _v47_num(s, 0.0)
    except Exception:
        _swallow()
        return 0.0


def _v47_side_sign(side):
    return 1.0 if str(side).upper() == "LONG" else -1.0


def _v47_dir_from_score(score):
    score = _v47_num(score, 50.0)
    return max(-1.0, min(1.0, (score - 50.0) / 25.0))


def _v47_pillar(label, side, value, confidence=1.0, available=True, reason=""):
    value = max(-1.0, min(1.0, _v47_num(value, 0.0)))
    confidence = max(0.0, min(1.0, _v47_num(confidence, 0.0)))
    return {
        "label": label,
        "side": side,
        "value": round(value, 4),
        "confidence": round(confidence, 4),
        "available": bool(available),
        "support": bool(value >= 0.20 and available),
        "oppose": bool(value <= -0.20 and available),
        "reason": str(reason or ""),
    }


def _v47_get_context(x):
    fusion = x.get("fusion") if isinstance(x.get("fusion"), dict) else {}
    if not fusion and isinstance(x.get("titan_analysis"), dict):
        fusion = x["titan_analysis"].get("fusion") or {}
    edge = x.get("edge") if isinstance(x.get("edge"), dict) else {}
    if not edge and isinstance(x.get("titan_analysis"), dict):
        edge = x["titan_analysis"].get("edge") or {}
    structure = edge.get("structure") if isinstance(edge.get("structure"), dict) else {}
    regime = edge.get("regime") if isinstance(edge.get("regime"), dict) else {}
    liquidity = edge.get("liquidity") if isinstance(edge.get("liquidity"), dict) else {}
    precision = x.get("precision") if isinstance(x.get("precision"), dict) else {}
    dq = x.get("data_quality") if isinstance(x.get("data_quality"), dict) else fusion.get("data_quality") or {}
    tf = x.get("tf_scores") if isinstance(x.get("tf_scores"), dict) else {}
    tf = {k: _v47_num(v, 50.0) for k, v in tf.items() if k in {"15m", "1h", "4h", "1d"}}
    for k in ("15m", "1h", "4h", "1d"):
        tf.setdefault(k, 50.0)
    vol_delta = x.get("volume_delta") if isinstance(x.get("volume_delta"), dict) else {}
    derivatives = {}
    if isinstance(x.get("titan_analysis"), dict):
        derivatives = x["titan_analysis"].get("derivatives") or {}
    if not derivatives:
        derivatives = fusion.get("derivatives") or {}
    return {
        "fusion": fusion,
        "edge": edge,
        "structure": structure,
        "regime": regime,
        "liquidity": liquidity,
        "precision": precision,
        "dq": dq,
        "tf": tf,
        "vol_delta": vol_delta,
        "derivatives": derivatives,
        "price": _v47_parse_price(x.get("price_raw", x.get("live_price", x.get("price")))),
        "rsi": _v47_num(x.get("rsi_value", x.get("rsi")), 50.0),
        "macd_cross": str(x.get("macd_cross") or "none").lower(),
        "macd_hist": _v47_num(x.get("macd_hist"), 0.0),
        "volume_spike": bool(x.get("volume_spike")),
        "taker_buy": _v47_num(x.get("taker_buy_pct"), float("nan")),
        "taker_sell": _v47_num(x.get("taker_sell_pct"), float("nan")),
        "ls_ratio": _v47_num(x.get("long_short_ratio"), float("nan")),
        "btc_trend": str(x.get("btc_trend") or "").lower(),
        "vol_pct": _v47_num(x.get("volatility_pct"), 0.0),
        "score": _v47_num(x.get("score"), 50.0),
        "alignment": _v47_num(x.get("alignment"), 50.0),
        "signal_quality": _v47_num(x.get("signal_quality"), 50.0),
        "confidence": _v47_num(x.get("decision_confidence"), _v47_num(x.get("success_probability"), 50.0)),
    }


def _v47_extract_indicator_availability(ctx):
    # Missing values are genuinely missing — never replaced with directional evidence.
    return {
        "taker": math.isfinite(ctx.get("taker_buy", float("nan"))),
        "ls": math.isfinite(ctx.get("ls_ratio", float("nan"))) and ctx.get("ls_ratio", float("nan")) > 0,
        "volume_delta": isinstance(ctx.get("vol_delta"), dict) and "delta_pct" in ctx.get("vol_delta", {}),
        "structure": bool(ctx.get("structure")),
        "regime": bool(ctx.get("regime")),
    }


def _v47_build_pillars(x, side):
    c = _v47_get_context(x)
    sign = _v47_side_sign(side)
    tf = c["tf"]

    # V51 data-awareness: defaults used for scoring are NOT treated as observed evidence.
    raw_tf = x.get("tf_scores") if isinstance(x.get("tf_scores"), dict) else {}
    tf_available = {k: (k in raw_tf and _v47_num(raw_tf.get(k), float("nan")) == _v47_num(raw_tf.get(k), float("nan")))
                    for k in ("15m", "1h", "4h", "1d")}
    rsi_raw = x.get("rsi_value", x.get("rsi"))
    rsi_available = _v47_num(rsi_raw, float("nan")) == _v47_num(rsi_raw, float("nan"))
    macd_cross_raw = str(x.get("macd_cross") or "").lower()
    macd_available = macd_cross_raw in {"bull", "bear"}
    macd_hist_raw = _v47_num(x.get("macd_hist"), float("nan"))
    macd_hist_available = math.isfinite(macd_hist_raw)
    momentum_available = rsi_available or macd_available or macd_hist_available
    # Pillar 1 — trend spine (1h/4h/1d); 15m is deliberately excluded from trend.
    trend_raw = (
        0.45 * _v47_dir_from_score(tf["1h"]) +
        0.35 * _v47_dir_from_score(tf["4h"]) +
        0.20 * _v47_dir_from_score(tf["1d"])
    ) * sign
    observed_trend_tfs = [k for k in ("1h", "4h", "1d") if tf_available.get(k)]
    trend_conf = (sum(1 for k in observed_trend_tfs if abs(tf[k] - 50.0) >= 2.0) / max(len(observed_trend_tfs), 1)) if observed_trend_tfs else 0.0
    trend_reason = f"1h={tf['1h']:.1f} · 4h={tf['4h']:.1f} · 1d={tf['1d']:.1f}"

    # Pillar 2 — structure: BOS / HH-HL / LH-LL are treated as one structural family.
    s = c["structure"]
    sbias = str(s.get("bias") or "")
    sevent = str(s.get("event") or "")
    match = "صعودی" if side == "LONG" else "نزولی"
    opposite = "نزولی" if side == "LONG" else "صعودی"
    structure_value = 0.0
    structure_reason = sevent or "structure unavailable"
    if sbias == match:
        structure_value += 0.60
    elif sbias == opposite:
        structure_value -= 0.70
    if side == "LONG" and sevent == "BOS_UP":
        structure_value += 0.55
    elif side == "SHORT" and sevent == "BOS_DOWN":
        structure_value += 0.55
    elif side == "LONG" and sevent == "BOS_DOWN":
        structure_value -= 0.65
    elif side == "SHORT" and sevent == "BOS_UP":
        structure_value -= 0.65
    structure_value = max(-1.0, min(1.0, structure_value))
    structure_conf = min(1.0, max(0.0, _v47_num(s.get("confirmation_score"), 0.0) / 100.0)) if s else 0.0

    # Pillar 3 — momentum / timing.
    rsi = c["rsi"]
    macd = c["macd_cross"]
    momentum_value = 0.0
    momentum_bits = []
    if side == "LONG":
        if 52 <= rsi <= 68: momentum_value += 0.45; momentum_bits.append("RSI healthy")
        elif 44 <= rsi < 52: momentum_value += 0.15; momentum_bits.append("RSI neutral-bull")
        elif 35 <= rsi < 44: momentum_value += 0.25; momentum_bits.append("RSI pullback")
        elif rsi < 27: momentum_value += 0.05; momentum_bits.append("RSI extreme")
        elif rsi > 74: momentum_value -= 0.65; momentum_bits.append("RSI exhaustion")
        elif rsi > 68: momentum_value -= 0.20; momentum_bits.append("RSI stretched")
        if macd == "bull": momentum_value += 0.45; momentum_bits.append("MACD bull")
        elif macd == "bear": momentum_value -= 0.45; momentum_bits.append("MACD bear")
        if c["macd_hist"] > 0: momentum_value += 0.10
        elif c["macd_hist"] < 0: momentum_value -= 0.10
    else:
        if 32 <= rsi <= 48: momentum_value += 0.35; momentum_bits.append("RSI healthy")
        elif 48 < rsi <= 56: momentum_value += 0.10; momentum_bits.append("RSI neutral-bear")
        elif 56 < rsi <= 65: momentum_value += 0.20; momentum_bits.append("RSI pullback")
        elif rsi > 73: momentum_value += 0.05; momentum_bits.append("RSI extreme")
        elif rsi < 26: momentum_value -= 0.65; momentum_bits.append("RSI exhaustion")
        elif rsi < 32: momentum_value -= 0.20; momentum_bits.append("RSI stretched")
        if macd == "bear": momentum_value += 0.45; momentum_bits.append("MACD bear")
        elif macd == "bull": momentum_value -= 0.45; momentum_bits.append("MACD bull")
        if c["macd_hist"] < 0: momentum_value += 0.10
        elif c["macd_hist"] > 0: momentum_value -= 0.10
    momentum_value = max(-1.0, min(1.0, momentum_value))
    momentum_conf = 0.8 if macd in {"bull", "bear"} else 0.5
    momentum_conf *= 0.75 if rsi in (0, 50) else 1.0

    # Pillar 4 — flow / positioning. Only available inputs are scored.
    flow_vals = []
    flow_bits = []
    tb = c["taker_buy"]
    if math.isfinite(tb):
        flow_vals.append(max(-1.0, min(1.0, (tb - 50.0) / 12.0)) * sign)
        flow_bits.append(f"taker={tb:.1f}")
    vd = _v47_num(c["vol_delta"].get("delta_pct"), float("nan")) if isinstance(c.get("vol_delta"), dict) else float("nan")
    if math.isfinite(vd):
        flow_vals.append(max(-1.0, min(1.0, vd / 25.0)) * sign)
        flow_bits.append(f"delta={vd:.1f}")
    lsr = c["ls_ratio"]
    if math.isfinite(lsr) and lsr > 0:
        # Contrarian only at meaningful extremes; neutral in the middle.
        contr = 0.0
        if lsr >= 1.75: contr = -0.65
        elif lsr >= 1.35: contr = -0.25
        elif lsr <= 0.58: contr = 0.65
        elif lsr <= 0.78: contr = 0.25
        flow_vals.append(contr * sign)
        flow_bits.append(f"L/S={lsr:.2f}")
    flow_available = bool(flow_vals)
    flow_value = float(np.mean(flow_vals)) if flow_vals else 0.0
    if c["volume_spike"]:
        # volume spike is confirmation, not directional evidence by itself.
        flow_value *= 1.15
        flow_bits.append("volume spike")
    flow_value = max(-1.0, min(1.0, flow_value))
    flow_conf = min(1.0, len(flow_vals) / 3.0)

    # Pillar 5 — context: regime + BTC context + liquidity. It should not dominate.
    rg = str(c["regime"].get("regime") or "unknown").lower()
    context_value = 0.0
    context_bits = []
    if side == "LONG":
        if rg == "trend_up": context_value += 0.65; context_bits.append("trend_up")
        elif rg == "trend_down": context_value -= 0.75; context_bits.append("trend_down")
        elif rg == "breakout_watch": context_value += 0.20; context_bits.append("breakout_watch")
    else:
        if rg == "trend_down": context_value += 0.65; context_bits.append("trend_down")
        elif rg == "trend_up": context_value -= 0.75; context_bits.append("trend_up")
        elif rg == "breakout_watch": context_value += 0.20; context_bits.append("breakout_watch")
    btc = c["btc_trend"]
    if btc in {"صعودی", "up", "bull", "bullish"}:
        context_value += 0.25 if side == "LONG" else -0.20
        context_bits.append("BTC↑")
    elif btc in {"نزولی", "down", "bear", "bearish"}:
        context_value += 0.25 if side == "SHORT" else -0.20
        context_bits.append("BTC↓")
    lp = _v47_num(c["liquidity"].get("pressure"), 0.0)
    if abs(lp) > 0.05:
        context_value += (0.35 if lp > 0 else -0.35) * sign
        context_bits.append(f"liq={lp:.2f}")
    context_value = max(-1.0, min(1.0, context_value))
    context_conf = min(1.0, max(0.2, (_v47_num(c["regime"].get("confidence"), 0.0) / 100.0))) if c["regime"] else 0.0

    pillars = [
        _v47_pillar("trend", side, trend_raw, trend_conf, bool(observed_trend_tfs), trend_reason if observed_trend_tfs else "trend data unavailable"),
        _v47_pillar("structure", side, structure_value, structure_conf, bool(s), structure_reason),
        _v47_pillar("momentum", side, momentum_value, momentum_conf, momentum_available, " · ".join(momentum_bits) if momentum_available else "momentum data unavailable"),
        _v47_pillar("flow", side, flow_value, flow_conf, flow_available, " · ".join(flow_bits)),
        _v47_pillar("context", side, context_value, context_conf, bool(c["regime"]), " · ".join(context_bits)),
    ]

    weights = {"trend": 0.29, "structure": 0.23, "momentum": 0.18, "flow": 0.16, "context": 0.14}
    available = [p for p in pillars if p["available"]]
    denom = sum(weights[p["label"]] * max(p["confidence"], 0.15) for p in available)
    score = sum(weights[p["label"]] * max(p["confidence"], 0.15) * p["value"] for p in available) / max(denom, 1e-9)
    support = sum(1 for p in available if p["support"])
    oppose = sum(1 for p in available if p["oppose"])
    strong_opposition = any(p["available"] and p["value"] <= -0.72 and p["label"] in {"trend", "structure"} for p in pillars)
    return {
        "side": side,
        "score": round(score, 5),
        "quality": round(clamp(50.0 + score * 50.0, 0.0, 100.0), 2),
        "pillars": pillars,
        "support_count": support,
        "opposition_count": oppose,
        "available_count": len(available),
        "strong_opposition": strong_opposition,
        "weights": weights,
    }


def _v47_setup_type(ctx, side, pillar_pack):
    structure = ctx["structure"]
    rg = str(ctx["regime"].get("regime") or "unknown").lower()
    score = pillar_pack["score"]
    rsi = ctx["rsi"]
    if (side == "LONG" and structure.get("event") == "BOS_UP" or side == "SHORT" and structure.get("event") == "BOS_DOWN") and ctx["volume_spike"]:
        return "BREAKOUT", "شکست ساختار با تأیید حجم"
    trend_ok = (side == "LONG" and ctx["tf"]["4h"] >= 54 and ctx["tf"]["1h"] >= 52) or (side == "SHORT" and ctx["tf"]["4h"] <= 46 and ctx["tf"]["1h"] <= 48)
    pullback = trend_ok and ((side == "LONG" and rsi < 52) or (side == "SHORT" and rsi > 48))
    if pullback and score >= 0.10:
        return "PULLBACK", "ادامه روند پس از پولبک کوتاه"
    if rg == "range" and ((side == "LONG" and rsi <= 30) or (side == "SHORT" and rsi >= 70)):
        return "MEAN_REVERSION", "بازگشت از افراط در بازار رنج"
    return "TREND_CONTINUATION", "ادامه روند چندتایم‌فریمی"


def _v47_recent_stats(symbol="", side="", regime="", horizon="24h"):
    try:
        outcome_col = "outcome_24h" if horizon == "24h" else "outcome_48h"
        return _v47_stats_from_rows(_v47_query_rows(
            symbol=symbol, side=side, regime=regime, outcome_col=outcome_col, limit=5000
        ), outcome_col=outcome_col)
    except Exception as exc:
        LOGGER.debug("V47 recent stats failed: %s", exc)
        return {"trades": 0, "wins": 0, "losses": 0, "win_rate": None, "profit_factor": None, "expectancy_pct": 0.0,
                "max_drawdown_pct": 0.0, "win_rate_lower_95": None}


def _v47_bayes(wins, losses):
    # Mild neutral prior; used internally as posterior, never displayed as a fabricated sample.
    a, b = 5.0 + max(0, int(wins)), 5.0 + max(0, int(losses))
    mean = a / max(a + b, 1e-9) * 100.0
    var = (a * b) / max((a + b) ** 2 * (a + b + 1.0), 1e-9)
    sd = math.sqrt(var)
    return {"mean": round(mean, 2), "low95": round(max(0.0, mean - 1.96 * sd * 100.0), 2),
            "high95": round(min(100.0, mean + 1.96 * sd * 100.0), 2), "samples": int(wins + losses)}


def _v47_wilson(wins, n, z=1.96):
    if n <= 0:
        return None
    p = wins / n
    den = 1.0 + z*z/n
    centre = p + z*z/(2*n)
    margin = z * math.sqrt((p*(1-p) + z*z/(4*n))/n)
    return max(0.0, (centre - margin) / den) * 100.0


def _v47_stats_from_rows(rows, outcome_col="outcome_24h"):
    usable = []
    ambiguous = 0
    for r in rows or []:
        outcome = str(r.get(outcome_col) or "")
        ret = _v47_num(r.get("return_net_" + outcome_col.split("_")[-1]), float("nan"))
        if outcome == "AMBIGUOUS":
            ambiguous += 1
            continue
        if outcome in {"WIN", "LOSS", "TIME_EXIT"} and math.isfinite(ret):
            usable.append((outcome, ret))
    decisive = []
    for outcome, ret in usable:
        if outcome == "WIN": decisive.append(1)
        elif outcome == "LOSS": decisive.append(0)
        else: decisive.append(1 if ret > 0 else 0 if ret < 0 else None)
    decisive = [d for d in decisive if d is not None]
    wins = int(sum(decisive)); losses = int(len(decisive) - wins)
    rets = np.asarray([ret for _, ret in usable], dtype=float)
    pos = rets[rets > 0]; neg = rets[rets < 0]
    pf = float(pos.sum() / abs(neg.sum())) if neg.size else (math.inf if pos.size else None)
    eq = np.cumprod(1.0 + np.clip(rets / 100.0, -0.999, 10.0)) if rets.size else np.asarray([])
    dd = 0.0
    if eq.size:
        pk = np.maximum.accumulate(eq); dd = float(np.max((pk - eq) / np.maximum(pk, 1e-12)) * 100.0)
    return {
        "trades": int(len(usable)), "wins": wins, "losses": losses, "ambiguous": ambiguous,
        "win_rate": round(wins / max(wins + losses, 1) * 100.0, 2) if wins + losses else None,
        "win_rate_lower_95": round(_v47_wilson(wins, wins + losses), 2) if wins + losses else None,
        "profit_factor": round(pf, 3) if pf is not None and math.isfinite(pf) else pf,
        "expectancy_pct": round(float(rets.mean()), 5) if rets.size else 0.0,
        "avg_win_pct": round(float(pos.mean()), 4) if pos.size else 0.0,
        "avg_loss_pct": round(float(neg.mean()), 4) if neg.size else 0.0,
        "max_drawdown_pct": round(dd, 4),
        "bayesian": _v47_bayes(wins, losses),
    }


def _v47_init_schema():
    try:
        with DB_LOCK, db_conn() as con:
            con.execute("""
                CREATE TABLE IF NOT EXISTS titan_v47_ledger(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at REAL NOT NULL,
                    symbol TEXT NOT NULL,
                    timeframe TEXT NOT NULL DEFAULT '1h',
                    side TEXT NOT NULL,
                    published INTEGER NOT NULL DEFAULT 0,
                    mode TEXT NOT NULL DEFAULT 'SHADOW',
                    setup TEXT NOT NULL DEFAULT 'UNKNOWN',
                    entry REAL NOT NULL,
                    stop_loss REAL NOT NULL,
                    tp1 REAL NOT NULL,
                    tp2 REAL NOT NULL,
                    risk_pct REAL NOT NULL DEFAULT 0,
                    rr1 REAL NOT NULL DEFAULT 0,
                    rr2 REAL NOT NULL DEFAULT 0,
                    effective_rr1 REAL NOT NULL DEFAULT 0,
                    confidence REAL NOT NULL DEFAULT 0,
                    estimated_win_probability REAL,
                    score REAL NOT NULL DEFAULT 0,
                    quality REAL NOT NULL DEFAULT 0,
                    data_quality REAL NOT NULL DEFAULT 0,
                    pillar_count INTEGER NOT NULL DEFAULT 0,
                    support_count INTEGER NOT NULL DEFAULT 0,
                    opposition_count INTEGER NOT NULL DEFAULT 0,
                    coverage REAL NOT NULL DEFAULT 0,
                    regime TEXT DEFAULT 'unknown',
                    primary_horizon_min INTEGER NOT NULL DEFAULT 1440,
                    extended_horizon_min INTEGER NOT NULL DEFAULT 2880,
                    outcome_24h TEXT DEFAULT 'PENDING',
                    outcome_48h TEXT DEFAULT 'PENDING',
                    exit_24h REAL,
                    exit_48h REAL,
                    return_gross_24h REAL,
                    return_net_24h REAL,
                    return_gross_48h REAL,
                    return_net_48h REAL,
                    r_multiple_24h REAL,
                    r_multiple_48h REAL,
                    mae_24h REAL,
                    mfe_24h REAL,
                    mae_48h REAL,
                    mfe_48h REAL,
                    tte_24h REAL,
                    tte_48h REAL,
                    components_json TEXT DEFAULT '[]',
                    reasons_json TEXT DEFAULT '[]',
                    entry_mode TEXT DEFAULT 'NOW',
                    entry_preferred REAL,
                    expires_at REAL,
                    evaluated_24h_at REAL,
                    evaluated_48h_at REAL,
                    param_version TEXT NOT NULL
                )
            """)
            con.execute("CREATE INDEX IF NOT EXISTS idx_v47_pending24 ON titan_v47_ledger(outcome_24h,created_at)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_v47_pending48 ON titan_v47_ledger(outcome_48h,created_at)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_v47_symbol_side ON titan_v47_ledger(symbol,side,created_at)")
            con.commit()
    except Exception as exc:
        LOGGER.debug("V47 schema init: %s", exc)


_v47_init_schema()


def _v47_query_rows(symbol="", side="", regime="", outcome_col=None, limit=5000):
    try:
        where=[]; params=[]
        if symbol: where.append("symbol=?"); params.append(symbol)
        if side in {"LONG", "SHORT"}: where.append("side=?"); params.append(side)
        if regime: where.append("regime=?"); params.append(regime)
        if outcome_col in {"outcome_24h", "outcome_48h"}:
            where.append(f"{outcome_col} IN ('WIN','LOSS','TIME_EXIT','AMBIGUOUS')")
        sql="SELECT * FROM titan_v47_ledger" + (" WHERE " + " AND ".join(where) if where else "") + " ORDER BY created_at DESC LIMIT ?"
        sql="SELECT * FROM ("+sql+") ORDER BY created_at ASC"
        params.append(int(max(1, min(limit, 50000))))
        with DB_LOCK, db_conn() as con:
            return [dict(r) for r in con.execute(sql, tuple(params)).fetchall()]
    except Exception as exc:
        LOGGER.debug("V47 query failed: %s", exc)
        return []


def _v47_price_level_plan(x, side, ctx):
    price = ctx["price"]
    if price <= 0:
        return None
    atr = _v47_num(x.get("atr_raw"), 0.0)
    if atr <= 0:
        atr = price * ctx["vol_pct"] / 100.0 if ctx["vol_pct"] > 0 else 0.0
    if atr <= 0:
        return None
    s = ctx["structure"]
    anchor = _v47_num(s.get("swing_low" if side == "LONG" else "swing_high"), 0.0)
    # Rebuild levels when upstream levels are absent, malformed, or have poor effective R.
    old_sl = _v47_num(x.get("stop_loss_raw"), 0.0)
    old_tp1 = _v47_num(x.get("tp1_raw"), 0.0)
    old_tp2 = _v47_num(x.get("tp2_raw"), 0.0)
    valid_old = ((side == "LONG" and old_sl > 0 and old_sl < price < old_tp1 < old_tp2) or
                 (side == "SHORT" and old_tp2 > 0 and old_tp2 < old_tp1 < price < old_sl))
    if valid_old:
        sl, tp1, tp2 = old_sl, old_tp1, old_tp2
    else:
        lv = _v45_rr_levels(price, atr, side, anchor if anchor > 0 else None,
                            rr1=V47_TARGET_RR1, rr2=V47_TARGET_RR2)
        if not lv:
            return None
        sl, tp1, tp2 = float(lv["sl"]), float(lv["tp1"]), float(lv["tp2"])
    risk = abs(price - sl)
    if risk <= 0:
        return None
    rr1 = abs(tp1 - price) / risk
    rr2 = abs(tp2 - price) / risk
    risk_pct = risk / price * 100.0
    cost_r = V47_FRICTION_PCT / max(risk_pct, 1e-9)
    effective_rr1 = rr1 - cost_r
    effective_rr2 = rr2 - cost_r
    # Do not let the model "fix" a weak reward/risk by increasing probability.
    if effective_rr1 < 1.05:
        lv = _v45_rr_levels(price, atr, side, anchor if anchor > 0 else None,
                            rr1=V47_TARGET_RR1, rr2=V47_TARGET_RR2)
        if lv:
            sl, tp1, tp2 = float(lv["sl"]), float(lv["tp1"]), float(lv["tp2"])
            risk = abs(price - sl); rr1 = abs(tp1-price)/max(risk,1e-12); rr2 = abs(tp2-price)/max(risk,1e-12)
            risk_pct = risk / price * 100.0; cost_r = V47_FRICTION_PCT/max(risk_pct,1e-9)
            effective_rr1 = rr1 - cost_r; effective_rr2 = rr2 - cost_r
    if not ((side == "LONG" and sl < price < tp1 < tp2) or (side == "SHORT" and tp2 < tp1 < price < sl)):
        return None
    return {
        "entry": price, "sl": sl, "tp1": tp1, "tp2": tp2, "risk": risk,
        "risk_pct": risk_pct, "rr1": rr1, "rr2": rr2, "cost_r": cost_r,
        "effective_rr1": effective_rr1, "effective_rr2": effective_rr2,
        "atr": atr,
    }


def _v47_entry_plan(ctx, lv, side, setup):
    p = ctx["price"]; atr = lv["atr"]
    if p <= 0 or atr <= 0:
        return {"mode":"NOW","now":p,"preferred":p,"zone_low":p,"zone_high":p,"ttl_min":0,"note":""}
    # Breakouts can be chased only while not severely extended; continuation is more patient.
    extension = 0.0
    bb = ctx["edge"].get("technical", {}) if isinstance(ctx.get("edge"), dict) else {}
    try:
        middle = _v47_parse_price((bb.get("bollinger") or {}).get("middle"))
        if middle > 0:
            extension = (p - middle) / atr if side == "LONG" else (middle - p) / atr
    except Exception:
        _swallow()
        extension = 0.0
    if setup == "BREAKOUT" and extension <= V47_ENTRY_EXTREME_ATR:
        return {"mode":"NOW","now":p,"preferred":p,"zone_low":p-0.12*atr,"zone_high":p+0.12*atr,"ttl_min":120,"note":"ورود نزدیک بازار؛ شکست هنوز بیش‌ازحد کشیده نشده است."}
    if extension <= V47_ENTRY_EXTREME_ATR:
        return {"mode":"NOW","now":p,"preferred":p,"zone_low":p-0.18*atr,"zone_high":p+0.18*atr,"ttl_min":240,"note":"ورود جاری؛ قیمت هنوز در محدوده قابل معامله است."}
    # Publish direction but improve entry quality by proposing a nearby pullback price.
    preferred = p - V47_ENTRY_PULLBACK_ATR*atr if side == "LONG" else p + V47_ENTRY_PULLBACK_ATR*atr
    return {"mode":"PULLBACK","now":p,"preferred":preferred,
            "zone_low":preferred-0.18*atr,"zone_high":preferred+0.18*atr,"ttl_min":V47_ENTRY_TTL_MIN,
            "note":"جهت معتبر است ولی ورود روی پولبک نزدیک، R/R و نسبت ریسک به نوسان را بهتر می‌کند."}


def _v47_historical_adjustment(symbol, side, regime):
    same = _v47_recent_stats(symbol, side, regime, "24h")
    n = int(same.get("trades") or 0)
    scope = "REGIME"
    if n < V47_LEARN_MIN_N:
        overall = _v47_recent_stats(symbol, side, "", "24h")
        if int(overall.get("trades") or 0) > n:
            same = overall
            n = int(same.get("trades") or 0)
            scope = "SYMBOL_SIDE"
    if n < V47_LEARN_MIN_N:
        return {"n": n, "penalty": 0.0, "status":"INSUFFICIENT", "estimated_win_probability":None, "stats":same, "scope":scope}
    bay = same.get("bayesian") or {}
    penalty = 0.0
    pf = _v47_num(same.get("profit_factor"), 0.0)
    exp = _v47_num(same.get("expectancy_pct"), 0.0)
    if n >= V47_LEARN_BLOCK_N and ((pf and pf < V47_NEGATIVE_PF_BLOCK) or exp < V47_NEGATIVE_EXP_BLOCK):
        penalty = 8.0
    elif exp < 0:
        penalty = 3.5
    elif pf >= V47_PROMOTION_PF and exp >= V47_PROMOTION_EXP and _v47_num(same.get("win_rate_lower_95"), 0.0) >= V47_PROMOTION_LCB:
        penalty = -2.0
    return {"n":n,"penalty":penalty,"status":"RELIABLE" if n>=V47_LEARN_MIN_N else "INSUFFICIENT",
            "estimated_win_probability":bay.get("mean"),"wilson_lower_95":bay.get("low95"),"stats":same,"scope":scope}


def _v47_apply_policy(x):
    x = dict(x or {})
    ctx = _v47_get_context(x)
    side_existing = str(x.get("decision_tag") or x.get("decision") or "WAIT").upper()
    if side_existing not in {"LONG","SHORT"}:
        side_existing = ""
    candidates = {}
    for side in ("LONG", "SHORT"):
        p = _v47_build_pillars(x, side)
        candidates[side] = p
    best_side = max(("LONG","SHORT"), key=lambda s: candidates[s]["score"])
    side = side_existing or (best_side if candidates[best_side]["score"] >= V47_MIN_DIRECTIONAL_EDGE and (candidates[best_side]["score"] - candidates["SHORT" if best_side == "LONG" else "LONG"]["score"]) >= V47_MIN_SIDE_MARGIN else "")
    other = "SHORT" if side == "LONG" else "LONG" if side == "SHORT" else ("SHORT" if best_side == "LONG" else "LONG")
    pbest = candidates[side] if side in candidates else candidates[best_side]
    pother = candidates[other]
    margin = pbest["score"] - pother["score"]
    hard=[]; soft=[]
    dq = _v47_num(ctx["dq"].get("score"), 0.0)
    live_age = _v47_num(x.get("live_price_age_sec"), 0.0)
    if ctx["price"] <= 0: hard.append("invalid_price")
    if live_age > V47_STALE_PRICE_SEC: hard.append("stale_live_price")
    if dq < 50.0: hard.append("data_quality_hard")
    if ctx["vol_pct"] >= V47_EXTREME_VOL_PCT: hard.append("extreme_volatility")
    if not side:
        # Still store a V47 shadow candidate only when there is directional evidence.
        x["v47"]={"version":V47_VERSION,"decision":"WAIT","candidate":"WAIT","state":"NO_DIRECTIONAL_EDGE",
                   "horizon_primary_min":V47_PRIMARY_HORIZON_MIN,"horizon_extended_min":V47_EXTENDED_HORIZON_MIN,
                   "candidates":candidates}
        return x

    setup, setup_note = _v47_setup_type(ctx, side, candidates[side])
    lv = _v47_price_level_plan(x, side, ctx)
    if not lv:
        hard.append("invalid_levels")
    else:
        if lv["effective_rr1"] < V47_MIN_RR1: hard.append("effective_rr1_below_floor")
        if lv["cost_r"] > V47_MAX_COST_R: hard.append("friction_too_high")
        if lv["risk_pct"] > 5.5: soft.append("wide_stop_distance")
    if dq < V47_MIN_DQ: soft.append("data_quality_borderline")
    if pbest["strong_opposition"]: hard.append("strong_htf_or_structure_conflict")
    if pbest["support_count"] < V47_MIN_PILLARS and setup != "MEAN_REVERSION": soft.append("few_independent_pillars")
    if pbest["opposition_count"] >= 2: soft.append("multiple_opposing_pillars")
    # 15m may be counter-trend in a pullback setup; do not hard-veto it.
    if side == "LONG" and ctx["tf"]["4h"] <= 44 and ctx["tf"]["1h"] <= 46: hard.append("htf_bearish")
    if side == "SHORT" and ctx["tf"]["4h"] >= 56 and ctx["tf"]["1h"] >= 54: hard.append("htf_bullish")

    hist = _v47_historical_adjustment(_normalize_symbol(str(x.get("symbol") or "")), side,
                                       str(ctx["regime"].get("regime") or "unknown"))
    if hist["penalty"] > 0:
        soft.append("learned_negative_edge")
    if hist["penalty"] >= 8:
        # Strong current structural setups may remain visible as SHADOW, but are not published.
        soft.append("learned_negative_block")

    # Adaptive quality / confidence: current evidence first, historical data only as an adjustment.
    evidence_quality = pbest["quality"]
    signal_quality = ctx["signal_quality"]
    alignment = ctx["alignment"]
    conf = (
        0.48 * evidence_quality +
        0.18 * signal_quality +
        0.14 * alignment +
        0.12 * dq +
        0.08 * (50.0 + min(25.0, abs(pbest["score"]) * 25.0))
    )
    conf -= hist["penalty"]
    # High-conviction breakout relief avoids the classic "strong breakout -> WAIT" failure mode.
    breakout_relief = setup == "BREAKOUT" and ctx["volume_spike"] and pbest["support_count"] >= 3 and dq >= 55
    if breakout_relief:
        conf += 3.0
    conf = clamp(conf, 0.0, 88.0)

    entry_plan = _v47_entry_plan(ctx, lv, side, setup)
    mode = "TACTICAL"
    if hist["n"] >= V47_LEARN_BLOCK_N and hist["stats"].get("profit_factor") is not None and _v47_num(hist["stats"].get("profit_factor"),0) >= V47_PROMOTION_PF and _v47_num(hist["stats"].get("expectancy_pct"),0) >= V47_PROMOTION_EXP:
        mode = "CORE"
    elif setup == "BREAKOUT":
        mode = "BREAKOUT"
    elif setup == "PULLBACK":
        mode = "PULLBACK"
    elif setup == "MEAN_REVERSION":
        mode = "MEAN_REVERSION"

    # Controlled opportunity policy: 3 pillars + adequate R/R is enough for a tactical paper signal,
    # even before historical learning is mature. This is the key fix for WAIT saturation.
    publish_ok = (
        not hard and
        dq >= V47_MIN_DQ and
        lv is not None and lv["effective_rr1"] >= V47_MIN_RR1 and
        pbest["available_count"] >= V47_MIN_PILLARS and
        pbest["support_count"] >= V47_MIN_PILLARS and
        pbest["score"] >= V47_MIN_DIRECTIONAL_EDGE and
        margin >= V47_MIN_SIDE_MARGIN and
        conf >= V47_MIN_CONFIDENCE and
        "multiple_opposing_pillars" not in soft and
        "learned_negative_block" not in soft
    )
    # Special relief for a confirmed breakout or clean pullback continuation.
    if not publish_ok and not hard and lv is not None:
        special = (
            breakout_relief and pbest["available_count"] >= 3 and pbest["support_count"] >= 3 and
            pbest["score"] >= 0.08 and margin >= 0.04 and conf >= 53.0 and
            lv["effective_rr1"] >= 1.40
        ) or (
            setup == "PULLBACK" and pbest["available_count"] >= 4 and pbest["support_count"] >= 3 and
            pbest["score"] >= 0.08 and margin >= 0.045 and conf >= 53.0 and
            lv["effective_rr1"] >= 1.40
        )
        if special:
            publish_ok = True
            soft = [s for s in soft if s not in {"few_independent_pillars"}]
            mode = "BREAKOUT" if breakout_relief else "PULLBACK"

    decision = side if publish_ok else "WAIT"
    state = "PUBLISHED" if publish_ok else "SHADOW_CANDIDATE" if not hard and pbest["support_count"] >= 2 else "BLOCKED"
    estimated_prob = hist.get("estimated_win_probability")
    x["v47"] = {
        "version": V47_VERSION,
        "decision": decision,
        "candidate": side,
        "state": state,
        "mode": mode,
        "setup": setup,
        "setup_note": setup_note,
        "horizon_primary_min": V47_PRIMARY_HORIZON_MIN,
        "horizon_extended_min": V47_EXTENDED_HORIZON_MIN,
        "confidence": round(conf, 1),
        "estimated_win_probability": estimated_prob,
        "calibration_status": hist.get("status"),
        "historical_samples": hist.get("n", 0),
        "historical_wilson_lower_95": hist.get("wilson_lower_95"),
        "data_quality": round(dq, 1),
        "evidence_coverage": round(pbest["available_count"] / 5.0 * 100.0, 1),
        "score": round(pbest["score"], 4),
        "quality": round(pbest["quality"], 1),
        "margin": round(margin, 4),
        "pillars": pbest["pillars"],
        "support_count": pbest["support_count"],
        "opposition_count": pbest["opposition_count"],
        "hard_blocks": hard,
        "soft_flags": soft,
        "levels": ({k: round(float(lv[k]), 8) for k in ("entry","sl","tp1","tp2","risk_pct","rr1","rr2","effective_rr1","effective_rr2","cost_r")} if lv else {}),
        "entry_plan": {k: round(float(v), 8) if isinstance(v,(int,float)) and math.isfinite(float(v)) else v for k,v in entry_plan.items()},
        "ai_role": "ADVISORY_ONLY — AI cannot create or rescue a direction",
        "no_fake_probability": estimated_prob is None,
        "reasoning": [
            f"setup={setup}",
            f"pillars={pbest['support_count']}/{pbest['available_count']}",
            f"quality={pbest['quality']:.1f}",
            f"confidence={conf:.1f}",
            f"effective_RR1={lv['effective_rr1']:.2f}" if lv else "levels invalid",
            *(soft[:4] if soft else []),
            *(hard[:4] if hard else []),
        ],
    }

    if publish_ok and lv and decision in {"LONG","SHORT"}:
        # Update the public surface used by the existing dashboard.
        x["decision"] = decision
        x["decision_tag"] = decision
        x["bias"] = "صعودی" if decision == "LONG" else "نزولی"
        x["decision_state"] = f"V47_{mode}_{setup}_{decision}"
        x["authority"] = V47_VERSION
        x["signal_tag"] = f"V47 {mode} — {setup} — {decision}"
        x["decision_confidence"] = round(conf, 1)
        x["signal_quality"] = max(_v47_num(x.get("signal_quality"), 0.0), round(pbest["quality"], 1))
        x["entry_now"] = smart_format(lv["entry"])
        x["entry_preferred"] = smart_format(entry_plan.get("preferred"))
        x["entry_zone_low"] = smart_format(entry_plan.get("zone_low"))
        x["entry_zone_high"] = smart_format(entry_plan.get("zone_high"))
        # Existing stop/targets become the validated V47 levels.
        x["entry_valid"] = smart_format(lv["entry"])
        x["entry_raw"] = float(lv["entry"])
        x["stop_loss"] = smart_format(lv["sl"])
        x["tp1"] = smart_format(lv["tp1"])
        x["tp2"] = smart_format(lv["tp2"])
        x["stop_loss_raw"] = float(lv["sl"])
        x["tp1_raw"] = float(lv["tp1"])
        x["tp2_raw"] = float(lv["tp2"])
        x["risk_distance_pct"] = round(lv["risk_pct"], 3)
        x["rr_tp1"] = round(lv["rr1"], 2)
        x["rr_tp2"] = round(lv["rr2"], 2)
        x["effective_rr_tp1"] = round(lv["effective_rr1"], 2)
        x["effective_rr_tp2"] = round(lv["effective_rr2"], 2)
        x["v47_status"] = "ACTIVE"
        x["v47_mode"] = mode
        x["v47_setup"] = setup
        x["v47_risk_multiplier"] = {"CORE":1.0,"BREAKOUT":0.75,"PULLBACK":0.80,"TACTICAL":0.60,"MEAN_REVERSION":0.45}.get(mode,0.60)
    else:
        # Keep the existing WAIT visible but enrich it with a directional candidate.
        x["v47_status"] = "SHADOW" if state == "SHADOW_CANDIDATE" else "BLOCKED"
        x["v47_candidate"] = side
        x["v47_candidate_confidence"] = round(conf, 1)
        x["v47_candidate_quality"] = round(pbest["quality"], 1)
    # Expose reliable top-level fields for UI / downstream learners.
    x["v47_data_quality"] = round(dq, 1)
    x["v47_estimated_win_probability"] = estimated_prob
    x["v47_horizon"] = "24h / 48h"
    return x


def _v47_record_signal(x):
    try:
        v47 = x.get("v47") if isinstance(x.get("v47"), dict) else {}
        side = str(v47.get("candidate") or x.get("decision_tag") or "").upper()
        if side not in {"LONG","SHORT"}: return None
        symbol = _normalize_symbol(x.get("symbol") or "")
        if not symbol: return None
        levels = v47.get("levels") or {}
        entry = _v47_num(levels.get("entry"), _v47_parse_price(x.get("price_raw", x.get("price"))))
        sl = _v47_num(levels.get("sl"), _v47_parse_price(x.get("stop_loss_raw", x.get("stop_loss"))))
        tp1 = _v47_num(levels.get("tp1"), _v47_parse_price(x.get("tp1_raw", x.get("tp1"))))
        tp2 = _v47_num(levels.get("tp2"), _v47_parse_price(x.get("tp2_raw", x.get("tp2"))))
        if entry <= 0 or sl <= 0 or tp1 <= 0 or tp2 <= 0: return None
        regime = str(((_v47_get_context(x).get("regime") or {}).get("regime")) or "unknown")
        published = 1 if str(v47.get("decision") or "WAIT").upper() in {"LONG","SHORT"} else 0
        mode = str(v47.get("mode") or "SHADOW")
        now = time.time()
        with DB_LOCK, db_conn() as con:
            # One active sample per symbol/side for the cooldown; prevents scan frequency from becoming fake sample size.
            recent = con.execute("""SELECT 1 FROM titan_v47_ledger
                WHERE symbol=? AND side=? AND created_at>=? AND
                ((outcome_24h='PENDING') OR (outcome_48h='PENDING')) LIMIT 1""",
                (symbol, side, now - V47_SIGNAL_COOLDOWN_SEC)).fetchone()
            if recent: return None
            today_count = con.execute("SELECT COUNT(*) FROM titan_v47_ledger WHERE symbol=? AND created_at>=?",
                                      (symbol, now - 86400)).fetchone()[0]
            if int(today_count or 0) >= V47_MAX_SHADOW_PER_SYMBOL_DAY: return None
            cur = con.execute("""INSERT INTO titan_v47_ledger(
                created_at,symbol,timeframe,side,published,mode,setup,entry,stop_loss,tp1,tp2,
                risk_pct,rr1,rr2,effective_rr1,confidence,estimated_win_probability,score,quality,
                data_quality,pillar_count,support_count,opposition_count,coverage,regime,
                primary_horizon_min,extended_horizon_min,components_json,reasons_json,entry_mode,
                entry_preferred,expires_at,param_version)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (now,symbol,"1h",side,published,mode,str(v47.get("setup") or "UNKNOWN"),entry,sl,tp1,tp2,
                 _v47_num(levels.get("risk_pct"),0),_v47_num(levels.get("rr1"),0),_v47_num(levels.get("rr2"),0),_v47_num(levels.get("effective_rr1"),0),
                 _v47_num(v47.get("confidence"),0),v47.get("estimated_win_probability"),_v47_num(v47.get("score"),0),_v47_num(v47.get("quality"),0),
                 _v47_num(v47.get("data_quality"),0),int((v47.get("pillars") or []).__len__()),int(v47.get("support_count",0)),
                 int(v47.get("opposition_count",0)),_v47_num(v47.get("evidence_coverage"),0),regime,
                 V47_PRIMARY_HORIZON_MIN,V47_EXTENDED_HORIZON_MIN,
                 json.dumps(v47.get("pillars") or [],ensure_ascii=False,default=str),json.dumps(v47.get("reasoning") or [],ensure_ascii=False),
                 str((v47.get("entry_plan") or {}).get("mode") or "NOW"),_v47_num((v47.get("entry_plan") or {}).get("preferred"),entry),
                 now + V47_ENTRY_TTL_MIN*60,V47_VERSION))
            con.commit()
            return int(cur.lastrowid)
    except Exception as exc:
        LOGGER.debug("V47 record signal failed: %s", exc)
        return None


def _v47_first_touch(window, side, sl, tp):
    return _ft_simple(window, side == "LONG", sl, tp, guard_positive=False)


def _v47_eval_one(row, horizon, outcome_col, exit_col, gross_col, net_col, r_col, mae_col, mfe_col, tte_col, eval_col, target):
    created = _v47_num(row.get("created_at"),0)
    end = created + horizon*60.0
    sym = str(row.get("symbol") or "")
    side = str(row.get("side") or "")
    entry = _v47_num(row.get("entry"),0); sl = _v47_num(row.get("stop_loss"),0); tp = _v47_num(target,0)
    if not (created and entry>0 and sl>0 and tp>0 and side in {"LONG","SHORT"}): return False
    try:
        bars = min(400, max(20, int(math.ceil(horizon/15.0))+6))
        df = fetch_klines(sym,"15m",bars,start_ms=int(created*1000),end_ms=int(end*1000))
        if df is None or df.empty: return False
        w = df[(df["t"].astype(float)>=created*1000)&(df["t"].astype(float)<end*1000)].sort_values("t")
        if w.empty: return False
        outcome, exit_px, event_ts = _v47_first_touch(w,side,sl,tp)
        last = _v47_num(w["close"].iloc[-1],entry)
        if exit_px is None: exit_px = last
        gross = ((exit_px-entry)/entry*100.0) if side=="LONG" else ((entry-exit_px)/entry*100.0 if exit_px>0 else 0.0)
        net = gross - V47_FRICTION_PCT
        risk_pct = abs(entry-sl)/max(entry,1e-12)*100.0
        rmult = net/max(risk_pct,1e-12)
        hi = w["high"].astype(float); lo = w["low"].astype(float)
        if side=="LONG":
            mae = (float(lo.min())/entry-1.0)*100.0; mfe=(float(hi.max())/entry-1.0)*100.0
        else:
            mae = (entry/float(hi.max())-1.0)*100.0; mfe=(entry/float(lo.min())-1.0)*100.0
        tte = ((event_ts-created)/60.0) if event_ts else None
        now=time.time()
        with DB_LOCK, db_conn() as con:
            con.execute(f"""UPDATE titan_v47_ledger SET {outcome_col}=?,{exit_col}=?,{gross_col}=?,{net_col}=?,
                {r_col}=?,{mae_col}=?,{mfe_col}=?,{tte_col}=?,{eval_col}=? WHERE id=?""",
                (outcome,exit_px,gross,net,rmult,mae,mfe,tte,now,int(row["id"])))
            con.commit()
        return True
    except Exception as exc:
        LOGGER.debug("V47 evaluate %s #%s failed: %s", horizon,row.get("id"),exc)
        return False


def _v47_evaluate_pending(limit=80):
    now=time.time(); done=0
    # 24h evaluation
    rows=_v47_query_rows(limit=max(10,int(limit)))
    for r in rows:
        age=now-_v47_num(r.get("created_at"),now)
        if r.get("outcome_24h")=="PENDING" and age >= V47_PRIMARY_HORIZON_MIN*60.0:
            if _v47_eval_one(r,V47_PRIMARY_HORIZON_MIN,"outcome_24h","exit_24h","return_gross_24h","return_net_24h","r_multiple_24h","mae_24h","mfe_24h","tte_24h","evaluated_24h_at",r.get("tp1")):
                done+=1
    # 48h evaluation from the same entry, independent TP2 path.
    rows2=_v47_query_rows(limit=max(10,int(limit)))
    for r in rows2:
        age=now-_v47_num(r.get("created_at"),now)
        if r.get("outcome_48h")=="PENDING" and age >= V47_EXTENDED_HORIZON_MIN*60.0:
            if _v47_eval_one(r,V47_EXTENDED_HORIZON_MIN,"outcome_48h","exit_48h","return_gross_48h","return_net_48h","r_multiple_48h","mae_48h","mfe_48h","tte_48h","evaluated_48h_at",r.get("tp2")):
                done+=1
    return done


def _v47_audit():
    all_rows=_v47_query_rows(limit=50000)
    all24=all_rows
    all48=all_rows
    pub24=[r for r in all_rows if int(r.get("published") or 0)==1 and r.get("outcome_24h") != "PENDING"]
    pub48=[r for r in all_rows if int(r.get("published") or 0)==1 and r.get("outcome_48h") != "PENDING"]
    groups={}
    for r in all24:
        key=str(r.get("setup") or "UNKNOWN")
        groups.setdefault(key,[]).append(r)
    return {
        "version":V47_VERSION,
        "scope":"24h / 48h V47 ledger; causal live-signal outcomes; no claim about unseen history",
        "primary_24h":_v47_stats_from_rows(all24,"outcome_24h"),
        "extended_48h":_v47_stats_from_rows(all48,"outcome_48h"),
        "published_24h":_v47_stats_from_rows(pub24,"outcome_24h"),
        "published_48h":_v47_stats_from_rows(pub48,"outcome_48h"),
        "by_setup_24h":{k:_v47_stats_from_rows(v,"outcome_24h") for k,v in groups.items()},
        "pending_24h":sum(1 for r in all24 if r.get("outcome_24h")=="PENDING"),
        "pending_48h":sum(1 for r in all48 if r.get("outcome_48h")=="PENDING"),
        "rules":{
            "primary_horizon_hours":24,"extended_horizon_hours":48,
            "min_pillars":V47_MIN_PILLARS,"min_rr1":V47_MIN_RR1,
            "same_bar":"AMBIGUOUS","ai_can_create_direction":False,
            "probability_requires_samples":V47_LEARN_MIN_N,
            "shadow_learning":True,"friction_aware":True,"analysis_only":True,
        },
    }


@app.get("/api/v47/status")
def api_v47_status():
    try:
        a=_v47_audit()
        return jsonify({"ok":True,**a})
    except Exception as exc:
        return jsonify({"ok":False,"error":str(exc)[:240]}),500


@app.get("/api/v47/metrics")
def api_v47_metrics():
    try:
        symbol=_normalize_symbol(request.args.get("symbol") or "")
        side=str(request.args.get("side") or "").upper()
        regime=str(request.args.get("regime") or "")
        horizon=str(request.args.get("horizon") or "24h")
        col="outcome_24h" if horizon!="48h" else "outcome_48h"
        rows=_v47_query_rows(symbol, side, regime, col, 20000)
        return jsonify({"ok":True,"version":V47_VERSION,"horizon":horizon,"stats":_v47_stats_from_rows(rows,col)})
    except Exception as exc:
        return jsonify({"ok":False,"error":str(exc)[:240]}),500


@app.get("/api/v47/ledger")
def api_v47_ledger():
    try:
        rows=_v47_query_rows(limit=300)
        return jsonify({"ok":True,"version":V47_VERSION,"rows":rows})
    except Exception as exc:
        return jsonify({"ok":False,"error":str(exc)[:240]}),500


# Fix two older honesty issues globally: V46 ambiguity must not become a hidden win/loss,
# and V46 audit should expose actual timeframe instead of treating every sample as 15m.
def _v46_stats(rows):
    try:
        valid=[]; ambiguous=0
        for r in rows or []:
            out=str(r.get("outcome") or "")
            if out=="AMBIGUOUS":
                ambiguous+=1; continue
            ret=_v47_num(r.get("return_net_pct"),float("nan"))
            if math.isfinite(ret): valid.append((out,ret))
        wins=sum(1 for out,ret in valid if out=="WIN" or (out=="TIME_EXIT" and ret>0))
        losses=sum(1 for out,ret in valid if out=="LOSS" or (out=="TIME_EXIT" and ret<0))
        rets=np.asarray([ret for _,ret in valid],dtype=float)
        pos=rets[rets>0]; neg=rets[rets<0]
        pf=(float(pos.sum()/abs(neg.sum())) if neg.size else (math.inf if pos.size else None))
        exp=float(rets.mean()) if rets.size else 0.0
        eq=np.cumprod(1+np.clip(rets/100.0,-0.999,10.0)) if rets.size else np.asarray([])
        maxdd=0.0
        if eq.size:
            pk=np.maximum.accumulate(eq); maxdd=float(np.max((pk-eq)/np.maximum(pk,1e-12))*100.0)
        return {
            "trades":len(valid),"wins":wins,"losses":losses,"ambiguous":ambiguous,
            "win_rate":round(wins/max(wins+losses,1)*100,2) if wins+losses else None,
            "win_rate_lower_95":round(_v47_wilson(wins,wins+losses),2) if wins+losses else None,
            "profit_factor":round(pf,3) if pf is not None and math.isfinite(pf) else pf,
            "expectancy_pct":round(exp,5),"max_drawdown_pct":round(maxdd,4),
            "avg_win_pct":round(float(pos.mean()),4) if pos.size else 0.0,
            "avg_loss_pct":round(float(neg.mean()),4) if neg.size else 0.0,
            "bayesian":_v47_bayes(wins,losses),
        }
    except Exception:
        _swallow()
        return {"trades":0,"wins":0,"losses":0,"ambiguous":0,"win_rate":None,"profit_factor":None,"expectancy_pct":0.0,"max_drawdown_pct":0.0}



def _v47_self_test():
    failures=[]
    def chk(name,cond,detail=""):
        if cond: print("  ✓",name)
        else:
            print("  ✗",name,"—",detail); failures.append(name)
    print("="*64); print("TITAN V47 SELF-TEST"); print("="*64)
    chk("horizon_24h", V47_PRIMARY_HORIZON_MIN == 1440)
    chk("horizon_48h", V47_EXTENDED_HORIZON_MIN == 2880)
    chk("wilson_none", _v47_wilson(0,0) is None)
    chk("no_fake_probability_n0", _v47_historical_adjustment("NOPE/USDT","LONG","unknown").get("estimated_win_probability") is None)
    lv=_v45_rr_levels(100.0,2.0,"LONG",rr1=V47_TARGET_RR1,rr2=V47_TARGET_RR2)
    chk("levels_rr", bool(lv) and lv["rr1"] >= V47_TARGET_RR1-1e-9 and lv["rr2"] >= V47_TARGET_RR2-1e-9, str(lv))
    amb=[{"outcome_24h":"AMBIGUOUS","return_net_24h":2.0},{"outcome_24h":"WIN","return_net_24h":1.0},{"outcome_24h":"LOSS","return_net_24h":-1.0}]
    st=_v47_stats_from_rows(amb,"outcome_24h")
    chk("ambiguous_excluded", st["trades"]==2 and st["wins"]==1 and st["losses"]==1, str(st))
    # Direction selection must respect an explicitly supplied upstream side.
    base={"symbol":"TEST/USDT","price_raw":100.0,"live_price_age_sec":1.0,"volatility_pct":1.5,"rsi_value":58,
          "macd_cross":"bull","macd_hist":0.2,"volume_spike":True,"volume_delta":{"delta_pct":12},"taker_buy_pct":56,
          "long_short_ratio":0.7,"btc_trend":"صعودی","score":62,"alignment":65,"signal_quality":70,"decision_confidence":67,
          "tf_scores":{"15m":58,"1h":63,"4h":64,"1d":60},"data_quality":{"score":85},
          "edge":{"structure":{"bias":"صعودی","event":"BOS_UP","confirmation_score":80,"swing_low":96},
                  "regime":{"regime":"trend_up","confidence":80},"liquidity":{"pressure":0.15},
                  "technical":{"bollinger":{"middle":"98"}}},
          "stop_loss_raw":96.0,"tp1_raw":106.0,"tp2_raw":111.2,"decision_tag":"LONG"}
    got=_v47_apply_policy(base)
    chk("explicit_side_respected", got.get("v47",{}).get("candidate") == "LONG")
    print("V47 SELF-TEST:", "PASS" if not failures else f"FAIL {failures}")
    return 0 if not failures else 1

# Final V47 wrapper: V45/V46 remain the mature evidence spine; V47 is the last
# opportunity layer and 24/48h learner.
_V47_PREV_ANALYZE = _analyze_asset_v46

def _analyze_asset_v47(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:
    try:
        base=_V47_PREV_ANALYZE(symbol,btc_trend)
        if not base: return base
        out=_v47_apply_policy(base)
        try: _v47_record_signal(out)
        except Exception: _swallow()
        return out
    except Exception as exc:
        LOGGER.exception("V47 analyze wrapper failed for %s: %s",symbol,exc)
        return None


_V47_PREV_UPDATE = _update_cache_v46

def _update_cache_v47(force: bool=False):
    try: _v47_evaluate_pending(limit=120)
    except Exception: _swallow()
    data,summary,macro=_V47_PREV_UPDATE(force)
    try:
        data=_normalise_dashboard(data) if "_normalise_dashboard" in globals() else data
        # Ensure V47 status remains available at top level after dashboard normalization.
        for item in data or []:
            if not isinstance(item,dict): continue
            if "v47" in item and isinstance(item["v47"],dict):
                item["v47_status"] = item.get("v47_status") or item["v47"].get("state","UNKNOWN")
    except Exception: _swallow()
    return data,summary,macro


# Last runtime entry-point definition: keeps existing startup lifecycle but prints V47 status.
