# [TITAN V77 layer] governors/v48_short_swing_router - V48 short-swing router
# Original V76 source lines 19054-19547 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# TITAN V48 — SHORT-SWING OPPORTUNITY ROUTER / 6H-24H-48H
# ============================================================
# V48 does NOT promise profitability and does NOT bypass hard safety.
# It is an opportunity layer designed to reduce WAIT saturation for
# high-quality 1–2 day setups while keeping strict invalid-data/risk vetoes.
# Learning uses V48's own realized ledger; V47 remains the upstream evidence spine.
V48_VERSION = "TITAN-V48-SHORT-SWING-OPPORTUNITY-6H24H48H"
V48_FAST_HORIZON_MIN = 360       # entry-quality telemetry only
V48_PRIMARY_HORIZON_MIN = 1440   # 24h decision horizon
V48_EXTENDED_HORIZON_MIN = 2880  # 48h decision horizon
V48_SIGNAL_COOLDOWN_SEC = 75 * 60
V48_MAX_SIGNALS_PER_SYMBOL_DAY = 10
V48_STALE_PRICE_SEC = 25.0
V48_HARD_DQ = 48.0
V48_SOFT_DQ = 55.0
V48_MIN_AVAILABLE = 3
V48_HARD_EXTREME_VOL_PCT = 12.0
V48_MAX_STOP_PCT = 6.5
V48_MIN_EFFECTIVE_RR = 1.28
V48_TACTICAL_EDGE = 0.070
V48_TACTICAL_MARGIN = 0.022
V48_TACTICAL_CONF = 51.5
V48_STANDARD_EDGE = 0.090
V48_STANDARD_MARGIN = 0.030
V48_STANDARD_CONF = 55.0
V48_CORE_EDGE = 0.120
V48_CORE_MARGIN = 0.050
V48_CORE_CONF = 63.0
V48_RANGE_EDGE = 0.075
V48_RANGE_MARGIN = 0.025
V48_RANGE_CONF = 53.0
V48_MIN_RR = 1.30
V48_TARGET_RR1 = 1.55
V48_TARGET_RR2 = 2.65
V48_BREAKOUT_RR1 = 1.40
V48_PULLBACK_RR1 = 1.55
V48_TACTICAL_RISK_MULT = 0.45
V48_STANDARD_RISK_MULT = 0.70
V48_CORE_RISK_MULT = 1.00
V48_BREAKOUT_RISK_MULT = 0.60
V48_PULLBACK_RISK_MULT = 0.75
V48_RANGE_RISK_MULT = 0.40
V48_FRICTION_PCT = safe_float(globals().get("V45_FRICTION_PCT"), TOTAL_ENTRY_BUFFER * 2.0 * 100.0)
V48_MIN_LEARN_N = 18
V48_STRONG_LEARN_N = 30
V48_BLOCK_PF = 0.82
_v48_num = _v47_num
V48_BLOCK_EXP_R = -0.05
V48_PROMOTE_PF = 1.12
V48_PROMOTE_EXP_R = 0.025
V48_PROMOTE_LCB = 47.0


def _v48_dynamic_thresholds(ctx, setup):
    rg = str((ctx.get("regime") or {}).get("regime") or "unknown").lower()
    if setup == "BREAKOUT":
        e,m,c = 0.070, 0.025, 52.5
    elif setup == "PULLBACK":
        e,m,c = 0.075, 0.025, 52.0
    elif setup == "MEAN_REVERSION":
        e,m,c = V48_RANGE_EDGE, V48_RANGE_MARGIN, V48_RANGE_CONF
    else:
        e,m,c = V48_STANDARD_EDGE, V48_STANDARD_MARGIN, V48_STANDARD_CONF
    if rg in {"trend_up","trend_down"}:
        e -= 0.006; m -= 0.003; c -= 1.0
    elif rg in {"breakout_watch"}:
        e -= 0.008; c -= 1.5
    elif rg in {"range","sideways","mean_reversion"}:
        e = min(e, 0.080); c = max(c, 53.0)
    elif "transition" in rg or "high_vol" in rg:
        e += 0.012; m += 0.006; c += 2.0
    return {"edge":max(0.055,e),"margin":max(0.018,m),"confidence":max(50.0,c)}


def _v48_context_strength(ctx, side, setup, p):
    tf = ctx["tf"]
    score = 0.0; bits=[]
    if side == "LONG":
        if tf["4h"] >= 54: score += 0.25; bits.append("4h↑")
        elif tf["4h"] <= 45: score -= 0.35; bits.append("4h↓")
        if tf["1h"] >= 54: score += 0.22; bits.append("1h↑")
        elif tf["1h"] <= 45: score -= 0.30; bits.append("1h↓")
        if tf["15m"] >= 53: score += 0.12; bits.append("15m↑")
        elif tf["15m"] <= 43: score -= 0.10; bits.append("15m↓")
    else:
        if tf["4h"] <= 46: score += 0.25; bits.append("4h↓")
        elif tf["4h"] >= 55: score -= 0.35; bits.append("4h↑")
        if tf["1h"] <= 46: score += 0.22; bits.append("1h↓")
        elif tf["1h"] >= 55: score -= 0.30; bits.append("1h↑")
        if tf["15m"] <= 47: score += 0.12; bits.append("15m↓")
        elif tf["15m"] >= 57: score -= 0.10; bits.append("15m↑")
    rg=str((ctx.get("regime") or {}).get("regime") or "unknown").lower()
    if setup in {"BREAKOUT","PULLBACK"} and rg in {"trend_up","trend_down","breakout_watch"}:
        score += 0.10
    if setup == "MEAN_REVERSION" and rg in {"range","sideways","mean_reversion"}:
        score += 0.18
    return float(clamp(score,-1,1)), ";".join(bits)


def _v48_setup(ctx, side, p):
    s=ctx["structure"]; rg=str((ctx.get("regime") or {}).get("regime") or "unknown").lower()
    event=str(s.get("event") or "")
    rsi=ctx["rsi"]
    tf=ctx["tf"]
    if ((side=="LONG" and event=="BOS_UP") or (side=="SHORT" and event=="BOS_DOWN")) and ctx["volume_spike"]:
        return "BREAKOUT"
    trend_ok=(side=="LONG" and tf["4h"]>=54 and tf["1h"]>=52) or (side=="SHORT" and tf["4h"]<=46 and tf["1h"]<=48)
    pull=(trend_ok and ((side=="LONG" and 35<=rsi<=55) or (side=="SHORT" and 45<=rsi<=65)))
    if pull and p["score"]>=0.06: return "PULLBACK"
    if rg in {"range","sideways","mean_reversion"} and ((side=="LONG" and rsi<=32) or (side=="SHORT" and rsi>=68)):
        return "MEAN_REVERSION"
    return "TREND_CONTINUATION"


def _v48_historical_edge(symbol, side, regime):
    # Combine 24h and 48h outcomes without inventing a probability when samples are absent.
    s24=_v47_recent_stats(symbol,side,regime,"24h")
    s48=_v47_recent_stats(symbol,side,regime,"48h")
    n24=int(s24.get("trades") or 0); n48=int(s48.get("trades") or 0)
    # If regime sample is sparse, fallback to symbol/side. This is still observational, not predictive.
    if n24 < 8:
        s24b=_v47_recent_stats(symbol,side,"","24h")
        if int(s24b.get("trades") or 0)>n24: s24=s24b; n24=int(s24.get("trades") or 0)
    if n48 < 8:
        s48b=_v47_recent_stats(symbol,side,"","48h")
        if int(s48b.get("trades") or 0)>n48: s48=s48b; n48=int(s48.get("trades") or 0)
    samples=n24+n48
    if samples < V48_MIN_LEARN_N:
        return {"samples":samples,"status":"INSUFFICIENT","penalty":0.0,"probability":None,"pf":None,"exp_r":None,"lcb":None}
    # More recent primary horizon is weighted slightly more heavily.
    stats=[]
    if n24: stats.append((0.65,s24))
    if n48: stats.append((0.35,s48))
    wsum=sum(w for w,_ in stats) or 1.0
    exp=sum(w*_v48_num(st.get("expectancy_pct"),0.0) for w,st in stats)/wsum
    pfs=[(_v48_num(st.get("profit_factor"),0.0),w) for w,st in stats if st.get("profit_factor") is not None and math.isfinite(_v48_num(st.get("profit_factor"),0.0))]
    pf=(sum(p*w for p,w in pfs)/sum(w for _,w in pfs)) if pfs else None
    lcbs=[(_v48_num(st.get("win_rate_lower_95"),0.0),w) for w,st in stats if st.get("win_rate_lower_95") is not None]
    lcb=(sum(v*w for v,w in lcbs)/sum(w for _,w in lcbs)) if lcbs else None
    wrs=[(_v48_num(st.get("win_rate"),0.0),w) for w,st in stats if st.get("win_rate") is not None]
    wr=(sum(v*w for v,w in wrs)/sum(w for _,w in wrs)) if wrs else None
    penalty=0.0
    if samples>=V48_STRONG_LEARN_N and ((pf is not None and pf < V48_BLOCK_PF) or exp < V48_BLOCK_EXP_R): penalty=7.0
    elif exp < 0: penalty=2.5
    if samples>=V48_STRONG_LEARN_N and pf is not None and exp>0 and pf>=V48_PROMOTE_PF and (lcb or 0)>=V48_PROMOTE_LCB:
        penalty=-1.5
    return {"samples":samples,"status":"RELIABLE","penalty":penalty,"probability":round(wr,1) if wr is not None else None,
            "pf":round(pf,3) if pf is not None else None,"exp_r":round(exp,4),"lcb":round(lcb,1) if lcb is not None else None,
            "stats24":s24,"stats48":s48}


def _v48_build_levels(x, side, ctx, setup):
    lv=_v47_price_level_plan(x,side,ctx)
    if not lv: return None
    target_min=V48_BREAKOUT_RR1 if setup=="BREAKOUT" else V48_PULLBACK_RR1 if setup=="PULLBACK" else V48_TARGET_RR1
    if lv["effective_rr1"] < target_min:
        anchor=_v48_num(ctx["structure"].get("swing_low" if side=="LONG" else "swing_high"),0.0)
        alt=_v45_rr_levels(ctx["price"],lv["atr"],side,anchor if anchor>0 else None,rr1=target_min,rr2=V48_TARGET_RR2)
        if alt:
            sl,tp1,tp2=float(alt["sl"]),float(alt["tp1"]),float(alt["tp2"])
            risk=abs(ctx["price"]-sl); rp=risk/max(ctx["price"],1e-12)*100
            cr=V48_FRICTION_PCT/max(rp,1e-9)
            lv={"entry":ctx["price"],"sl":sl,"tp1":tp1,"tp2":tp2,"risk":risk,"risk_pct":rp,
                "rr1":abs(tp1-ctx["price"])/max(risk,1e-12),"rr2":abs(tp2-ctx["price"])/max(risk,1e-12),
                "cost_r":cr,"effective_rr1":abs(tp1-ctx["price"])/max(risk,1e-12)-cr,
                "effective_rr2":abs(tp2-ctx["price"])/max(risk,1e-12)-cr,"atr":lv.get("atr",0)}
    if lv["risk_pct"]>V48_MAX_STOP_PCT or lv["effective_rr1"]<V48_MIN_EFFECTIVE_RR: return None
    return lv


def _v48_apply_opportunity(x):
    x=dict(x or {})
    ctx=_v47_get_context(x)
    candidates={s:_v47_build_pillars(x,s) for s in ("LONG","SHORT")}
    upstream=str((x.get("v47") or {}).get("candidate") or x.get("decision_tag") or "").upper()
    if upstream not in {"LONG","SHORT"}: upstream=""
    best=max(("LONG","SHORT"),key=lambda s:candidates[s]["score"])
    side=upstream or best
    pbest=candidates[side]; other="SHORT" if side=="LONG" else "LONG"; pother=candidates[other]
    margin=pbest["score"]-pother["score"]
    setup=_v48_setup(ctx,side,pbest)
    thr=_v48_dynamic_thresholds(ctx,setup)
    hard=[]; notes=[]
    dq=_v48_num(ctx["dq"].get("score"),0.0)
    age=_v48_num(x.get("live_price_age_sec"),0.0)
    if ctx["price"]<=0: hard.append("invalid_price")
    if age>V48_STALE_PRICE_SEC: hard.append("stale_price")
    if dq<V48_HARD_DQ: hard.append("data_quality_hard")
    if ctx["vol_pct"]>=V48_HARD_EXTREME_VOL_PCT: hard.append("extreme_volatility")
    v45=x.get("v45") if isinstance(x.get("v45"),dict) else {}
    if str(v45.get("state") or "").upper() in {"HARD_BLOCK","BLOCKED_HARD","LEARNED_NEGATIVE_EV","DEMOTED_NEG"}: hard.append("upstream_v45_hard")
    lv=_v48_build_levels(x,side,ctx,setup)
    if not lv: hard.append("invalid_or_poor_levels")
    # Hard structural conflict only when both 1h and 4h decisively reject the side.
    if side=="LONG" and ctx["tf"]["4h"]<=43 and ctx["tf"]["1h"]<=45: hard.append("htf_double_conflict")
    if side=="SHORT" and ctx["tf"]["4h"]>=57 and ctx["tf"]["1h"]>=55: hard.append("htf_double_conflict")
    # Tactical timing: allow pullback counter-move, but reject a strong opposite 15m trigger.
    if side=="LONG" and setup in {"BREAKOUT","TREND_CONTINUATION"} and ctx["tf"]["15m"]<41: notes.append("15m_timing_weak")
    if side=="SHORT" and setup in {"BREAKOUT","TREND_CONTINUATION"} and ctx["tf"]["15m"]>59: notes.append("15m_timing_weak")
    context_strength, context_note=_v48_context_strength(ctx,side,setup,pbest)
    score_boost=max(-0.06,min(0.08,context_strength*0.08))
    effective_edge=pbest["score"]+score_boost
    signal_quality=ctx["signal_quality"]
    alignment=ctx["alignment"]
    dq_pen=max(0.0, V48_SOFT_DQ-dq)*0.15
    conf=0.46*pbest["quality"]+0.20*signal_quality+0.16*alignment+0.12*dq+0.06*(50+min(25,abs(effective_edge)*60))
    conf-=dq_pen
    if notes: conf-=2.0
    hist=_v48_historical_edge(_normalize_symbol(str(x.get("symbol") or "")),side,str((ctx.get("regime") or {}).get("regime") or "unknown"))
    conf-=hist["penalty"]
    if setup=="BREAKOUT" and ctx["volume_spike"]: conf+=3.0
    if setup=="PULLBACK" and context_strength>0.20: conf+=2.0
    conf=clamp(conf,48,90)
    # Published decision policy: prioritize fresh edge; history modulates, it does not create direction.
    enough=(pbest["available_count"]>=V48_MIN_AVAILABLE and margin>=thr["margin"] and effective_edge>=thr["edge"] and conf>=thr["confidence"])
    # Setup-specific qualification; this creates more opportunities without opening obvious garbage.
    if setup=="BREAKOUT":
        setup_ok=(ctx["volume_spike"] and ("BOS_UP" if side=="LONG" else "BOS_DOWN") in str(ctx["structure"].get("event") or ""))
    elif setup=="PULLBACK":
        setup_ok=context_strength>=0.03 and ((side=="LONG" and ctx["tf"]["4h"]>=52) or (side=="SHORT" and ctx["tf"]["4h"]<=48))
    elif setup=="MEAN_REVERSION":
        rg=str((ctx.get("regime") or {}).get("regime") or "unknown").lower()
        setup_ok=rg in {"range","sideways","mean_reversion"} and ((side=="LONG" and ctx["rsi"]<=33) or (side=="SHORT" and ctx["rsi"]>=67))
    else:
        setup_ok=context_strength>=-0.02
    # Controlled tactical relief when upstream V47 is a valid directional shadow.
    v47=x.get("v47") if isinstance(x.get("v47"),dict) else {}
    v47_state=str(v47.get("state") or "").upper()
    tactical_relief=(
        not hard and lv is not None and setup_ok and pbest["available_count"]>=3 and
        effective_edge>=V48_TACTICAL_EDGE and margin>=V48_TACTICAL_MARGIN and conf>=V48_TACTICAL_CONF and
        hist["penalty"]<7.0 and "15m_timing_weak" not in notes
    )
    # Strong V47 publication remains eligible for promotion to V48 CORE/STANDARD.
    publish_ok=(not hard and setup_ok and enough and hist["penalty"]<7.0)
    if not publish_ok and tactical_relief:
        publish_ok=True
        mode="TACTICAL"
    elif publish_ok:
        if hist["samples"]>=V48_STRONG_LEARN_N and hist["penalty"]<0 and effective_edge>=V48_CORE_EDGE and margin>=V48_CORE_MARGIN and conf>=V48_CORE_CONF:
            mode="CORE"
        elif setup=="BREAKOUT": mode="BREAKOUT"
        elif setup=="PULLBACK": mode="PULLBACK"
        elif setup=="MEAN_REVERSION": mode="MEAN_REVERSION"
        else: mode="STANDARD"
    else:
        mode="WATCH"
    # Do not resurrect a hard-blocked upstream side. V48 may only promote V45/V47 soft waits.
    decision=side if publish_ok else "WAIT"
    risk_mult=(V48_CORE_RISK_MULT if mode=="CORE" else V48_BREAKOUT_RISK_MULT if mode=="BREAKOUT" else V48_PULLBACK_RISK_MULT if mode=="PULLBACK" else V48_RANGE_RISK_MULT if mode=="MEAN_REVERSION" else V48_TACTICAL_RISK_MULT)
    entry_plan=_v47_entry_plan(ctx,lv,side,setup) if lv else {}
    v48={
        "version":V48_VERSION,"decision":decision,"candidate":side,"mode":mode,"setup":setup,
        "confidence":round(conf,1),"score":round(effective_edge,4),"raw_score":round(pbest["score"],4),
        "margin":round(margin,4),"quality":round(pbest["quality"],1),"data_quality":round(dq,1),
        "evidence_coverage":round(pbest["available_count"]/5*100,1),"support_count":pbest["support_count"],
        "opposition_count":pbest["opposition_count"],"hard_blocks":hard,"notes":notes,
        "context_strength":round(context_strength,4),"context_note":context_note,
        "history":hist,"thresholds":thr,"risk_multiplier":risk_mult,
        "entry_plan":entry_plan,"levels":({k:round(float(lv[k]),8) for k in ("entry","sl","tp1","tp2","risk_pct","rr1","rr2","effective_rr1","effective_rr2","cost_r")} if lv else {}),
        "horizon":{"fast_hours":6,"primary_hours":24,"extended_hours":48},
        "explanation":[f"setup={setup}",f"edge={effective_edge:.3f}",f"margin={margin:.3f}",f"confidence={conf:.1f}",f"pillars={pbest['support_count']}/{pbest['available_count']}",f"context={context_note or 'neutral'}"],
        "analysis_only":True,
    }
    x["v48"]=v48; x["v48_status"]="ACTIVE" if decision in {"LONG","SHORT"} else "WATCH"
    x["v48_candidate"]=side; x["v48_setup"]=setup; x["v48_mode"]=mode
    x["v48_confidence"]=round(conf,1); x["v48_risk_multiplier"]=risk_mult
    x["v48_horizon"]="6h telemetry / 24h primary / 48h extended"
    if decision in {"LONG","SHORT"} and lv:
        x["decision"]=decision; x["decision_tag"]=decision; x["bias"]="صعودی" if decision=="LONG" else "نزولی"
        x["decision_state"]=f"V48_{mode}_{setup}_{decision}"; x["authority"]=V48_VERSION
        x["signal_tag"]=f"V48 {mode} — {setup} — {decision}"
        x["decision_confidence"]=round(conf,1); x["signal_quality"]=max(_v48_num(x.get("signal_quality"),0),round(pbest["quality"],1))
        x["entry_now"]=smart_format(lv["entry"]); x["entry_valid"]=smart_format(lv["entry"]); x["entry_raw"]=float(lv["entry"])
        x["entry_preferred"]=smart_format(entry_plan.get("preferred")); x["entry_zone_low"]=smart_format(entry_plan.get("zone_low")); x["entry_zone_high"]=smart_format(entry_plan.get("zone_high"))
        x["stop_loss"]=smart_format(lv["sl"]); x["tp1"]=smart_format(lv["tp1"]); x["tp2"]=smart_format(lv["tp2"])
        x["stop_loss_raw"]=float(lv["sl"]); x["tp1_raw"]=float(lv["tp1"]); x["tp2_raw"]=float(lv["tp2"])
        x["risk_distance_pct"]=round(lv["risk_pct"],3); x["rr_tp1"]=round(lv["rr1"],2); x["rr_tp2"]=round(lv["rr2"],2)
        x["effective_rr_tp1"]=round(lv["effective_rr1"],2); x["effective_rr_tp2"]=round(lv["effective_rr2"],2)
    return x


def _v48_init_schema():
    try:
        with DB_LOCK, db_conn() as con:
            con.execute("""CREATE TABLE IF NOT EXISTS titan_v48_ledger(
                id INTEGER PRIMARY KEY AUTOINCREMENT,created_at REAL NOT NULL,symbol TEXT NOT NULL,timeframe TEXT NOT NULL DEFAULT '1h',
                side TEXT NOT NULL,published INTEGER NOT NULL DEFAULT 0,mode TEXT NOT NULL DEFAULT 'WATCH',setup TEXT NOT NULL DEFAULT 'UNKNOWN',
                entry REAL NOT NULL,stop_loss REAL NOT NULL,tp1 REAL NOT NULL,tp2 REAL NOT NULL,risk_pct REAL DEFAULT 0,rr1 REAL DEFAULT 0,rr2 REAL DEFAULT 0,
                effective_rr1 REAL DEFAULT 0,effective_rr2 REAL DEFAULT 0,confidence REAL DEFAULT 0,score REAL DEFAULT 0,quality REAL DEFAULT 0,data_quality REAL DEFAULT 0,
                margin REAL DEFAULT 0,context_strength REAL DEFAULT 0,estimated_win_probability REAL,history_samples INTEGER DEFAULT 0,regime TEXT DEFAULT 'unknown',
                outcome_6h TEXT DEFAULT 'PENDING',outcome_24h TEXT DEFAULT 'PENDING',outcome_48h TEXT DEFAULT 'PENDING',
                exit_6h REAL,exit_24h REAL,exit_48h REAL,return_net_6h REAL,return_net_24h REAL,return_net_48h REAL,r_multiple_6h REAL,r_multiple_24h REAL,r_multiple_48h REAL,
                mae_6h REAL,mfe_6h REAL,mae_24h REAL,mfe_24h REAL,mae_48h REAL,mfe_48h REAL,tte_6h REAL,tte_24h REAL,tte_48h REAL,
                components_json TEXT DEFAULT '[]',reasons_json TEXT DEFAULT '[]',entry_mode TEXT DEFAULT 'NOW',entry_preferred REAL,expires_at REAL,evaluated_6h_at REAL,evaluated_24h_at REAL,evaluated_48h_at REAL,
                param_version TEXT NOT NULL)""")
            con.execute("CREATE INDEX IF NOT EXISTS idx_v48_pending ON titan_v48_ledger(outcome_6h,outcome_24h,outcome_48h,created_at)")
            con.execute("CREATE INDEX IF NOT EXISTS idx_v48_symbol ON titan_v48_ledger(symbol,side,created_at)")
            con.commit()
    except Exception as exc: LOGGER.debug("V48 schema init: %s",exc)

_v48_init_schema()


def _v48_query(limit=5000,symbol="",side="",regime=""):
    try:
        wh=[];pa=[]
        if symbol: wh.append("symbol=?");pa.append(symbol)
        if side in {"LONG","SHORT"}: wh.append("side=?");pa.append(side)
        if regime: wh.append("regime=?");pa.append(regime)
        sql="SELECT * FROM (SELECT * FROM titan_v48_ledger"+(" WHERE "+" AND ".join(wh) if wh else "")+" ORDER BY created_at DESC LIMIT ?) ORDER BY created_at ASC"; pa.append(max(1,min(int(limit),50000)))
        with DB_LOCK, db_conn() as con: return [dict(r) for r in con.execute(sql,tuple(pa)).fetchall()]
    except Exception as exc: LOGGER.debug("V48 query failed: %s",exc); return []


def _v48_record(x):
    try:
        v=x.get("v48") if isinstance(x.get("v48"),dict) else {}
        side=str(v.get("candidate") or "").upper(); symbol=_normalize_symbol(str(x.get("symbol") or ""))
        lv=v.get("levels") or {}
        if side not in {"LONG","SHORT"} or not symbol or not lv: return None
        now=time.time()
        with DB_LOCK, db_conn() as con:
            q=con.execute("SELECT 1 FROM titan_v48_ledger WHERE symbol=? AND side=? AND created_at>? AND outcome_24h='PENDING' LIMIT 1",(symbol,side,now-V48_SIGNAL_COOLDOWN_SEC)).fetchone()
            if q: return None
            nday=con.execute("SELECT COUNT(*) FROM titan_v48_ledger WHERE symbol=? AND created_at>?",(symbol,now-86400)).fetchone()[0]
            if int(nday)>=V48_MAX_SIGNALS_PER_SYMBOL_DAY: return None
            cur=con.execute("""INSERT INTO titan_v48_ledger(created_at,symbol,timeframe,side,published,mode,setup,entry,stop_loss,tp1,tp2,risk_pct,rr1,rr2,effective_rr1,effective_rr2,confidence,score,quality,data_quality,margin,context_strength,estimated_win_probability,history_samples,regime,components_json,reasons_json,entry_mode,entry_preferred,expires_at,param_version)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (now,symbol,"1h",side,1 if v.get("decision") in {"LONG","SHORT"} else 0,str(v.get("mode") or "WATCH"),str(v.get("setup") or "UNKNOWN"),
                 lv.get("entry"),lv.get("sl"),lv.get("tp1"),lv.get("tp2"),lv.get("risk_pct"),lv.get("rr1"),lv.get("rr2"),lv.get("effective_rr1"),lv.get("effective_rr2"),v.get("confidence"),v.get("score"),v.get("quality"),v.get("data_quality"),v.get("margin"),v.get("context_strength"),v.get("history",{}).get("probability"),v.get("history",{}).get("samples"),str(((_v47_get_context(x).get("regime") or {}).get("regime")) or "unknown"),json.dumps(v.get("explanation") or [],ensure_ascii=False),json.dumps(v.get("hard_blocks") or [],ensure_ascii=False),str((v.get("entry_plan") or {}).get("mode") or "NOW"),_v48_num((v.get("entry_plan") or {}).get("preferred"),lv.get("entry")),now+V48_SIGNAL_COOLDOWN_SEC,V48_VERSION))
            con.commit(); return int(cur.lastrowid)
    except Exception as exc: LOGGER.debug("V48 record failed: %s",exc); return None


def _v48_first_touch(window,side,sl,tp):
    return _ft_simple(window, side == "LONG", sl, tp, guard_positive=False)


def _v48_eval(row,horizon,ocol,ecol,rcol,rmcol,maec,mfec,ttec,evalc,target):
    created=_v48_num(row.get("created_at"),0); end=created+horizon*60; symbol=str(row.get("symbol") or ""); side=str(row.get("side") or "")
    entry=_v48_num(row.get("entry"),0); sl=_v48_num(row.get("stop_loss"),0); tp=_v48_num(target,0)
    if not(created and entry>0 and sl>0 and tp>0 and side in {"LONG","SHORT"}): return False
    try:
        bars=min(220,max(24,int(math.ceil(horizon/15))+6)); df=fetch_klines(symbol,"15m",bars,start_ms=int(created*1000),end_ms=int(end*1000))
        if df is None or df.empty:return False
        w=df[(df["t"].astype(float)>=created*1000)&(df["t"].astype(float)<end*1000)].sort_values("t")
        if w.empty:return False
        out,exitpx,ets=_v48_first_touch(w,side,sl,tp); last=_v48_num(w["close"].iloc[-1],entry);exitpx=last if exitpx is None else exitpx
        gross=((exitpx-entry)/entry*100) if side=="LONG" else ((entry-exitpx)/entry*100 if exitpx>0 else 0)
        net=gross-V48_FRICTION_PCT; rp=abs(entry-sl)/max(entry,1e-12)*100;rm=net/max(rp,1e-12)
        hi=w["high"].astype(float);lo=w["low"].astype(float)
        mae=((float(lo.min())/entry-1)*100) if side=="LONG" else ((entry/float(hi.max())-1)*100)
        mfe=((float(hi.max())/entry-1)*100) if side=="LONG" else ((entry/float(lo.min())-1)*100)
        tte=((ets-created)/60) if ets else None
        with DB_LOCK, db_conn() as con:
            con.execute(f"UPDATE titan_v48_ledger SET {ocol}=?,{ecol}=?,{rcol.replace('r_multiple','return_net')}=?,{rmcol}=?,{maec}=?,{mfec}=?,{ttec}=?,{evalc}=? WHERE id=?",(out,exitpx,net,rm,mae,mfe,tte,time.time(),int(row["id"])))
            con.commit()
        return True
    except Exception as exc: LOGGER.debug("V48 eval %s failed: %s",row.get("id"),exc); return False


def _v48_evaluate_pending(limit=100):
    now=time.time(); done=0
    rows=_v48_query(limit=max(10,int(limit)))
    for r in rows:
        age=now-_v48_num(r.get("created_at"),now)
        if r.get("outcome_6h")=="PENDING" and age>=V48_FAST_HORIZON_MIN*60:
            done+=int(_v48_eval(r,V48_FAST_HORIZON_MIN,"outcome_6h","exit_6h","return_net_6h","r_multiple_6h","mae_6h","mfe_6h","tte_6h","evaluated_6h_at",r.get("tp1")) or 0)
    rows=_v48_query(limit=max(10,int(limit)))
    for r in rows:
        age=now-_v48_num(r.get("created_at"),now)
        if r.get("outcome_24h")=="PENDING" and age>=V48_PRIMARY_HORIZON_MIN*60:
            done+=int(_v48_eval(r,V48_PRIMARY_HORIZON_MIN,"outcome_24h","exit_24h","return_net_24h","r_multiple_24h","mae_24h","mfe_24h","tte_24h","evaluated_24h_at",r.get("tp1")) or 0)
    rows=_v48_query(limit=max(10,int(limit)))
    for r in rows:
        age=now-_v48_num(r.get("created_at"),now)
        if r.get("outcome_48h")=="PENDING" and age>=V48_EXTENDED_HORIZON_MIN*60:
            done+=int(_v48_eval(r,V48_EXTENDED_HORIZON_MIN,"outcome_48h","exit_48h","return_net_48h","r_multiple_48h","mae_48h","mfe_48h","tte_48h","evaluated_48h_at",r.get("tp2")) or 0)
    return done


def _v48_stats(rows,horizon="24h"):
    col="outcome_"+horizon; retcol="return_net_"+horizon
    vals=[]; amb=0
    for r in rows or []:
        out=str(r.get(col) or "");ret=_v48_num(r.get(retcol),float("nan"))
        if out=="AMBIGUOUS":amb+=1;continue
        if math.isfinite(ret) and out in {"WIN","LOSS","TIME_EXIT"}:vals.append((out,ret))
    decisive=[1 if o=="WIN" or (o=="TIME_EXIT" and ret>0) else 0 for o,ret in vals if o=="WIN" or o=="LOSS" or (o=="TIME_EXIT" and ret!=0)]
    wins=sum(decisive);losses=len(decisive)-wins;re=np.asarray([r for _,r in vals],dtype=float);pos=re[re>0];neg=re[re<0]
    pf=float(pos.sum()/abs(neg.sum())) if neg.size else (math.inf if pos.size else None);exp=float(re.mean()) if re.size else 0
    eq=np.cumprod(1+np.clip(re/100,-.999,10)) if re.size else np.asarray([]);dd=0
    if eq.size:
        pk=np.maximum.accumulate(eq);dd=float(np.max((pk-eq)/np.maximum(pk,1e-12))*100)
    return {"trades":len(vals),"wins":wins,"losses":losses,"ambiguous":amb,"win_rate":round(100*wins/max(wins+losses,1),2) if wins+losses else None,"profit_factor":round(pf,3) if pf is not None and math.isfinite(pf) else pf,"expectancy_pct":round(exp,5),"max_drawdown_pct":round(dd,4),"avg_win_pct":round(float(pos.mean()),4) if pos.size else 0.0,"avg_loss_pct":round(float(neg.mean()),4) if neg.size else 0.0,"win_rate_lower_95":round(_v47_wilson(wins,wins+losses),2) if wins+losses else None}


def _v48_audit():
    rows=_v48_query(limit=50000); pubs=[r for r in rows if int(r.get("published") or 0)==1]
    return {"version":V48_VERSION,"scope":"V48 realized ledger","fast_6h":_v48_stats(rows,"6h"),"primary_24h":_v48_stats(rows,"24h"),"extended_48h":_v48_stats(rows,"48h"),"published_24h":_v48_stats(pubs,"24h"),"published_48h":_v48_stats(pubs,"48h"),"pending_6h":sum(1 for r in rows if r.get("outcome_6h")=="PENDING"),"pending_24h":sum(1 for r in rows if r.get("outcome_24h")=="PENDING"),"pending_48h":sum(1 for r in rows if r.get("outcome_48h")=="PENDING"),"rules":{"short_term":"6h telemetry / 24h primary / 48h extended","hard_dq":V48_HARD_DQ,"tactical_edge":V48_TACTICAL_EDGE,"min_rr":V48_MIN_EFFECTIVE_RR,"analysis_only":True}}


@app.get("/api/v48/status")
def api_v48_status():
    try:return jsonify({"ok":True,**_v48_audit()})
    except Exception as exc:return jsonify({"ok":False,"error":str(exc)[:240]}),500

@app.get("/api/v48/ledger")
def api_v48_ledger():
    try:return jsonify({"ok":True,"version":V48_VERSION,"rows":_v48_query(limit=500)})
    except Exception as exc:return jsonify({"ok":False,"error":str(exc)[:240]}),500

@app.get("/api/v48/metrics")
def api_v48_metrics():
    try:
        sym=_normalize_symbol(request.args.get("symbol") or "");side=str(request.args.get("side") or "").upper();reg=str(request.args.get("regime") or "");h=str(request.args.get("horizon") or "24h")
        if h not in {"6h","24h","48h"}:h="24h"
        rows=_v48_query(20000,sym,side,reg);return jsonify({"ok":True,"version":V48_VERSION,"horizon":h,"stats":_v48_stats(rows,h)})
    except Exception as exc:return jsonify({"ok":False,"error":str(exc)[:240]}),500


_V48_PREV_ANALYZE = _analyze_asset_v47

def _analyze_asset_v48(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:
    try:
        base=_V48_PREV_ANALYZE(symbol,btc_trend)
        if not base:return base
        out=_v48_apply_opportunity(base)
        try:_v48_record(out)
        except Exception:_swallow()
        return out
    except Exception as exc:
        LOGGER.exception("V48 analyze wrapper failed for %s: %s",symbol,exc)
        return None

_V48_PREV_UPDATE = _update_cache_v47

def _update_cache_v48(force: bool=False):
    try:_v48_evaluate_pending(limit=120)
    except Exception:_swallow()
    return _V48_PREV_UPDATE(force)


def _v48_self_test():
    fails=[]
    def ck(n,c):
        if not c:fails.append(n);print("  ✗",n)
        else:print("  ✓",n)
    ck("h6",V48_FAST_HORIZON_MIN==360);ck("h24",V48_PRIMARY_HORIZON_MIN==1440);ck("h48",V48_EXTENDED_HORIZON_MIN==2880)
    ck("rr",V48_TARGET_RR2>V48_TARGET_RR1>1);ck("wilson0",_v47_wilson(0,0) is None)
    ck("no_fake_prob",_v48_historical_edge("NOPE/USDT","LONG","unknown").get("probability") is None)
    ck("stats",_v48_stats([{"outcome_24h":"AMBIGUOUS","return_net_24h":1},{"outcome_24h":"WIN","return_net_24h":1},{"outcome_24h":"LOSS","return_net_24h":-1}],"24h")["trades"]==2)
    return 0 if not fails else 1


def run_titan(open_browser: bool = False) -> None:
    """Boot workers, warm cache, then serve the Flask app (analysis-only)."""
    try:
        _safe_startup_check()
        load_settings()
        reload_keys()
        _v47_init_schema()
        _v48_init_schema()
    except Exception as exc:
        LOGGER.exception("V48 startup preparation failed: %s", exc)
    try:
        start_live_engine()
    except Exception as exc:
        LOGGER.warning("Live engine startup deferred: %s", exc)
    for target, name in (
        (_v29_auto_loop, "titan-v29-autonomous"),
        (_v40_maintenance_loop, "titan-v40-heal"),
    ):
        try:
            threading.Thread(target=target, name=name, daemon=True).start()
        except Exception as exc:
            LOGGER.warning("worker %s failed: %s", name, exc)
    # Force first scan on boot so the progress bar and cards fill from second 0.
    try:
        threading.Thread(
            target=lambda: _background_market_refresh(True),
            name="titan-warmup",
            daemon=True,
        ).start()
    except Exception:
        _swallow()
    try:
        _ensure_central_learner()
    except Exception:
        _swallow()
    if open_browser:
        try:
            threading.Thread(
                target=_open_dashboard_browser, name="titan-browser", daemon=True
            ).start()
        except Exception:
            _swallow()

    dash_host = "127.0.0.1" if str(HOST) in {"0.0.0.0", "::"} else str(HOST)
    print("=" * 82)
    print(f"TITAN {TITAN_PARAM_VERSION} — analysis only (no order execution)")
    print(f"  Storage : {APP_HOME}")
    print(f"  Decision: {TITAN_ACTIVE_DECISION_PATH}")
    print(f"  Dashboard: http://{dash_host}:{PORT}")
    print(f"  Bind    : {HOST}:{PORT}")
    print("=" * 82)
    try:
        from waitress import serve as _waitress_serve
        LOGGER.info("Serving with waitress on %s:%s", HOST, PORT)
        _waitress_serve(app, host=HOST, port=PORT, threads=8, channel_timeout=120)
    except ImportError:
        LOGGER.warning("waitress not installed; falling back to Flask dev server")
        app.run(host=HOST, port=PORT, threaded=True, debug=False, use_reloader=False)
