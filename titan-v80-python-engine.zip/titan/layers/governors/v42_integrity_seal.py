# [TITAN V77 layer] governors/v42_integrity_seal - V42 integrity / risk / provenance
# Original V76 source lines 14807-14961 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# TITAN V42 — INTEGRITY / RISK / PROVENANCE SEAL
# ============================================================
# This is intentionally a *last-mile* layer.  It does not create signals.
# It validates that every published directional signal is internally coherent,
# fresh, risk-defined, auditable, and clearly separated from calibrated odds.
V42_VERSION = "TITAN-V42-INTEGRITY-SEAL"
V42_MAX_LIVE_AGE = 12.0
V42_MIN_RR1 = 1.10
V42_MIN_RR2 = 1.40
V42_MIN_DATA = 45.0
V42_MIN_CAL_SAMPLES = 30
V42_MAX_ATR_STRETCH = 3.25


def _v42_price(x: dict[str, Any]) -> float:
    return safe_float(x.get("price_raw"), safe_float(x.get("live_price"), safe_float(str(x.get("price") or "0").replace(",", ""), 0.0)))


def _v42_levels_ok(price: float, sl: float, tp1: float, tp2: float, side: str) -> bool:
    if min(price, sl, tp1, tp2) <= 0:
        return False
    if side == "LONG":
        return sl < price < tp1 < tp2
    if side == "SHORT":
        return tp2 < tp1 < price < sl
    return True


def _v42_integrity_seal(item: dict[str, Any]) -> dict[str, Any]:
    """Final fail-closed contract for the public signal object.

    The seal is deliberately independent of the score-producing engines.  It
    catches stale data, malformed levels, weak RR, contradictory direction,
    uncalibrated probability claims, and missing audit/provenance fields.
    """
    x = dict(item or {})
    side = str(x.get("decision_tag") or x.get("decision") or "WAIT").upper()
    price = _v42_price(x)
    sl = safe_float(x.get("stop_loss_raw"), safe_float(x.get("stop_loss"), 0.0))
    tp1 = safe_float(x.get("tp1_raw"), safe_float(x.get("tp1"), 0.0))
    tp2 = safe_float(x.get("tp2_raw"), safe_float(x.get("tp2"), 0.0))
    atr = safe_float(x.get("atr"), 0.0)
    live_age = safe_float(x.get("live_price_age_sec"), 1e9)
    dq = x.get("data_quality") if isinstance(x.get("data_quality"), dict) else {}
    data_score = safe_float(dq.get("score"), safe_float(x.get("data_trust"), 0.0))
    reasons: list[str] = []

    if side in {"LONG", "SHORT"}:
        if price <= 0:
            reasons.append("invalid_price")
        if live_age > V42_MAX_LIVE_AGE:
            reasons.append("stale_live_price")
        if data_score and data_score < V42_MIN_DATA:
            reasons.append("low_data_quality")
        if not _v42_levels_ok(price, sl, tp1, tp2, side):
            reasons.append("invalid_directional_levels")
        risk = abs(price - sl)
        rr1 = abs(tp1 - price) / risk if risk > 0 else 0.0
        rr2 = abs(tp2 - price) / risk if risk > 0 else 0.0
        if rr1 < V42_MIN_RR1:
            reasons.append("rr1_below_floor")
        if rr2 < V42_MIN_RR2:
            reasons.append("rr2_below_floor")
        if atr > 0 and risk > 0 and risk / atr > V42_MAX_ATR_STRETCH:
            reasons.append("stop_distance_extreme")
    else:
        rr1 = rr2 = 0.0

    # Probability must never be presented as calibrated unless it is backed by
    # realized samples.  This field is a contract guard, not a prediction.
    cal = x.get("probability_calibration") if isinstance(x.get("probability_calibration"), dict) else {}
    cal_n = int(safe_float(cal.get("samples"), 0))
    is_cal = bool(x.get("success_probability_is_calibrated") and cal.get("is_calibrated"))
    if side in {"LONG", "SHORT"} and is_cal and cal_n < V42_MIN_CAL_SAMPLES:
        is_cal = False
        reasons.append("calibration_sample_floor")

    # A signal can only be published directionally if its final risk contract
    # is coherent.  WAIT is the safe state and remains fully auditable.
    if side in {"LONG", "SHORT"} and reasons:
        x["decision_tag"] = "WAIT"
        x["decision"] = "WAIT"
        x["bias"] = "خنثی"
        x["entry_mode"] = "WAIT"
        x["signal_tag"] = "V42 INTEGRITY BLOCK"
        x["v42_blocked_candidate"] = side
        side = "WAIT"

    x["success_probability_is_calibrated"] = is_cal
    if not is_cal:
        # Keep the raw confidence for backward compatibility but prevent the
        # dashboard/API from implying that it is a measured win probability.
        x["calibrated_probability"] = None
        x["probability_semantics"] = "model_confidence_not_win_probability"
    else:
        x["probability_semantics"] = "realized_calibrated_probability"

    x["v42_integrity"] = {
        "version": V42_VERSION,
        "passed": not bool(reasons),
        "final_decision": side,
        "candidate_before_seal": x.get("v42_blocked_candidate") or side,
        "reasons": reasons,
        "live_age_sec": round(live_age, 3) if live_age < 1e8 else None,
        "data_quality": round(data_score, 2),
        "rr1": round(rr1, 3),
        "rr2": round(rr2, 3),
        "calibration_samples": cal_n,
        "calibrated": is_cal,
        "timestamp": time.time(),
    }
    arch = dict(x.get("decision_architecture") or {}) if isinstance(x.get("decision_architecture"), dict) else {}
    arch.update({
        "integrity_seal": V42_VERSION,
        "final_decision": side,
        "fail_closed": True,
        "probability_is_calibrated": is_cal,
    })
    x["decision_architecture"] = arch
    x["authority"] = f"{x.get('authority') or TITAN_CENTRAL_VERSION}+{V42_VERSION}"
    return x


def titan_system_audit() -> dict[str, Any]:
    """Offline/runtime audit of the major subsystems and persistence contract."""
    checks: dict[str, Any] = {}
    checks["python_imports"] = True
    checks["central_governor"] = callable(globals().get("_central_decide"))
    checks["real_edge"] = callable(globals().get("_real_edge_engine"))
    checks["v40_precision"] = callable(globals().get("_v40_precision_gate"))
    checks["v42_integrity"] = callable(globals().get("_v42_integrity_seal"))
    checks["v43_unified_governor"] = callable(globals().get("_v43_unified_decide"))
    checks["forecast_evaluator"] = callable(globals().get("_central_evaluate_pending"))
    checks["paper_evaluator"] = callable(globals().get("evaluate_paper_trades"))
    checks["walk_forward"] = callable(globals().get("walk_forward_backtest"))
    checks["neural_engine"] = "TitanNeuralSynapseV9" in globals()
    checks["ai_ensemble"] = callable(globals().get("generate_ai_opinions"))
    checks["live_engine"] = callable(globals().get("start_live_engine"))
    checks["db_path_locked"] = str(DB_PATH).startswith(str(APP_HOME))
    try:
        with DB_LOCK, db_conn() as con:
            tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        required = {"central_predictions", "central_component_stats", "central_arbiter_log"}
        checks["required_tables"] = required.issubset(tables)
        checks["table_count"] = len(tables)
    except Exception as exc:
        checks["required_tables"] = False
        checks["db_error"] = str(exc)[:180]
    checks["passed"] = all(v is True for k, v in checks.items() if k not in {"table_count", "db_error"})
    checks["version"] = V42_VERSION
    checks["timestamp"] = _now_iso()
    return checks
