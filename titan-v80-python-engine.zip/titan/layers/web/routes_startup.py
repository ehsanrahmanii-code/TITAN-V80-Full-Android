# [TITAN V77 layer] web/routes_startup - Routes + startup
# Original V76 source lines 11530-12406 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# ROUTES
# ============================================================


# ---- TTL response cache for heavy analytical endpoints (dashboard must stay responsive) ----
_HEAVY_API_CACHE: dict[str, tuple[float, Any]] = {}
_HEAVY_API_LOCK = threading.Lock()
_HEAVY_API_TTL = {
    "backtest": 120.0,
    "walk_forward": 180.0,
    "performance": 90.0,
    "all_performance": 180.0,
    "pro_lab": 120.0,
    "market_pulse": 20.0,
}

def _heavy_cache_get(key: str, ttl: float):
    try:
        with _HEAVY_API_LOCK:
            row = _HEAVY_API_CACHE.get(key)
        if not row:
            return None
        ts, payload = row
        if time.time() - ts > ttl:
            return None
        return payload
    except Exception:
        return None

def _heavy_cache_put(key: str, payload):
    try:
        with _HEAVY_API_LOCK:
            _HEAVY_API_CACHE[key] = (time.time(), payload)
            if len(_HEAVY_API_CACHE) > 256:
                # drop oldest half
                items = sorted(_HEAVY_API_CACHE.items(), key=lambda kv: kv[1][0])
                for k, _ in items[: max(1, len(items)//2)]:
                    _HEAVY_API_CACHE.pop(k, None)
    except Exception:
        pass


def _query_int(name: str, default: int, lo: int, hi: int) -> int:
    """Parse bounded integer query parameters without turning bad URLs into 500s."""
    try:
        value = int(request.args.get(name, default))
    except (TypeError, ValueError):
        value = int(default)
    return max(int(lo), min(int(value), int(hi)))


def _query_timeframe(name: str = "timeframe", default: str = "1h") -> str:
    value = str(request.args.get(name, default) or default).strip()
    # Binance-supported TITAN analysis frames. Reject arbitrary strings early.
    return value if value in {"15m", "1h", "4h", "1d"} else default

_MAINTENANCE_LOCK = threading.Lock()

def _safe_background_forecast_maintenance():
    if not _MAINTENANCE_LOCK.acquire(blocking=False):
        return
    if not TITAN_V51_AUTHORITATIVE:
        try:
            v32_evaluate_pending()
            v32_register_learning_maintenance()
        except Exception as exc:
            LOGGER.warning("V32 learning maintenance failed: %s", exc)
        try:
            evaluate_pending_forecasts()
        except Exception as exc:
            LOGGER.warning("Background forecast maintenance failed: %s", exc)
        try:
            evaluate_paper_trades()
        except Exception as exc:
            LOGGER.warning("Background paper-trade maintenance failed: %s", exc)
    try:
        autonomous_performance_maintenance(False)
    except Exception as exc:
        LOGGER.debug("Autonomous performance maintenance failed: %s", exc)
    finally:
        _MAINTENANCE_LOCK.release()

# --- V53.1 UI: signal ordering + neon tiers for dashboard cards -------------
def _titan_ui_family(item: Any) -> str:
    try:
        dec = str((item.get("stance_family") or item.get("decision_tag") or "WAIT")).upper()
    except Exception:
        _swallow()
        return "WAIT"
    return dec if dec in ("LONG", "SHORT") else "WAIT"


def titan_sort_signals(rows: Any, limit: Optional[int] = None, only_active: bool = False) -> list:
    """Dashboard display order: LONG (strongest first) -> SHORT (strongest first) -> WAIT.

    Strength is directional: LONG uses score, SHORT uses 100-score (lower score = stronger
    bearish edge), WAIT uses the raw score. Ties are broken by signal quality, success
    probability and opportunity score. Also tags neon tiers (elite / good) per side and
    TF direction dots (up / down). Display only — analysis values are never modified.
    """
    fam_order = {"LONG": 0, "SHORT": 1, "WAIT": 2}
    items = []
    for raw in rows or []:
        if not isinstance(raw, dict):
            continue
        x = dict(raw)
        fam = _titan_ui_family(x)
        sc = safe_float(x.get("score"), 50.0)
        strength = sc if fam == "LONG" else (100.0 - sc) if fam == "SHORT" else sc
        x["ui_family"] = fam
        x["ui_strength"] = round(float(clamp(strength, 0.0, 100.0)), 1)
        tfs = x.get("tfs") if isinstance(x.get("tfs"), dict) else {}
        dirs = {}
        for tf in ("15m", "1h", "4h", "1d"):
            v = safe_float(tfs.get(tf, x.get("tfs" + tf, sc)), sc)
            dirs[tf] = "up" if v >= 50.0 else "down"
        x["ui_tfdir"] = dirs
        items.append(x)
    if only_active:
        items = [x for x in items if x["ui_family"] != "WAIT"]
    items.sort(key=lambda x: (
        fam_order.get(x["ui_family"], 2),
        -x["ui_strength"],
        -safe_float(x.get("signal_quality"), 0.0),
        -safe_float(x.get("success_probability"), 0.0),
        -safe_float(x.get("opportunity_score"), 0.0),
    ))
    counts = {"LONG": 0, "SHORT": 0, "WAIT": 0}
    for x in items:
        counts[x["ui_family"]] += 1
    rank = {"LONG": 0, "SHORT": 0, "WAIT": 0}
    for x in items:
        fam = x["ui_family"]
        r = rank[fam]
        x["ui_rank"] = r + 1
        x["ui_group_start"] = (r == 0)
        x["ui_group_count"] = counts[fam]
        grade = str(x.get("grade") or "")
        glow = ""
        if fam != "WAIT":
            if (r < 2 and x["ui_strength"] >= 60) or grade == "A+" or x["ui_strength"] >= 78:
                glow = "glowElite"
            elif r < 5 or grade == "A" or x["ui_strength"] >= 64:
                glow = "glowGood"
        x["ui_glow"] = glow
        rank[fam] = r + 1
    if limit:
        items = items[: int(limit)]
    return items


try:
    app.jinja_env.globals["titan_sort_signals"] = titan_sort_signals
except Exception:
    _swallow()


def _index_base():
    # Fast-but-complete bootstrap: if a usable snapshot exists, render it immediately.
    # On a cold start, wait for the market engine ONCE so the user receives the full coin
    # dashboard exactly like the original build. The engine itself is parallelized and
    # Gemini is non-blocking, making the cold start substantially faster without a blank UI.
    try:
        t0 = time.perf_counter()
        market_data, gemini_summary, macro = _fast_market_snapshot()
        with CACHE_LOCK:
            cache_age = time.time() - float(CACHE.get("timestamp") or 0) if CACHE.get("timestamp") else 1e9
        # Never block the first paint on a full multi-coin analyze when any snapshot exists.
        # Cold start without disk cache: kick background refresh and render lightweight empty shell.
        if not market_data:
            # Never block the HTTP request on a full multi-coin scan (Android/mobile).
            # Show emergency live prices immediately, then refresh analysis in background.
            try:
                emergency = _emergency_live_cards()
                if emergency:
                    market_data = emergency
                    with CACHE_LOCK:
                        if not CACHE.get("data"):
                            CACHE["data"] = emergency
                            CACHE["timestamp"] = time.time()
            except Exception as _em_exc:
                LOGGER.warning("index emergency cards: %s", _em_exc)
            _background_market_refresh(True)
        elif cache_age >= MARKET_CACHE_TTL:
            _background_market_refresh(False)
        if RENDER_PERF_LOG:
            LOGGER.info("index snapshot ready in %.0fms coins=%s age=%.1fs",
                        (time.perf_counter() - t0) * 1000, len(market_data or []), cache_age if market_data else -1)
    except Exception as exc:
        LOGGER.exception("Index market bootstrap error: %s", exc)
        market_data, gemini_summary, macro = _fast_market_snapshot()
        if not market_data:
            _background_market_refresh(False)
    # Historical evaluation is maintenance work; never hold up dashboard rendering.
    threading.Thread(target=lambda: _safe_background_forecast_maintenance(), name="titan-forecast-maint", daemon=True).start()
    return _v59_page_response()



@app.get("/api/dashboard-status")
def api_dashboard_status():
    """Tiny non-blocking status endpoint used by the fast dashboard bootstrap."""
    with CACHE_LOCK:
        data = CACHE.get("data") or []
        ts = float(CACHE.get("timestamp") or 0)
    return jsonify({"ok": True, "ready": bool(data), "count": len(data), "age": round(max(0.0, time.time()-ts), 1) if ts else None, "refreshing": bool(_BACKGROUND_REFRESH_RUNNING), "scan": _scan_progress_snapshot()})

@app.get("/api/scan-progress")
def api_scan_progress():
    p=_scan_progress_snapshot()
    with CACHE_LOCK:
        ts=float(CACHE.get("timestamp") or 0)
    if not p.get("last_success_at") and ts:
        p["last_success_at"]=ts
        p["finished_at"]=ts
    p["cache_age_sec"]=round(max(0.0,time.time()-ts),1) if ts else None
    p["server_now"]=time.time()
    return jsonify({"ok":True,"progress":p})

@app.get("/api/performance-learning")
def api_performance_learning():
    try:
        symbol=request.args.get("symbol","").strip() or None
        v32_evaluate_pending()
        matrix=v32_performance_matrix(symbol)
        learning=v32_learning_profile(_normalize_symbol(symbol)) if symbol else None
        with DB_LOCK, db_conn() as con:
            total=con.execute("SELECT COUNT(*) FROM v32_forecast_audit").fetchone()[0]
            pending=con.execute("SELECT COUNT(*) FROM v32_forecast_audit WHERE outcome='PENDING'").fetchone()[0]
            wins=con.execute("SELECT COUNT(*) FROM v32_forecast_audit WHERE outcome='WIN'").fetchone()[0]
            losses=con.execute("SELECT COUNT(*) FROM v32_forecast_audit WHERE outcome='LOSS'").fetchone()[0]
            wait_ok=con.execute("SELECT COUNT(*) FROM v32_forecast_audit WHERE outcome='WAIT_CORRECT'").fetchone()[0]
            wait_missed=con.execute("SELECT COUNT(*) FROM v32_forecast_audit WHERE outcome='WAIT_MISSED'").fetchone()[0]
        dec=wins+losses
        # Keep technical backtest snapshots separate from the live forecast audit:
        # these snapshots are not realized live trades and must never inflate live WR.
        snapshot_where = "WHERE oos_status='ok'"
        snapshot_args = []
        if symbol:
            snapshot_where += " AND symbol=?"
            snapshot_args.append(_normalize_symbol(symbol))
        with DB_LOCK, db_conn() as con:
            snapshot_rows = con.execute(
                f"""SELECT timeframe, COUNT(*) AS snapshots,
                           COUNT(DISTINCT symbol) AS symbols,
                           ROUND(AVG(trades), 2) AS avg_trades,
                           ROUND(AVG(win_rate), 2) AS avg_win_rate,
                           ROUND(AVG(expectancy), 4) AS avg_expectancy,
                           ROUND(AVG(profit_factor), 4) AS avg_profit_factor,
                           ROUND(AVG(max_drawdown), 4) AS avg_max_drawdown,
                           MAX(created_at) AS latest_at
                    FROM performance_snapshots {snapshot_where}
                    GROUP BY timeframe ORDER BY timeframe""",
                snapshot_args,
            ).fetchall()
            snapshot_total = con.execute(
                f"SELECT COUNT(*) FROM performance_snapshots {snapshot_where}", snapshot_args
            ).fetchone()[0]
        backtest_proxy = {
            "source": "performance_snapshots",
            "scope": "technical_proxy_backtest_not_live_trades",
            "snapshot_count": int(snapshot_total or 0),
            "by_timeframe": [dict(r) for r in snapshot_rows],
            "semantics": "averages of stored snapshots; not pooled trade-level statistics",
        }
        return jsonify({"ok":True,"version":V32_VERSION,"timeframe_policy":V59_TF_POLICY,"matrix":matrix,"learning":learning,
                        "summary":{"total":total,"pending":pending,"wins":wins,"losses":losses,
                                   "directional_win_rate":round(wins/dec*100,1) if dec else None,
                                   "wait_correct":wait_ok,"wait_missed":wait_missed},
                        "backtest_proxy":backtest_proxy})
    except Exception as exc:
        LOGGER.exception("V32 performance endpoint failed")
        return jsonify({"ok":False,"error":str(exc)}),500

@app.get("/api/forecast-audit")
def api_forecast_audit():
    symbol=request.args.get("symbol","").strip()
    limit=_query_int("limit",100,10,500)
    where="WHERE symbol=?" if symbol else ""; args=[_normalize_symbol(symbol)] if symbol else []
    with DB_LOCK, db_conn() as con:
        rows=con.execute(f"SELECT * FROM v32_forecast_audit {where} ORDER BY created_at DESC LIMIT ?",args+[limit]).fetchall()
    return jsonify({"ok":True,"items":[dict(r) for r in rows]})

@app.route("/api/tf-gauge")
def api_tf_gauge():
    symbol = _normalize_symbol(request.args.get("symbol", "") or (USER_SETTINGS.get("active_coins") or DEFAULT_COINS)[0])
    frames = ["15m", "1h", "4h", "1d"]
    out = []
    try:
        data, _, _ = _fast_market_snapshot()
        if not data:
            _background_market_refresh(False)
        item = next((x for x in (data or []) if x.get("symbol") == symbol), None)
        if not item:
            bare = symbol.replace("/", "")
            item = next((x for x in (data or []) if str(x.get("tv_symbol", "")).replace("/", "") == bare), {}) or {}
        tf_scores = (item or {}).get("tf_scores") or {}
        base = float((item or {}).get("score") or 50)
        alignment_all = float((item or {}).get("alignment") or 50)
        vol_spike = bool((item or {}).get("volume_spike"))
    except Exception as exc:
        LOGGER.warning("TF gauge snapshot failed for %s: %s", symbol, exc)
        tf_scores, base, alignment_all, vol_spike = {}, 50.0, 50.0, False
    # The gauge must be independently reliable even when the dashboard cache is cold.
    # Build missing timeframe scores directly from closed Binance candles.
    if not tf_scores:
        try:
            fresh_scores = {}
            for f in frames:
                df = fetch_klines(symbol, f, 140 if f in ("15m", "1h") else 100)
                if df is not None and len(df) >= 55:
                    _d, _sc, _m = _tf_forecast(df, tf=f)
                    fresh_scores[f] = float(_sc)
            tf_scores = fresh_scores
        except Exception as exc:
            LOGGER.debug("fresh TF gauge fallback failed: %s", exc)
    if not tf_scores and not data:
        return jsonify({"ok": False, "ready": False, "symbol": symbol, "error": "داده تایم‌فریم هنوز آماده نشده است"}), 202
    for f in frames:
        score = float(tf_scores.get(f, base))
        trend = int(clamp(score, 0, 100))
        momentum = int(clamp(score * 0.92 + (5 if score >= 60 else -5 if score <= 40 else 0), 0, 100))
        volume = int(clamp((75 if vol_spike else 45) + (score - 50) * 0.35, 0, 100))
        alignment = int(clamp(alignment_all * 0.7 + score * 0.3, 0, 100))
        final = int(round(trend * 0.35 + momentum * 0.25 + volume * 0.15 + alignment * 0.25))
        out.append({"name": f, "trend": trend, "momentum": momentum, "volume": volume, "alignment": alignment, "score": final})
    return jsonify({"ok": True, "symbol": symbol, "timeframes": out})

@app.route("/rescan")
def rescan():
    """Force a fresh scan in the background; keep last cards visible so UI never goes blank."""
    global CACHE
    with CACHE_LOCK:
        # Invalidate TTL without wiping cards — index/background will refresh.
        CACHE["timestamp"] = 0.0
    _scan_progress_update(
        status="queued", phase="در صف اسکن", started_at=time.time(), finished_at=0.0,
        completed=0, total=len(USER_SETTINGS.get("active_coins") or DEFAULT_COINS),
        percent=2, message="اسکن جدید در پس‌زمینه شروع شد…", fresh=False,
    )
    try:
        _background_market_refresh(True)
    except Exception as exc:
        LOGGER.warning("rescan background start failed: %s", exc)
    return redirect(url_for("index"))

@app.route("/update_settings", methods=["POST"])
def update_settings():
    global USER_SETTINGS, CACHE
    risk = clamp(safe_float(request.form.get("risk_multiplier"), 1.2), 0.2, 5.0)
    coins: list[str] = []
    for raw in request.form.get("active_coins", "").split(","):
        symbol = _normalize_symbol(raw)
        if symbol and symbol not in coins:
            coins.append(symbol)
    USER_SETTINGS = {"risk_multiplier": risk, "active_coins": coins or DEFAULT_COINS.copy()}
    save_settings()
    with CACHE_LOCK:
        CACHE = {"timestamp": 0.0, "data": [], "gemini_summary": "", "macro": {}}
    return redirect(url_for("index"))






@app.get("/api/depth")
def api_depth():
    symbol = _normalize_symbol(request.args.get("symbol", "BTC/USDT"))
    return jsonify({"ok": True, "depth": get_depth_snapshot(symbol), "watchlist": DEPTH_WATCHLIST})

@app.get("/api/calibration")
def api_calibration():
    symbol = _normalize_symbol(request.args.get("symbol", ""))
    direction = str(request.args.get("direction", "") or "")
    raw = safe_float(request.args.get("raw", 55), 55)
    return jsonify({"ok": True, "calibration": calibrate_success_probability(symbol, direction, raw)})


@app.get("/api/pattern-forecast")
def api_pattern_forecast():
    """Pattern detection + probabilistic future candle path for one symbol."""
    symbol = _normalize_symbol(request.args.get("symbol", "BTC/USDT"))
    tf = str(request.args.get("timeframe", "1h") or "1h")
    if tf not in {"15m", "1h", "4h", "1d"}:
        tf = "1h"
    horizon = min(max(int(request.args.get("horizon", 48)), 3), 48)
    try:
        df = fetch_klines(symbol, tf, 200 if tf in ("15m", "1h") else 150)
        rsi_s = wilder_rsi(df["close"])
        patterns = detect_chart_patterns(df, rsi_s)
        forecast = forecast_future_candles(df, horizon=horizon, patterns=patterns)
        macd = calc_macd(df["close"])
        stoch = calc_stoch_rsi(df["close"])
        return jsonify({
            "ok": True,
            "symbol": symbol,
            "timeframe": tf,
            "rsi": round(float(rsi_s.iloc[-1]), 2) if len(rsi_s) else None,
            "macd": macd,
            "stoch_rsi": stoch,
            "patterns": patterns,
            "forecast": forecast,
            "guide_catalog": PATTERN_GUIDE,
        })
    except Exception as exc:
        LOGGER.warning("pattern-forecast failed %s: %s", symbol, exc)
        return jsonify({"ok": False, "error": str(exc)[:300], "symbol": symbol}), 500


@app.get("/api/klines")
def api_klines():
    """OHLCV for dashboard chart (robust column mapping)."""
    symbol = _normalize_symbol(request.args.get("symbol", "BTC/USDT"))
    tf = str(request.args.get("timeframe", "1h") or "1h")
    if tf not in {"15m", "1h", "4h", "1d"}:
        tf = "1h"
    limit = min(max(int(request.args.get("limit", 120)), 20), 300)
    try:
        df = None
        if callable(globals().get("fetch_ohlcv")):
            try:
                df = fetch_ohlcv(symbol, tf, limit=limit)
            except Exception:
                df = None
        if df is None or getattr(df, "empty", True):
            df = fetch_klines(symbol, tf, limit)
        if df is None or getattr(df, "empty", True):
            return jsonify({"ok": False, "error": "no_ohlcv", "symbol": symbol, "candles": []}), 200
        # flexible columns
        cols = {str(c).lower(): c for c in df.columns}
        def col(*names):
            for n in names:
                if n in df.columns:
                    return df[n]
                if n in cols:
                    return df[cols[n]]
            return None
        o = col("open", "o")
        h = col("high", "h")
        l = col("low", "l")
        c = col("close", "c")
        v = col("vol", "volume", "v")
        ts = col("t", "time", "open_time", "timestamp")
        if c is None:
            return jsonify({"ok": False, "error": "missing_close", "symbol": symbol, "candles": []}), 200
        n = len(df)
        candles = []
        for i in range(n):
            try:
                candles.append({
                    "t": int(ts.iloc[i]) if ts is not None else i,
                    "o": float(o.iloc[i]) if o is not None else float(c.iloc[i]),
                    "h": float(h.iloc[i]) if h is not None else float(c.iloc[i]),
                    "l": float(l.iloc[i]) if l is not None else float(c.iloc[i]),
                    "c": float(c.iloc[i]),
                    "v": float(v.iloc[i]) if v is not None else 0.0,
                })
            except Exception:
                continue
        return jsonify({"ok": True, "symbol": symbol, "timeframe": tf, "candles": candles, "n": len(candles)})
    except Exception as exc:
        LOGGER.warning("api_klines failed %s: %s", symbol, exc)
        return jsonify({"ok": False, "error": str(exc)[:300], "symbol": symbol, "candles": []}), 200





@app.get("/api/scalp-window")
def api_scalp_window():
    """Short-horizon (30-60 min) leverage suitability from 15m/1h scores + live micro bias.

    Analysis-only. Designed for holding a position roughly 30 minutes, max ~60.
    """
    try:
        data, _, macro = _fast_market_snapshot()
        rows = []
        for item in data or []:
            sym = str(item.get("symbol") or "")
            # Enforce unified stance — scalp cannot contradict central opinion
            st = str(item.get("stance") or "")
            family = str(item.get("stance_family") or "")
            if not st or not family:
                st_info = _unified_stance(item)
                st, family = st_info["stance"], st_info["stance_family"]
            if family not in {"LONG", "SHORT"}:
                continue  # no directional scalp when core says WAIT
            tfs = item.get("tfs") or item.get("tf_scores") or {}
            s15 = safe_float(tfs.get("15m"), safe_float(item.get("score"), 50))
            s1h = safe_float(tfs.get("1h"), 50)
            rsi = safe_float(item.get("rsi"), 50)
            buy = safe_float((item.get("buy_sell") or {}).get("buy_pct") if isinstance(item.get("buy_sell"), dict) else None, item.get("taker_buy_pct", 50))
            sell = 100.0 - buy
            decision = str(item.get("decision_tag") or "WAIT").upper()
            score = safe_float(item.get("score"), 50)
            success = safe_float(item.get("success_probability"), safe_float(item.get("signal_quality"), 50))
            long_edge = (s15 - 50) * 1.35 + (s1h - 50) * 0.55 + (buy - 50) * 0.30 + (success - 50) * 0.20
            short_edge = (50 - s15) * 1.35 + (50 - s1h) * 0.55 + (sell - 50) * 0.30 + (success - 50) * 0.20
            if rsi >= 70:
                short_edge += 5; long_edge -= 4
            elif rsi <= 30:
                long_edge += 5; short_edge -= 4
            # Side MUST match central stance family
            if family == "LONG":
                side = "LONG"; edge = max(long_edge, 8.0)
            else:
                side = "SHORT"; edge = max(short_edge, 8.0)
            # Require short-TF agreement with family
            if side == "LONG" and not (s15 >= 52 and s1h >= 46):
                continue
            if side == "SHORT" and not (s15 <= 48 and s1h <= 54):
                continue
            if decision == side:
                edge += 4
            conf = float(clamp(safe_float(item.get("stance_confidence"), 50) * 0.55 + edge * 1.6 + (success - 50) * 0.12, 0, 92))
            if conf < 58:
                continue
            hold_min = 30 if conf >= 75 else 40 if conf >= 68 else 50
            rows.append({
                "symbol": sym,
                "base": sym.split("/")[0] if "/" in sym else sym,
                "side": side,
                "stance": st,
                "published": bool(item.get("stance_published")),
                "confidence": round(conf, 1),
                "success": round(success, 1),
                "hold_minutes": hold_min,
                "max_hold_minutes": 60,
                "score_15m": round(s15, 1),
                "score_1h": round(s1h, 1),
                "rsi": round(rsi, 1),
                "buy_pct": round(buy, 1),
                "reason": (
                    f"۱۵م={s15:.0f} · ۱س={s1h:.0f} · RSI={rsi:.0f} · موفقیت~{success:.0f} · "
                    f"{'خرید' if side=='LONG' else 'فروش'} {(buy if side=='LONG' else sell):.0f}% · "
                    f"نگهداری ~{hold_min}–۶۰ دقیقه"
                ),
            })
        rows.sort(key=lambda r: (
            -safe_float(r.get("confidence"), 0),
            -safe_float(r.get("success"), 0),
            -safe_float(r.get("score_15m"), 0),
        ))
        # Only the single best LONG and/or SHORT — hard cap 2 total
        top2 = rows[:2]
        return jsonify({
            "ok": True,
            "horizon": "30-60m",
            "count": len(top2),
            "rows": top2,
            "note": "هم‌راستا با نظر مرکزی TITAN (stance). فقط تمایل/سیگنال هم‌جهت نمایش داده می‌شود. اهرم کوتاه‌مدت · حداکثر ۶۰ دقیقه · تحلیل نه توصیه.",
            "macro": {"btc_trend": (macro or {}).get("btc_trend")},
        })
    except Exception as exc:
        LOGGER.exception("scalp-window failed: %s", exc)
        return jsonify({"ok": False, "error": str(exc)[:300]}), 500


@app.get("/api/realtime-analysis")
def api_realtime_analysis():
    """Real-time snapshot: live prices, micro-moves, breadth, and per-symbol live bias."""
    try:
        coins = USER_SETTINGS.get("active_coins") or DEFAULT_COINS
        # Refresh a batch of live prices (non-blocking-ish, short timeout path)
        try:
            prices = _fetch_live_prices(list(coins)[:40])
            for sym, px in prices.items():
                if px and px > 0:
                    _register_live_price(sym, px, "REST-rt")
        except Exception as exc:
            LOGGER.debug("realtime price batch: %s", exc)

        live_status = _live_status()
        rows = []
        up = down = flat = 0
        with LIVE_LOCK:
            live_map = dict(LIVE_PRICES)

        # Merge with last cache decisions for context
        cached, _, macro = _fast_market_snapshot()
        by_sym = {str(x.get("symbol")): x for x in (cached or [])}

        for sym in coins:
            ns = _normalize_symbol(sym)
            bare = _normalize_symbol_for_binance(ns)
            info = live_map.get(ns) or live_map.get(bare) or live_map.get(bare.replace("USDT", "/USDT")) or {}
            # try alternate keys
            if not info:
                for k, v in live_map.items():
                    if k.replace("/", "") == bare:
                        info = v
                        break
            px = safe_float(info.get("price"), 0)
            ch = safe_float(info.get("change_pct"), 0)
            age = time.time() - safe_float(info.get("ts"), 0) if info.get("ts") else None
            item = by_sym.get(ns) or {}
            decision = str(item.get("decision_tag") or "WAIT")
            score = safe_float(item.get("score"), 50)
            buy = safe_float((item.get("buy_sell") or {}).get("buy_pct"), item.get("taker_buy_pct", 50))
            sell = safe_float((item.get("buy_sell") or {}).get("sell_pct"), 100 - buy)

            # Micro live bias from last tick change
            if ch > 0.08:
                micro = "صعودی"
                up += 1
            elif ch < -0.08:
                micro = "نزولی"
                down += 1
            else:
                micro = "خنثی"
                flat += 1

            # Build the realtime row from the same cached signal plus the newest
            # live snapshot so Entry/SL/TP shown by the UI cannot lag the price.
            live_item = dict(item)
            if px > 0:
                live_item = _v35_rebase_price_dependent_outputs(
                    live_item, {"price": px, "ts": safe_float(info.get("ts"), time.time()),
                                "source": info.get("source") or "Binance"}
                )
            rows.append({
                "symbol": ns,
                "price": px if px > 0 else safe_float(str(item.get("price") or "0").replace(",", ""), 0),
                "entry": safe_float(live_item.get("entry_raw"), px),
                "stop_loss": safe_float(live_item.get("stop_loss_raw"), 0),
                "tp1": safe_float(live_item.get("tp1_raw"), 0),
                "tp2": safe_float(live_item.get("tp2_raw"), 0),
                "rr_tp1": safe_float(live_item.get("rr_tp1"), 0),
                "rr_tp2": safe_float(live_item.get("rr_tp2"), 0),
                "change_pct": round(ch, 4),
                "age_sec": round(age, 2) if age is not None else None,
                "source": info.get("source") or "cache",
                "decision": str(live_item.get("decision_tag") or decision),
                "score": score,
                "buy_pct": round(buy, 1),
                "sell_pct": round(sell, 1),
                "micro_bias": micro,
                "fresh": bool(age is not None and age <= 8),
                "live_sync": bool(live_item.get("live_sync", False)),
            })

        rows.sort(key=lambda r: abs(safe_float(r.get("change_pct"), 0)), reverse=True)
        leaders = [r for r in rows if r.get("fresh") and abs(safe_float(r.get("change_pct"), 0)) >= 0.05][:5]
        return jsonify({
            "ok": True,
            "mode": "realtime",
            "server_time": int(time.time() * 1000),
            "live": live_status,
            "breadth": {"up": up, "down": down, "flat": flat},
            "leaders": leaders,
            "rows": rows,
            "macro": {
                "fear": (macro or {}).get("fear_greed_val"),
                "btc_dom": (macro or {}).get("dominance_btc"),
                "btc_trend": (macro or {}).get("btc_trend"),
            },
            "note": "تحلیل بلادرنگ بر اساس تیک زنده + آخرین سیگنال کش‌شده؛ سفارش اجرا نمی‌شود.",
        })
    except Exception as exc:
        LOGGER.exception("realtime-analysis failed: %s", exc)
        return jsonify({"ok": False, "error": str(exc)[:300]}), 500


@app.get("/api/live-prices")
def api_live_prices():
    symbols = [_normalize_symbol(x) for x in request.args.get("symbols", "").split(",") if x.strip()][:100]
    return jsonify({"ok": True, "source": "Binance Spot Ticker", "prices": _fetch_live_prices(symbols), "server_time": int(time.time() * 1000)})

@app.get("/api/market-pulse")
def api_market_pulse():
    force = str(request.args.get("refresh", "0")).lower() in {"1", "true", "yes"}
    ck = "market_pulse"
    if not force:
        hit = _heavy_cache_get(ck, _HEAVY_API_TTL["market_pulse"])
        if hit is not None:
            return jsonify(hit)
    data, _summary, macro = _fast_market_snapshot()
    payload = {"ok": True, "pulse": _market_pulse_snapshot(data, macro)}
    _heavy_cache_put(ck, payload)
    return jsonify(payload)

@app.get("/api/advanced-metrics")
def api_advanced_metrics():
    evaluate_paper_trades()
    return jsonify({"ok": True, "metrics": get_advanced_metrics()})

@app.get("/api/backtest")
def api_backtest():
    symbol = _normalize_symbol(request.args.get("symbol", "BTC/USDT")); tf = _query_timeframe(); limit = _query_int("limit", 1000, 100, MAX_BACKTEST_CANDLES)
    force = str(request.args.get("refresh", "0")).lower() in {"1", "true", "yes"}
    ck = f"backtest:{symbol}:{tf}:{limit}"
    if not force:
        hit = _heavy_cache_get(ck, _HEAVY_API_TTL["backtest"])
        if hit is not None:
            return jsonify(hit)
    payload = backtest_signal_logic(symbol, tf, limit)
    _heavy_cache_put(ck, payload)
    return jsonify(payload)

@app.get("/api/walk-forward")
def api_walk_forward():
    symbol = _normalize_symbol(request.args.get("symbol", "BTC/USDT")); tf = _query_timeframe(); limit = _query_int("limit", 1000, 200, MAX_BACKTEST_CANDLES)
    train = _query_int("train", 300, 100, MAX_BACKTEST_CANDLES); test = _query_int("test", 100, 20, MAX_BACKTEST_CANDLES)
    force = str(request.args.get("refresh", "0")).lower() in {"1", "true", "yes"}
    ck = f"wf:{symbol}:{tf}:{limit}:{train}:{test}"
    if not force:
        hit = _heavy_cache_get(ck, _HEAVY_API_TTL["walk_forward"])
        if hit is not None:
            return jsonify(hit)
    payload = walk_forward_backtest(symbol, tf, limit, train, test)
    _heavy_cache_put(ck, payload)
    return jsonify(payload)

@app.get("/api/titan-terminal")
def api_titan_terminal():
    symbol = _normalize_symbol(request.args.get("symbol", USER_SETTINGS.get("active_coins", DEFAULT_COINS)[0]))
    data, _summary, _macro = update_cache(False)
    item = next((x for x in data if x.get("symbol") == symbol), None)
    if not item:
        return jsonify({"ok": False, "error": "نماد در کش فعلی موجود نیست"}), 404
    return jsonify({"ok": True, "terminal": item.get("decision_terminal", TITAN_EDGE_SUITE.decision_terminal(item))})


@app.get("/api/all-performance")
def api_all_performance():
    force = str(request.args.get("refresh", "0")).lower() in {"1", "true", "yes"}
    cache_key = "all_performance:" + ",".join(USER_SETTINGS.get("active_coins") or DEFAULT_COINS)
    if not force:
        hit = _heavy_cache_get(cache_key, _HEAVY_API_TTL["all_performance"])
        if hit is not None:
            return jsonify(hit)
    symbols = USER_SETTINGS.get("active_coins") or DEFAULT_COINS
    out = []
    audit = get_audit_stats()
    # Cap synchronous work: first 8 symbols online; rest deferred markers
    for i, symbol in enumerate(symbols):
        try:
            sym = _normalize_symbol(symbol)
            if i >= 8 and not force:
                out.append({"symbol": sym, "deferred": True, "note": "cached batch limit; pass refresh=1 for full"})
                continue
            result = backtest_signal_logic(sym, "1h", 500)
            m = result.get("metrics", {}) if isinstance(result, dict) and result.get("ok") else {}
            out.append({
                "symbol": sym,
                "win_rate": m.get("win_rate", audit.get("win_rate", 0)),
                "wins": m.get("wins", audit.get("wins", 0)),
                "losses": m.get("losses", audit.get("losses", 0)),
                "expectancy": m.get("expectancy", 0),
                "profit_factor": m.get("profit_factor", 0),
            })
        except Exception as e:
            out.append({"symbol": symbol, "error": str(e)[:160]})
    payload = {"ok": True, "items": out, "audit": audit}
    _heavy_cache_put(cache_key, payload)
    return jsonify(payload)


@app.get("/api/performance-history")
def api_performance_history():
    symbol = _normalize_symbol(request.args.get("symbol", "")) if request.args.get("symbol") else ""
    tf = request.args.get("timeframe", "")
    limit = _query_int("limit", 120, 1, 500)
    return jsonify(get_performance_history(symbol, tf, limit))


@app.get("/api/performance")
def api_performance():
    symbol = _normalize_symbol(request.args.get("symbol", USER_SETTINGS.get("active_coins", DEFAULT_COINS)[0]))
    tf = _query_timeframe(); limit = _query_int("limit", 1200, 200, MAX_BACKTEST_CANDLES)
    force = str(request.args.get("refresh", "0")).lower() in {"1", "true", "yes"}
    ck = f"performance:{symbol}:{tf}:{limit}"
    if not force:
        hit = _heavy_cache_get(ck, _HEAVY_API_TTL["performance"])
        if hit is not None:
            return jsonify(hit)
    result = backtest_signal_logic(symbol, tf, limit)
    wf = walk_forward_backtest(symbol, tf, limit, max(200, min(300, limit//3)), max(50, min(100, limit//8))) if result.get("ok") else {"ok": False}
    audit = get_audit_stats()
    strategies = result.get("professional", {}).get("strategy_lab", {}) if result.get("ok") else {}
    payload = {"ok": bool(result.get("ok")), "symbol": symbol, "timeframe": tf, "backtest": result, "walk_forward": wf, "historical": audit, "strategies": strategies}
    _heavy_cache_put(ck, payload)
    return jsonify(payload)

@app.get("/api/pro-lab")
def api_pro_lab():
    symbol = _normalize_symbol(request.args.get("symbol", USER_SETTINGS.get("active_coins", DEFAULT_COINS)[0]))
    tf = _query_timeframe()
    limit = _query_int("limit", 1000, 200, MAX_BACKTEST_CANDLES)
    force = str(request.args.get("refresh", "0")).lower() in {"1", "true", "yes"}
    ck = f"prolab:{symbol}:{tf}:{limit}"
    if not force:
        hit = _heavy_cache_get(ck, _HEAVY_API_TTL["pro_lab"])
        if hit is not None:
            return jsonify(hit)
    result = backtest_signal_logic(symbol, tf, limit)
    payload = {"ok": bool(result.get("ok")), "suite": {"modules": 12, "status": "ACTIVE"}, "result": result}
    _heavy_cache_put(ck, payload)
    return jsonify(payload)

@app.get("/api/ai-votes")
def api_ai_votes():
    """Aggregate AI model votes across active symbols for dashboard AI tab."""
    data, _summary, _macro = _fast_market_snapshot()
    if not data:
        _background_market_refresh(False)
    board = []
    tally = {"LONG": 0, "SHORT": 0, "WAIT": 0, "providers": {}}
    for item in data or []:
        ai = item.get("ai_opinions") or {}
        ens = (item.get("edge") or {}).get("ai") or TITAN_EDGE_SUITE.ai_ensemble(ai, item.get("bias", "خنثی"))
        votes = ens.get("votes") or {}
        details = ens.get("details") or {}
        row = {
            "symbol": item.get("symbol"),
            "bias": item.get("bias"),
            "decision_tag": item.get("decision_tag") or "WAIT",
            "score": item.get("score"),
            "titan": "LONG" if item.get("bias") == "صعودی" else "SHORT" if item.get("bias") == "نزولی" else "WAIT",
            "majority": ens.get("majority", "WAIT"),
            "agreement": ens.get("agreement", 0),
            "status": ens.get("status", "NO_AI_DATA"),
            "votes": votes,
            "details": details,
            "gemini": ai.get("gemini") or "",
            "openai": ai.get("openai") or "",
            "grok": ai.get("grok") or "",
            "claude": ai.get("claude") or "",
            "deepseek": ai.get("deepseek") or "",
        }
        board.append(row)
        maj = row["majority"]
        if maj in tally:
            tally[maj] += 1
        for p, v in votes.items():
            bucket = tally["providers"].setdefault(p, {"LONG": 0, "SHORT": 0, "WAIT": 0})
            if v in bucket:
                bucket[v] += 1
    return jsonify({"ok": True, "board": board, "tally": tally, "count": len(board)})


@app.get("/api/gemini-analysis")
def api_gemini_analysis():
    """Return fresh Gemini global analysis instead of only reading the cache.

    This endpoint is intentionally fail-safe: cached market data is reused when
    available, and a fresh Gemini request is attempted whenever the caller asks
    for a refresh or the cached summary is empty.
    """
    reload_keys()
    data, summary, macro = _load_market_cache()
    force = str(request.args.get("refresh", "0")).lower() in {"1", "true", "yes", "on"}
    if not data:
        try:
            data, summary, macro = update_cache(False)
        except Exception as exc:
            LOGGER.exception("Gemini endpoint cache update failed: %s", exc)
    if GEMINI_API_KEY and data and (force or not str(summary or "").strip()):
        try:
            fresh = _global_ai_summary(data, macro)
            if fresh:
                summary = fresh
                _save_json(MARKET_CACHE_PATH, {"timestamp": time.time(), "data": data, "gemini_summary": summary, "macro": macro})
                with CACHE_LOCK:
                    CACHE.update(timestamp=time.time(), data=data, gemini_summary=summary, macro=macro)
        except Exception as exc:
            LOGGER.exception("Gemini global refresh failed: %s", exc)
    return jsonify({
        "ok": True,
        "provider": "Gemini",
        "available": bool(GEMINI_API_KEY),
        "ready": bool(str(summary or "").strip()),
        "analysis": summary or "",
        "macro": macro,
        "error": (GEMINI_LAST_ERROR if not str(summary or '').strip() else ""),
    })



@app.get("/api/gemini-symbol")
def api_gemini_symbol():
    """Real Gemini analysis for one symbol from live TITAN dossier fields."""
    reload_keys()
    symbol = _normalize_symbol(request.args.get("symbol", "BTC/USDT"))
    if not GEMINI_API_KEY:
        return jsonify({"ok": False, "available": False, "error": "کلید Gemini موجود نیست", "analysis": ""}), 200
    item = None
    try:
        with CACHE_LOCK:
            rows = list(CACHE.get("data") or [])
        for r in rows:
            if isinstance(r, dict) and str(r.get("symbol") or "") == symbol:
                item = r
                break
        if item is None:
            data, _, _ = _load_market_cache()
            for r in (data or []):
                if isinstance(r, dict) and str(r.get("symbol") or "") == symbol:
                    item = r
                    break
    except Exception:
        _swallow()
    if not item:
        return jsonify({"ok": False, "available": True, "error": "داده نماد در کش نیست", "analysis": "", "symbol": symbol}), 200
    payload = {
        "symbol": symbol,
        "price": item.get("price"),
        "bias": item.get("bias"),
        "decision": item.get("decision_tag") or item.get("stance_family") or "WAIT",
        "score": item.get("score"),
        "alignment": item.get("alignment"),
        "signal_quality": item.get("signal_quality"),
        "success_probability": item.get("success_probability"),
        "rsi": item.get("rsi"),
        "tfs": item.get("tfs") or {},
        "entry": item.get("entry_valid") or item.get("entry"),
        "stop_loss": item.get("stop_loss"),
        "tp1": item.get("tp1"),
        "tp2": item.get("tp2"),
        "rr1": item.get("rr_tp1"),
        "rr2": item.get("rr_tp2"),
        "oi": item.get("coinglass_oi"),
        "funding": item.get("coinglass_funding"),
        "buy_sell": item.get("buy_sell"),
        "regime": item.get("regime"),
        "structure": item.get("structure"),
    }
    try:
        text = _call_gemini(payload, global_summary=False)
        return jsonify({
            "ok": bool(text),
            "available": True,
            "symbol": symbol,
            "analysis": text or "",
            "error": (GEMINI_LAST_ERROR if not text else ""),
            "provider": "Gemini",
        })
    except Exception as exc:
        LOGGER.exception("gemini-symbol failed")
        return jsonify({"ok": False, "available": True, "symbol": symbol, "analysis": "", "error": str(exc)[:200]}), 200


@app.get("/api/gemini-debug")
def api_gemini_debug():
    reload_keys()
    models = _gemini_available_models() if GEMINI_API_KEY else []
    return jsonify({
        "ok": True,
        "available": bool(GEMINI_API_KEY),
        "models": models[:20],
        "last_error": GEMINI_LAST_ERROR,
        "storage": str(APP_HOME),
    })

@app.route("/health")
def health():
    """Lightweight liveness + storage + key presence (no secrets leaked)."""
    with CACHE_LOCK:
        age = time.time() - CACHE["timestamp"] if CACHE.get("timestamp") else None
        assets = len(CACHE.get("data") or [])
    db_ok, db_msg = True, "ok"
    try:
        with DB_LOCK, db_conn() as con:
            con.execute("SELECT 1").fetchone()
            db_msg = con.execute("PRAGMA quick_check").fetchone()[0]
            db_ok = str(db_msg).lower() == "ok"
    except Exception as exc:
        db_ok, db_msg = False, str(exc)[:120]
    status = "ok" if db_ok else "degraded"
    live = {}
    try:
        live = _live_status()
    except Exception:
        _swallow()
        live = {}
    return jsonify({
        "status": status,
        "ok": db_ok,
        "build": TITAN_BUILD_ID,
        "home": str(APP_HOME),
        "gemini": bool(GEMINI_API_KEY),
        "openai": bool(OPENAI_API_KEY),
        "grok": bool(GROK_API_KEY),
        "claude": bool(CLAUDE_API_KEY),
        "deepseek": bool(DEEPSEEK_API_KEY),
        "coinglass": bool(COINGLASS_API_KEY),
        "cache_age_seconds": round(age, 2) if age is not None else None,
        "assets": assets,
        "live": live,
        "database": {"ok": db_ok, "quick_check": str(db_msg)[:80]},
        "storage_enforced": True,
        "storage_root": str(APP_HOME),
        "single_folder_mode": TITAN_FOLDER_NAME,
        "analysis_only": True,
        "orders_disabled": True,
    }), (200 if db_ok else 503)

# ============================================================
# STARTUP
# ============================================================
