# [TITAN V77 layer] desk/v54_replay_telegram - V54 replay / telegram / multi-exchange / news
# Original V76 source lines 21977-22829 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# TITAN V54 — REPLAY / TELEGRAM / MULTI-EXCHANGE / NEWS-FILTER ADD-ON
# ============================================================
# Integration contract (does not touch any earlier decision logic):
#   * News blackout + multi-exchange crowding are applied at CANDIDATE level, i.e. BEFORE the V52 trust
#     gate and BEFORE the V49 ledger write, so the learning ledger never contains a signal that was
#     blocked by these filters.
#   * Telegram alerts are sent only AFTER publication (decision LONG/SHORT + READY_FOR_PUBLICATION).
#   * Historical replay is a separate background job; it never writes to the live ledger.
# Analysis only. No order execution.
import html as _v54_html
import queue as _v54_queue
from datetime import timedelta as _v54_timedelta
try:
    from zoneinfo import ZoneInfo as _V54ZoneInfo
except Exception:                                    # pragma: no cover
    _V54ZoneInfo = None

V54_VERSION = "TITAN-V54-REPLAY-ALERTS-MULTIVENUE-NEWS"
V54_SETTINGS_PATH = DATA_DIR / "v54_settings.json"
V54_EVENTS_PATH = DATA_DIR / "v54_events.json"
V54_HIST_DIR = HIST_DIR
V54_REPLAY_DIR = REPLAY_DIR
V54_DEFAULTS: dict[str, Any] = {
    "news_filter": {"enabled": True, "mode": "block", "default_before_min": 30, "default_after_min": 60,
                    "builtin_fomc": True, "builtin_nfp": True},
    "multi_exchange": {"enabled": True, "mode": "annotate", "crowded_funding_pct": 0.05,
                       "max_price_divergence_pct": 0.35, "cache_ttl_sec": 45, "timeout_sec": 5},
    "telegram": {"enabled": True, "cooldown_sec": 3 * 3600, "min_trust": 0.0,
                 "quiet_hours_utc": None, "max_queue": 100},
}
_V54_SETTINGS_CACHE: dict[str, Any] = {"mtime": -1.0, "data": None}
_V54_SETTINGS_LOCK = threading.Lock()


def _v54_deep_merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        if isinstance(v, dict) and isinstance(out.get(k), dict):
            out[k] = _v54_deep_merge(out[k], v)
        else:
            out[k] = v
    return out


def v54_settings() -> dict[str, Any]:
    """User-editable settings (DATA_DIR/v54_settings.json) merged over safe defaults; reloaded on file change."""
    with _V54_SETTINGS_LOCK:
        try:
            mt = V54_SETTINGS_PATH.stat().st_mtime if V54_SETTINGS_PATH.exists() else 0.0
        except OSError:
            mt = 0.0
        if _V54_SETTINGS_CACHE["data"] is not None and _V54_SETTINGS_CACHE["mtime"] == mt:
            return _V54_SETTINGS_CACHE["data"]
        user = _load_json(V54_SETTINGS_PATH, {}) if mt else {}
        data = _v54_deep_merge(V54_DEFAULTS, user if isinstance(user, dict) else {})
        if not mt:
            _save_json(V54_SETTINGS_PATH, V54_DEFAULTS)   # write a template the user can edit
            try:
                mt = V54_SETTINGS_PATH.stat().st_mtime
            except OSError:
                mt = 0.0
        _V54_SETTINGS_CACHE.update(mtime=mt, data=data)
        return data


# ------------------------------------------------------------------ 1) NEWS / ECONOMIC CALENDAR
# FOMC 2026 decision days (statement 14:00 America/New_York). Verify yearly against federalreserve.gov.
_V54_FOMC_2026 = ["2026-01-28", "2026-03-18", "2026-04-29", "2026-06-17",
                  "2026-07-29", "2026-09-16", "2026-10-28", "2026-12-09"]


def _v54_et_to_utc(y: int, m: int, d: int, hh: int, mm: int) -> datetime:
    if _V54ZoneInfo is not None:
        try:
            return datetime(y, m, d, hh, mm, tzinfo=_V54ZoneInfo("America/New_York")).astimezone(timezone.utc)
        except Exception:
            _swallow()
    # fallback: US DST approx (second Sunday March .. first Sunday November)
    dt = datetime(y, m, d, hh, mm)
    off = 4 if 3 <= m <= 10 else 5
    return (dt + _v54_timedelta(hours=off)).replace(tzinfo=timezone.utc)


def _v54_nfp_date(year: int, month: int) -> tuple[int, int, int]:
    """Release date (y, m, d) of the jobs report for DATA month (year, month).
    BLS rule: 3rd Friday after the end (Saturday) of the reference week containing the 12th.
    Holiday shifts (e.g. Jul 3 2026 -> Jul 2) are NOT modelled; override via v54_events.json."""
    ref = datetime(year, month, 12)
    days_to_sat = (5 - ref.weekday()) % 7          # Monday=0 ... Saturday=5
    sat = ref + _v54_timedelta(days=days_to_sat)
    # BLS reference-week is Sunday..Saturday containing the 12th; release is for the PREVIOUS month's data
    rel = sat + _v54_timedelta(days=20)
    return rel.year, rel.month, rel.day


def _v54_builtin_events(now_ts: float) -> list[dict[str, Any]]:
    cfg = v54_settings()["news_filter"]
    out: list[dict[str, Any]] = []
    if cfg.get("builtin_fomc", True):
        for ds in _V54_FOMC_2026:
            y, m, d = (int(x) for x in ds.split("-"))
            out.append({"name": "FOMC Rate Decision", "time_utc": _v54_et_to_utc(y, m, d, 14, 0).timestamp(),
                        "impact": "high", "before_min": 60, "after_min": 120, "symbols": [], "source": "builtin"})
    if cfg.get("builtin_nfp", True):
        base = datetime.fromtimestamp(now_ts, tz=timezone.utc)
        for k in (-2, -1, 0, 1):          # data months -> releases fall in the previous/current/next month
            mm = base.month - 1 + k
            y, m = base.year + mm // 12, mm % 12 + 1
            ry, rm, rd = _v54_nfp_date(y, m)
            out.append({"name": "US Non-Farm Payrolls (approx.)",
                        "time_utc": _v54_et_to_utc(ry, rm, rd, 8, 30).timestamp(),
                        "impact": "high", "before_min": 30, "after_min": 60, "symbols": [], "source": "builtin"})
    return out


def _v54_parse_ts(v: Any) -> Optional[float]:
    if isinstance(v, (int, float)) and math.isfinite(float(v)):
        return float(v) / 1000.0 if float(v) > 1e11 else float(v)
    try:
        s = str(v).strip().replace("Z", "+00:00")
        dt = datetime.fromisoformat(s)
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=timezone.utc)
        return dt.timestamp()
    except Exception:
        _swallow()
        return None


def _v54_user_events() -> list[dict[str, Any]]:
    """DATA_DIR/v54_events.json: [{"name","time_utc","impact":"high|medium","before_min","after_min","symbols":[]}]
    Use it for CPI, PPI, token unlocks, exchange listings, ETF decisions... A template is created on first run."""
    if not V54_EVENTS_PATH.exists():
        _save_json(V54_EVENTS_PATH, {"_help": "Add events: name, time_utc (ISO, e.g. 2026-10-14T12:30:00Z), impact (high|medium), "
                                     "before_min, after_min, symbols (e.g. [\"SOL/USDT\"], empty = all)",
                                     "events": []})
        return []
    raw = _load_json(V54_EVENTS_PATH, {})
    rows = raw.get("events") if isinstance(raw, dict) else raw
    out = []
    for e in rows or []:
        if not isinstance(e, dict):
            continue
        ts = _v54_parse_ts(e.get("time_utc"))
        if ts is None:
            continue
        out.append({"name": str(e.get("name") or "Event")[:80], "time_utc": ts,
                    "impact": str(e.get("impact") or "high").lower(),
                    "before_min": int(safe_float(e.get("before_min"), v54_settings()["news_filter"]["default_before_min"])),
                    "after_min": int(safe_float(e.get("after_min"), v54_settings()["news_filter"]["default_after_min"])),
                    "symbols": [_normalize_symbol(str(s)) for s in (e.get("symbols") or [])], "source": "user"})
    return out


def v54_news_state(symbol: str, now_ts: Optional[float] = None) -> dict[str, Any]:
    """Pure local computation (no network): active blackout windows + events in the next 24h."""
    now_ts = time.time() if now_ts is None else float(now_ts)
    cfg = v54_settings()["news_filter"]
    if not cfg.get("enabled", True):
        return {"enabled": False, "blackout": False, "active": [], "upcoming_24h": []}
    sym = _normalize_symbol(symbol)
    active, upcoming = [], []
    for e in _v54_builtin_events(now_ts) + _v54_user_events():
        if e["symbols"] and sym not in e["symbols"]:
            continue
        t = float(e["time_utc"])
        rec = {"name": e["name"], "impact": e["impact"], "time_utc": datetime.fromtimestamp(t, tz=timezone.utc).isoformat(timespec="minutes"),
               "minutes_to_event": round((t - now_ts) / 60.0, 1), "source": e["source"]}
        if t - e["before_min"] * 60 <= now_ts <= t + e["after_min"] * 60 and e["impact"] in {"high", "medium"}:
            if e["impact"] == "high" or cfg.get("mode") == "block_all":
                active.append(rec)
        elif 0 < t - now_ts <= 86400:
            upcoming.append(rec)
    upcoming.sort(key=lambda r: r["minutes_to_event"])
    return {"enabled": True, "mode": cfg.get("mode", "block"), "blackout": bool(active),
            "active": active, "upcoming_24h": upcoming[:6]}


# ------------------------------------------------------------------ 2) MULTI-EXCHANGE DERIVATIVES
_V54_MX_CACHE: dict[str, tuple[float, dict[str, Any]]] = {}
_V54_MX_LOCK = threading.Lock()
_V54_POOL: Optional[ThreadPoolExecutor] = None
_V54_POOL_LOCK = threading.Lock()


def _v54_pool() -> ThreadPoolExecutor:
    global _V54_POOL
    with _V54_POOL_LOCK:
        if _V54_POOL is None:
            _V54_POOL = ThreadPoolExecutor(max_workers=4, thread_name_prefix="titan-v54")
        return _V54_POOL


def _v54_get_json(url: str, params: dict, timeout: float) -> Optional[Any]:
    try:
        r = _http_session().get(url, params=params, timeout=timeout)
        return r.json() if r.ok else None
    except Exception:
        _swallow()
        return None


def _v54_base_quote(symbol: str) -> str:
    return _binance_symbol(symbol).replace("USDT", "")


def _v54_fetch_bybit(symbol: str, timeout: float) -> Optional[dict[str, Any]]:
    js = _v54_get_json("https://api.bybit.com/v5/market/tickers",
                       {"category": "linear", "symbol": _binance_symbol(symbol)}, timeout)
    try:
        row = (js or {}).get("result", {}).get("list", [])[0]
        px = safe_float(row.get("lastPrice"), 0)
        if px <= 0:
            return None
        fr = row.get("fundingRate")
        return {"venue": "Bybit", "price": px,
                "funding_pct": safe_float(fr, np.nan) * 100 if fr not in (None, "") else None,
                "oi_usd": safe_float(row.get("openInterestValue"), 0) or None}
    except Exception:
        _swallow()
        return None


def _v54_fetch_okx(symbol: str, timeout: float) -> Optional[dict[str, Any]]:
    inst = f"{_v54_base_quote(symbol)}-USDT-SWAP"
    base = "https://www.okx.com/api/v5"
    tk = _v54_get_json(f"{base}/market/ticker", {"instId": inst}, timeout)
    try:
        px = safe_float(((tk or {}).get("data") or [{}])[0].get("last"), 0)
    except Exception:
        _swallow()
        px = 0
    if px <= 0:
        return None
    fr = _v54_get_json(f"{base}/public/funding-rate", {"instId": inst}, timeout)
    oi = _v54_get_json(f"{base}/public/open-interest", {"instType": "SWAP", "instId": inst}, timeout)
    try:
        fv = safe_float(((fr or {}).get("data") or [{}])[0].get("fundingRate"), np.nan)
    except Exception:
        _swallow()
        fv = np.nan
    try:
        oiu = safe_float(((oi or {}).get("data") or [{}])[0].get("oiUsd"), 0) or None
    except Exception:
        _swallow()
        oiu = None
    return {"venue": "OKX", "price": px, "funding_pct": fv * 100 if np.isfinite(fv) else None, "oi_usd": oiu}


def v54_aggregate_venues(rows: list[dict[str, Any]], ref_price: float = 0.0, ref_funding_pct: Optional[float] = None,
                         side: str = "", cfg: Optional[dict] = None) -> dict[str, Any]:
    """Pure aggregation (unit-testable): funding consensus, price divergence, crowding flags."""
    cfg = cfg or v54_settings()["multi_exchange"]
    venues = [r for r in rows if r]
    prices = [float(r["price"]) for r in venues if r.get("price")]
    if ref_price and ref_price > 0:
        prices.append(float(ref_price))
    fund = [float(r["funding_pct"]) for r in venues if r.get("funding_pct") is not None and np.isfinite(r["funding_pct"])]
    if ref_funding_pct is not None and np.isfinite(ref_funding_pct):
        fund.append(float(ref_funding_pct))
    div = ((max(prices) - min(prices)) / (sum(prices) / len(prices)) * 100.0) if len(prices) >= 2 else None
    fmean = float(np.mean(fund)) if fund else None
    flags: list[str] = []
    thr = float(cfg.get("crowded_funding_pct", 0.05))
    if fmean is not None:
        if side == "LONG" and fmean >= thr:
            flags.append("crowded_long_funding")
        if side == "SHORT" and fmean <= -thr:
            flags.append("crowded_short_funding")
    if div is not None and div > float(cfg.get("max_price_divergence_pct", 0.35)):
        flags.append("venue_price_divergence")
    if len(fund) >= 2 and (max(fund) > 0) != (min(fund) > 0) and max(abs(x) for x in fund) >= thr * 0.5:
        flags.append("funding_sign_conflict")
    return {"venues": venues, "venue_count": len(venues) + (1 if ref_price else 0),
            "funding_mean_pct": None if fmean is None else round(fmean, 5),
            "funding_dispersion_pct": round(float(np.std(fund)), 5) if len(fund) >= 2 else None,
            "price_divergence_pct": None if div is None else round(div, 4),
            "oi_usd_bybit_okx": round(sum(float(r.get("oi_usd") or 0) for r in venues), 2) or None,
            "flags": flags, "side": side}


def v54_multi_exchange(symbol: str, side: str = "", ref_price: float = 0.0, ref_funding_pct: Optional[float] = None) -> dict[str, Any]:
    cfg = v54_settings()["multi_exchange"]
    if not cfg.get("enabled", True):
        return {"enabled": False, "flags": []}
    key = _normalize_symbol(symbol)
    ttl = float(cfg.get("cache_ttl_sec", 45))
    with _V54_MX_LOCK:
        hit = _V54_MX_CACHE.get(key)
    rows = None
    if hit and time.time() - hit[0] < ttl:
        rows = hit[1]["rows"]
    if rows is None:
        to = float(cfg.get("timeout_sec", 5))
        pool = _v54_pool()
        futs = [pool.submit(_v54_fetch_bybit, symbol, to), pool.submit(_v54_fetch_okx, symbol, to)]
        rows = []
        for fu in futs:
            try:
                rows.append(fu.result(timeout=to * 3 + 2))
            except Exception:
                _swallow()
        with _V54_MX_LOCK:
            if len(_V54_MX_CACHE) > 200:
                _V54_MX_CACHE.pop(next(iter(_V54_MX_CACHE)), None)
            _V54_MX_CACHE[key] = (time.time(), {"rows": rows})
    out = v54_aggregate_venues(rows, ref_price, ref_funding_pct, side, cfg)
    out["enabled"] = True
    out["mode"] = cfg.get("mode", "annotate")
    return out


# ------------------------------------------------------------------ 3) TELEGRAM ALERTS
_V54_TG_QUEUE: "_v54_queue.Queue[dict[str, Any]]" = _v54_queue.Queue(maxsize=200)
_V54_TG_THREAD: Optional[threading.Thread] = None
_V54_TG_LOCK = threading.Lock()
_V54_TG_SENT: dict[str, float] = {}        # "SYMBOL|SIDE" -> last sent ts
_V54_TG_HASHES: dict[str, float] = {}
_V54_TG_STATS = {"queued": 0, "sent": 0, "failed": 0, "deduped": 0, "suppressed": 0}


def _v54_read_secret(env_name: str, filenames: list[str]) -> str:
    v = os.environ.get(env_name, "").strip()
    if v:
        return v
    for fn in filenames:
        for base in (SECRETS_DIR, APP_HOME, DATA_DIR):
            try:
                p = base / fn
                if p.is_file():
                    txt = p.read_text(encoding="utf-8").lstrip("\ufeff").strip()
                    if "=" in txt and "\n" not in txt:
                        txt = txt.split("=", 1)[1].strip()
                    txt = txt.strip("\"'")
                    if txt:
                        return txt
            except OSError:
                _swallow()
    return ""


def v54_telegram_credentials() -> tuple[str, str]:
    return (_v54_read_secret("TITAN_TELEGRAM_TOKEN", ["telegram_bot_token.txt", "telegram_token.txt"]),
            _v54_read_secret("TITAN_TELEGRAM_CHAT_ID", ["telegram_chat_id.txt", "telegram_chat.txt"]))


def _v54_alert_init() -> None:
    try:
        with DB_LOCK, db_conn() as con:
            con.execute("""CREATE TABLE IF NOT EXISTS v54_alert_log(
                id INTEGER PRIMARY KEY AUTOINCREMENT, ts REAL NOT NULL, symbol TEXT, side TEXT,
                decision_hash TEXT, status TEXT, detail TEXT)""")
            con.execute("CREATE INDEX IF NOT EXISTS idx_v54_alert_sym ON v54_alert_log(symbol, side, ts)")
            con.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_v54_alert_hash ON v54_alert_log(decision_hash) WHERE status='SENT' AND decision_hash IS NOT NULL")
    except Exception as exc:
        LOGGER.debug("V54 alert schema: %s", exc)


def _v54_alert_log(symbol: str, side: str, dhash: str, status: str, detail: str = "") -> None:
    try:
        with DB_LOCK, db_conn() as con:
            con.execute("INSERT OR IGNORE INTO v54_alert_log(ts,symbol,side,decision_hash,status,detail) VALUES(?,?,?,?,?,?)",
                        (time.time(), symbol, side, dhash or None, status, str(detail)[:200]))
    except Exception:
        _swallow()


def _v54_last_sent(symbol: str, side: str) -> float:
    key = f"{symbol}|{side}"
    if key in _V54_TG_SENT:
        return _V54_TG_SENT[key]
    try:
        with DB_LOCK, db_conn() as con:
            r = con.execute("SELECT MAX(ts) FROM v54_alert_log WHERE symbol=? AND side=? AND status='SENT'", (symbol, side)).fetchone()
        return float(r[0] or 0.0)
    except Exception:
        _swallow()
        return 0.0


def _v54_in_quiet_hours(now_ts: float, quiet: Any) -> bool:
    try:
        if not quiet or len(quiet) != 2:
            return False
        a, b = int(quiet[0]) % 24, int(quiet[1]) % 24
        h = datetime.fromtimestamp(now_ts, tz=timezone.utc).hour
        return (a <= h < b) if a < b else (h >= a or h < b)
    except Exception:
        _swallow()
        return False


def v54_format_alert(item: dict[str, Any]) -> str:
    e = _v54_html.escape
    side = str(item.get("decision") or "")
    icon = "🟢" if side == "LONG" else "🔴"
    px = safe_float(item.get("price_raw", item.get("live_price")), 0)

    def fmt(v):
        v = safe_float(v, 0)
        return "—" if v <= 0 else (f"{v:,.4f}" if v < 100 else f"{v:,.2f}")
    prob = item.get("success_probability")
    prob_txt = (f"{safe_float(prob, 0):.1f}%" if item.get("success_probability_is_calibrated") and prob is not None
                else "کالیبره نشده")
    lines = [f"{icon} <b>{e(str(item.get('symbol')))}</b> — <b>{'خرید (LONG)' if side == 'LONG' else 'فروش (SHORT)'}</b>",
             f"قیمت: <code>{fmt(px)}</code>",
             f"حد ضرر: <code>{fmt(item.get('stop_loss_raw'))}</code>",
             f"هدف ۱: <code>{fmt(item.get('tp1_raw'))}</code>   هدف ۲: <code>{fmt(item.get('tp2_raw'))}</code>",
             f"R/R مؤثر: {safe_float(item.get('effective_rr_tp1'), 0):.2f}   |   اعتماد: {safe_float(item.get('trust'), 0):.0f}/100",
             f"احتمال موفقیت: {prob_txt}"]
    mx = item.get("multi_exchange") or {}
    if mx.get("flags"):
        lines.append("⚠️ " + e(", ".join(mx["flags"])))
    nxt = (item.get("news_calendar") or {}).get("upcoming_24h") or []
    if nxt:
        lines.append(f"📅 رویداد نزدیک: {e(str(nxt[0]['name']))} (~{abs(nxt[0]['minutes_to_event']):.0f} دقیقه)")
    lines.append("<i>تحلیل آماری؛ توصیه‌ی مالی نیست.</i>")
    return "\n".join(lines)[:4000]


def _v54_send_telegram(text: str, token: str, chat_id: str, session=None) -> tuple[bool, str]:
    sess = session or _http_session()
    url = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {"chat_id": chat_id, "text": text, "parse_mode": "HTML", "disable_web_page_preview": True}
    last = ""
    for attempt in range(3):
        try:
            r = sess.post(url, json=payload, timeout=10)
            if r.status_code == 429:
                try:
                    wait = float(r.json().get("parameters", {}).get("retry_after", 2))
                except Exception:
                    _swallow()
                    wait = 2.0
                time.sleep(min(wait, 30)); last = "429"; continue
            if r.ok:
                return True, "OK"
            last = f"HTTP {r.status_code}"
            if 400 <= r.status_code < 500:
                break                                     # bad token / chat id: do not retry
        except Exception as exc:
            last = type(exc).__name__                     # never include the URL (it contains the token)
        time.sleep(1.5 * (attempt + 1))
    return False, last


def _v54_tg_worker() -> None:
    while not LIVE_STOP.is_set():
        try:
            job = _V54_TG_QUEUE.get(timeout=2)
        except _v54_queue.Empty:
            continue
        try:
            token, chat = v54_telegram_credentials()
            if not token or not chat:
                _V54_TG_STATS["failed"] += 1
                _v54_alert_log(job["symbol"], job["side"], job["hash"], "NO_CREDENTIALS")
                continue
            ok, detail = _v54_send_telegram(job["text"], token, chat)
            if ok:
                _V54_TG_STATS["sent"] += 1
                _V54_TG_SENT[f"{job['symbol']}|{job['side']}"] = time.time()
                _v54_alert_log(job["symbol"], job["side"], job["hash"], "SENT")
            else:
                _V54_TG_STATS["failed"] += 1
                _v54_alert_log(job["symbol"], job["side"], job["hash"], "FAILED", detail)
                LOGGER.warning("Telegram send failed: %s", detail)
            time.sleep(1.1)                               # Telegram: ~1 msg/sec per chat
        except Exception as exc:
            LOGGER.warning("Telegram worker error: %s", type(exc).__name__)


def _v54_ensure_tg_worker() -> None:
    global _V54_TG_THREAD
    with _V54_TG_LOCK:
        if _V54_TG_THREAD is None or not _V54_TG_THREAD.is_alive():
            _v54_alert_init()
            _V54_TG_THREAD = threading.Thread(target=_v54_tg_worker, name="titan-v54-telegram", daemon=True)
            _V54_TG_THREAD.start()


def v54_enqueue_alert(item: dict[str, Any], now_ts: Optional[float] = None) -> str:
    """Returns QUEUED / DEDUP / COOLDOWN / QUIET / LOW_TRUST / DISABLED / NO_CREDENTIALS / NOT_PUBLISHED / QUEUE_FULL."""
    cfg = v54_settings()["telegram"]
    if not cfg.get("enabled", True):
        return "DISABLED"
    side = str(item.get("decision") or "")
    if side not in {"LONG", "SHORT"} or "READY_FOR_PUBLICATION" not in str(item.get("decision_state") or ""):
        return "NOT_PUBLISHED"
    token, chat = v54_telegram_credentials()
    if not token or not chat:
        return "NO_CREDENTIALS"
    now_ts = time.time() if now_ts is None else now_ts
    sym = str(item.get("symbol") or "")
    dhash = str(item.get("decision_hash") or "")
    if safe_float(item.get("trust"), 0) < float(cfg.get("min_trust", 0.0)):
        return "LOW_TRUST"
    if _v54_in_quiet_hours(now_ts, cfg.get("quiet_hours_utc")):
        _V54_TG_STATS["suppressed"] += 1
        return "QUIET"
    with _V54_TG_LOCK:
        if dhash and dhash in _V54_TG_HASHES:
            _V54_TG_STATS["deduped"] += 1
            return "DEDUP"
        if now_ts - _v54_last_sent(sym, side) < float(cfg.get("cooldown_sec", 10800)):
            _V54_TG_STATS["deduped"] += 1
            return "COOLDOWN"
        if dhash:
            if len(_V54_TG_HASHES) > 2000:
                _V54_TG_HASHES.clear()
            _V54_TG_HASHES[dhash] = now_ts
        # reserve the cooldown slot immediately so parallel scans cannot double-send
        _V54_TG_SENT[f"{sym}|{side}"] = now_ts
    _v54_ensure_tg_worker()
    try:
        _V54_TG_QUEUE.put_nowait({"text": v54_format_alert(item), "symbol": sym, "side": side, "hash": dhash})
        _V54_TG_STATS["queued"] += 1
        return "QUEUED"
    except _v54_queue.Full:
        return "QUEUE_FULL"


# ------------------------------------------------------------------ 4) HISTORICAL REPLAY
_V54_JOBS: dict[str, dict[str, Any]] = {}
_V54_JOBS_LOCK = threading.Lock()


def _v54_hist_path(symbol: str, tf: str) -> Path:
    safe = "".join(ch for ch in _binance_symbol(symbol) if ch.isalnum())
    return _safe_app_path(V54_HIST_DIR / f"{safe}_{''.join(ch for ch in str(tf) if ch.isalnum())}.csv.gz")


def v54_load_history(symbol: str, tf: str) -> pd.DataFrame:
    p = _v54_hist_path(symbol, tf)
    if not p.is_file():
        return pd.DataFrame(columns=["t", "open", "high", "low", "close", "vol", "T"])
    try:
        df = pd.read_csv(p)
        return df.sort_values("t").drop_duplicates("t", keep="last").reset_index(drop=True)
    except Exception as exc:
        LOGGER.warning("History read failed %s: %s", p.name, exc)
        return pd.DataFrame(columns=["t", "open", "high", "low", "close", "vol", "T"])


def v54_download_history(symbol: str, tf: str = "1h", years: float = 2.0, max_requests: int = 600,
                         fetcher=None, progress=None, sleep_sec: float = 0.12) -> dict[str, Any]:
    """Incremental paginated download (1000 candles/request) cached under LLL/cache/history. Resumable."""
    fetcher = fetcher or fetch_klines
    step = tf_to_ms(tf)
    now_ms = int(time.time() * 1000)
    want_from = now_ms - int(years * 365.25 * 86400 * 1000)
    old = v54_load_history(symbol, tf)
    cur = want_from if old.empty else max(want_from, int(old["t"].iloc[-1]) + step)
    frames, requests_done, err = [], 0, None
    while cur < now_ms - step and requests_done < max_requests:
        try:
            df = fetcher(symbol, tf, 1000, start_ms=cur, end_ms=now_ms)
        except Exception as exc:
            msg = str(exc)
            if "Insufficient closed candles" in msg:      # reached the live edge
                break
            err = msg[:160]
            requests_done += 1
            time.sleep(min(2.0, sleep_sec * 5))
            if err and requests_done >= 3 and not frames:
                break
            continue
        requests_done += 1
        if df is None or len(df) == 0:
            break
        frames.append(df)
        last_t = int(df["t"].iloc[-1])
        if last_t < cur:
            break
        cur = last_t + step
        if progress:
            try:
                progress(min(0.99, (cur - want_from) / max(1, now_ms - want_from)))
            except Exception:
                _swallow()
        if len(df) < 5:
            break
        time.sleep(sleep_sec)
    new = pd.concat([old] + frames, ignore_index=True) if frames else old
    if not new.empty:
        new = new.sort_values("t").drop_duplicates("t", keep="last").reset_index(drop=True)
        new = new[new["t"] >= want_from].reset_index(drop=True)
        p = _v54_hist_path(symbol, tf)
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_name(p.name + ".tmp")
        new.to_csv(tmp, index=False, compression="gzip")
        tmp.replace(p)
    gaps = int((np.diff(new["t"].to_numpy()) > step * 1.5).sum()) if len(new) > 1 else 0
    return {"symbol": symbol, "timeframe": tf, "candles": int(len(new)), "requests": requests_done,
            "gaps": gaps, "error": err, "from": None if new.empty else float(new["t"].iloc[0]),
            "to": None if new.empty else float(new["t"].iloc[-1])}


def _v54_period_breakdown(trades: list[dict[str, Any]], t_index: np.ndarray, freq: str = "Q") -> list[dict[str, Any]]:
    if not trades:
        return []
    rows = []
    buckets: dict[str, list[dict[str, Any]]] = {}
    for tr in trades:
        ts = float(t_index[min(int(tr["i"]), len(t_index) - 1)]) / 1000.0
        d = datetime.fromtimestamp(ts, tz=timezone.utc)
        key = f"{d.year}-Q{(d.month - 1) // 3 + 1}" if freq == "Q" else f"{d.year}-{d.month:02d}"
        buckets.setdefault(key, []).append(tr)
    for key in sorted(buckets):
        b = buckets[key]
        rs = np.asarray([x["r_net"] for x in b], dtype=float)
        rows.append({"period": key, "trades": len(b), "expectancy_r": round(float(rs.mean()), 4),
                     "win_rate_net": round(float((np.asarray([x["net_pct"] for x in b]) > 0).mean() * 100), 1),
                     "sum_r": round(float(rs.sum()), 3)})
    return rows


def _v54_equity_stats(trades: list[dict[str, Any]]) -> dict[str, Any]:
    if not trades:
        return {"max_drawdown_r": 0.0, "longest_losing_streak": 0, "profit_factor": None, "sum_r": 0.0}
    rs = np.asarray([t["r_net"] for t in trades], dtype=float)
    eq = np.cumsum(rs)
    peak = np.maximum.accumulate(np.concatenate([[0.0], eq]))[1:]
    dd = float((peak - eq).max()) if len(eq) else 0.0
    streak = best = 0
    for r in rs:
        streak = streak + 1 if r < 0 else 0
        best = max(best, streak)
    gp, gl = float(rs[rs > 0].sum()), float(-rs[rs < 0].sum())
    return {"max_drawdown_r": round(dd, 3), "longest_losing_streak": int(best),
            "profit_factor": round(gp / gl, 3) if gl > 0 else None, "sum_r": round(float(rs.sum()), 3)}


def v54_replay_core(df: pd.DataFrame, symbol: str, tf: str, run_walk_forward: bool = True) -> dict[str, Any]:
    """Full-history replay of the V45 causal technical pipeline (same signal table, levels, costs, same-bar SL-first rule)."""
    df = df.reset_index(drop=True)
    if len(df) < 400:
        return {"ok": False, "error": "تاریخچه کافی نیست (حداقل ۴۰۰ کندل)", "candles": int(len(df))}
    max_hold = V45_TF_MAX_HOLD.get(str(tf), 12)
    arr = _v45_arrays(df)
    table = _v45_signal_table(df)
    params = {"long_thr": 55.0, "short_thr": 42.0, "adx_min": 0.0}
    trades = _v45_run_sim(arr, table, params, 60, len(df) - 2, max_hold)
    m = _v45_trade_metrics(trades)
    longs = [t for t in trades if t["side"] == "LONG"]
    shorts = [t for t in trades if t["side"] == "SHORT"]
    returns = [t["net_pct"] for t in trades]
    oos = TITAN_EDGE_SUITE.out_of_sample_check(returns, return_unit="pct")
    rnd = _v45_random_baseline(arr, len(trades), (len(longs) / len(trades)) if trades else 0.5, max_hold, 60, len(df) - 2)
    rnd_pct = round(100.0 * sum(1 for x in rnd if x < m["expectancy_r"]) / len(rnd), 1) if rnd else None
    # cost sensitivity: same trades with 2x friction
    harsh = [t["r_net"] - (V45_FRICTION_PCT / max(t["risk_pct"], 1e-9)) for t in trades]
    out: dict[str, Any] = {
        "ok": True, "symbol": symbol, "timeframe": tf, "candles": int(len(df)),
        "from": float(df["t"].iloc[0]), "to": float(df["t"].iloc[-1]),
        "validation_scope": "technical_proxy_full_history_replay_no_historical_ai_or_derivatives",
        "metrics": m, "long_metrics": _v45_trade_metrics(longs), "short_metrics": _v45_trade_metrics(shorts),
        "equity": _v54_equity_stats(trades), "by_quarter": _v54_period_breakdown(trades, df["t"].to_numpy(), "Q"),
        "cost_stress_2x_expectancy_r": round(float(np.mean(harsh)), 4) if harsh else None,
        "random_entry_percentile": rnd_pct, "oos": oos,
        "verdict": _v45_verdict(m, rnd_pct, oos),
        "buy_and_hold_pct": round((float(arr["c"][-1]) / float(arr["c"][0]) - 1.0) * 100.0, 2),
        "note": "این بک‌تست فقط منطق تکنیکال را بازپخش می‌کند؛ AI و مشتقات تاریخی در آن نیستند.",
    }
    if run_walk_forward:
        out["walk_forward"] = walk_forward_backtest(symbol, tf, limit=len(df), df_override=df, table_override=table)
    return out


def v54_replay_job(job_id: str, symbol: str, tf: str, years: float, run_walk_forward: bool) -> None:
    def upd(**kw):
        with _V54_JOBS_LOCK:
            _V54_JOBS[job_id].update(kw)
    try:
        upd(status="downloading", progress=0.02)
        dl = v54_download_history(symbol, tf, years, progress=lambda p: upd(progress=round(0.02 + 0.45 * p, 3)))
        df = v54_load_history(symbol, tf)
        upd(status="replaying", progress=0.5, download=dl)
        res = v54_replay_core(df, symbol, tf, run_walk_forward)
        res["download"] = dl
        V54_REPLAY_DIR.mkdir(parents=True, exist_ok=True)
        _save_json(V54_REPLAY_DIR / f"{job_id}.json", res)
        upd(status="done" if res.get("ok") else "failed", progress=1.0, finished_at=time.time(),
            error=None if res.get("ok") else res.get("error"))
    except Exception as exc:
        LOGGER.exception("V54 replay job failed: %s", exc)
        upd(status="failed", error=str(exc)[:200], finished_at=time.time())


def v54_start_replay(symbol: str, tf: str = "1h", years: float = 2.0, run_walk_forward: bool = True) -> dict[str, Any]:
    symbol = _normalize_symbol(symbol)
    tf = tf if tf in {"15m", "30m", "1h", "4h", "1d"} else "1h"
    years = float(min(max(years, 0.25), 6.0))
    with _V54_JOBS_LOCK:
        for jid, j in _V54_JOBS.items():
            if j.get("symbol") == symbol and j.get("tf") == tf and j.get("status") in {"queued", "downloading", "replaying"}:
                return {"ok": True, "job_id": jid, "status": j["status"], "reused": True}
        if sum(1 for j in _V54_JOBS.values() if j.get("status") in {"downloading", "replaying"}) >= 2:
            return {"ok": False, "error": "حداکثر ۲ replay هم‌زمان مجاز است"}
        jid = hashlib.sha1(f"{symbol}|{tf}|{time.time()}".encode()).hexdigest()[:12]
        _V54_JOBS[jid] = {"job_id": jid, "symbol": symbol, "tf": tf, "years": years, "status": "queued",
                          "progress": 0.0, "started_at": time.time()}
        if len(_V54_JOBS) > 40:
            for k in sorted(_V54_JOBS, key=lambda x: _V54_JOBS[x].get("started_at", 0))[:10]:
                _V54_JOBS.pop(k, None)
    threading.Thread(target=v54_replay_job, args=(jid, symbol, tf, years, run_walk_forward),
                     name=f"titan-v54-replay-{jid}", daemon=True).start()
    return {"ok": True, "job_id": jid, "status": "queued"}


# ------------------------------------------------------------------ 5) PIPELINE HOOKS
_V54_PREV_BUILD = _v51_build_authoritative
_V54_PREV_ANALYZE = analyze_asset


def _v51_build_authoritative(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:     # noqa: F811
    """Candidate stage: news blackout + multi-exchange crowding BEFORE trust gate / ledger."""
    cand = _V54_PREV_BUILD(symbol, btc_trend)
    if not cand:
        return cand
    try:
        news = v54_news_state(symbol)
        cand["news_calendar"] = news
        side = str(cand.get("decision") or cand.get("decision_tag") or "WAIT")
        if side in {"LONG", "SHORT"}:
            if news.get("blackout") and v54_settings()["news_filter"].get("mode", "block") != "annotate":
                names = ", ".join(a["name"] for a in news["active"][:2])
                cand = _v40_force_wait(cand, f"پنجره‌ی خبر مهم فعال است: {names}", "V54_NEWS_BLACKOUT")
                cand["decision_state"] = "V54_NEWS_BLACKOUT"
                cand["news_calendar"] = news
                return cand
            mx = v54_multi_exchange(symbol, side, safe_float(cand.get("price_raw", cand.get("live_price")), 0.0),
                                    (cand.get("derivatives") or {}).get("funding_value") if isinstance(cand.get("derivatives"), dict) else None)
            cand["multi_exchange"] = mx
            if mx.get("flags"):
                cand.setdefault("v54_warnings", []).extend(mx["flags"])
                if mx.get("mode") == "block" and any(f.startswith("crowded") or f == "venue_price_divergence" for f in mx["flags"]):
                    cand = _v40_force_wait(cand, "ازدحام فاندینگ/اختلاف قیمت بین صرافی‌ها", "V54_MULTIVENUE_BLOCK")
                    cand["decision_state"] = "V54_MULTIVENUE_BLOCK"
                    cand["multi_exchange"] = mx
    except Exception as exc:
        LOGGER.warning("V54 candidate hook failed for %s: %s", symbol, exc)
    return cand


def analyze_asset(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:               # noqa: F811
    """V54 public gateway = V53 gateway + post-publication Telegram alert."""
    out = _V54_PREV_ANALYZE(symbol, btc_trend)
    try:
        if out:
            status = v54_enqueue_alert(out)
            out["alert_status"] = status
    except Exception as exc:
        LOGGER.warning("V54 alert hook failed: %s", type(exc).__name__)
    return out


# ------------------------------------------------------------------ 6) API
@app.get("/api/v54/status")
def api_v54_status():
    token, chat = v54_telegram_credentials()
    return jsonify({"ok": True, "version": V54_VERSION, "settings": v54_settings(),
                    "telegram": {"configured": bool(token and chat), "stats": dict(_V54_TG_STATS)},
                    "settings_path": str(V54_SETTINGS_PATH), "events_path": str(V54_EVENTS_PATH)})


@app.get("/api/v54/news")
def api_v54_news():
    sym = _normalize_symbol(request.args.get("symbol", "BTC/USDT"))
    return jsonify({"ok": True, "symbol": sym, "news": v54_news_state(sym)})


@app.get("/api/v54/venues")
def api_v54_venues():
    sym = _normalize_symbol(request.args.get("symbol", "BTC/USDT"))
    side = str(request.args.get("side", "")).upper()
    return jsonify({"ok": True, "symbol": sym, "venues": v54_multi_exchange(sym, side if side in {"LONG", "SHORT"} else "")})


@app.get("/api/v54/telegram/test")
def api_v54_telegram_test():
    token, chat = v54_telegram_credentials()
    if not token or not chat:
        return jsonify({"ok": False, "error": "telegram_bot_token.txt و telegram_chat_id.txt را فقط در پوشه‌ی LLL/secrets بگذارید"}), 400
    ok, detail = _v54_send_telegram("✅ TITAN V54 — اتصال Telegram برقرار است.", token, chat)
    return jsonify({"ok": ok, "detail": detail}), (200 if ok else 502)


@app.get("/api/v54/replay/start")
def api_v54_replay_start():
    try:
        years = float(request.args.get("years", 2))
    except ValueError:
        years = 2.0
    wf = str(request.args.get("walk_forward", "1")) not in {"0", "false", "no"}
    res = v54_start_replay(request.args.get("symbol", "BTC/USDT"), str(request.args.get("timeframe", "1h")), years, wf)
    return jsonify(res), (200 if res.get("ok") else 429)


@app.get("/api/v54/replay/status")
def api_v54_replay_status():
    jid = str(request.args.get("id", ""))
    with _V54_JOBS_LOCK:
        job = dict(_V54_JOBS.get(jid) or {})
    if not job:
        return jsonify({"ok": False, "error": "job not found"}), 404
    if job.get("status") == "done":
        job["result"] = _load_json(V54_REPLAY_DIR / f"{''.join(ch for ch in jid if ch.isalnum())}.json", {})
    return jsonify({"ok": True, "job": job})


@app.get("/api/v54/replay/jobs")
def api_v54_replay_jobs():
    with _V54_JOBS_LOCK:
        return jsonify({"ok": True, "jobs": list(_V54_JOBS.values())})


# ------------------------------------------------------------------ 7) SELF-TEST
def _v54_self_test() -> int:
    fails: list[str] = []

    def chk(name: str, ok: bool):
        print(("  ✓ " if ok else "  ✗ ") + name)
        if not ok:
            fails.append(name)
    # news windows
    ts = _v54_et_to_utc(2026, 10, 28, 14, 0).timestamp()
    chk("fomc_blackout_inside", v54_news_state("BTC/USDT", ts - 30 * 60)["blackout"])
    chk("fomc_blackout_after", v54_news_state("BTC/USDT", ts + 100 * 60)["blackout"])
    chk("fomc_clear_far_before", not v54_news_state("BTC/USDT", ts - 6 * 3600)["blackout"])
    chk("nfp_rule", _v54_nfp_date(2026, 8) == (2026, 9, 4) and _v54_nfp_date(2026, 1) == (2026, 2, 6))
    # aggregation
    agg = v54_aggregate_venues([{"venue": "Bybit", "price": 100.0, "funding_pct": 0.08}, {"venue": "OKX", "price": 100.1, "funding_pct": 0.07}],
                               100.05, 0.09, "LONG", V54_DEFAULTS["multi_exchange"])
    chk("crowded_long_flag", "crowded_long_funding" in agg["flags"])
    chk("no_flag_for_short", "crowded_short_funding" not in v54_aggregate_venues([{"venue": "x", "price": 1.0, "funding_pct": 0.08}], 1.0, 0.09, "SHORT")["flags"])
    chk("price_divergence_flag", "venue_price_divergence" in v54_aggregate_venues([{"venue": "x", "price": 100.0}, {"venue": "y", "price": 101.0}], 0, None, "")["flags"])
    # telegram
    item = {"symbol": "BTC/USDT", "decision": "LONG", "decision_state": "V53_READY_FOR_PUBLICATION", "price_raw": 100.0,
            "stop_loss_raw": 98.0, "tp1_raw": 103.0, "tp2_raw": 106.0, "effective_rr_tp1": 1.5, "trust": 70}
    chk("alert_format_html_safe", "<b>BTC/USDT</b>" in v54_format_alert(item) and len(v54_format_alert(item)) < 4096)
    chk("alert_not_published", v54_enqueue_alert({**item, "decision_state": "V53_WAIT"}) == "NOT_PUBLISHED")
    chk("quiet_hours_wrap", _v54_in_quiet_hours(datetime(2026, 1, 1, 23, tzinfo=timezone.utc).timestamp(), [22, 6]))
    # replay kernels on synthetic data
    rng = np.random.default_rng(5)
    n = 900
    close = 100 + np.cumsum(rng.normal(0, 0.4, n))
    op = np.r_[close[0], close[:-1]]
    hi = np.maximum(op, close) + abs(rng.normal(0, .15, n)); lo = np.minimum(op, close) - abs(rng.normal(0, .15, n))
    t = (np.arange(n) * 3600_000 + 1_700_000_000_000).astype(float)
    sdf = pd.DataFrame({"t": t, "open": op, "high": hi, "low": lo, "close": close, "vol": 10.0, "T": t + 3599_999})
    res = v54_replay_core(sdf, "TEST/USDT", "1h", run_walk_forward=False)
    chk("replay_ok", bool(res.get("ok")) and "equity" in res and "by_quarter" in res)
    chk("replay_short_history_rejected", not v54_replay_core(sdf.iloc[:100], "TEST/USDT", "1h").get("ok", True))
    print("V54 SELF-TEST:", "PASS" if not fails else "FAIL " + ",".join(fails))
    return 0 if not fails else 1
