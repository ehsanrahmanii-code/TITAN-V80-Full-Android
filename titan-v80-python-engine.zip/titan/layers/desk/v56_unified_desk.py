# [TITAN V77 layer] desk/v56_unified_desk - V56 unified pro desk
# Original V76 source lines 23203-23805 (kept verbatim unless listed in CHANGELOG.md).
# =============================================================================
# TITAN V56 — UNIFIED PRO DESK (phone-optimised single file)
# 1) Position journal + risk% on desk
# 2) Correlation cluster veto (BTC↔alts book-level)
# 3) Session profile Asia / London / New York
# 4) Internal module map (maintainability without multi-file deploy)
# 5) 1h kline-close WebSocket scan trigger
# Storage remains HARD-LOCKED to LLL only. Analysis only — no order execution.
# =============================================================================

V56_VERSION = "TITAN-V56-UNIFIED-PRO-DESK"
V56_JOURNAL_PATH = DATA_DIR / "v56_position_journal.json"
V56_DEFAULT_ACCOUNT_RISK_PCT = 0.75   # suggested risk per idea (% of equity concept)
V56_MAX_CLUSTER_SAME_SIDE = 3        # max high-corr alts same side vs BTC
V56_CORR_CLUSTER_THRESH = 0.70
V56_SESSION_QUALITY = {
    # soft multipliers on rank / quality — never invent direction
    "ASIA": 0.92,
    "LONDON": 1.06,
    "NEW_YORK": 1.08,
    "OVERLAP_LN_NY": 1.12,
    "OFF": 0.88,
}
_V56_JOURNAL_LOCK = threading.RLock()
_V56_KLINE_CLOSE_LOCK = threading.Lock()
_V56_LAST_1H_CLOSE_MS = 0
_V56_KLINE_THREAD: Optional[threading.Thread] = None

# --- 4) Internal module map (documentation + runtime registry) ---
TITAN_MODULE_MAP: dict[str, str] = {
    "storage": "LLL hard-lock / APP_HOME / DATA_DIR / CACHE_DIR",
    "live": "REST + miniTicker WS + depth WS",
    "features": "closed-bar OHLCV / multi-TF quant spine",
    "policy": "V49 policy + V51 candidate + V52 trust + V53 DNA",
    "filters": "V54 news / multi-venue / telegram",
    "desk": "V55 ranked book + capacity + stale gate",
    "journal": "V56 position journal + risk%",
    "correlation": "V56 book-level cluster veto",
    "session": "V56 Asia/London/NY quality profile",
    "kline_trigger": "V56 1h close → scan queue",
    "unified_core": "V57 single decision voice + forecast integrity + balanced gates",
}


def v56_session_profile(now_ts: Optional[float] = None) -> dict[str, Any]:
    """UTC session buckets used by desks worldwide."""
    ts = time.time() if now_ts is None else float(now_ts)
    h = datetime.fromtimestamp(ts, tz=timezone.utc).hour
    # Approximate liquid windows (UTC): Asia 00-08, London 07-16, NY 13-22
    asia = 0 <= h < 8
    london = 7 <= h < 16
    ny = 13 <= h < 22
    if london and ny:
        name, mult = "OVERLAP_LN_NY", V56_SESSION_QUALITY["OVERLAP_LN_NY"]
    elif ny:
        name, mult = "NEW_YORK", V56_SESSION_QUALITY["NEW_YORK"]
    elif london:
        name, mult = "LONDON", V56_SESSION_QUALITY["LONDON"]
    elif asia:
        name, mult = "ASIA", V56_SESSION_QUALITY["ASIA"]
    else:
        name, mult = "OFF", V56_SESSION_QUALITY["OFF"]
    return {
        "session": name,
        "quality_mult": mult,
        "hour_utc": h,
        "windows": {"asia": asia, "london": london, "new_york": ny},
        "note_fa": {
            "ASIA": "جلسه آسیا — نقدشوندگی متوسط",
            "LONDON": "جلسه لندن — نقدشوندگی خوب",
            "NEW_YORK": "جلسه نیویورک — نقدشوندگی بالا",
            "OVERLAP_LN_NY": "همپوشانی لندن/نیویورک — بهترین کیفیت",
            "OFF": "خارج از پنجره اصلی — احتیاط بیشتر",
        }.get(name, ""),
    }


def v56_position_risk(item: dict[str, Any], account_risk_pct: float = V56_DEFAULT_ACCOUNT_RISK_PCT) -> dict[str, Any]:
    """Conceptual risk journal row (no execution). risk% of idea based on stop distance."""
    side = str(item.get("decision") or item.get("decision_tag") or "WAIT")
    entry = safe_float(item.get("price_raw"), safe_float(item.get("live_price"), 0))
    sl = safe_float(item.get("stop_loss_raw"), 0)
    tp1 = safe_float(item.get("tp1_raw"), 0)
    tp2 = safe_float(item.get("tp2_raw"), 0)
    side = side.upper()
    base = safe_float(account_risk_pct, 0.0)
    if entry <= 0 or sl <= 0 or side not in {"LONG", "SHORT"}:
        return {"ok": False, "reason": "no_levels", "suggested_risk_pct": 0.0}
    if base <= 0 or base > 1.25:
        return {"ok": False, "reason": "invalid_risk_budget", "suggested_risk_pct": 0.0}
    # Reject inverted barriers instead of converting them into a plausible-looking RR.
    valid_long = side == "LONG" and sl < entry and tp1 > entry and (tp2 <= 0 or tp2 >= tp1)
    valid_short = side == "SHORT" and sl > entry and tp1 < entry and (tp2 <= 0 or tp2 <= tp1)
    if not (valid_long or valid_short):
        return {"ok": False, "reason": "invalid_level_orientation", "suggested_risk_pct": 0.0}
    stop_dist = abs(entry - sl) / entry
    if stop_dist < 1e-6:
        return {"ok": False, "reason": "zero_stop", "suggested_risk_pct": 0.0}
    # Tighter stops → slightly higher size within fixed risk budget concept
    rr1 = abs(tp1 - entry) / abs(entry - sl)
    rr2 = abs(tp2 - entry) / abs(entry - sl) if tp2 > 0 else 0.0
    trust = clamp(safe_float(item.get("trust"), safe_float(item.get("decision_confidence"), 0)), 0.0, 100.0)
    if trust < 35.0:
        return {"ok": False, "reason": "insufficient_trust", "suggested_risk_pct": 0.0}
    # If quality/freshness is supplied, fail closed on explicit bad values.
    dq_raw = item.get("data_quality")
    if dq_raw is not None and safe_float(dq_raw, -1.0) >= 0 and safe_float(dq_raw, -1.0) < V49_HARD_DQ:
        return {"ok": False, "reason": "data_quality_below_hard_gate", "suggested_risk_pct": 0.0}
    contract = item.get("data_contract") if isinstance(item.get("data_contract"), dict) else {}
    age_raw = contract.get("live_age_sec", item.get("live_age_sec"))
    if age_raw is not None and (safe_float(age_raw, float("inf")) < 0 or safe_float(age_raw, float("inf")) > V49_STALE_PRICE_SEC):
        return {"ok": False, "reason": "stale_market_data", "suggested_risk_pct": 0.0}
    # Scale within the risk budget. Low trust never receives a positive floor.
    scale = clamp((trust / 100.0) * (0.75 + 0.25 * min(rr1, 2.5) / 2.5), 0.0, 1.0)
    if scale <= 0:
        return {"ok": False, "reason": "zero_risk_scale", "suggested_risk_pct": 0.0}
    suggested = round(min(base * scale, 1.25), 3)
    notional_risk_unit = 1.0  # abstract unit equity
    position_units = suggested / (stop_dist * 100.0) if stop_dist > 0 else 0.0
    return {
        "ok": True,
        "side": side,
        "entry": entry,
        "stop": sl,
        "tp1": tp1,
        "tp2": tp2,
        "stop_distance_pct": round(stop_dist * 100.0, 4),
        "rr_tp1": round(rr1, 3),
        "rr_tp2": round(rr2, 3),
        "suggested_risk_pct": suggested,
        "position_units_per_equity": round(position_units, 6),
        "trust": round(trust, 1),
        "session": v56_session_profile().get("session"),
        "note": "تحلیل آماری — بدون اجرای سفارش",
    }


def v56_journal_load() -> list[dict[str, Any]]:
    raw = _load_json(V56_JOURNAL_PATH, {"entries": []})
    entries = raw.get("entries") if isinstance(raw, dict) else []
    return list(entries) if isinstance(entries, list) else []


def v56_journal_append(item: dict[str, Any], risk: dict[str, Any]) -> None:
    """Persist published desk ideas to LLL journal (capped)."""
    if not risk.get("ok"):
        return
    side = str(item.get("decision") or "")
    if side not in {"LONG", "SHORT"}:
        return
    if not item.get("desk_published"):
        return
    row = {
        "ts": time.time(),
        "iso": _now_iso(),
        "symbol": item.get("symbol"),
        "side": side,
        "decision_state": item.get("decision_state"),
        "rank": item.get("v55_rank"),
        "risk": risk,
        "decision_hash": item.get("decision_hash"),
    }
    with _V56_JOURNAL_LOCK:
        entries = v56_journal_load()
        # de-dupe same decision_hash
        dh = str(row.get("decision_hash") or "")
        if dh and any(str(e.get("decision_hash") or "") == dh for e in entries[-80:]):
            return
        entries.append(row)
        if len(entries) > 400:
            entries = entries[-400:]
        _save_json(V56_JOURNAL_PATH, {"version": V56_VERSION, "entries": entries})


def v56_correlation_cluster_veto(market_data: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Book-level: if too many high-BTC-corr alts share the same side, keep best ranks only."""
    if not market_data:
        return market_data
    groups: dict[str, list[dict[str, Any]]] = {"LONG": [], "SHORT": []}
    for it in market_data:
        if not isinstance(it, dict):
            continue
        side = str(it.get("decision") or it.get("decision_tag") or "")
        if side not in groups:
            continue
        if not it.get("desk_published"):
            continue
        sym = str(it.get("symbol") or "")
        if sym in {"BTC/USDT", "BTCUSDT", "ETH/USDT", "ETHUSDT"}:
            # majors always keep seat; still count toward cluster pressure for alts
            it["v56_corr_cluster"] = {"role": "major", "corr": 1.0 if "BTC" in sym else 0.85}
            groups[side].append(it)
            continue
        corr = 0.0
        try:
            info = compute_btc_correlation(sym)
            corr = abs(safe_float(info.get("corr"), 0))
            it["v56_corr_cluster"] = {"role": "alt", "corr": round(corr, 3), "regime": info.get("regime")}
        except Exception:
            _swallow()
            it["v56_corr_cluster"] = {"role": "alt", "corr": 0.0}
            corr = 0.0
        if corr >= V56_CORR_CLUSTER_THRESH:
            groups[side].append(it)
    for side, members in groups.items():
        alts = [m for m in members if (m.get("v56_corr_cluster") or {}).get("role") == "alt"]
        if len(alts) <= V56_MAX_CLUSTER_SAME_SIDE:
            continue
        alts.sort(key=lambda x: safe_float(x.get("v55_rank"), 0), reverse=True)
        keep = set(id(x) for x in alts[:V56_MAX_CLUSTER_SAME_SIDE])
        for m in alts:
            if id(m) in keep:
                continue
            m["desk_published"] = False
            m["v56_corr_veto"] = True
            m.setdefault("v56_warnings", []).append("CORR_CLUSTER_VETO")
            m["v55_desk_gate"] = "CORR_CLUSTER_VETO"
            # soft demote — keep evidence, remove from published book
            try:
                m = _v40_force_wait(m, "ازدحام همبستگی با BTC در کتاب سیگنال", "V56_CORR_CLUSTER")
                m["decision_state"] = "V56_CORR_CLUSTER"
            except Exception:
                _swallow()
    return market_data


def v56_apply_session(item: dict[str, Any]) -> dict[str, Any]:
    prof = v56_session_profile()
    item["v56_session"] = prof
    mult = float(prof.get("quality_mult") or 1.0)
    # Idempotent adjustment: preserve the pre-session rank so repeated wrappers,
    # cache refreshes, or dashboard reads cannot compound the multiplier.
    # If upstream recalculates rank, refresh the base only when its explicit
    # source rank changes; otherwise reuse the stored base.
    current_rank = safe_float(item.get("v55_rank"), 0)
    prior_mult = safe_float(item.get("v56_session_mult"), 0)
    base_rank = item.get("v56_base_rank")
    if base_rank is None or prior_mult <= 0:
        base_rank = current_rank
    else:
        base_rank = safe_float(base_rank, current_rank)
        # An upstream rank refresh is distinguishable from our prior adjusted rank.
        expected = round(base_rank * prior_mult, 2)
        if round(current_rank, 2) != expected:
            base_rank = current_rank
    item["v56_base_rank"] = round(base_rank, 4)
    item["v55_rank"] = round(base_rank * mult, 2)
    item["v56_session_mult"] = mult
    q = safe_float(item.get("signal_quality"), 0)
    if q > 0:
        item["signal_quality_session"] = round(clamp(q * mult, 0, 100), 1)
    return item


def _v56_apply_to_item(item: Optional[dict[str, Any]]) -> Optional[dict[str, Any]]:
    if not item:
        return item
    try:
        item = v56_apply_session(item)
        risk = v56_position_risk(item)
        item["v56_risk"] = risk
        item["v56_version"] = V56_VERSION
        if item.get("desk_published") and risk.get("ok"):
            v56_journal_append(item, risk)
    except Exception as exc:
        LOGGER.debug("V56 item apply: %s", type(exc).__name__)
    return item


def v56_enrich_desk(desk: dict[str, Any]) -> dict[str, Any]:
    """Attach session + journal tail + module map to desk payload."""
    desk = dict(desk or {})
    desk["v56"] = {
        "version": V56_VERSION,
        "session": v56_session_profile(),
        "modules": TITAN_MODULE_MAP,
        "journal_path": str(V56_JOURNAL_PATH),
        "journal_tail": v56_journal_load()[-12:],
        "corr_policy": {
            "max_cluster_same_side": V56_MAX_CLUSTER_SAME_SIDE,
            "corr_threshold": V56_CORR_CLUSTER_THRESH,
        },
    }
    # annotate published rows with risk if missing
    for row in desk.get("published") or []:
        if "risk" not in row:
            # lightweight echo from journal if present
            pass
    return desk


_V56_PREV_ANALYZE = analyze_asset


def analyze_asset(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:  # noqa: F811
    out = _V56_PREV_ANALYZE(symbol, btc_trend)
    return _v56_apply_to_item(out)


_V56_PREV_UPDATE = update_cache


def update_cache(force: bool = False):  # noqa: F811
    out = _V56_PREV_UPDATE(force)
    try:
        data = out[0] if isinstance(out, tuple) and out else None
        if data:
            data = v56_correlation_cluster_veto(list(data))
            for it in data:
                if isinstance(it, dict):
                    _v56_apply_to_item(it)
            with CACHE_LOCK:
                CACHE["data"] = data
            # rebuild desk after correlation veto
            try:
                v55_rebuild_desk(data)
            except Exception:
                _swallow()
    except Exception as exc:
        LOGGER.debug("V56 update_cache: %s", exc)
    return out


def _v56_kline_close_worker() -> None:
    """Watch BTCUSDT 1h kline stream; on closed candle queue a market scan."""
    global _V56_LAST_1H_CLOSE_MS
    if _websocket_client is None:
        return
    while not LIVE_STOP.is_set():
        try:
            url = "wss://data-stream.binance.vision/ws/btcusdt@kline_1h"
            ws = _websocket_client.create_connection(url, timeout=12)
            ws.settimeout(20)
            while not LIVE_STOP.is_set():
                raw = ws.recv()
                if not raw:
                    break
                try:
                    msg = json.loads(raw)
                except Exception:
                    _swallow(); continue
                k = msg.get("k") if isinstance(msg, dict) else None
                if not isinstance(k, dict):
                    continue
                if not k.get("x"):
                    continue  # only closed candles
                close_ms = int(safe_float(k.get("T"), 0))
                with _V56_KLINE_CLOSE_LOCK:
                    if close_ms and close_ms <= _V56_LAST_1H_CLOSE_MS:
                        continue
                    _V56_LAST_1H_CLOSE_MS = close_ms
                LOGGER.info("V56 1h candle closed @ %s — queue scan", close_ms)
                try:
                    _background_market_refresh(False)
                except Exception as exc:
                    LOGGER.debug("V56 kline scan queue: %s", exc)
            try:
                ws.close()
            except Exception:
                _swallow()
        except Exception as exc:
            LOGGER.info("V56 kline WS retry: %s", type(exc).__name__)
            LIVE_STOP.wait(8)


def v56_start_kline_trigger() -> None:
    global _V56_KLINE_THREAD
    if _websocket_client is None:
        return
    if _V56_KLINE_THREAD is not None and _V56_KLINE_THREAD.is_alive():
        return
    _V56_KLINE_THREAD = threading.Thread(
        target=_v56_kline_close_worker, name="titan-v56-kline-1h", daemon=True
    )
    _V56_KLINE_THREAD.start()
    LIVE_THREADS.append(_V56_KLINE_THREAD)


_V56_PREV_START_LIVE = start_live_engine


def start_live_engine() -> None:  # noqa: F811
    _V56_PREV_START_LIVE()
    try:
        v56_start_kline_trigger()
    except Exception as exc:
        LOGGER.debug("V56 kline trigger start: %s", exc)


# Wrap desk snapshot to include V56 enrichment
_V56_PREV_DESK = v55_desk_snapshot


def v55_desk_snapshot() -> dict[str, Any]:  # noqa: F811
    return v56_enrich_desk(_V56_PREV_DESK())


@app.get("/api/v56/status")
def api_v56_status():
    desk = v55_desk_snapshot()
    return jsonify({
        "ok": True,
        "version": V56_VERSION,
        "build": TITAN_BUILD_ID,
        "path": TITAN_ACTIVE_DECISION_PATH,
        "storage": str(APP_HOME),
        "session": v56_session_profile(),
        "modules": TITAN_MODULE_MAP,
        "kline_trigger": {
            "enabled": _websocket_client is not None,
            "last_1h_close_ms": _V56_LAST_1H_CLOSE_MS,
            "thread_alive": bool(_V56_KLINE_THREAD and _V56_KLINE_THREAD.is_alive()),
        },
        "journal_entries": len(v56_journal_load()),
        "desk_stats": (desk.get("stats") or {}),
    })


@app.get("/api/v56/journal")
def api_v56_journal():
    try:
        limit = max(1, min(int(request.args.get("limit", 40)), 200))
    except ValueError:
        limit = 40
    entries = v56_journal_load()[-limit:]
    return jsonify({"ok": True, "version": V56_VERSION, "count": len(entries), "entries": entries})


@app.get("/api/v56/session")
def api_v56_session():
    return jsonify({"ok": True, "session": v56_session_profile()})




@app.get("/api/titan/observability")
def api_titan_observability():
    """Read-only compact dashboard snapshot; never triggers a market scan."""
    try:
        with CACHE_LOCK:
            rows = [dict(x) for x in (CACHE.get("data") or []) if isinstance(x, dict)]
            cache_ts = float(CACHE.get("timestamp") or 0)
        specs = {
            "V51": ("هسته تحلیل و تولید نامزد", "نامزد اولیه، جهت و کنترل داده چندتایم‌فریمی", ("v49", "decision_reasons", "decision_state", "score")),
            "V52": ("دروازه اعتماد و ریسک", "اعتماد، اعتبارسنجی و کنترل انتشار", ("v52", "trust", "trust_status", "decision_confidence")),
            "V53": ("DNA تصمیم و انتساب خطا", "پایداری، DNA و ارزیابی تصمیم", ("v53", "v53_dna", "counterfactual", "decision_state")),
            "V54": ("فیلترهای انتشار و بازپخش", "فیلتر خبر/بازار و وضعیت اعلان", ("alert_status", "v54_news", "venues", "news_calendar", "multi_exchange")),
            "V55": ("میز رتبه‌بندی سیگنال", "رتبه، ظرفیت و تازگی قیمت", ("v55_rank", "v55_desk_gate", "desk_published", "v55_version")),
            "V56": ("ژورنال، جلسه و همبستگی", "ریسک، جلسه و کنترل خوشه همبستگی", ("v56_risk", "v56_session_mult", "v56_version", "v56_session")),
        }
        modules = {k: {"name": v[0], "role": v[1], "status": "registered"} for k, v in specs.items()}
        engines = {}
        for key, (_, _, fields) in specs.items():
            relevant = [r for r in rows if any(f in r for f in fields)]
            # Fallback: if fields missing but rows exist, still count as observed registry activity
            if not relevant and rows and key in ("V51", "V52"):
                relevant = list(rows)
            sides = [str(r.get("decision") or r.get("decision_tag") or "WAIT").upper() for r in relevant]
            trusts = []
            for r in relevant:
                try:
                    val = float(r.get("trust", r.get("decision_confidence", 0)) or 0)
                    if math.isfinite(val):
                        trusts.append(val)
                except (TypeError, ValueError):
                    pass
            engines[key] = {
                "status": "data_observed" if relevant else "registered_awaiting_cache",
                "symbols_seen": len(relevant),
                "long": sum(x == "LONG" for x in sides),
                "short": sum(x == "SHORT" for x in sides),
                "wait": sum(x not in {"LONG", "SHORT"} for x in sides),
                "avg_trust": round(sum(trusts) / len(trusts), 1) if trusts else None,
                "observed_fields": [f for f in fields if any(f in r for r in relevant)],
                "note": "ورودی مکمل برای هوش مرکزی؛ تصمیم نهایی فقط Central Governor.",
            }
        recent = []
        for r in rows[:12]:
            reasons = r.get("decision_reasons") or ((r.get("v52") or {}).get("reasons") if isinstance(r.get("v52"), dict) else []) or []
            recent.append({
                "symbol": str(r.get("symbol") or "")[:40],
                "decision": str(r.get("decision") or r.get("decision_tag") or "WAIT")[:20],
                "decision_state": str(r.get("decision_state") or "")[:80],
                "reasons": [str(x)[:100] for x in reasons[:4]] if isinstance(reasons, list) else [],
            })
        try:
            audit = titan_system_audit()
        except Exception as exc:
            audit = {"passed": False, "error": str(exc)[:160]}
        # Central brain snapshot (lightweight; no scan)
        central_brain = {
            "version": globals().get("TITAN_CENTRAL_VERSION", "TITAN-CENTRAL-GOVERNOR"),
            "mode": "CENTRAL_GOVERNOR_ONLY",
            "pending": None,
            "live_weights": None,
        }
        try:
            with DB_LOCK, db_conn() as con:
                try:
                    central_brain["pending"] = int(con.execute(
                        "SELECT COUNT(*) FROM central_predictions WHERE outcome='PENDING'"
                    ).fetchone()[0])
                except Exception:
                    _swallow()
            if "_CENTRAL_WEIGHTS" in globals():
                with globals().get("_CENTRAL_WEIGHT_LOCK", threading.RLock()):
                    central_brain["live_weights"] = dict(_CENTRAL_WEIGHTS)
        except Exception:
            _swallow()
        return jsonify({
            "ok": True,
            "build": TITAN_BUILD_ID,
            "active_path": globals().get("TITAN_ACTIVE_DECISION_PATH", "DATA->FEATURE->V51-56->CENTRAL->LEDGER"),
            "modules": modules,
            "engines": engines,
            "recent": recent,
            "runtime": {
                "symbols": len(rows),
                "published": sum(bool(r.get("desk_published")) for r in rows),
                "cache_age_sec": round(max(0.0, time.time() - cache_ts), 1) if cache_ts else None,
            },
            "integrity": audit,
            "central_brain": central_brain,
            "safety": {"order_execution": False, "learning_auto_promote": False},
            "module_health": {
                k: {
                    "registered": True,
                    "runtime_checked": bool(engines[k].get("symbols_seen")),
                    "status_source": "cache_observation",
                }
                for k in modules
            },
        })
    except Exception as exc:
        LOGGER.exception("TITAN observability snapshot failed: %s", exc)
        return jsonify({"ok": False, "error": str(exc)[:200]}), 500


@app.get("/api/titan/modules")
def api_titan_modules():
    """Unified, read-only registry for V51–V56 runtime components."""
    modules = {
        "V51": {"name": "هسته تحلیل و تولید نامزد", "role": "ساخت سیگنال و تحلیل چندتایم‌فریمی", "status": "registered"},
        "V52": {"name": "دروازه اعتماد و ریسک", "role": "اعتبارسنجی و جلوگیری از انتشار نامعتبر", "status": "registered"},
        "V53": {"name": "DNA تصمیم و انتساب خطا", "role": "ردیابی تصمیم، پایداری و بررسی نتایج", "status": "registered"},
        "V54": {"name": "فیلترهای انتشار و بازپخش", "role": "فیلتر خبر/بازار و replay جدا از دفتر زنده", "status": "registered"},
        "V55": {"name": "میز رتبه‌بندی سیگنال", "role": "رتبه‌بندی، ظرفیت و کنترل تازگی", "status": "registered"},
        "V56": {"name": "ژورنال، جلسه و همبستگی", "role": "ثبت تصمیم، تعدیل رتبه و کنترل ازدحام", "status": "registered"},
    }
    try:
        audit = titan_system_audit()
    except Exception as exc:
        audit = {"passed": False, "error": str(exc)[:180]}
    try:
        with CACHE_LOCK:
            rows = list(CACHE.get("data") or [])
            cache_ts = float(CACHE.get("timestamp") or 0)
        published = sum(1 for row in rows if isinstance(row, dict) and row.get("desk_published"))
        symbols = len(rows)
    except Exception:
        _swallow()
        published, symbols, cache_ts = 0, 0, 0
    return jsonify({
        "ok": True, "build": TITAN_BUILD_ID, "active_path": TITAN_ACTIVE_DECISION_PATH,
        "modules": modules, "module_map": TITAN_MODULE_MAP,
        "integrity": audit, "runtime": {
            "symbols": symbols, "published": published,
            "cache_age_sec": round(max(0.0, time.time() - cache_ts), 1) if cache_ts else None,
            "session": v56_session_profile(),
        },
        "safety": {"order_execution": False, "learning_auto_promote": False},
        "module_health": {k: {"registered": True, "runtime_checked": False, "status_source": "static_registry_only"} for k in modules},
    })


def _v56_self_test() -> int:
    fails = []
    def chk(n, c):
        print(("  ✓ " if c else "  ✗ ") + n)
        if not c:
            fails.append(n)
    prof = v56_session_profile(datetime(2026, 6, 15, 14, 0, tzinfo=timezone.utc).timestamp())
    chk("session_overlap_or_ny", prof["session"] in {"OVERLAP_LN_NY", "NEW_YORK", "LONDON"})
    sample = {
        "symbol": "ETH/USDT", "decision": "LONG", "decision_state": "V53_READY_FOR_PUBLICATION",
        "trust": 72, "signal_quality": 61, "score": 66, "grade": "A",
        "price_raw": 2000.0, "stop_loss_raw": 1940.0, "tp1_raw": 2120.0, "tp2_raw": 2200.0,
        "desk_published": True, "v55_rank": 80.0,
        "data_contract": {"live_age_sec": 2},
    }
    risk = v56_position_risk(sample)
    chk("risk_ok", bool(risk.get("ok")) and risk.get("suggested_risk_pct", 0) > 0)
    bad_stop = dict(sample, stop_loss_raw=2050.0)
    bad_target = dict(sample, tp1_raw=1990.0)
    chk("risk_rejects_inverted_stop", v56_position_risk(bad_stop).get("reason") == "invalid_level_orientation")
    chk("risk_rejects_inverted_target", v56_position_risk(bad_target).get("reason") == "invalid_level_orientation")
    chk("risk_rejects_invalid_budget", v56_position_risk(sample, 0).get("reason") == "invalid_risk_budget")
    chk("modules_mapped", "journal" in TITAN_MODULE_MAP and "kline_trigger" in TITAN_MODULE_MAP)
    chk("journal_path_in_storage", str(V56_JOURNAL_PATH).startswith(str(APP_HOME)) if APP_HOME.exists() else True)
    print("V56 SELF-TEST:", "PASS" if not fails else "FAIL " + ",".join(fails))
    return 0 if not fails else 1
