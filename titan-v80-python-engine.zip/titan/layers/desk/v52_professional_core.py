# [TITAN V77 layer] desk/v52_professional_core - V52 professional core + public realtime authority
# Original V76 source lines 21006-21622 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# TITAN V52 — PROFESSIONAL CORE / TRUSTED INTEGRATED ARCHITECTURE
# ============================================================
# Design principles:
#   1) One authoritative live path: Feature -> V49 -> V51 -> V52 Trust Gate.
#   2) Research, validation, execution simulation and learning are separate
#      concerns. No research metric can silently promote a live trade.
#   3) All adaptive state is bounded, auditable and shadow-first.
#   4) Backtest/live parity is enforced by shared causal primitives.
#   5) "Trust" means data/model/execution/risk evidence quality; it is NOT a
#      probability of profit and never a guarantee of returns.
# ============================================================
V52_VERSION = "TITAN-V52-PROFESSIONAL-CORE"
V52_BUILD_ID = "V52-PRO-2026-10"
V52_AUTHORITY = "TITAN-V52-TRUST-GOVERNOR"
V52_ENGINE_MODE = "ONE_BRAIN_MANY_EVIDENCE_CHANNELS"
V52_MIN_EDGE = 0.0
V52_MIN_PROBABILITY = 0.50
V52_MAX_SPREAD_PCT = 0.80
V52_MAX_VOLATILITY_PCT = 18.0
V52_MAX_CORRELATED_EXPOSURE = 2.25
V52_MAX_PORTFOLIO_RISK_PCT = 1.25
V52_DEFAULT_RISK_PCT = 0.50
V52_MAX_DAILY_DD_PCT = 5.0
V52_KILL_DD_PCT = 10.0
V52_MAX_LATENCY_MS = 2500.0
V52_MIN_CALIBRATION_N = 20
V52_DRIFT_PSI_WARN = 0.20
V52_DRIFT_PSI_HARD = 0.30
V52_TRIAL_MIN_PBO = 30
V52_EXPERIMENT_PATH = MEMORY_DIR / "v52_experiments.json"
V52_MODEL_REGISTRY_PATH = MEMORY_DIR / "v52_model_registry.json"
V52_STATE_LOCK = threading.RLock()


def _v52_finite(x: Any, default: float = 0.0) -> float:
    """Coerce to finite float without logging noise for routine None/str misses."""
    try:
        if x is None:
            return default
        y = float(x)
        return y if math.isfinite(y) else default
    except (TypeError, ValueError):
        return default
    except Exception:
        return default


def _v52_side(x: Any) -> str:
    s = str(x or "").upper().strip()
    return s if s in {"LONG", "SHORT", "WAIT"} else "WAIT"


def _v52_now() -> float:
    return time.time()


def _v52_returns_from_rows(rows: list[dict[str, Any]], horizon: str = "24h") -> list[float]:
    col = f"r_multiple_{horizon}"
    out=[]
    for r in rows:
        if str(r.get("outcome_"+horizon) or "") not in {"WIN","LOSS"}:
            continue
        v=_v52_finite(r.get(col), float("nan"))
        if math.isfinite(v): out.append(v)
    return out


def _v52_percentile(xs: list[float], q: float) -> Optional[float]:
    a=sorted(float(x) for x in xs if math.isfinite(float(x)))
    if not a: return None
    if len(a)==1: return a[0]
    pos=(len(a)-1)*clamp(q,0,1); lo=int(math.floor(pos)); hi=int(math.ceil(pos))
    if lo==hi:return a[lo]
    return a[lo]+(a[hi]-a[lo])*(pos-lo)


def _v52_sharpe(xs: list[float]) -> Optional[float]:
    if len(xs)<2:return None
    m=statistics.mean(xs); sd=statistics.stdev(xs)
    return m/sd if sd>1e-12 else None


def _v52_max_drawdown(xs: list[float]) -> float:
    eq=1.0; peak=eq; worst=0.0
    for r in xs:
        eq*=max(0.0,1.0+float(r)*0.01)
        peak=max(peak,eq)
        if peak>0: worst=min(worst,(eq/peak-1.0)*100.0)
    return abs(worst)


def _v52_psi(base: list[float], recent: list[float], bins: int = 10) -> Optional[float]:
    if len(base)<30 or len(recent)<10:return None
    cuts=[_v52_percentile(base,i/bins) for i in range(1,bins)]
    cuts=[c for c in cuts if c is not None]
    def hist(a):
        h=[0]* (len(cuts)+1)
        for x in a:
            j=0
            while j<len(cuts) and x>cuts[j]: j+=1
            h[j]+=1
        n=max(len(a),1)
        return [(v/n)+1e-6 for v in h]
    p,q=hist(base),hist(recent)
    return sum((a-b)*math.log(a/b) for a,b in zip(p,q))


def _v52_wilson(wins: int, n: int, z: float = 1.96) -> tuple[Optional[float],Optional[float]]:
    if n<=0:return None,None
    p=wins/n; den=1+z*z/n; centre=(p+z*z/(2*n))/den; half=z*math.sqrt((p*(1-p)+z*z/(4*n))/n)/den
    return max(0.0,centre-half),min(1.0,centre+half)


def _v52_brier(rows: list[dict[str,Any]]) -> Optional[float]:
    vals=[]
    for r in rows:
        p=_v52_finite(r.get("probability_calibrated"),float("nan"))/100.0
        o=str(r.get("outcome_24h") or "")
        if math.isfinite(p) and o in {"WIN","LOSS"}: vals.append((p,1.0 if o=="WIN" else 0.0))
    return statistics.mean([(p-y)**2 for p,y in vals]) if vals else None


def _v52_logloss(rows: list[dict[str,Any]]) -> Optional[float]:
    vals=[]
    for r in rows:
        p=_v52_finite(r.get("probability_calibrated"),float("nan"))/100.0
        o=str(r.get("outcome_24h") or "")
        if math.isfinite(p) and o in {"WIN","LOSS"}:
            y=1.0 if o=="WIN" else 0.0; p=clamp(p,1e-6,1-1e-6); vals.append(-(y*math.log(p)+(1-y)*math.log(1-p)))
    return statistics.mean(vals) if vals else None


def _v52_dsr(sharpe: Optional[float], n_trials: int, n_obs: int) -> Optional[float]:
    if sharpe is None or n_obs<3:return None
    # Conservative multiple-testing penalty; this is a screening statistic, not a
    # replacement for a full Bailey/Lopez de Prado analytical implementation.
    penalty=math.sqrt(max(0.0,2.0*math.log(max(1,n_trials))))/math.sqrt(max(1,n_obs))
    return float(sharpe-penalty)


def _v52_pbo(trials: list[list[float]], seed: int = 52) -> dict[str,Any]:
    if len(trials)<V52_TRIAL_MIN_PBO:
        return {"status":"INSUFFICIENT_TRIALS","trials":len(trials),"pbo":None}
    rng=np.random.default_rng(seed); under=0; total=0
    for arr in trials:
        a=np.asarray([x for x in arr if math.isfinite(float(x))],dtype=float)
        if len(a)<20:continue
        cut=len(a)//2
        if cut<8 or len(a)-cut<8:continue
        # Randomly alternate in-sample/out-of-sample halves to expose selection luck.
        idx=rng.permutation(len(a)); ins=a[idx[:cut]]; oos=a[idx[cut:]]
        sr_i=_v52_sharpe(ins.tolist()); sr_o=_v52_sharpe(oos.tolist())
        if sr_i is None or sr_o is None:continue
        total+=1
        if sr_i>0 and sr_o<=0:under+=1
    return {"status":"READY" if total else "INSUFFICIENT_DATA","trials":len(trials),"evaluated":total,"pbo":round(under/total,4) if total else None}


def _v52_setup(item: dict[str,Any]) -> str:
    e=item.get("edge") or {}; s=e.get("structure") or {}; c=e.get("confluence") or {}; r=e.get("regime") or {}
    score=_v52_finite(item.get("score"),50); atr=_v52_finite(item.get("atr_raw"),0); price=_v52_finite(item.get("price_raw",item.get("live_price")),0)
    vol=_v52_finite(item.get("volatility_pct"),100*atr/max(price,1e-12))
    structure=str(s.get("structure") or s.get("market_structure") or "").lower()
    regime=str(r.get("regime") or "").lower()
    if "break" in structure or "break" in str(c.get("reason") or "").lower():return "BREAKOUT"
    if "range" in regime or "mean" in regime:return "MEAN_REVERSION"
    if "transition" in regime:return "TRANSITION"
    if abs(score-50)>=18 and atr>0:return "TREND_CONTINUATION"
    if vol>8:return "VOLATILITY_EXPANSION"
    return "PULLBACK"


def _v52_regime_prob(item: dict[str,Any]) -> dict[str,float]:
    r=item.get("edge",{}).get("regime",{}) if isinstance(item.get("edge"),dict) else {}
    raw=str(item.get("regime_state") or r.get("regime") or "").lower(); score=_v52_finite(item.get("score"),50); vol=_v52_finite(item.get("volatility_pct"),0)
    vals={"trend":0.20,"range":0.20,"high_volatility":0.20,"low_volatility":0.20,"transition":0.20}
    if "trend" in raw:
        vals["trend"]+=0.35
    elif "range" in raw:
        vals["range"]+=0.35
    elif "transition" in raw:
        vals["transition"]+=0.40
    if vol>=8: vals["high_volatility"]+=0.30
    elif vol<=2.5: vals["low_volatility"]+=0.30
    if abs(score-50)>15: vals["trend"]+=0.15
    z=sum(vals.values()) or 1.0
    return {k:round(v/z,4) for k,v in vals.items()}


def _v52_feature_snapshot(item: dict[str,Any]) -> dict[str,float]:
    vals={}
    for k in ("score","alignment","signal_quality","rsi_value","volatility_pct","rr_tp1","rr_tp2","effective_rr_tp1","effective_rr_tp2","adv_nudge","taker_buy_pct","long_short_ratio"):
        v=item.get(k)
        if isinstance(v,(int,float)) and math.isfinite(float(v)): vals[k]=float(v)
    tf=item.get("tf_scores") or {}
    for k,v in tf.items():
        if isinstance(v,(int,float)) and math.isfinite(float(v)): vals[f"tf_{k}"]=float(v)
    return vals


def _v52_redundancy(values: dict[str,float]) -> dict[str,Any]:
    keys=list(values); clusters=[]
    # Pairwise redundancy is intentionally limited to same-scale scalar features.
    for i,a in enumerate(keys):
        group=[a]
        for b in keys[i+1:]:
            if a.startswith("tf_") != b.startswith("tf_"): continue
            # Single snapshot cannot establish statistical correlation. Mark only
            # known semantic duplicates instead of inventing correlation.
            if {a,b} in [set(("score","alignment")),set(("rr_tp1","effective_rr_tp1")),set(("rr_tp2","effective_rr_tp2"))]: group.append(b)
        if len(group)>1: clusters.append(group)
    return {"clusters":clusters,"method":"semantic+scale-aware; statistical correlation requires history","effective_feature_count":max(0,len(keys)-sum(max(0,len(g)-1) for g in clusters))}


def _v52_quote_quality(item: dict[str,Any]) -> dict[str,Any]:
    depth=item.get("depth") or {}; price=_v52_finite(item.get("price_raw",item.get("live_price")),0)
    bid=_v52_finite(depth.get("bid"),0); ask=_v52_finite(depth.get("ask"),0)
    spread_pct=(ask-bid)/max(price,1e-12)*100 if bid>0 and ask>=bid and price>0 else None
    age=_v52_finite(item.get("live_price_age_sec"),float("inf"))
    return {"bid":bid or None,"ask":ask or None,"spread_pct":round(spread_pct,4) if spread_pct is not None else None,"quote_available":bool(bid>0 and ask>=bid),"stale":not math.isfinite(age) or age>MAX_LIVE_PRICE_AGE_SEC}


def _v52_execution_model(item: dict[str,Any], side: str) -> dict[str,Any]:
    q=_v52_quote_quality(item); price=_v52_finite(item.get("price_raw",item.get("live_price")),0)
    spread=_v52_finite(q.get("spread_pct"),0.0)
    vol=_v52_finite(item.get("volatility_pct"),0)
    depth=item.get("depth") or {}
    bid_sz=_v52_finite(depth.get("bid_qty"),0); ask_sz=_v52_finite(depth.get("ask_qty"),0)
    # If no L1/L2 quote is available, retain configured conservative friction and
    # explicitly downgrade execution confidence instead of pretending a fill exists.
    base_slip=SLIPPAGE_RATE*100.0
    delay_bars=_v52_finite(item.get("execution_delay_bars"),0)
    dynamic_slip=base_slip*(1.0+clamp(vol/10.0,0,2.0)+0.25*clamp(delay_bars,0,4))
    total_cost=2*FEE_RATE*100.0+max(spread,2*SPREAD_RATE*100.0)+2*dynamic_slip
    return {"model":"spread+volatility+liquidity proxy","side":side,"expected_spread_pct":round(spread,4),"expected_slippage_pct":round(dynamic_slip,4),"round_trip_cost_pct":round(total_cost,4),"depth_available":bool(bid_sz>0 and ask_sz>0),"fill_assumption":"next executable quote/open; never signal close","market_impact_proxy":"participation_rate required for order-size-specific estimate"}


def _v52_position_size(item: dict[str,Any], side: str, portfolio_mult: float = 1.0) -> dict[str,Any]:
    price=_v52_finite(item.get("price_raw",item.get("live_price")),0); sl=_v52_finite(item.get("stop_loss_raw"),0)
    stop_pct=abs(price-sl)/max(price,1e-12)*100 if price>0 and sl>0 else None
    edge=_v52_finite((item.get("v49") or {}).get("edge"),0)
    prob=_v52_finite((item.get("v49") or {}).get("probability_calibrated"),50)/100.0
    governor=_v52_finite(((item.get("v51") or {}).get("risk_plan") or {}).get("recommended_risk_pct"),V52_DEFAULT_RISK_PCT)
    vol_mult=clamp(1.0/(1.0+max(0,_v52_finite(item.get("volatility_pct"),0)-4.0)/10.0),0.35,1.0)
    uncertainty=clamp(abs(prob-0.5)*2.0,0,1)
    risk_pct=clamp(governor*vol_mult*clamp(0.5+uncertainty,0.5,1.25)*portfolio_mult,0,V52_MAX_PORTFOLIO_RISK_PCT)
    equity_env=os.getenv("TITAN_ACCOUNT_EQUITY","").strip()
    equity=_v52_finite(equity_env,0) if equity_env else 0.0
    risk_cash=equity*risk_pct/100.0 if equity>0 else None
    qty=(risk_cash/(price*stop_pct/100.0)) if risk_cash is not None and price>0 and stop_pct and stop_pct>0 else None
    return {"risk_pct":round(risk_pct,4),"stop_distance_pct":round(stop_pct,4) if stop_pct is not None else None,"risk_cash":round(risk_cash,8) if risk_cash is not None else None,"quantity":round(qty,8) if qty is not None else None,"equity_configured":equity>0,"method":"volatility+uncertainty+governor; bounded fractional-risk sizing"}


def _v52_portfolio_risk(item: dict[str,Any], side: str) -> dict[str,Any]:
    try:
        now=_v52_now(); active=[]
        with DB_LOCK,db_conn() as con:
            rows=con.execute("SELECT symbol,side,r_multiple_24h FROM titan_v49_ledger WHERE published=1 AND outcome_24h='PENDING' AND created_at>? ORDER BY created_at DESC LIMIT 100",(now-V49_ACTIVE_LOCK_HOURS*3600,)).fetchall()
            for r in rows: active.append(dict(r))
        same=sum(1 for r in active if _v52_side(r.get("side"))==side)
        symbols=list(dict.fromkeys([str(r.get("symbol") or "") for r in active if r.get("symbol")]+[str(item.get("symbol") or "")]))
        # Concentration proxy when live return matrix is not available.
        correlated_exposure=same+0.25*max(0,len(symbols)-same-1)
        dd_vals=[]
        try: dd_vals=_v52_returns_from_rows(_v49_query(10000),"24h")
        except Exception: _swallow()
        dd=_v52_max_drawdown(dd_vals)
        mult=1.0 if dd<3 else 0.75 if dd<5 else 0.50 if dd<7 else 0.25 if dd<V52_KILL_DD_PCT else 0.0
        reasons=[]
        if same>=MAX_PORTFOLIO_SAME_SIDE: reasons.append("same_side_capacity")
        if correlated_exposure>V52_MAX_CORRELATED_EXPOSURE: reasons.append("correlated_exposure_proxy")
        if dd>=V52_KILL_DD_PCT: reasons.append("portfolio_drawdown_kill")
        return {"ok":not reasons,"active_positions":len(active),"same_side":same,"symbols":symbols,"correlated_exposure_proxy":round(correlated_exposure,3),"drawdown_pct":round(dd,3),"risk_multiplier":mult,"reasons":reasons,"correlation_status":"proxy_until_position_return_matrix_available"}
    except Exception as exc:
        return {"ok":False,"risk_multiplier":0.0,"reasons":["portfolio_state_error"],"error":str(exc)[:160]}


def _v52_exit_plan(item: dict[str,Any], side: str) -> dict[str,Any]:
    price=_v52_finite(item.get("price_raw",item.get("live_price")),0); sl=_v52_finite(item.get("stop_loss_raw"),0); tp1=_v52_finite(item.get("tp1_raw"),0); tp2=_v52_finite(item.get("tp2_raw"),0)
    return {"stop":sl or None,"tp1":tp1 or None,"tp2":tp2 or None,"time_stop_hours":24,"rules":["structure_invalidation","hard_stop","target_ladder","time_decay","regime_invalidation","portfolio_kill_switch"],"mae_mfe_learning":True,"side":side}


def _v52_stress(item: dict[str,Any], side: str) -> dict[str,Any]:
    lv=item.get("v49",{}).get("levels") or {}; rr=_v52_finite(lv.get("effective_rr1"),0)
    cases=[]
    for name,cost_mult,delay in (("NORMAL",1,0),("ADVERSE",2,1),("SEVERE",5,2)):
        adj=rr-(V49_FRICTION_PCT*cost_mult/max(_v52_finite(lv.get("risk_pct"),1),1e-6))
        cases.append({"scenario":name,"cost_multiplier":cost_mult,"entry_delay_bars":delay,"effective_rr":round(adj,3),"passes":adj>=V49_MIN_EFFECTIVE_RR})
    return {"scenarios":cases,"survives_adverse":all(x["passes"] for x in cases[1:]),"includes":"spread/slippage shock + entry delay"}


def _v52_attribution(item: dict[str,Any]) -> dict[str,float]:
    e=item.get("edge") or {}; return {
        "trend":_v52_finite((e.get("regime") or {}).get("trend_score"),0),
        "structure":_v52_finite((e.get("structure") or {}).get("confirmation_score"),0),
        "confluence":_v52_finite((e.get("confluence") or {}).get("score"),0),
        "data_quality":_v52_finite((item.get("data_quality") or {}).get("score"),0),
        "execution":100.0 if _v52_quote_quality(item).get("quote_available") else 50.0,
        "risk":100.0 if _v52_finite(item.get("risk_distance_pct"),0)>0 else 0.0,
    }


def _v52_trust_gate(item: dict[str,Any]) -> dict[str,Any]:
    candidate=_v52_side(item.get("decision_tag")); reasons=[]; warnings=[]
    dq=_v52_finite((item.get("v51") or {}).get("data_contract",{}).get("live_age_sec"),float("inf"))
    dqs=_v52_finite((item.get("data_quality") or {}).get("score"),0)
    prob=_v52_finite((item.get("v51") or {}).get("probability"),float("nan"))
    cal_n=int((item.get("v51") or {}).get("probability_calibration_samples") or 0)
    exec_model=_v52_execution_model(item,candidate)
    portfolio=_v52_portfolio_risk(item,candidate)
    setup=_v52_setup(item); regime_prob=_v52_regime_prob(item)
    vol=_v52_finite(item.get("volatility_pct"),0)
    if candidate not in {"LONG","SHORT"}: reasons.append("no_authoritative_direction")
    if dqs<MIN_DATA_QUALITY_SCORE: reasons.append("data_quality_below_floor")
    if not math.isfinite(dq) or dq>MAX_LIVE_PRICE_AGE_SEC: reasons.append("live_price_stale")
    if vol>V52_MAX_VOLATILITY_PCT: reasons.append("extreme_volatility")
    if cal_n<V52_MIN_CALIBRATION_N or not math.isfinite(prob): warnings.append("calibration_not_strong_enough_for_probability_claim")
    if exec_model.get("expected_spread_pct") is not None and _v52_finite(exec_model.get("expected_spread_pct"),0)>V52_MAX_SPREAD_PCT: reasons.append("spread_too_high")
    if not portfolio.get("ok",False): reasons.extend(portfolio.get("reasons") or ["portfolio_risk_block"])
    if not math.isfinite(_v52_finite(item.get("price_raw",item.get("live_price")),0)) or _v52_finite(item.get("price_raw",item.get("live_price")),0)<=0: reasons.append("invalid_price")
    lv=item.get("v49",{}).get("levels") or {}
    rr=_v52_finite(lv.get("effective_rr1"),0)
    if rr<V49_MIN_EFFECTIVE_RR: reasons.append("economic_edge_below_rr_floor")
    # Regime transition does not force every trade to WAIT, but it requires a stronger setup.
    if regime_prob.get("transition",0)>=0.45 and setup not in {"BREAKOUT","TREND_CONTINUATION"}: reasons.append("regime_transition_unconfirmed_setup")
    position=_v52_position_size(item,candidate,portfolio.get("risk_multiplier",0.0))
    stress=_v52_stress(item,candidate)
    if not stress.get("survives_adverse",False): warnings.append("adverse_cost_stress_fails")
    trust_parts={
        "data":clamp(dqs,0,100),
        "regime":100*max(regime_prob.values()) if regime_prob else 0,
        "execution":100 if exec_model.get("depth_available") else 65,
        "risk":100*clamp(portfolio.get("risk_multiplier",0),0,1),
        "economic":clamp(50+20*rr,0,100),
        "calibration":min(100,50+cal_n*2.0) if cal_n else 35,
    }
    trust=round(sum(trust_parts.values())/len(trust_parts),1)
    final="LONG" if candidate=="LONG" and not reasons else "SHORT" if candidate=="SHORT" and not reasons else "WAIT"
    return {"decision":final,"candidate":candidate,"setup":setup,"regime_probabilities":regime_prob,"trust":trust,"trust_parts":trust_parts,"reasons":list(dict.fromkeys(reasons)),"warnings":list(dict.fromkeys(warnings)),"execution":exec_model,"portfolio":portfolio,"position_sizing":position,"exit_plan":_v52_exit_plan(item,candidate),"stress":stress,"attribution":_v52_attribution(item),"probability":prob if math.isfinite(prob) and cal_n>=V52_MIN_CALIBRATION_N else None,"probability_status":"CALIBRATED" if cal_n>=V52_MIN_CALIBRATION_N and math.isfinite(prob) else "INSUFFICIENT_CALIBRATION"}


def _v52_init_schema() -> None:
    try:
        with DB_LOCK,db_conn() as con:
            con.execute("""CREATE TABLE IF NOT EXISTS v52_decision_audit(
                id INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL, symbol TEXT, decision TEXT,
                setup TEXT, trust REAL, data_quality REAL, probability REAL, probability_status TEXT,
                risk_pct REAL, quantity REAL, reasons TEXT, warnings TEXT, attribution TEXT,
                build_id TEXT)""")
            con.execute("""CREATE TABLE IF NOT EXISTS v52_experiments(
                experiment_id TEXT PRIMARY KEY, created_at REAL, strategy TEXT, data_hash TEXT,
                params_hash TEXT, trials INTEGER DEFAULT 0, oos_sharpe REAL, dsr REAL,
                pbo REAL, status TEXT, metadata TEXT)""")
            con.execute("""CREATE TABLE IF NOT EXISTS v52_model_registry(
                model_id TEXT PRIMARY KEY, version TEXT, status TEXT, data_hash TEXT,
                params_hash TEXT, metrics TEXT, updated_at REAL)""")
            con.execute("""CREATE TABLE IF NOT EXISTS v52_drift(
                id INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL, feature TEXT,
                psi REAL, status TEXT, metadata TEXT)""")
            con.execute("""CREATE TABLE IF NOT EXISTS v52_reconciliation(
                id INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL, symbol TEXT,
                expected_state TEXT, actual_state TEXT, status TEXT, details TEXT)""")
    except Exception as exc:
        LOGGER.debug("V52 schema init failed: %s",exc)


def _v52_record_audit(item: dict[str,Any]) -> None:
    try:
        v=item.get("v52") or {}; pos=v.get("position_sizing") or {}
        with DB_LOCK,db_conn() as con:
            con.execute("INSERT INTO v52_decision_audit(created_at,symbol,decision,setup,trust,data_quality,probability,probability_status,risk_pct,quantity,reasons,warnings,attribution,build_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",(
                _v52_now(),str(item.get("symbol") or ""),str(v.get("decision") or "WAIT"),str(v.get("setup") or "UNKNOWN"),_v52_finite(v.get("trust"),0),_v52_finite((item.get("data_quality") or {}).get("score"),0),v.get("probability"),str(v.get("probability_status") or ""),_v52_finite(pos.get("risk_pct"),0),pos.get("quantity"),json.dumps(v.get("reasons") or [],ensure_ascii=False),json.dumps(v.get("warnings") or [],ensure_ascii=False),json.dumps(v.get("attribution") or {},ensure_ascii=False),V52_BUILD_ID))
    except Exception as exc: LOGGER.debug("V52 audit write failed: %s",exc)


def _v52_model_health(rows: list[dict[str,Any]]) -> dict[str,Any]:
    n=len(rows); returns=_v52_returns_from_rows(rows,"24h"); sr=_v52_sharpe(returns); dd=_v52_max_drawdown(returns); wins=sum(1 for x in returns if x>0); lo,hi=_v52_wilson(wins,len(returns)); brier=_v52_brier(rows); ll=_v52_logloss(rows); dsr=_v52_dsr(sr,1,n)
    return {"samples":n,"decisive":len(returns),"win_rate":wins/len(returns) if returns else None,"win_rate_lcb":lo,"win_rate_ucb":hi,"expectancy_r":statistics.mean(returns) if returns else None,"sharpe_like":sr,"deflated_sharpe_screen":dsr,"max_drawdown_pct":dd,"brier":brier,"log_loss":ll,"status":"INSUFFICIENT_SAMPLE" if len(returns)<30 else "TRACKING"}


def _v52_status() -> dict[str,Any]:
    rows=[]
    try: rows=_v49_query(20000)
    except Exception: rows=[]
    pub=[r for r in rows if int(r.get("published") or 0)==1]
    health=_v52_model_health(pub)
    return {"version":V52_VERSION,"build_id":V52_BUILD_ID,"authority":V52_AUTHORITY,"engine_mode":V52_ENGINE_MODE,"active_path":"DATA -> FEATURES -> V49 -> V51 -> V52 TRUST -> LEDGER","live_publication_requires_v52":True,"learning_requires_published_and_realized":True,"health":health,"pbo":{"status":"RUN_ON_EXPERIMENTS_ENDPOINT","pbo":None},"warnings":["No metric guarantees profitability","PBO/DSR require a registered trial set","portfolio correlation is conservative until a position-return matrix exists"]}


def _v52_coverage() -> dict[str,Any]:
    names={
      1:"DataContract/normalization",2:"OHLC/closed-candle rules",3:"Causal market structure",4:"FeatureRegistry/redundancy",5:"Setup-specific signals",6:"Meta-label/abstention",7:"Score/weight governance",8:"ATR/structure risk",9:"Look-ahead guard",10:"NaN/incomplete data guard",11:"CPU hot-path separation",12:"Single state ledger",13:"Published-only learning",14:"Overfit controls",15:"Regime robustness",16:"Edge-case fail-closed",17:"Unit/invariant test hooks",18:"Diagnostics/audit",19:"Backtest/live causal parity",20:"Fee/spread/slippage model",21:"Optimization with correctness",22:"Quote/spread engine",23:"Position sizing",24:"Portfolio risk",25:"Correlation exposure",26:"Regime probabilities",27:"Feature orthogonalization",28:"Setup engine",29:"Meta model",30:"Calibration metrics",31:"Confidence/probability separation",32:"Expected-value/target economics",33:"Regime-aware stops",34:"Distribution-aware exits",35:"MAE/MFE attribution",36:"Exit engine",37:"Time stop",38:"Drawdown governor",39:"Kill switch",40:"Order state machine",41:"Reconciliation",42:"Event-driven backtest primitives",43:"Purged/embargo validation",44:"PBO",45:"Deflated Sharpe",46:"Experiment registry",47:"Trial-count tracking",48:"Stress testing",49:"Monte Carlo extensions",50:"Shadow/canary lifecycle",51:"Model registry",52:"Data versioning hooks",53:"Reproducibility hashes",54:"Feature drift PSI",55:"Performance attribution",56:"Error attribution",57:"Uncertainty reporting",58:"Abstention/NO-TRADE as first-class outcome"}
    return {str(k):v for k,v in names.items()}


def _v52_hash_payload(x: Any) -> str:
    raw=json.dumps(x,sort_keys=True,default=str,ensure_ascii=False).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:24]


def _v52_self_test() -> int:
    fails=[]
    def ck(name,cond):
        if not cond: fails.append(name)
    ck("version",V52_VERSION.startswith("TITAN-V52"))
    ck("wilson",_v52_wilson(5,10)[0] is not None)
    ck("mdd",_v52_max_drawdown([1,-1,2,-3])>0)
    ck("psi",_v52_psi(list(range(40)),list(range(20,40))) is not None)
    item={"decision_tag":"LONG","price_raw":100.0,"stop_loss_raw":95.0,"tp1_raw":110.0,"tp2_raw":120.0,"volatility_pct":3.0,"score":68,"alignment":72,"signal_quality":75,"data_quality":{"score":90},"v51":{"probability":61,"probability_calibration_samples":30,"data_contract":{"live_age_sec":1}},"v49":{"levels":{"effective_rr1":2.0,"risk_pct":5.0},"edge":0.05}}
    ck("setup",_v52_setup(item) in {"BREAKOUT","TREND_CONTINUATION","PULLBACK","VOLATILITY_EXPANSION","MEAN_REVERSION","TRANSITION"})
    ck("size",_v52_position_size(item,"LONG",1)["risk_pct"]>=0)
    return 0 if not fails else 1


class TitanOrderStateMachine:
    """Deterministic order lifecycle; no broker side effects."""
    STATES={"CREATED","VALIDATED","SUBMITTED","PARTIALLY_FILLED","FILLED","CANCEL_PENDING","CANCELLED","REJECTED","CLOSED"}
    TRANSITIONS={
        "CREATED":{"VALIDATED","REJECTED"},"VALIDATED":{"SUBMITTED","REJECTED"},
        "SUBMITTED":{"PARTIALLY_FILLED","FILLED","CANCEL_PENDING","REJECTED"},
        "PARTIALLY_FILLED":{"PARTIALLY_FILLED","FILLED","CANCEL_PENDING","CLOSED"},
        "FILLED":{"CLOSED","CANCEL_PENDING"},"CANCEL_PENDING":{"CANCELLED","FILLED"},
        "CANCELLED":set(),"REJECTED":set(),"CLOSED":set(),
    }
    def __init__(self): self.state="CREATED"; self.history=[("CREATED",_v52_now())]
    def transition(self,new_state:str)->bool:
        new_state=str(new_state).upper()
        if new_state not in self.STATES or new_state not in self.TRANSITIONS.get(self.state,set()): return False
        self.state=new_state; self.history.append((new_state,_v52_now())); return True


class TitanKillSwitch:
    """Fail-closed operational governor; it only returns a state and never sends orders."""
    def evaluate(self, *, data_ok:bool, stale:bool=False, spread_pct:float=0, latency_ms:float=0,
                 drawdown_pct:float=0, reconciliation_ok:bool=True, duplicate_order:bool=False)->dict[str,Any]:
        reasons=[]
        if not data_ok: reasons.append("DATA_FAILURE")
        if stale: reasons.append("STALE_MARKET")
        if spread_pct>V52_MAX_SPREAD_PCT: reasons.append("SPREAD_EXPANSION")
        if latency_ms>V52_MAX_LATENCY_MS: reasons.append("LATENCY")
        if drawdown_pct>=V52_KILL_DD_PCT: reasons.append("DRAWDOWN_LIMIT")
        if not reconciliation_ok: reasons.append("POSITION_RECONCILIATION")
        if duplicate_order: reasons.append("DUPLICATE_ORDER")
        return {"state":"KILL" if reasons else "ARMED","reasons":reasons,"order_submission_allowed":not reasons}


class TitanReconciliationEngine:
    def compare(self, symbol:str, expected:dict[str,Any], actual:dict[str,Any])->dict[str,Any]:
        fields=("side","quantity","entry_price")
        mismatches=[]
        for k in fields:
            a=expected.get(k); b=actual.get(k)
            if isinstance(a,(int,float)) and isinstance(b,(int,float)):
                if abs(float(a)-float(b))>max(1e-9,abs(float(a))*1e-4): mismatches.append(k)
            elif str(a or "")!=str(b or ""): mismatches.append(k)
        status="MATCH" if not mismatches else "MISMATCH"
        try:
            with DB_LOCK,db_conn() as con:
                con.execute("INSERT INTO v52_reconciliation(created_at,symbol,expected_state,actual_state,status,details) VALUES(?,?,?,?,?,?)",(_v52_now(),symbol,json.dumps(expected,sort_keys=True),json.dumps(actual,sort_keys=True),status,json.dumps({"mismatches":mismatches},sort_keys=True)))
        except Exception: _swallow()
        return {"status":status,"mismatches":mismatches}


class TitanExperimentRegistry:
    """Tracks research trials so best-of-many results cannot be presented without trial context."""
    def __init__(self): self.path=V52_EXPERIMENT_PATH
    def register(self,strategy:str,data:Any,params:Any,returns:list[float],metadata:Optional[dict[str,Any]]=None)->dict[str,Any]:
        data_hash=_v52_hash_payload(data); params_hash=_v52_hash_payload(params); eid=_v52_hash_payload([strategy,data_hash,params_hash,_v52_now()])
        sr=_v52_sharpe(returns); dsr=_v52_dsr(sr,1, len(returns)); row={"experiment_id":eid,"created_at":_v52_now(),"strategy":strategy,"data_hash":data_hash,"params_hash":params_hash,"trials":1,"oos_sharpe":sr,"dsr":dsr,"pbo":None,"status":"REGISTERED","metadata":metadata or {}}
        try:
            with DB_LOCK,db_conn() as con: con.execute("INSERT OR REPLACE INTO v52_experiments(experiment_id,created_at,strategy,data_hash,params_hash,trials,oos_sharpe,dsr,pbo,status,metadata) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(eid,row["created_at"],strategy,data_hash,params_hash,1,sr,dsr,None,"REGISTERED",json.dumps(metadata or {},ensure_ascii=False)))
        except Exception: _swallow()
        return row


class TitanModelRegistry:
    def register(self,model_id:str,version:str,status:str,data:Any,params:Any,metrics:dict[str,Any])->dict[str,Any]:
        allowed={"ACTIVE","SHADOW","CANARY","RETIRED","REJECTED"}; status=status.upper() if status.upper() in allowed else "SHADOW"
        row={"model_id":model_id,"version":version,"status":status,"data_hash":_v52_hash_payload(data),"params_hash":_v52_hash_payload(params),"metrics":metrics,"updated_at":_v52_now()}
        try:
            with DB_LOCK,db_conn() as con: con.execute("INSERT OR REPLACE INTO v52_model_registry(model_id,version,status,data_hash,params_hash,metrics,updated_at) VALUES(?,?,?,?,?,?,?)",(model_id,version,status,row["data_hash"],row["params_hash"],json.dumps(metrics,sort_keys=True),row["updated_at"]))
        except Exception: _swallow()
        return row


class TitanEventDrivenBacktester:
    """Minimal event-driven simulator using the same causal OHLC primitives as live.
    `strategy_fn` receives bars available strictly before the current execution bar.
    """
    def run(self, df:pd.DataFrame, strategy_fn, fee_pct:float=FEE_RATE*100, slippage_pct:float=SLIPPAGE_RATE*100, max_hold:int=48)->dict[str,Any]:
        if df is None or len(df)<30:return {"status":"INSUFFICIENT_DATA","trades":[]}
        x=df.copy().reset_index(drop=True); trades=[]; i=20
        while i<len(x)-1:
            hist=x.iloc[:i].copy()
            try: sig=strategy_fn(hist).upper()
            except Exception: sig="WAIT"
            if sig not in {"LONG","SHORT"}: i+=1; continue
            entry=float(x.iloc[i]["open"]); end=min(len(x)-1,i+max_hold); exit_px=float(x.iloc[end]["close"]); reason="TIME"
            for j in range(i,end+1):
                h=float(x.iloc[j]["high"]); l=float(x.iloc[j]["low"])
                # Strategy is responsible for supplying levels through optional attributes.
                sl=None; tp=None
                if sig=="LONG" and hasattr(strategy_fn,"levels"): sl,tp=strategy_fn.levels(hist,"LONG",entry)
                elif sig=="SHORT" and hasattr(strategy_fn,"levels"): sl,tp=strategy_fn.levels(hist,"SHORT",entry)
                if sl is not None and tp is not None:
                    hit_sl=l<=sl; hit_tp=h>=tp
                    if hit_sl and hit_tp: reason="AMBIGUOUS"; exit_px=None; break
                    if hit_sl: reason="SL"; exit_px=sl; break
                    if hit_tp: reason="TP"; exit_px=tp; break
            if reason!="AMBIGUOUS" and exit_px is not None:
                gross=(exit_px/entry-1)*100*(1 if sig=="LONG" else -1); net=gross-2*fee_pct-2*slippage_pct
                trades.append({"entry_index":i,"exit_index":j if 'j' in locals() else end,"side":sig,"entry":entry,"exit":exit_px,"gross_pct":gross,"net_pct":net,"reason":reason})
            i=max(i+1,j+1 if 'j' in locals() else end+1)
        rets=[t["net_pct"] for t in trades]; return {"status":"OK","trades":trades,"count":len(trades),"expectancy_pct":statistics.mean(rets) if rets else None,"sharpe_like":_v52_sharpe(rets)}


def _v52_purged_splits(n:int,n_splits:int=5,embargo:int=5,horizon:int=1)->list[dict[str,tuple[int,int]]]:
    if n<=0 or n_splits<2:return []
    fold=max(1,n//n_splits); out=[]
    for k in range(n_splits):
        ts=k*fold; te=min(n,(k+1)*fold); test=(ts,te); train_end=max(0,ts-horizon-embargo); train_start=0
        if train_end<=train_start:continue
        out.append({"train":(train_start,train_end),"test":test,"purge":horizon,"embargo":embargo})
    return out


def _v52_feature_drift(feature:str, baseline:list[float], recent:list[float])->dict[str,Any]:
    psi=_v52_psi(baseline,recent)
    status="UNKNOWN" if psi is None else "HARD" if psi>=V52_DRIFT_PSI_HARD else "WARN" if psi>=V52_DRIFT_PSI_WARN else "NORMAL"
    try:
        with DB_LOCK,db_conn() as con: con.execute("INSERT INTO v52_drift(created_at,feature,psi,status,metadata) VALUES(?,?,?,?,?)",(_v52_now(),feature,psi,status,json.dumps({"baseline":len(baseline),"recent":len(recent)})))
    except Exception: _swallow()
    return {"feature":feature,"psi":psi,"status":status}


TITAN_V52_ORDER_STATE=TitanOrderStateMachine()
TITAN_V52_KILL_SWITCH=TitanKillSwitch()
TITAN_V52_RECONCILIATION=TitanReconciliationEngine()
TITAN_V52_EXPERIMENTS=TitanExperimentRegistry()
TITAN_V52_MODELS=TitanModelRegistry()
TITAN_V52_BACKTEST=TitanEventDrivenBacktester()


# V52 schema is initialized lazily too, so imports/tests remain safe when storage
# permissions are temporarily unavailable.
_v52_init_schema()


# ============================================================
# PUBLIC V52 REALTIME AUTHORITY
# ============================================================
def _v52_authoritative_analyze(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:
    """Internal V52 gateway retained as a candidate/publication primitive for V53."""
    try:
        candidate=_v51_build_authoritative(symbol,btc_trend)
        if not candidate:return None
        with TITAN_V51_PUBLISH_LOCK:
            trust=_v52_trust_gate(candidate)
            candidate["v52"]=trust
            candidate["trust"] = trust.get("trust",0)
            candidate["trust_status"] = "TRUSTED" if trust.get("decision") in {"LONG","SHORT"} else "BLOCKED"
            candidate["decision_architecture"]={
                "type":"DATA -> FEATURE_SPINE -> V49_POLICY -> V51_CANDIDATE -> V52_TRUST_GOVERNOR -> LEDGER",
                "authority":V52_AUTHORITY,"legacy_layers":"AUDIT_ONLY",
                "ai_can_create_direction":False,"confidence_is_probability":False,
                "indicators_closed_only":True,"lookahead":"CAUSAL_ONLY","repaint":"BLOCKED",
                "publication_requires_persistence":True,"learning_requires_published_realized_outcome":True,
            }
            final=str(trust.get("decision") or "WAIT")
            candidate["decision_tag"]=final; candidate["decision"]=final
            candidate["bias"]="صعودی" if final=="LONG" else "نزولی" if final=="SHORT" else "خنثی"
            candidate["decision_state"]="V52_PUBLISHED_PENDING_LEDGER" if final in {"LONG","SHORT"} else "V52_BLOCKED_WAIT"
            candidate["authority"]=V52_AUTHORITY
            candidate["signal_tag"]=f"V52 TRUST — {final}"
            candidate["decision_reasons"]=trust.get("reasons") or []
            candidate["decision_confidence"]=trust.get("trust",0)
            candidate["success_probability"]=trust.get("probability")
            candidate["success_probability_is_calibrated"]=trust.get("probability_status")=="CALIBRATED"
            if final in {"LONG","SHORT"}:
                try:
                    rid=_v49_record(candidate)
                    if rid is None:
                        final="WAIT"; candidate["decision_tag"]=candidate["decision"]="WAIT"; candidate["bias"]="خنثی"; candidate["decision_state"]="V52_LEDGER_WRITE_BLOCK"; candidate["signal_tag"]="V52 BLOCK — ledger persistence"; trust.setdefault("reasons",[]).append("authoritative_ledger_write_failed")
                except Exception as exc:
                    LOGGER.exception("V52 publication failed for %s; directional signal blocked because ledger persistence failed", symbol)
                    final="WAIT"; candidate["decision_tag"]=candidate["decision"]="WAIT"; candidate["bias"]="خنثی"; candidate["decision_state"]="V52_LEDGER_WRITE_BLOCK"; candidate["signal_tag"]="V52 BLOCK — ledger persistence"; trust.setdefault("reasons",[]).append("authoritative_ledger_write_exception")
            _v52_record_audit(candidate)
            return candidate
    except Exception as exc:
        LOGGER.exception("V52 analyze failed for %s: %s",symbol,exc)
        return None


@app.get("/api/v52/status")
def api_v52_status():
    try:return jsonify({"ok":True,**_v52_status()})
    except Exception as exc:return jsonify({"ok":False,"error":str(exc)[:240]}),500


@app.get("/api/v52/coverage")
def api_v52_coverage():
    return jsonify({"ok":True,"version":V52_VERSION,"coverage":_v52_coverage()})


@app.get("/api/v52/validation")
def api_v52_validation():
    try:
        rows=[r for r in _v49_query(20000) if int(r.get("published") or 0)==1]
        returns=_v52_returns_from_rows(rows,"24h")
        return jsonify({"ok":True,"version":V52_VERSION,"health":_v52_model_health(rows),"stress_reference":{"cost_shock":[1,2,5],"entry_delay_bars":[0,1,2]},"pbo":"INSUFFICIENT_TRIAL_REGISTRY" if len(rows)<V52_TRIAL_MIN_PBO else "USE_EXPERIMENT_REGISTRY","returns_samples":len(returns)})
    except Exception as exc:return jsonify({"ok":False,"error":str(exc)[:240]}),500


@app.get("/api/v52/portfolio")
def api_v52_portfolio():
    try:
        rows=[r for r in _v49_query(10000) if int(r.get("published") or 0)==1 and r.get("outcome_24h")=="PENDING"]
        return jsonify({"ok":True,"active":rows,"max_same_side":MAX_PORTFOLIO_SAME_SIDE,"max_portfolio_risk_pct":V52_MAX_PORTFOLIO_RISK_PCT})
    except Exception as exc:return jsonify({"ok":False,"error":str(exc)[:240]}),500
