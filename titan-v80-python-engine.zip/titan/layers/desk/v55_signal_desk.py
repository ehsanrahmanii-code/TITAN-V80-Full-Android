# [TITAN V77 layer] desk/v55_signal_desk - V55 professional signal desk
# Original V76 source lines 22830-23202 (kept verbatim unless listed in CHANGELOG.md).
# =============================================================================
# TITAN V55 — PROFESSIONAL SIGNAL DESK
# Ranked book, concurrent risk, stale-price hard gate, adaptive scan, desk API.
# Analysis only. No order execution. Layers above V54 never invent direction.
# =============================================================================

V55_VERSION = "TITAN-V55-PRO-SIGNAL-DESK"
V55_MAX_PUBLISHED_BOOK = 6          # max simultaneous LONG+SHORT across the desk
V55_MIN_TRUST_PUBLISH = 50.0
V55_MIN_RR_PUBLISH = 1.05
V55_MIN_QUALITY_PUBLISH = 47.0
V55_STALE_PRICE_SEC = 15.0
V55_SCAN_ADAPT_FLOOR = 20.0         # min seconds between full scans (mobile)
V55_SCAN_ADAPT_CEIL = 75.0
_V55_DESK_LOCK = threading.RLock()
_V55_DESK: dict[str, Any] = {
    "version": V55_VERSION,
    "updated_at": 0.0,
    "published": [],
    "lean": [],
    "wait": [],
    "blocked": [],
    "stats": {},
}
_V55_LAST_SCAN_MS = 0.0
_V55_ADAPT_INTERVAL = float(AUTO_SCAN_INTERVAL_SECONDS)


def _v55_live_age(item: dict[str, Any]) -> float:
    try:
        age = safe_float((item.get("data_contract") or {}).get("live_age_sec"), 1e9)
        if math.isfinite(age) and age >= 0:
            return float(age)
    except Exception:
        _swallow()
    sym = str(item.get("symbol") or "")
    with LIVE_LOCK:
        row = LIVE_PRICES.get(sym) or LIVE_PRICES.get(_normalize_symbol(sym))
    if not row:
        return 1e9
    return max(0.0, time.time() - safe_float(row.get("ts"), 0))


def _v55_score_rank(item: dict[str, Any]) -> float:
    """Single composite rank for professional desk ordering (higher = better)."""
    trust = safe_float(item.get("trust"), safe_float(item.get("decision_confidence"), 0))
    quality = safe_float(item.get("signal_quality"), 0)
    rr = safe_float(item.get("effective_rr_tp1"), safe_float(item.get("effective_rr1"), 0))
    score = safe_float(item.get("score"), 50)
    lean = abs(score - 50.0)
    age = _v55_live_age(item)
    freshness = 1.0 if age <= 5 else (0.7 if age <= 12 else 0.3)
    grade = str(item.get("grade") or "")
    grade_bonus = {"A+": 8, "A": 5, "B": 2}.get(grade, 0)
    return (
        trust * 0.35
        + quality * 0.25
        + min(rr, 3.0) * 12.0
        + lean * 0.4
        + grade_bonus
    ) * freshness


def _v55_publish_gate(item: dict[str, Any]) -> tuple[bool, str]:
    """Hard professional gates before a signal stays published on the desk."""
    side = str(item.get("decision") or item.get("decision_tag") or "WAIT")
    if side not in {"LONG", "SHORT"}:
        return False, "NOT_DIRECTIONAL"
    state = str(item.get("decision_state") or "")
    if "BLACKOUT" in state or "BLOCK" in state:
        return False, "BLOCKED_STATE"
    if "READY_FOR_PUBLICATION" not in state and "PUBLISHED" not in state and "V53_READY" not in state:
        # Unified accept: any trust-ready / central / published family
        if not any(k in state for k in ("PUBLISH", "READY", "V51_PUBLISHED", "V52_", "V53_", "CENTRAL_", "UNIFIED_", "V57_")):
            return False, "NOT_READY"
    trust = safe_float(item.get("trust"), safe_float(item.get("decision_confidence"), 0))
    quality = safe_float(item.get("signal_quality"), 0)
    rr = safe_float(item.get("effective_rr_tp1"), safe_float(item.get("effective_rr1"), 0))
    if trust < V55_MIN_TRUST_PUBLISH:
        return False, "LOW_TRUST"
    if quality < V55_MIN_QUALITY_PUBLISH:
        return False, "LOW_QUALITY"
    if rr > 0 and rr < V55_MIN_RR_PUBLISH:
        return False, "LOW_RR"
    age = _v55_live_age(item)
    if age > V55_STALE_PRICE_SEC:
        return False, "STALE_PRICE"
    entry = safe_float(item.get("price_raw"), safe_float(item.get("live_price"), 0))
    sl = safe_float(item.get("stop_loss_raw"), 0)
    tp1 = safe_float(item.get("tp1_raw"), 0)
    if entry <= 0 or sl <= 0 or tp1 <= 0:
        return False, "MISSING_LEVELS"
    if side == "LONG" and not (sl < entry < tp1):
        return False, "INVALID_LONG_LEVELS"
    if side == "SHORT" and not (tp1 < entry < sl):
        return False, "INVALID_SHORT_LEVELS"
    return True, "OK"


def _v55_summarize_item(item: dict[str, Any]) -> dict[str, Any]:
    return {
        "symbol": item.get("symbol"),
        "decision": item.get("decision") or item.get("decision_tag"),
        "decision_state": item.get("decision_state"),
        "trust": round(safe_float(item.get("trust"), safe_float(item.get("decision_confidence"), 0)), 1),
        "quality": round(safe_float(item.get("signal_quality"), 0), 1),
        "score": item.get("score"),
        "grade": item.get("grade"),
        "rr": round(safe_float(item.get("effective_rr_tp1"), safe_float(item.get("effective_rr1"), 0)), 3),
        "rank": round(_v55_score_rank(item), 2),
        "live_age_sec": round(_v55_live_age(item), 2),
        "price": item.get("price_raw") or item.get("live_price"),
        "stop": item.get("stop_loss_raw"),
        "tp1": item.get("tp1_raw"),
        "tp2": item.get("tp2_raw"),
        "alert_status": item.get("alert_status"),
        "desk_gate": item.get("v55_desk_gate"),
    }


def v55_rebuild_desk(market_data: Optional[list] = None) -> dict[str, Any]:
    """Rebuild the ranked professional signal book from the latest market snapshot."""
    with CACHE_LOCK:
        data = list(market_data if market_data is not None else (CACHE.get("data") or []))
    published, lean, wait, blocked = [], [], [], []
    for item in data:
        if not isinstance(item, dict):
            continue
        side = str(item.get("decision") or item.get("decision_tag") or "WAIT")
        ok, reason = _v55_publish_gate(item)
        item["v55_desk_gate"] = reason
        item["v55_rank"] = round(_v55_score_rank(item), 2)
        row = _v55_summarize_item(item)
        if side in {"LONG", "SHORT"} and ok:
            published.append(row)
        elif side in {"LEAN_LONG", "LEAN_SHORT"} or (side in {"LONG", "SHORT"} and not ok):
            if side in {"LONG", "SHORT"} and not ok:
                blocked.append(row)
            else:
                lean.append(row)
        else:
            wait.append(row)
    published.sort(key=lambda x: safe_float(x.get("rank"), 0), reverse=True)
    # Concurrent risk: keep only top N by rank
    if len(published) > V55_MAX_PUBLISHED_BOOK:
        demoted = published[V55_MAX_PUBLISHED_BOOK:]
        published = published[:V55_MAX_PUBLISHED_BOOK]
        for d in demoted:
            d["desk_gate"] = "BOOK_CAPACITY"
            blocked.append(d)
    lean.sort(key=lambda x: safe_float(x.get("rank"), 0), reverse=True)
    blocked.sort(key=lambda x: safe_float(x.get("rank"), 0), reverse=True)
    stats = {
        "published": len(published),
        "lean": len(lean),
        "wait": len(wait),
        "blocked": len(blocked),
        "long": sum(1 for x in published if x.get("decision") == "LONG"),
        "short": sum(1 for x in published if x.get("decision") == "SHORT"),
        "avg_trust": round(float(np.mean([safe_float(x.get("trust"), 0) for x in published])) if published else 0, 1),
        "avg_rr": round(float(np.mean([safe_float(x.get("rr"), 0) for x in published if safe_float(x.get("rr"), 0) > 0])) if any(safe_float(x.get("rr"), 0) > 0 for x in published) else 0, 3),
        "scan_interval_sec": round(_V55_ADAPT_INTERVAL, 1),
        "last_scan_ms": round(_V55_LAST_SCAN_MS, 1),
    }
    desk = {
        "version": V55_VERSION,
        "updated_at": time.time(),
        "updated_iso": _now_iso(),
        "published": published,
        "lean": lean[:12],
        "wait": wait[:8],
        "blocked": blocked[:12],
        "stats": stats,
        "gates": {
            "max_book": V55_MAX_PUBLISHED_BOOK,
            "min_trust": V55_MIN_TRUST_PUBLISH,
            "min_rr": V55_MIN_RR_PUBLISH,
            "min_quality": V55_MIN_QUALITY_PUBLISH,
            "stale_sec": V55_STALE_PRICE_SEC,
        },
        "storage": str(APP_HOME),
        "path": TITAN_ACTIVE_DECISION_PATH,
    }
    with _V55_DESK_LOCK:
        _V55_DESK.clear()
        _V55_DESK.update(desk)
    return desk


def v55_desk_snapshot() -> dict[str, Any]:
    with _V55_DESK_LOCK:
        if not _V55_DESK.get("updated_at"):
            return v55_rebuild_desk()
        return dict(_V55_DESK)


def v55_adapt_scan_interval(last_scan_ms: float) -> float:
    """Slow down when scans are heavy; speed up when the engine is light."""
    global _V55_ADAPT_INTERVAL, _V55_LAST_SCAN_MS, AUTO_SCAN_INTERVAL_SECONDS
    _V55_LAST_SCAN_MS = float(last_scan_ms or 0)
    if last_scan_ms > 20000:
        _V55_ADAPT_INTERVAL = min(V55_SCAN_ADAPT_CEIL, _V55_ADAPT_INTERVAL + 5)
    elif last_scan_ms > 10000:
        _V55_ADAPT_INTERVAL = min(V55_SCAN_ADAPT_CEIL, _V55_ADAPT_INTERVAL + 2)
    elif last_scan_ms < 3500:
        _V55_ADAPT_INTERVAL = max(V55_SCAN_ADAPT_FLOOR, _V55_ADAPT_INTERVAL - 3)
    else:
        _V55_ADAPT_INTERVAL = 0.9 * _V55_ADAPT_INTERVAL + 0.1 * float(AUTO_SCAN_INTERVAL_SECONDS)
    _V55_ADAPT_INTERVAL = float(clamp(_V55_ADAPT_INTERVAL, V55_SCAN_ADAPT_FLOOR, V55_SCAN_ADAPT_CEIL))
    return _V55_ADAPT_INTERVAL


def _v55_apply_to_item(item: Optional[dict[str, Any]]) -> Optional[dict[str, Any]]:
    if not item:
        return item
    try:
        ok, reason = _v55_publish_gate(item)
        item["v55_desk_gate"] = reason
        item["v55_rank"] = round(_v55_score_rank(item), 2)
        item["v55_version"] = V55_VERSION
        side = str(item.get("decision") or item.get("decision_tag") or "WAIT")
        if side in {"LONG", "SHORT"} and not ok:
            # Soft demote on desk: keep evidence, mark not desk-published
            item["desk_published"] = False
            item.setdefault("v55_warnings", []).append(reason)
            if reason == "STALE_PRICE":
                item = _v40_force_wait(item, "قیمت زنده کهنه است — انتشار روی میز سیگنال متوقف شد", "V55_STALE_PRICE")
                item["decision_state"] = "V55_STALE_PRICE"
        else:
            item["desk_published"] = bool(side in {"LONG", "SHORT"} and ok)
    except Exception as exc:
        LOGGER.debug("V55 item gate: %s", type(exc).__name__)
    return item


_V55_PREV_ANALYZE = analyze_asset


def analyze_asset(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:  # noqa: F811
    """V55 public gateway = V54 gateway + professional desk gates."""
    out = _V55_PREV_ANALYZE(symbol, btc_trend)
    return _v55_apply_to_item(out)




def _v55_after_scan_hook(results: list, scan_ms: float) -> None:
    try:
        v55_adapt_scan_interval(scan_ms)
        v55_rebuild_desk(results)
    except Exception as exc:
        LOGGER.debug("V55 after-scan: %s", exc)


# Hook adaptive interval into autonomous loop without rewriting the whole loop body
_V55_ORIG_AUTO = _v29_auto_loop


def _v29_auto_loop() -> None:  # noqa: F811
    last_scan = 0.0
    while True:
        try:
            now = time.time()
            interval = max(V55_SCAN_ADAPT_FLOOR, float(_V55_ADAPT_INTERVAL or AUTO_SCAN_INTERVAL_SECONDS))
            if now - last_scan >= interval:
                started = time.perf_counter()
                queued = _background_market_refresh(False)
                last_scan = now
                elapsed_ms = (time.perf_counter() - started) * 1000
                if not queued:
                    # already running; don't adapt on queue-only
                    pass
                LOGGER.info(
                    "V55 autonomous scan %s in %.1fms (next interval %.0fs)",
                    "queued" if queued else "already-running",
                    elapsed_ms,
                    interval,
                )
            _scan_supervisor_tick()
            _safe_background_forecast_maintenance()
            try:
                if now - _PERFORMANCE_LAST_RUN >= PERFORMANCE_AUTO_INTERVAL_SECONDS:
                    threading.Thread(
                        target=autonomous_performance_maintenance,
                        kwargs={"force": False},
                        name="titan-performance-maintenance",
                        daemon=True,
                    ).start()
            except Exception as perf_exc:
                LOGGER.debug("Performance maintenance dispatch failed: %s", perf_exc)
            try:
                with CACHE_LOCK:
                    snap = list(CACHE.get("data") or [])
                if snap:
                    v55_rebuild_desk(snap)
            except Exception:
                _swallow()
        except Exception as exc:
            LOGGER.warning("V55 autonomous loop error: %s", exc)
        LIVE_STOP.wait(AUTO_MAINTENANCE_INTERVAL_SECONDS)


# Patch public update_cache: rebuild desk after every successful scan
_V55_PREV_UPDATE_PUBLIC = update_cache


def update_cache(force: bool = False):  # noqa: F811
    t0 = time.perf_counter()
    out = _V55_PREV_UPDATE_PUBLIC(force)
    scan_ms = (time.perf_counter() - t0) * 1000.0
    try:
        data = out[0] if isinstance(out, tuple) and out else None
        if data:
            for it in data:
                if isinstance(it, dict):
                    _v55_apply_to_item(it)
            _v55_after_scan_hook(list(data), scan_ms)
    except Exception as exc:
        LOGGER.debug("V55 cache hook: %s", exc)
    return out


@app.get("/api/v55/desk")
def api_v55_desk():
    desk = v55_desk_snapshot()
    return jsonify({"ok": True, "desk": desk})


@app.get("/api/v55/status")
def api_v55_status():
    desk = v55_desk_snapshot()
    return jsonify({
        "ok": True,
        "version": V55_VERSION,
        "build": TITAN_BUILD_ID,
        "path": TITAN_ACTIVE_DECISION_PATH,
        "storage": str(APP_HOME),
        "single_folder": TITAN_FOLDER_NAME,
        "adapt_interval_sec": round(_V55_ADAPT_INTERVAL, 1),
        "last_scan_ms": round(_V55_LAST_SCAN_MS, 1),
        "desk_stats": desk.get("stats") or {},
        "gates": desk.get("gates") or {},
    })


def _v55_self_test() -> int:
    fails = []
    def chk(n, c):
        print(("  ✓ " if c else "  ✗ ") + n)
        if not c:
            fails.append(n)
    sample = {
        "symbol": "BTC/USDT", "decision": "LONG", "decision_state": "V53_READY_FOR_PUBLICATION",
        "trust": 70, "signal_quality": 60, "effective_rr_tp1": 1.5, "score": 68, "grade": "A",
        "price_raw": 100.0, "stop_loss_raw": 97.0, "tp1_raw": 105.0, "tp2_raw": 110.0,
        "data_contract": {"live_age_sec": 2.0},
    }
    ok, reason = _v55_publish_gate(sample)
    chk("gate_ok", ok and reason == "OK")
    bad = dict(sample); bad["stop_loss_raw"] = 102.0
    chk("invalid_levels", not _v55_publish_gate(bad)[0])
    stale = dict(sample); stale["data_contract"] = {"live_age_sec": 99}
    chk("stale", _v55_publish_gate(stale)[1] == "STALE_PRICE")
    chk("rank_positive", _v55_score_rank(sample) > 20)
    interval = v55_adapt_scan_interval(3000)
    chk("adapt_floor", V55_SCAN_ADAPT_FLOOR <= interval <= V55_SCAN_ADAPT_CEIL)
    print("V55 SELF-TEST:", "PASS" if not fails else "FAIL " + ",".join(fails))
    return 0 if not fails else 1
