# [TITAN V77 layer] desk/v53_decision_dna - V53 decision DNA / counterfactual / error attribution
# Original V76 source lines 21623-21976 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# TITAN V53 — DECISION DNA / COUNTERFACTUAL / ERROR ATTRIBUTION
# ============================================================
V53_VERSION = "TITAN-V53-DECISION-DNA"
V53_BUILD_ID = "V53-PRO-2026-10"
V53_AUTHORITY = "TITAN-V53-TRUST-STABILITY-GOVERNOR"
V53_ENGINE_MODE = "ONE_BRAIN + DECISION_DNA + COUNTERFACTUAL_STABILITY + ERROR_ATTRIBUTION"
V53_MIN_STABILITY = 58.0
V53_HARD_STABILITY = 42.0
V53_MAX_SENSITIVITY_DROP = 35.0
V53_MODEL_LIFECYCLE = ("RESEARCH","BACKTEST","OOS","SHADOW","CANARY","PRODUCTION","DEGRADED","RETIRED","REJECTED")


def _v53_num(x, default=0.0):
    try:
        y=float(x)
        return y if math.isfinite(y) else float(default)
    except Exception:
        _swallow()
        return float(default)


def _v53_hash(x):
    return _v52_hash_payload(x)


def _v53_feature_value(item, key, default=0.0):
    # Stable extraction for counterfactual perturbations; missing values remain missing.
    if key in item and item.get(key) is not None:
        return _v53_num(item.get(key), default)
    for container_key in ("v49","v51","v52","edge","fusion","technical"):
        obj=item.get(container_key)
        if isinstance(obj,dict) and key in obj and obj.get(key) is not None:
            return _v53_num(obj.get(key), default)
    return float(default)


def _v53_decision_vector(item):
    v52=item.get("v52") if isinstance(item.get("v52"),dict) else {}
    return {
        "decision":str(v52.get("decision") or item.get("decision_tag") or "WAIT"),
        "candidate":str(v52.get("candidate") or item.get("decision_tag") or "WAIT"),
        "trust":_v53_num(v52.get("trust"),0),
        "data_quality":_v53_num((item.get("data_quality") or {}).get("score"),0),
        "rr":_v53_num(((item.get("v49") or {}).get("levels") or {}).get("effective_rr1"),0),
        "probability":v52.get("probability"),
        "probability_status":str(v52.get("probability_status") or "UNKNOWN"),
        "reasons":list(v52.get("reasons") or []),
        "warnings":list(v52.get("warnings") or []),
    }


def _v53_counterfactual_case(item, name, mutate):
    base=_v53_decision_vector(item)
    try:
        x=copy.deepcopy(item)
        mutate(x)
        g=_v52_trust_gate(x)
        side=str(g.get("decision") or "WAIT")
        changed=side != base["decision"]
        trust_delta=_v53_num(g.get("trust"),0)-base["trust"]
        return {
            "case":name,"decision":side,"trust":round(_v53_num(g.get("trust"),0),2),
            "trust_delta":round(trust_delta,2),"changed":changed,
            "reasons":list(g.get("reasons") or []),
            "warnings":list(g.get("warnings") or []),
        }
    except Exception as exc:
        return {"case":name,"decision":"WAIT","trust":0.0,"trust_delta":-base["trust"],"changed":True,"error":str(exc)[:180]}


def _v53_counterfactual(item):
    base=_v53_decision_vector(item)
    if base["decision"] not in {"LONG","SHORT"}:
        # We still test WAIT stability, but never promote it.
        pass
    cases=[]
    cases.append(_v53_counterfactual_case(item,"SPREAD_X2",lambda x: x.setdefault("v52",{}).update({"_v53_spread_shock":True})))
    # Apply explicit market-condition perturbations to the fields consumed by V52.
    cases[-1]=_v53_counterfactual_case(item,"SPREAD_X2",lambda x: x.update({"depth":({"bid":_v53_num((x.get("depth") or {}).get("bid"),_v53_num(x.get("price_raw"),0)*0.999)*0.9995,"ask":_v53_num((x.get("depth") or {}).get("ask"),_v53_num(x.get("price_raw"),0)*1.001)*1.0005,"bid_qty":_v53_num((x.get("depth") or {}).get("bid_qty"),1),"ask_qty":_v53_num((x.get("depth") or {}).get("ask_qty"),1)})}))
    cases.append(_v53_counterfactual_case(item,"VOLATILITY_PLUS_30",lambda x: x.update({"volatility_pct":_v53_num(x.get("volatility_pct"),0)*1.30+0.01})))
    cases.append(_v53_counterfactual_case(item,"ENTRY_DELAY_1_BAR",lambda x: x.update({"execution_delay_bars":1,"slippage_pct":_v53_num(x.get("slippage_pct"),0)+0.10})))
    cases.append(_v53_counterfactual_case(item,"PROBABILITY_MINUS_5PT",lambda x: x.setdefault("v51",{}).update({"probability":max(0.0,_v53_num((x.get("v51") or {}).get("probability"),50)-5.0)})))
    cases.append(_v53_counterfactual_case(item,"REGIME_TRANSITION",lambda x: x.update({"regime":"TRANSITION","regime_state":"TRANSITION"})))
    stable=sum(1 for c in cases if not c.get("changed"))
    avg_abs_drop=statistics.mean([max(0,-_v53_num(c.get("trust_delta"),0)) for c in cases]) if cases else 0
    worst=min([_v53_num(c.get("trust"),0) for c in cases],default=base["trust"])
    stability=100.0
    if cases:
        stability=100.0*(stable/len(cases))
        stability-=min(35.0,avg_abs_drop*0.75)
        if worst < V53_HARD_STABILITY: stability-=15.0
    stability=clamp(stability,0,100)
    return {"base":base,"cases":cases,"stable_cases":stable,"total_cases":len(cases),"worst_trust":round(worst,2),"avg_negative_trust_delta":round(avg_abs_drop,2),"stability_score":round(stability,2),"status":"STABLE" if stability>=V53_MIN_STABILITY else "FRAGILE" if stability>=V53_HARD_STABILITY else "UNSTABLE"}


def _v53_attribution(item, outcome=None):
    """Causal-ish error taxonomy. It attributes only observable failure signals; no invented root cause."""
    v52=item.get("v52") if isinstance(item.get("v52"),dict) else {}
    decision=str(v52.get("decision") or item.get("decision_tag") or "WAIT")
    reasons=set(str(x) for x in (v52.get("reasons") or []))
    warnings=set(str(x) for x in (v52.get("warnings") or []))
    out={k:0.0 for k in ("signal_error","regime_error","entry_error","execution_error","exit_error","risk_error","calibration_error","data_error")}
    if any("data" in x or "stale" in x for x in reasons): out["data_error"]+=1.0
    if any("regime" in x for x in reasons): out["regime_error"]+=1.0
    if any("spread" in x or "execution" in x or "slippage" in x for x in reasons|warnings): out["execution_error"]+=1.0
    if any("calibration" in x for x in warnings): out["calibration_error"]+=1.0
    if any("risk" in x or "portfolio" in x for x in reasons): out["risk_error"]+=1.0
    if outcome in {"LOSS","WIN"} and decision in {"LONG","SHORT"}:
        if outcome=="LOSS": out["signal_error"]+=0.25
    if outcome in {"AMBIGUOUS","TIME_EXIT"}: out["exit_error"]+=0.5
    total=sum(out.values())
    normalized={k:round(v/total,4) for k,v in out.items()} if total>0 else {k:0.0 for k in out}
    primary=max(normalized,key=normalized.get) if total>0 else "UNATTRIBUTED"
    return {"decision":decision,"outcome":outcome,"raw":out,"normalized":normalized,"primary":primary,"attribution_is_observational":True}


def _v53_decision_dna(item, counterfactual=None, attribution=None):
    v52=_v53_decision_vector(item)
    setup=str((item.get("v52") or {}).get("setup") or "UNKNOWN")
    regime=(item.get("regime") or item.get("market_regime") or (item.get("v52") or {}).get("regime_probabilities") or "UNKNOWN")
    dna={
        "version":V53_VERSION,"build_id":V53_BUILD_ID,"symbol":str(item.get("symbol") or ""),
        "timestamp":_v52_now(),"decision":v52["decision"],"candidate":v52["candidate"],
        "authority":V53_AUTHORITY,"setup":setup,"regime":regime,
        "trust":v52["trust"],"data_quality":v52["data_quality"],"effective_rr":v52["rr"],
        "probability":v52["probability"],"probability_status":v52["probability_status"],
        "reasons":v52["reasons"],"warnings":v52["warnings"],
        "v52_trust_parts":(item.get("v52") or {}).get("trust_parts") or {},
        "attribution":attribution or _v53_attribution(item),
        "counterfactual_summary":{
            "stability_score":_v53_num((counterfactual or {}).get("stability_score"),0),
            "status":(counterfactual or {}).get("status","UNKNOWN"),
        },
        "lineage":{"data":"live/historical inputs","feature_spine":"causal","decision":"V52 trust governor","publication":"V53 stability governor","learning":"published realized outcomes only"},
    }
    dna["decision_hash"]=_v53_hash(dna)
    return dna


def _v53_init_schema():
    try:
        with DB_LOCK,db_conn() as con:
            con.execute("""CREATE TABLE IF NOT EXISTS v53_decision_dna(
                decision_hash TEXT PRIMARY KEY, created_at REAL, symbol TEXT, decision TEXT, stability REAL,
                status TEXT, dna TEXT, counterfactual TEXT, attribution TEXT)""")
            con.execute("""CREATE TABLE IF NOT EXISTS v53_error_attribution(
                id INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL, decision_hash TEXT, symbol TEXT,
                outcome TEXT, primary_error TEXT, attribution TEXT)""")
            con.execute("""CREATE TABLE IF NOT EXISTS v53_lifecycle(
                model_id TEXT PRIMARY KEY, state TEXT, version TEXT, previous_state TEXT,
                reason TEXT, updated_at REAL, evidence TEXT)""")
            con.execute("""CREATE TABLE IF NOT EXISTS v53_experiments(
                experiment_id TEXT PRIMARY KEY, created_at REAL, parent_id TEXT, strategy TEXT,
                data_hash TEXT, params_hash TEXT, trial_no INTEGER, oos_metrics TEXT,
                stability REAL, status TEXT, notes TEXT)""")
            con.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_v53_error_once ON v53_error_attribution(decision_hash,outcome)")
    except Exception as exc: LOGGER.debug("V53 schema init failed: %s",exc)


def _v53_store_dna(dna, counterfactual):
    try:
        with DB_LOCK,db_conn() as con:
            con.execute("INSERT OR REPLACE INTO v53_decision_dna(decision_hash,created_at,symbol,decision,stability,status,dna,counterfactual,attribution) VALUES(?,?,?,?,?,?,?,?,?)",(
                dna["decision_hash"],_v52_now(),dna["symbol"],dna["decision"],_v53_num(dna["counterfactual_summary"]["stability_score"]),dna["counterfactual_summary"]["status"],json.dumps(dna,ensure_ascii=False,default=str),json.dumps(counterfactual,ensure_ascii=False,default=str),json.dumps(dna.get("attribution") or {},ensure_ascii=False,default=str)))
        return True
    except Exception as exc: LOGGER.debug("V53 DNA write failed: %s",exc); return False


def _v53_record_error(item, outcome=None):
    try:
        dna=item.get("decision_dna") or {}; a=_v53_attribution(item,outcome)
        with DB_LOCK,db_conn() as con:
            con.execute("INSERT OR IGNORE INTO v53_error_attribution(created_at,decision_hash,symbol,outcome,primary_error,attribution) VALUES(?,?,?,?,?,?)",(_v52_now(),str(dna.get("decision_hash") or ""),str(item.get("symbol") or ""),outcome,a["primary"],json.dumps(a,ensure_ascii=False)))
        return a
    except Exception: return _v53_attribution(item,outcome)


def _v53_lifecycle_transition(model_id, new_state, version=V53_VERSION, reason="", evidence=None):
    new_state=str(new_state).upper()
    if new_state not in V53_MODEL_LIFECYCLE: return {"ok":False,"error":"invalid_state"}
    try:
        with DB_LOCK,db_conn() as con:
            row=con.execute("SELECT state FROM v53_lifecycle WHERE model_id=?",(model_id,)).fetchone()
            prev=str(row[0]) if row else None
            allowed={None:{"RESEARCH"},"RESEARCH":{"BACKTEST","REJECTED"},"BACKTEST":{"OOS","REJECTED"},"OOS":{"SHADOW","REJECTED"},"SHADOW":{"CANARY","REJECTED","DEGRADED"},"CANARY":{"PRODUCTION","SHADOW","REJECTED","DEGRADED"},"PRODUCTION":{"DEGRADED","RETIRED"},"DEGRADED":{"SHADOW","RETIRED","REJECTED"},"RETIRED":set(),"REJECTED":set()}
            if new_state not in allowed.get(prev,set()): return {"ok":False,"error":"invalid_transition","from":prev,"to":new_state}
            con.execute("INSERT OR REPLACE INTO v53_lifecycle(model_id,state,version,previous_state,reason,updated_at,evidence) VALUES(?,?,?,?,?,?,?)",(model_id,new_state,version,prev,reason,_v52_now(),json.dumps(evidence or {},ensure_ascii=False,default=str)))
            return {"ok":True,"model_id":model_id,"from":prev,"to":new_state}
    except Exception as exc: return {"ok":False,"error":str(exc)[:180]}


def _v53_register_experiment(strategy, data, params, oos_metrics, parent_id=None, stability=None, notes=""):
    eid=_v53_hash({"strategy":strategy,"data":_v53_hash(data),"params":_v53_hash(params),"time_bucket":int(_v52_now()/3600)})
    try:
        with DB_LOCK,db_conn() as con:
            n=int(con.execute("SELECT COUNT(*) FROM v53_experiments").fetchone()[0])+1
            con.execute("INSERT OR REPLACE INTO v53_experiments(experiment_id,created_at,parent_id,strategy,data_hash,params_hash,trial_no,oos_metrics,stability,status,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?)",(eid,_v52_now(),parent_id,strategy,_v53_hash(data),_v53_hash(params),n,json.dumps(oos_metrics or {},sort_keys=True,default=str),stability,"REGISTERED",notes))
        return {"experiment_id":eid,"trial_no":n,"status":"REGISTERED"}
    except Exception as exc: return {"experiment_id":eid,"status":"ERROR","error":str(exc)[:180]}



def _v53_process_realized_outcomes(limit=500):
    """Attach realized outcomes to the exact published Decision DNA hash once."""
    processed=0
    try:
        with DB_LOCK,db_conn() as con:
            rows=con.execute("SELECT id,symbol,side,decision_hash,outcome_24h FROM titan_v49_ledger WHERE published=1 AND outcome_24h IN ('WIN','LOSS','AMBIGUOUS','TIME_EXIT') AND decision_hash IS NOT NULL AND decision_hash!='' ORDER BY created_at DESC LIMIT ?",(int(limit),)).fetchall()
            dna_cache={}
            for r in rows:
                dh=str(r[3] or ""); outcome=str(r[4] or "")
                if not dh or not outcome: continue
                seen=con.execute("SELECT 1 FROM v53_error_attribution WHERE decision_hash=? AND outcome=? LIMIT 1",(dh,outcome)).fetchone()
                if seen: continue
                drow=con.execute("SELECT dna FROM v53_decision_dna WHERE decision_hash=?",(dh,)).fetchone()
                if not drow: continue
                try: dna=json.loads(drow[0]) if drow[0] else {}
                except Exception: dna={}
                item={"symbol":str(r[1] or ""),"decision_tag":str(r[2] or "WAIT"),"v52":dna.get("v52") or {"decision":str(r[2] or "WAIT")},"decision_dna":dna}
                a=_v53_record_error(item,outcome)
                processed+=1
        return processed
    except Exception as exc:
        LOGGER.debug("V53 realized attribution failed: %s",exc); return processed



def _v53_validation_summary():
    try:
        with DB_LOCK,db_conn() as con:
            dna=int(con.execute("SELECT COUNT(*) FROM v53_decision_dna").fetchone()[0])
            exp=int(con.execute("SELECT COUNT(*) FROM v53_experiments").fetchone()[0])
            life=[dict(r) for r in con.execute("SELECT model_id,state,version,updated_at FROM v53_lifecycle ORDER BY updated_at DESC LIMIT 100").fetchall()]
        return {"dna_records":dna,"experiments":exp,"lifecycle":life,"promotion_rule":"No direct promotion from backtest; OOS -> shadow -> canary -> production only"}
    except Exception as exc: return {"error":str(exc)[:180]}


def _v53_self_test():
    fails=[]
    def ck(n,c):
        if not c: fails.append(n)
    ck("version",V53_VERSION.startswith("TITAN-V53"))
    x={"symbol":"TEST/USDT","decision_tag":"LONG","data_quality":{"score":80},"v49":{"levels":{"effective_rr1":2.0},"probability":55},"v51":{"probability":55,"probability_calibration_samples":30},"volatility_pct":5.0,"price_raw":100,"v52":{"decision":"LONG","candidate":"LONG","trust":80,"trust_parts":{"data":80},"reasons":[],"warnings":[]}}
    cf=_v53_counterfactual(x)
    ck("counterfactual_cases",len(cf["cases"])==5)
    dna=_v53_decision_dna(x,cf,_v53_attribution(x))
    ck("dna_hash",isinstance(dna.get("decision_hash"),str) and len(dna.get("decision_hash") or "")>=16)
    ck("lifecycle_invalid",not _v53_lifecycle_transition("__selftest__","PRODUCTION").get("ok"))
    return 0 if not fails else 1


_v53_init_schema()


def update_cache(force: bool=False):
    """V53 runtime refresh: evaluate ledger, then attribute realized outcomes to exact DNA."""
    out=_v52_update_cache_base(force)
    try:_v53_process_realized_outcomes(limit=500)
    except Exception as exc: LOGGER.debug("V53 outcome attribution hook failed: %s",exc)
    return out


# V53 is the sole public realtime gateway. V52 remains the trusted risk/economic
# governor, while V53 adds decision lineage and stability before authoritative publication.
def analyze_asset(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:
    try:
        candidate=_v51_build_authoritative(symbol,btc_trend)
        if not candidate: return None
        with TITAN_V51_PUBLISH_LOCK:
            trust=_v52_trust_gate(candidate)
            candidate["v52"]=trust
            candidate["trust"]=trust.get("trust",0)
            candidate["trust_status"]="TRUSTED" if trust.get("decision") in {"LONG","SHORT"} else "BLOCKED"
            final=str(trust.get("decision") or "WAIT")
            candidate["decision_tag"]=final; candidate["decision"]=final
            candidate["bias"]="صعودی" if final=="LONG" else "نزولی" if final=="SHORT" else "خنثی"
            candidate["authority"]=V53_AUTHORITY
            cf=_v53_counterfactual(candidate)
            candidate["counterfactual_v53"]=cf
            stability=_v53_num(cf.get("stability_score"),0)
            # Fragile/unstable directional decisions abstain. WAIT remains WAIT.
            if final in {"LONG","SHORT"} and stability < V53_MIN_STABILITY:
                final="WAIT"
                candidate["decision_tag"]=candidate["decision"]="WAIT"
                candidate["bias"]="خنثی"
                candidate["decision_state"]="V53_STABILITY_BLOCK"
                candidate["signal_tag"]="V53 STABILITY — WAIT"
                trust.setdefault("reasons",[]).append("decision_stability_below_floor")
            else:
                candidate["decision_state"]="V53_READY_FOR_PUBLICATION" if final in {"LONG","SHORT"} else "V53_WAIT"
                candidate["signal_tag"]=f"V53 TRUST-STABILITY — {final}"
            candidate["decision_reasons"]=list(dict.fromkeys(trust.get("reasons") or []))
            candidate["decision_confidence"]=trust.get("trust",0)
            candidate["success_probability"]=trust.get("probability")
            candidate["success_probability_is_calibrated"]=trust.get("probability_status")=="CALIBRATED"
            attribution=_v53_attribution(candidate)
            dna=_v53_decision_dna(candidate,cf,attribution)
            candidate["decision_dna"]=dna
            candidate["decision_hash"]=dna["decision_hash"]
            candidate["decision_architecture"]={
                "type":V53_ENGINE_MODE,"authority":V53_AUTHORITY,"upstream_v52":"TRUST_GOVERNOR",
                "publication_requires_v53_stability":True,"counterfactual_required":True,
                "learning_requires_published_realized_outcome":True,"confidence_is_probability":False,
                "lookahead":"CAUSAL_ONLY","repaint":"BLOCKED",
            }
            # The ledger is written only after the complete decision DNA exists.
            if final in {"LONG","SHORT"}:
                try:
                    rid=_v49_record(candidate)
                    if rid is None:
                        final="WAIT"; candidate["decision_tag"]=candidate["decision"]="WAIT"; candidate["bias"]="خنثی"; candidate["decision_state"]="V53_LEDGER_WRITE_BLOCK"; trust.setdefault("reasons",[]).append("authoritative_ledger_write_failed")
                except Exception as exc:
                    LOGGER.exception("V53 publication failed for %s; directional signal blocked because ledger persistence failed", symbol)
                    final="WAIT"; candidate["decision_tag"]=candidate["decision"]="WAIT"; candidate["bias"]="خنثی"; candidate["decision_state"]="V53_LEDGER_WRITE_BLOCK"; trust.setdefault("reasons",[]).append("authoritative_ledger_write_exception")
            _v52_record_audit(candidate)
            _v53_store_dna(dna,cf)
            return _dashboard_finalize_item(candidate)
    except Exception as exc:
        LOGGER.exception("V53 analyze failed for %s: %s",symbol,exc)
        return None


@app.get("/api/v53/status")
def api_v53_status():
    try:
        return jsonify({"ok":True,"version":V53_VERSION,"build_id":V53_BUILD_ID,"authority":V53_AUTHORITY,"validation":_v53_validation_summary()})
    except Exception as exc:return jsonify({"ok":False,"error":str(exc)[:240]}),500


@app.get("/api/v53/diagnostics")
def api_v53_diagnostics():
    """Runtime health: uptime, threads, DB size, cache sizes and every suppressed exception site."""
    try:
        try: db_mb = round(DB_PATH.stat().st_size / 1048576, 2)
        except OSError: db_mb = None
        with _SWALLOW_LOCK:
            top = sorted(_SWALLOWED.items(), key=lambda kv: -kv[1])[:25]
        with KLINE_CACHE_LOCK:
            kc = len(KLINE_CACHE)
        return jsonify({
            "ok": True, "version": V53_VERSION, "uptime_sec": int(time.time() - _STARTED_AT),
            "threads": threading.active_count(), "db_mb": db_mb, "kline_cache_entries": kc,
            "suppressed_exceptions_total": int(sum(_SWALLOWED.values())),
            "suppressed_top": [{"site": k, "count": v} for k, v in top],
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)[:240]}), 500


@app.get("/api/v53/coverage")
def api_v53_coverage():
    return jsonify({"ok":True,"version":V53_VERSION,"modules":["DECISION_DNA","COUNTERFACTUAL_STABILITY","ERROR_ATTRIBUTION","EXPERIMENT_LINEAGE","SHADOW_CANARY_LIFECYCLE","RESEARCH_TO_PRODUCTION_GATES"]})
