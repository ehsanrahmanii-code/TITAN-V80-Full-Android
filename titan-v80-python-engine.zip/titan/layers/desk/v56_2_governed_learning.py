# [TITAN V77 layer] desk/v56_2_governed_learning - V56.2 governed learning / observability
# Original V76 source lines 23806-24020 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# V56.2 GOVERNED AUTOMATED LEARNING / OBSERVABILITY
# Collect -> evaluate -> diagnose -> shadow recommendation.
# No automatic order execution and no unvalidated live-weight mutation.
# ============================================================
_TITAN_LEARNING_LOCK = threading.RLock()
_TITAN_LEARNING_LAST_RUN = 0.0
_TITAN_LEARNING_INTERVAL_SEC = 900
_TITAN_LEARNING_KEY = "titan_governed_learning_cycle_v2"


def _titan_learning_ensure_schema(con) -> None:
    con.execute("""CREATE TABLE IF NOT EXISTS v32_learning_state(
        key TEXT PRIMARY KEY, updated_at REAL NOT NULL, payload TEXT NOT NULL
    )""")
    con.execute("CREATE INDEX IF NOT EXISTS idx_v32_learning_state_updated ON v32_learning_state(updated_at)")


def _titan_table_count(con, table: str) -> int:
    row = con.execute("SELECT COUNT(*) FROM \"" + table.replace('"','') + "\"").fetchone()
    return int(row[0] or 0)


def _titan_governed_learning(force: bool = False) -> dict[str, Any]:
    """Build a persisted evidence report. Recommendations are shadow-only."""
    global _TITAN_LEARNING_LAST_RUN
    now = time.time()
    with _TITAN_LEARNING_LOCK:
        with DB_LOCK, db_conn() as con:
            _titan_learning_ensure_schema(con)
            if not force and now - _TITAN_LEARNING_LAST_RUN < _TITAN_LEARNING_INTERVAL_SEC:
                row = con.execute("SELECT payload FROM v32_learning_state WHERE key=?", (_TITAN_LEARNING_KEY,)).fetchone()
                if row:
                    try:
                        return json.loads(row[0])
                    except Exception:
                        _swallow()
            report: dict[str, Any] = {
                "version": "V56.2",
                "generated_at": now,
                "mode": "SHADOW_ONLY",
                "auto_promote": False,
                "order_execution": False,
                "live_weight_mutation": False,
                "tables": {},
                "timeframes": {},
                "data_quality": {},
                "recommendations": [],
            }
            table_names = (
                "v32_forecast_audit", "titan_v49_ledger", "v52_decision_audit",
                "v53_decision_dna", "v53_error_attribution", "data_quality",
                "performance_snapshots"
            )
            for table in table_names:
                try:
                    report["tables"][table] = {"available": True, "rows": _titan_table_count(con, table)}
                except Exception:
                    _swallow()
                    report["tables"][table] = {"available": False, "rows": 0}

            # Realized forecast outcomes are the only source allowed for live WR.
            if report["tables"].get("v32_forecast_audit", {}).get("available"):
                rows = con.execute("""SELECT timeframe,
                    COUNT(*) total,
                    SUM(CASE WHEN outcome IN ('WIN','LOSS') THEN 1 ELSE 0 END) closed,
                    SUM(CASE WHEN outcome='WIN' THEN 1 ELSE 0 END) wins,
                    SUM(CASE WHEN outcome='LOSS' THEN 1 ELSE 0 END) losses,
                    SUM(CASE WHEN outcome='PENDING' THEN 1 ELSE 0 END) pending,
                    AVG(CASE WHEN outcome IN ('WIN','LOSS') THEN return_pct END) avg_return
                    FROM v32_forecast_audit GROUP BY timeframe""").fetchall()
                for r in rows:
                    closed=int(r["closed"] or 0); wins=int(r["wins"] or 0)
                    report["timeframes"][str(r["timeframe"])] = {
                        "live_outcome_source": True, "total": int(r["total"] or 0),
                        "closed": closed, "wins": wins, "losses": int(r["losses"] or 0),
                        "pending": int(r["pending"] or 0),
                        "directional_win_rate_pct": round(wins*100/closed,2) if closed else None,
                        "avg_return_pct": round(float(r["avg_return"]),5) if r["avg_return"] is not None else None,
                    }

            # Technical snapshots remain explicitly separate from live outcomes.
            if report["tables"].get("performance_snapshots", {}).get("available"):
                rows = con.execute("""SELECT timeframe, COUNT(*) n, SUM(trades) trades,
                    AVG(win_rate) win_rate, AVG(expectancy) expectancy,
                    AVG(profit_factor) profit_factor, AVG(max_drawdown) max_drawdown
                    FROM performance_snapshots WHERE lower(coalesce(oos_status,''))='ok'
                    GROUP BY timeframe""").fetchall()
                for r in rows:
                    report["timeframes"].setdefault(str(r["timeframe"]), {})["backtest_proxy"] = {
                        "snapshot_count": int(r["n"] or 0),
                        "reported_trades_sum": int(r["trades"] or 0),
                        "mean_snapshot_win_rate_pct": round(float(r["win_rate"]),3) if r["win_rate"] is not None else None,
                        "mean_expectancy": round(float(r["expectancy"]),5) if r["expectancy"] is not None else None,
                        "mean_profit_factor": round(float(r["profit_factor"]),5) if r["profit_factor"] is not None else None,
                        "mean_max_drawdown": round(float(r["max_drawdown"]),5) if r["max_drawdown"] is not None else None,
                        "not_live_wr": True,
                    }

            if report["tables"].get("data_quality", {}).get("available"):
                r=con.execute("""SELECT COUNT(*) n,
                    SUM(CASE WHEN overall_ok=1 THEN 1 ELSE 0 END) good,
                    SUM(CASE WHEN overall_ok=0 THEN 1 ELSE 0 END) bad,
                    AVG(latency_ms) latency FROM data_quality""").fetchone()
                n=int(r["n"] or 0); good=int(r["good"] or 0); bad=int(r["bad"] or 0)
                report["data_quality"]={"samples":n,"good":good,"bad":bad,
                    "good_pct":round(good*100/n,2) if n else None,
                    "avg_latency_ms":round(float(r["latency"]),2) if r["latency"] is not None else None}

            if not report["tables"].get("titan_v49_ledger", {}).get("rows"):
                report["recommendations"].append({"code":"LEDGER_PERSISTENCE_GATE","severity":"high",
                    "action":"Collect new published decisions and verify V49 persistence before claiming live performance."})
            if not report["tables"].get("v32_forecast_audit", {}).get("rows"):
                report["recommendations"].append({"code":"OUTCOME_COLLECTION_GATE","severity":"high",
                    "action":"Populate evaluated outcomes before live win-rate estimation or adaptive weighting."})
            dq=report.get("data_quality", {})
            if dq.get("samples") and dq.get("good_pct") is not None and dq["good_pct"] < 90:
                report["recommendations"].append({"code":"DATA_QUALITY_DEGRADED","severity":"high",
                    "action":"Investigate stale/incomplete market inputs before changing model weights."})

            # Adaptive weighting remains a proposal only. It is not applied to live code.
            for tf, metrics in report["timeframes"].items():
                closed=int(metrics.get("closed") or 0)
                if closed >= 30:
                    metrics["learning_gate"]="eligible_for_shadow_validation"
                elif metrics.get("backtest_proxy"):
                    metrics["learning_gate"]="backtest_only"
                else:
                    metrics["learning_gate"]="insufficient_evidence"
            report["learning_policy"]={
                "minimum_closed_outcomes":30,
                "requires_out_of_sample_validation":True,
                "requires_rollback_snapshot":True,
                "promotion": "manual/core-gated",
            }
            payload=json.dumps(report,ensure_ascii=False,separators=(",",":"))
            con.execute("""INSERT INTO v32_learning_state(key,updated_at,payload) VALUES(?,?,?)
                ON CONFLICT(key) DO UPDATE SET updated_at=excluded.updated_at,payload=excluded.payload""",
                (_TITAN_LEARNING_KEY, now, payload))
            con.commit()
        _TITAN_LEARNING_LAST_RUN=now
        return report


@app.get("/api/learning-cycle")
def api_learning_cycle():
    try:
        force=str(request.args.get("refresh","0")).lower() in {"1","true","yes"}
        return jsonify({"ok":True,"report":_titan_governed_learning(force=force)})
    except Exception as exc:
        LOGGER.exception("Governed learning cycle failed")
        return jsonify({"ok":False,"error":str(exc)[:240]}),500


@app.get("/api/titan/health")
def api_titan_health():
    try:
        report = _titan_governed_learning(False)
        with DB_LOCK, db_conn() as con:
            db_check = str(con.execute("PRAGMA quick_check").fetchone()[0])
            db_tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
        required = {"v32_forecast_audit", "titan_v49_ledger", "v52_decision_audit", "performance_snapshots", "v32_learning_state"}
        missing = sorted(required - db_tables)
        healthy = db_check.lower() == "ok" and not missing
        return jsonify({"ok":healthy,"status":"healthy" if healthy else "degraded",
                        "build":TITAN_BUILD_ID,"decision_path":TITAN_ACTIVE_DECISION_PATH,
                        "database":{"quick_check":db_check,"required_tables_missing":missing},
                        "learning":report,"safety":{"orders":False,"auto_promote":False,
                        "live_weight_mutation":False}}), (200 if healthy else 503)
    except Exception as exc:
        LOGGER.exception("TITAN health check failed")
        return jsonify({"ok":False,"status":"failed","error":str(exc)[:240],
                        "safety":{"orders":False,"auto_promote":False}}),500


_TITAN_PRE_FINAL_UPDATE_CACHE = update_cache

def update_cache(force: bool=False):  # noqa: F811
    result=_TITAN_PRE_FINAL_UPDATE_CACHE(force)
    try:
        # The learning engine already persists every 15 min. Avoid an extra
        # SQLite read/lock on every 20–30s market scan.
        if force or time.time() - _TITAN_LEARNING_LAST_RUN >= _TITAN_LEARNING_INTERVAL_SEC:
            _titan_governed_learning(force=force)
    except Exception:
        LOGGER.exception("Governed learning cycle failed after cache update")
    return result


def _titan_governed_self_test() -> int:
    fails=[]
    try:
        sample={"decision":"LONG","price_raw":100.0,"stop_loss_raw":98.0,
                "tp1_raw":104.0,"tp2_raw":106.0,"trust":0.0,"data_contract":{"live_age_sec":1}}
        risk=v56_position_risk(sample)
        if risk.get("reason") != "insufficient_trust":
            fails.append("risk_zero_trust_gate")
            print("  ✗ risk_zero_trust_gate")
        else:
            print("  ✓ risk_zero_trust_gate")
        stale=dict(sample,trust=70.0,data_contract={"live_age_sec":V49_STALE_PRICE_SEC+1})
        if v56_position_risk(stale).get("reason") != "stale_market_data":
            fails.append("risk_stale_data_gate")
            print("  ✗ risk_stale_data_gate")
        else:
            print("  ✓ risk_stale_data_gate")
        report=_titan_governed_learning(force=True)
        ok=(report.get("mode")=="SHADOW_ONLY" and report.get("auto_promote") is False
            and report.get("order_execution") is False and report.get("live_weight_mutation") is False)
        print("  ✓ governed_learning_safety" if ok else "  ✗ governed_learning_safety")
        if not ok: fails.append("governed_learning_safety")
    except Exception as exc:
        print("  ✗ governed_learning_error",exc); fails.append("governed_learning_error")
    return 1 if fails else 0
