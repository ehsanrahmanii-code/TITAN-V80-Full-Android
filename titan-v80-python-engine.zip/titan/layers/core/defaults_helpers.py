# [TITAN V77 layer] core/defaults_helpers - Defaults, constants, shared helpers
# Original V76 source lines 557-1521 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# DEFAULTS / HELPERS
# ============================================================

DEFAULT_COINS = [
    "BTC/USDT",
    "ETH/USDT",
    "BNB/USDT",
    "XRP/USDT",
    "SOL/USDT",
    "ADA/USDT",
    "DOGE/USDT",
    "AVAX/USDT",
    "LINK/USDT",
    "NEAR/USDT",
    "SUI/USDT",
    "TAO/USDT",
    "AAVE/USDT",
    "BCH/USDT",
    "XLM/USDT",
    "TRX/USDT",
    "SHIB/USDT",
    "PEPE/USDT",
    "WIF/USDT",
    "FLOKI/USDT",
    "CAKE/USDT",
    "HYPE/USDT",
    "ZEC/USDT",
    "XAUT/USDT",
]
LIVE_PRICE_URL = "https://data-api.binance.vision/api/v3/ticker/price"
BINANCE_REST_HOSTS = [
    "https://data-api.binance.vision",
    "https://api.binance.com",
    "https://api1.binance.com",
    "https://api2.binance.com",
    "https://api3.binance.com",
    "https://api4.binance.com",
]
LIVE_PRICE_URLS = [f"{h}/api/v3/ticker/price" for h in BINANCE_REST_HOSTS]
KLINES_URLS = [f"{h}/api/v3/klines" for h in BINANCE_REST_HOSTS]
# Public fallbacks when Binance is blocked/unreachable (common in restricted networks)
COINGECKO_SIMPLE_PRICE = "https://api.coingecko.com/api/v3/simple/price"
# Map TITAN base -> CoinGecko id
COINGECKO_IDS = {
    "BTC": "bitcoin", "ETH": "ethereum", "BNB": "binancecoin", "XRP": "ripple",
    "SOL": "solana", "ADA": "cardano", "DOGE": "dogecoin", "AVAX": "avalanche-2",
    "LINK": "chainlink", "NEAR": "near", "SUI": "sui", "TAO": "bittensor",
    "AAVE": "aave", "BCH": "bitcoin-cash", "XLM": "stellar", "TRX": "tron",
    "SHIB": "shiba-inu", "PEPE": "pepe", "WIF": "dogwifcoin", "FLOKI": "floki",
    "CAKE": "pancakeswap-token", "ZEC": "zcash",
}
# HTTP timeouts kept short so UI never freezes on blocked hosts
HTTP_CONNECT_TIMEOUT = 3.5
HTTP_READ_TIMEOUT = 6.0
SCAN_STALL_TIMEOUT_SEC = 90.0  # release refresh gate after 90s stuck


def _safe_startup_check():
    """Basic production startup validation."""
    try:
        APP_HOME.mkdir(parents=True, exist_ok=True)
        DATA_DIR.mkdir(parents=True, exist_ok=True)
        init_db()
        return True
    except Exception as exc:
        LOGGER.exception("Startup validation failed: %s", exc)
        return False
TF_CFG = {
    "15m": {"horizon": 60, "weight": 0.15},
    "1h": {"horizon": 240, "weight": 0.25},
    "4h": {"horizon": 720, "weight": 0.30},
    "1d": {"horizon": 2880, "weight": 0.30},
}

# V59 timeframe policy: tuned from the stored E performance evidence.
# 15m/1h are noisier and more cost-sensitive; 4h/1d carry more structural signal.
# These are precision policies, not profit guarantees.
V59_TF_POLICY = {
    # V75: low-TF thresholds raised + HTF confirm required to kill noise/cost drag
    "15m": {"fast": 8, "slow": 21, "momentum_bars": 5, "long": 64.0, "short": 36.0, "cooldown_min": 60, "min_quality": 58, "require_htf": True},
    "1h":  {"fast": 12, "slow": 36, "momentum_bars": 6, "long": 60.0, "short": 40.0, "cooldown_min": 150, "min_quality": 55, "require_htf": True},
    "4h":  {"fast": 16, "slow": 40, "momentum_bars": 6, "long": 55.0, "short": 45.0, "cooldown_min": 360, "min_quality": 50, "require_htf": False},
    "1d":  {"fast": 20, "slow": 50, "momentum_bars": 5, "long": 53.0, "short": 47.0, "cooldown_min": 1440, "min_quality": 48, "require_htf": False},
}
V59_LOW_TF_CONFIRM = {
    "15m": {"1h_min_long": 54.0, "1h_max_short": 46.0, "4h_min_long": 52.0, "4h_max_short": 48.0},
    "1h":  {"4h_min_long": 52.0, "4h_max_short": 48.0, "1d_min_long": 51.0, "1d_max_short": 49.0},
}

def v59_tf_policy(tf: str) -> dict[str, float]:
    return dict(V59_TF_POLICY.get(str(tf), V59_TF_POLICY["1h"]))


def v75_low_tf_gate(tf: str, score: float, tf_scores: dict, quality: float) -> dict:
    """V75: kill noisy low-TF signals unless HTF agrees and quality is high."""
    pol = v59_tf_policy(tf)
    reasons = []
    ok = True
    min_q = float(pol.get("min_quality", MIN_DIRECTIONAL_QUALITY))
    if quality < min_q:
        ok = False
        reasons.append(f"quality_{quality:.0f}<{min_q:.0f}")
    if pol.get("require_htf"):
        if tf == "15m":
            s1h = safe_float(tf_scores.get("1h"), 50)
            s4h = safe_float(tf_scores.get("4h"), 50)
            if score >= 50 and (s1h < 54 or s4h < 52):
                ok = False
                reasons.append("15m_needs_HTF_long")
            if score < 50 and (s1h > 46 or s4h > 48):
                ok = False
                reasons.append("15m_needs_HTF_short")
            if abs(score - 50) < 14:
                ok = False
                reasons.append("15m_score_not_extreme")
        elif tf == "1h":
            s4h = safe_float(tf_scores.get("4h"), 50)
            s1d = safe_float(tf_scores.get("1d"), 50)
            if score >= 50 and s4h < 52:
                ok = False
                reasons.append("1h_needs_4h_long")
            if score < 50 and s4h > 48:
                ok = False
                reasons.append("1h_needs_4h_short")
    return {"ok": ok, "reasons": reasons, "min_quality": min_q}




def v75_edge_grade(symbol: str, timeframe: str) -> dict[str, Any]:
    """Historical edge from performance_snapshots — professional gate."""
    out = {
        "grade": "UNKNOWN",
        "expectancy": None,
        "sharpe": None,
        "trades": 0,
        "win_rate": None,
        "supported": False,
        "reason": "no_snapshot",
    }
    try:
        with DB_LOCK, db_conn() as con:
            row = con.execute(
                """SELECT trades, win_rate, expectancy, profit_factor, max_drawdown, sharpe, oos_status, metrics_json
                   FROM performance_snapshots WHERE symbol=? AND timeframe=?
                   ORDER BY created_at DESC LIMIT 1""",
                (_normalize_symbol(symbol), str(timeframe)),
            ).fetchone()
        if not row:
            return out
        trades = int(row[0] or 0)
        wr = safe_float(row[1], 0)
        exp = safe_float(row[2], 0)
        sharpe = safe_float(row[5], 0)
        oos = str(row[6] or "")
        out.update({
            "trades": trades,
            "win_rate": wr,
            "expectancy": exp,
            "sharpe": sharpe,
            "oos_status": oos,
        })
        # net cost haircut
        net_exp = exp - safe_float(globals().get("TITAN_COST_ROUND_TRIP_PCT"), 0.16) * 0.25
        min_tr = int(globals().get("TITAN_MIN_EDGE_TRADES", 25))
        min_exp = float(globals().get("TITAN_MIN_EDGE_EXPECTANCY", 0.15))
        min_sh = float(globals().get("TITAN_MIN_EDGE_SHARPE", 0.08))
        if trades < min_tr:
            out["grade"] = "SPARSE"
            out["reason"] = f"trades={trades}<{min_tr}"
        elif net_exp >= min_exp and sharpe >= min_sh:
            out["grade"] = "EDGE_SUPPORTED"
            out["supported"] = True
            out["reason"] = f"net_exp={net_exp:.3f} sharpe={sharpe:.3f}"
        elif net_exp > 0:
            out["grade"] = "WEAK_POSITIVE"
            out["reason"] = f"net_exp={net_exp:.3f} below full support"
        else:
            out["grade"] = "NO_EDGE"
            out["reason"] = f"net_exp={net_exp:.3f}"
        out["net_expectancy"] = round(net_exp, 4)
    except Exception as exc:
        out["reason"] = str(exc)[:120]
    return out


def v75_threshold_boost(symbol: str, timeframe: str) -> float:
    """Auto-raise score threshold when deep-ledger shows poor results for this cell."""
    if not globals().get("TITAN_AUTO_THRESHOLD_BOOST", True):
        return 0.0
    try:
        with DB_LOCK, db_conn() as con:
            rows = con.execute(
                """SELECT outcome FROM v75_deep_ledger
                   WHERE symbol=? AND timeframe=? AND outcome IN ('WIN','LOSS','FLAT')
                   ORDER BY created_at DESC LIMIT 40""",
                (_normalize_symbol(symbol), str(timeframe)),
            ).fetchall()
        if len(rows) < 8:
            return 0.0
        wins = sum(1 for r in rows if str(r[0]) == "WIN")
        losses = sum(1 for r in rows if str(r[0]) == "LOSS")
        decided = wins + losses
        if decided < 6:
            return 0.0
        wr = wins / decided
        boost = 0.0
        if wr < 0.40:
            boost = 8.0
        elif wr < 0.48:
            boost = 4.0
        elif wr < 0.52:
            boost = 2.0
        return float(min(boost, float(globals().get("TITAN_THRESHOLD_BOOST_MAX", 12))))
    except Exception:
        _swallow()
        return 0.0


def v75_publish_allowed(tf: str, decision: str, edge: dict, checklist_pass: int, data_quality: float) -> dict[str, Any]:
    """Single professional gate: SAFE_MODE + EDGE + checklist + DQ."""
    reasons: list[str] = []
    ok = True
    safe = bool(globals().get("TITAN_SAFE_MODE", True))
    live_tfs = tuple(USER_SETTINGS.get("live_timeframes") or globals().get("TITAN_LIVE_TIMEFRAMES", ("4h", "1d")))
    if decision in {"LONG", "SHORT"}:
        if safe and tf not in live_tfs:
            ok = False
            reasons.append(f"SAFE_MODE: {tf} is shadow-only (live={list(live_tfs)})")
        if bool(globals().get("TITAN_REQUIRE_EDGE_SUPPORTED", True)) or bool(USER_SETTINGS.get("require_edge", True)):
            if not edge.get("supported"):
                # WEAK_POSITIVE may publish only on 1d with high checklist
                if edge.get("grade") == "WEAK_POSITIVE" and tf == "1d" and checklist_pass >= 7:
                    reasons.append("WEAK_POSITIVE allowed on 1d with strong checklist")
                else:
                    ok = False
                    reasons.append(f"edge_gate:{edge.get('grade')}:{edge.get('reason')}")
        min_ck = int(globals().get("TITAN_MANDATORY_CHECKLIST_MIN", 5))
        if checklist_pass < min_ck:
            ok = False
            reasons.append(f"checklist {checklist_pass}<{min_ck}")
        if data_quality < float(globals().get("MIN_DATA_QUALITY_SCORE", 50)):
            ok = False
            reasons.append(f"data_quality_low")
    return {"ok": ok, "reasons": reasons, "safe_mode": safe, "live_tfs": list(live_tfs)}


USER_SETTINGS = {"risk_multiplier": 1.0, "active_coins": DEFAULT_COINS.copy(), "safe_mode": True, "live_timeframes": ["4h", "1d"], "require_edge": True}
CACHE = {"timestamp": 0.0, "data": [], "gemini_summary": "", "macro": {}}
OI_HISTORY: dict[str, tuple[float, float, str]] = {}
LIVE_PRICES: dict[str, dict[str, Any]] = {}
LIVE_LOCK = threading.RLock()
LIVE_STOP = threading.Event()
LIVE_THREADS: list[threading.Thread] = []

COIN_META = {
    "BTC": ("Bitcoin", "₿"), "ETH": ("Ethereum", "Ξ"), "XRP": ("XRP", "✕"),
    "SOL": ("Solana", "◎"), "SHIB": ("Shiba Inu", "🐕"), "BNB": ("BNB", "◆"),
    "ZEC": ("Zcash", "ⓩ"), "ADA": ("Cardano", "₳"), "TRX": ("TRON", "⚡"),
    "HYPE": ("Hyperliquid", "🌊"), "DOGE": ("Dogecoin", "Ð"), "WIF": ("dogwifhat", "🐶"),
    "PEPE": ("Pepe", "🐸"), "AVAX": ("Avalanche", "🔺"), "FLOKI": ("Floki", "🐺"),
    "CAKE": ("PancakeSwap", "🥞"), "BCH": ("Bitcoin Cash", "Ƀ"), "XLM": ("Stellar", "✦"),
    "AAVE": ("Aave", "👻"), "SUI": ("Sui", "💧"), "TAO": ("Bittensor", "🧠"),
    "LINK": ("Chainlink", "⬡"), "NEAR": ("NEAR", "Ⓝ"), "XAUT": ("Tether Gold", "🥇"),
}


def safe_float(value: Any, default: float = 0.0) -> float:
    try:
        result = float(value)
        return result if math.isfinite(result) else default
    except (TypeError, ValueError):
        return default


# === V53.1 PERFORMANCE KERNELS (vectorised, behaviour-identical to the old iterrows loops) ===
def _fast_col(window, name: str, default: float = 0.0) -> "np.ndarray":
    """Column -> float64 ndarray; missing column / non-finite values -> default."""
    if window is None or name not in getattr(window, "columns", ()):
        return np.full(len(window) if window is not None else 0, default, dtype=float)
    arr = pd.to_numeric(window[name], errors="coerce").to_numpy(dtype=float, na_value=np.nan)
    return np.where(np.isfinite(arr), arr, default)


def _ft_simple(window, is_long: bool, sl: float, tp: float, guard_positive: bool = False):
    """Chronological first-touch over OHLC window (no sorting). Returns (tag, price, ts_sec)."""
    if window is None or len(window) == 0:
        return "TIME_EXIT", None, None
    hi = _fast_col(window, "high"); lo = _fast_col(window, "low")
    if is_long:
        a = lo <= sl; b = hi >= tp
    else:
        a = hi >= sl; b = lo <= tp
    if guard_positive:
        if not (sl > 0): a = np.zeros_like(a)
        if not (tp > 0): b = np.zeros_like(b)
    hit = a | b
    if not hit.any():
        return "TIME_EXIT", None, None
    i = int(hit.argmax())
    ts = float(_fast_col(window, "t")[i]) / 1000.0
    if a[i] and b[i]: return "AMBIGUOUS", None, ts
    if a[i]: return "LOSS", sl, ts
    return "WIN", tp, ts





# === TITAN ULTRA TECHNICAL LAYER ===

def calculate_auto_fibonacci(high, low):
    diff=float(high)-float(low)
    return {
        "0.236": round(float(high)-diff*0.236,8),
        "0.382": round(float(high)-diff*0.382,8),
        "0.500": round(float(high)-diff*0.500,8),
        "0.618": round(float(high)-diff*0.618,8),
        "0.786": round(float(high)-diff*0.786,8),
    }

def calculate_support_resistance(closes, window=20):
    vals=list(map(float, closes[-window:])) if closes else []
    if not vals:
        return {"support":None,"resistance":None}
    return {"support":min(vals),"resistance":max(vals)}

def technical_layers(df):
    """Compute technical display layers without leaking warm-up NaN/inf values."""
    empty={"bollinger":{"upper":None,"middle":None,"lower":None},"fibonacci":{},"support_resistance":{"support":None,"resistance":None}}
    if df is None or df.empty or "close" not in df:
        return empty
    close=pd.to_numeric(df["close"],errors="coerce").dropna()
    if close.empty:
        return empty
    mid=close.rolling(20,min_periods=min(20,len(close))).mean()
    std=close.rolling(20,min_periods=min(20,len(close))).std(ddof=0)
    middle=float(mid.iloc[-1]); deviation=float(std.iloc[-1])
    if not math.isfinite(middle): middle=float(close.iloc[-1])
    if not math.isfinite(deviation): deviation=0.0
    high=float(pd.to_numeric(df.get("high",close),errors="coerce").max())
    low=float(pd.to_numeric(df.get("low",close),errors="coerce").min())
    if not (math.isfinite(high) and math.isfinite(low)) or high<=0 or low<=0 or high<low:
        high=low=float(close.iloc[-1])
    return {"bollinger":{"upper":middle+2*deviation,"middle":middle,"lower":middle-2*deviation},"fibonacci":calculate_auto_fibonacci(high,low),"support_resistance":calculate_support_resistance(close.tolist())}

# === TITAN V6 ADVANCED TECHNICAL SUITE ===
def calc_macd(close: pd.Series, fast: int = 12, slow: int = 26, signal: int = 9) -> dict[str, float]:
    """MACD line, signal, histogram — fail-safe."""
    try:
        c = close.astype(float)
        if len(c) < slow + signal:
            return {"macd": 0.0, "signal": 0.0, "hist": 0.0, "cross": "none"}
        ema_f = c.ewm(span=fast, adjust=False).mean()
        ema_s = c.ewm(span=slow, adjust=False).mean()
        macd = ema_f - ema_s
        sig = macd.ewm(span=signal, adjust=False).mean()
        hist = macd - sig
        h0, h1 = float(hist.iloc[-1]), float(hist.iloc[-2]) if len(hist) > 1 else 0.0
        cross = "bull" if h1 <= 0 < h0 else "bear" if h1 >= 0 > h0 else "none"
        return {"macd": round(float(macd.iloc[-1]), 8), "signal": round(float(sig.iloc[-1]), 8),
                "hist": round(h0, 8), "cross": cross}
    except Exception:
        _swallow()
        return {"macd": 0.0, "signal": 0.0, "hist": 0.0, "cross": "none"}


def calc_stoch_rsi(close: pd.Series, rsi_period: int = 14, stoch_period: int = 14, k: int = 3, d: int = 3) -> dict[str, float]:
    """Stochastic RSI for timing entries on oversold/overbought extremes."""
    try:
        rsi = wilder_rsi(close, rsi_period)
        if len(rsi) < stoch_period + d:
            return {"k": 50.0, "d": 50.0, "zone": "mid"}
        rmin = rsi.rolling(stoch_period).min()
        rmax = rsi.rolling(stoch_period).max()
        stoch = 100 * (rsi - rmin) / (rmax - rmin).replace(0, np.nan)
        k_line = stoch.rolling(k).mean().fillna(50)
        d_line = k_line.rolling(d).mean().fillna(50)
        kv, dv = float(k_line.iloc[-1]), float(d_line.iloc[-1])
        zone = "oversold" if kv < 20 else "overbought" if kv > 80 else "mid"
        return {"k": round(kv, 2), "d": round(dv, 2), "zone": zone}
    except Exception:
        _swallow()
        return {"k": 50.0, "d": 50.0, "zone": "mid"}


def calc_pivot_points(df: pd.DataFrame) -> dict[str, float]:
    """Classic daily pivots from last closed candle high/low/close."""
    try:
        if df is None or len(df) < 2:
            return {}
        row = df.iloc[-1]
        h, l, c = float(row["high"]), float(row["low"]), float(row["close"])
        pp = (h + l + c) / 3.0
        r1 = 2 * pp - l
        s1 = 2 * pp - h
        r2 = pp + (h - l)
        s2 = pp - (h - l)
        r3 = h + 2 * (pp - l)
        s3 = l - 2 * (h - pp)
        return {k: round(v, 8) for k, v in (("pp", pp), ("r1", r1), ("r2", r2), ("r3", r3), ("s1", s1), ("s2", s2), ("s3", s3))}
    except Exception:
        _swallow()
        return {}


def calc_volume_delta(df: pd.DataFrame, lookback: int = 24) -> dict[str, float]:
    """Proxy CVD from candle body direction * volume (no tick data required)."""
    try:
        x = df.tail(lookback).copy()
        if x.empty:
            return {"delta": 0.0, "buy_vol": 0.0, "sell_vol": 0.0, "delta_pct": 0.0}
        body_up = (x["close"] >= x["open"]).astype(float)
        buy_v = float((x["vol"] * body_up).sum())
        sell_v = float((x["vol"] * (1 - body_up)).sum())
        total = buy_v + sell_v
        delta = buy_v - sell_v
        return {
            "delta": round(delta, 4),
            "buy_vol": round(buy_v, 4),
            "sell_vol": round(sell_v, 4),
            "delta_pct": round((delta / total * 100) if total > 0 else 0.0, 2),
        }
    except Exception:
        _swallow()
        return {"delta": 0.0, "buy_vol": 0.0, "sell_vol": 0.0, "delta_pct": 0.0}


def market_session_utc(asof_ts: Optional[float] = None) -> dict[str, Any]:
    """Return the session at an explicit as-of timestamp (UTC).

    Historical/replay callers must pass their event/bar timestamp; live callers can
    omit it and use current UTC. This prevents wall-clock leakage in backtests.
    """
    if asof_ts is None:
        dt = datetime.now(timezone.utc)
    else:
        try:
            dt = datetime.fromtimestamp(float(asof_ts), tz=timezone.utc)
        except Exception:
            _swallow()
            dt = datetime.now(timezone.utc)
    hour = dt.hour
    if 0 <= hour < 8:
        name, risk_mult = "Asia", 0.95
    elif 8 <= hour < 13:
        name, risk_mult = "London", 1.05
    elif 13 <= hour < 17:
        name, risk_mult = "London-NY Overlap", 1.12
    elif 17 <= hour < 21:
        name, risk_mult = "New York", 1.05
    else:
        name, risk_mult = "Off-hours", 0.88
    return {"session": name, "hour_utc": hour, "liquidity_boost": risk_mult}




# === TITAN PATTERN + FUTURE CANDLE FORECAST ENGINE ===
PATTERN_GUIDE = {
    "سرشانه": {
        "name_en": "Head & Shoulders",
        "meaning": "الگوی بازگشتی نزولی: سه قله که قله میانی (سر) بالاتر از دو شانه است. خط گردن اتصال کف‌های بین شانه و سر است.",
        "expect": "با شکست معتبر خط گردن به سمت پایین، انتظار ادامه نزول تا اندازه ارتفاع سر تا خط گردن وجود دارد. حد ضرر بالای شانه راست.",
        "bias": "نزولی",
    },
    "سرشانه معکوس": {
        "name_en": "Inverse Head & Shoulders",
        "meaning": "الگوی بازگشتی صعودی: سه کف که کف میانی (سر) پایین‌تر از دو شانه است.",
        "expect": "با شکست خط گردن به بالا، انتظار رشد تا اندازه ارتفاع الگو. حد ضرر زیر شانه راست.",
        "bias": "صعودی",
    },
    "سقف دوقلو": {
        "name_en": "Double Top",
        "meaning": "دو قله تقریباً هم‌تراز پس از روند صعودی؛ نشانه ضعف خریداران.",
        "expect": "شکست کف میانی (خط گردن) معمولاً ادامه نزول را تقویت می‌کند. هدف تقریبی: فاصله قله تا گردن.",
        "bias": "نزولی",
    },
    "کف دوقلو": {
        "name_en": "Double Bottom",
        "meaning": "دو کف تقریباً هم‌تراز پس از روند نزولی؛ نشانه ضعف فروشندگان.",
        "expect": "شکست سقف میانی معمولاً ادامه صعود را تقویت می‌کند. هدف تقریبی: فاصله کف تا گردن.",
        "bias": "صعودی",
    },
    "واگرایی صعودی": {
        "name_en": "Bullish Divergence",
        "meaning": "قیمت کف پایین‌تر می‌سازد اما RSI/MACD کف بالاتر می‌سازد — ضعف فروش.",
        "expect": "احتمال واکنش صعودی یا پایان موقت نزول؛ تأیید با برگشت قیمت و حجم لازم است.",
        "bias": "صعودی",
    },
    "واگرایی نزولی": {
        "name_en": "Bearish Divergence",
        "meaning": "قیمت سقف بالاتر می‌سازد اما RSI/MACD سقف پایین‌تر می‌سازد — ضعف خرید.",
        "expect": "احتمال اصلاح یا برگشت نزولی؛ تأیید با شکست ساختار لازم است.",
        "bias": "نزولی",
    },
    "مثلث فشرده": {
        "name_en": "Symmetrical / Tight Range",
        "meaning": "نوسان در حال فشرده شدن؛ انرژی برای شکست انباشته می‌شود.",
        "expect": "شکست با حجم می‌تواند حرکت جهت‌دار ایجاد کند؛ جهت از ساختار چندتایم‌فریمی خوانده شود.",
        "bias": "خنثی",
    },
}


def _find_swing_points(series: pd.Series, order: int = 3) -> tuple[list[tuple[int, float]], list[tuple[int, float]]]:
    """Local swing highs/lows as (index_position, value)."""
    vals = series.astype(float).tolist()
    highs, lows = [], []
    n = len(vals)
    for i in range(order, n - order):
        window = vals[i - order:i + order + 1]
        if vals[i] == max(window) and vals[i] > vals[i - 1] and vals[i] > vals[i + 1]:
            highs.append((i, vals[i]))
        if vals[i] == min(window) and vals[i] < vals[i - 1] and vals[i] < vals[i + 1]:
            lows.append((i, vals[i]))
    return highs, lows


def detect_chart_patterns(df: pd.DataFrame, rsi_series: Optional[pd.Series] = None) -> dict[str, Any]:
    """Detect standard patterns: H&S, double top/bottom, RSI divergence, tight range."""
    patterns: list[dict[str, Any]] = []
    try:
        if df is None or len(df) < 40:
            return {"patterns": [], "primary": None, "score_bias": 0.0}
        high = df["high"].astype(float)
        low = df["low"].astype(float)
        close = df["close"].astype(float)
        swing_highs, _ = _find_swing_points(high, 3)
        _, swing_lows = _find_swing_points(low, 3)

        # Double Top
        if len(swing_highs) >= 2:
            (i1, h1), (i2, h2) = swing_highs[-2], swing_highs[-1]
            if i2 > i1 and abs(h1 - h2) / max(h1, 1e-12) < 0.015:
                mid_low = float(low.iloc[i1:i2 + 1].min()) if i2 > i1 else float(low.iloc[-1])
                if float(close.iloc[-1]) < (h1 + h2) / 2:
                    conf = 62 + (10 if float(close.iloc[-1]) < mid_low else 0)
                    patterns.append({
                        "id": "سقف دوقلو", "confidence": min(88, conf),
                        "levels": {"peak1": round(h1, 8), "peak2": round(h2, 8), "neck": round(mid_low, 8)},
                        "guide": PATTERN_GUIDE["سقف دوقلو"],
                    })

        # Double Bottom
        if len(swing_lows) >= 2:
            (i1, l1), (i2, l2) = swing_lows[-2], swing_lows[-1]
            if i2 > i1 and abs(l1 - l2) / max(abs(l1), 1e-12) < 0.015:
                mid_high = float(high.iloc[i1:i2 + 1].max()) if i2 > i1 else float(high.iloc[-1])
                if float(close.iloc[-1]) > (l1 + l2) / 2:
                    conf = 62 + (10 if float(close.iloc[-1]) > mid_high else 0)
                    patterns.append({
                        "id": "کف دوقلو", "confidence": min(88, conf),
                        "levels": {"trough1": round(l1, 8), "trough2": round(l2, 8), "neck": round(mid_high, 8)},
                        "guide": PATTERN_GUIDE["کف دوقلو"],
                    })

        # Head & Shoulders (3 highs: L-shoulder, head, R-shoulder)
        if len(swing_highs) >= 3:
            (i0, s0), (i1, head), (i2, s1) = swing_highs[-3], swing_highs[-2], swing_highs[-1]
            if head > s0 and head > s1 and abs(s0 - s1) / max(head, 1e-12) < 0.04 and i0 < i1 < i2:
                neck = float(low.iloc[i0:i2 + 1].min())
                conf = 70 if float(close.iloc[-1]) < neck * 1.01 else 58
                patterns.append({
                    "id": "سرشانه", "confidence": conf,
                    "levels": {"left": round(s0, 8), "head": round(head, 8), "right": round(s1, 8), "neck": round(neck, 8)},
                    "guide": PATTERN_GUIDE["سرشانه"],
                })

        # Inverse H&S
        if len(swing_lows) >= 3:
            (i0, s0), (i1, head), (i2, s1) = swing_lows[-3], swing_lows[-2], swing_lows[-1]
            if head < s0 and head < s1 and abs(s0 - s1) / max(abs(head), 1e-12) < 0.04 and i0 < i1 < i2:
                neck = float(high.iloc[i0:i2 + 1].max())
                conf = 70 if float(close.iloc[-1]) > neck * 0.99 else 58
                patterns.append({
                    "id": "سرشانه معکوس", "confidence": conf,
                    "levels": {"left": round(s0, 8), "head": round(head, 8), "right": round(s1, 8), "neck": round(neck, 8)},
                    "guide": PATTERN_GUIDE["سرشانه معکوس"],
                })

        # RSI divergence
        rsi = rsi_series if rsi_series is not None else wilder_rsi(close)
        if len(close) >= 30 and len(rsi) >= 30:
            c_tail = close.tail(30)
            r_tail = rsi.tail(30)
            price_ll = float(c_tail.min()) == float(c_tail.iloc[-1]) or (
                float(c_tail.iloc[-1]) <= float(c_tail.iloc[:-5].min()) * 1.002
            )
            price_hh = float(c_tail.iloc[-1]) >= float(c_tail.iloc[:-5].max()) * 0.998
            rsi_now = float(r_tail.iloc[-1])
            rsi_prev_min = float(r_tail.iloc[:-5].min())
            rsi_prev_max = float(r_tail.iloc[:-5].max())
            if price_ll and rsi_now > rsi_prev_min + 3:
                patterns.append({
                    "id": "واگرایی صعودی", "confidence": 65,
                    "levels": {"rsi": round(rsi_now, 1)},
                    "guide": PATTERN_GUIDE["واگرایی صعودی"],
                })
            if price_hh and rsi_now < rsi_prev_max - 3:
                patterns.append({
                    "id": "واگرایی نزولی", "confidence": 65,
                    "levels": {"rsi": round(rsi_now, 1)},
                    "guide": PATTERN_GUIDE["واگرایی نزولی"],
                })

        # Tight range / triangle proxy
        recent = close.tail(20)
        atr_pct = float((high.tail(20) - low.tail(20)).mean() / close.iloc[-1] * 100) if float(close.iloc[-1]) else 0
        if atr_pct < 1.4 and float(recent.max() / recent.min() - 1) * 100 < 3.5:
            patterns.append({
                "id": "مثلث فشرده", "confidence": 55,
                "levels": {"range_high": round(float(recent.max()), 8), "range_low": round(float(recent.min()), 8)},
                "guide": PATTERN_GUIDE["مثلث فشرده"],
            })

        patterns.sort(key=lambda x: -x.get("confidence", 0))
        primary = patterns[0] if patterns else None
        score_bias = 0.0
        if primary:
            g = primary.get("guide") or {}
            b = g.get("bias", "خنثی")
            conf = primary.get("confidence", 50) / 100.0
            if b == "صعودی":
                score_bias = 4.0 * conf
            elif b == "نزولی":
                score_bias = -4.0 * conf
        return {"patterns": patterns[:5], "primary": primary, "score_bias": round(score_bias, 2)}
    except Exception as exc:
        LOGGER.debug("pattern detect failed: %s", exc)
        return {"patterns": [], "primary": None, "score_bias": 0.0}


def forecast_future_candles(
    df: pd.DataFrame,
    horizon: int = 48,
    patterns: Optional[dict] = None,
    *,
    macd: Optional[dict] = None,
    stoch: Optional[dict] = None,
    structure: Optional[dict] = None,
    regime: Optional[dict] = None,
) -> dict[str, Any]:
    """V76 REAL multi-factor path — not decorative.

    Uses: return distribution, multi-horizon momentum, EMA structure, MACD/Stoch,
    chart-pattern bias, historical analogue (always on for decision), volume skew,
    support/resistance position in recent range, and ATR-scaled bands.
    Output feeds neural fuse, score nudge, levels, and hard/soft publish gates.
    Analysis-only — scenario path, not a guarantee.
    """
    try:
        horizon = int(clamp(horizon, 3, 48))
        if df is None or len(df) < 50:
            return {"ok": False, "candles": [], "narrative": "داده کافی برای پیش‌بینی نیست", "horizon": horizon}
        close = df["close"].astype(float)
        high = df["high"].astype(float)
        low = df["low"].astype(float)
        vol = df["vol"].astype(float) if "vol" in df.columns else pd.Series([1.0] * len(df), index=df.index)
        rets = close.pct_change().dropna().tail(200)
        if len(rets) < 20:
            return {"ok": False, "candles": [], "narrative": "تاریخچه بازده ناکافی", "horizon": horizon}

        mu = float(rets.mean())
        sigma = float(rets.std()) or 1e-6
        last = float(close.iloc[-1])
        atr = float((high - low).tail(14).mean()) or last * 0.01

        # Multi-horizon momentum
        mom3 = float(close.iloc[-1] / close.iloc[-4] - 1) if len(close) > 4 else 0.0
        mom5 = float(close.iloc[-1] / close.iloc[-6] - 1) if len(close) > 6 else 0.0
        mom12 = float(close.iloc[-1] / close.iloc[-13] - 1) if len(close) > 13 else 0.0
        mom24 = float(close.iloc[-1] / close.iloc[-25] - 1) if len(close) > 25 else 0.0
        ema20 = float(close.ewm(span=20, adjust=False).mean().iloc[-1])
        ema50 = float(close.ewm(span=50, adjust=False).mean().iloc[-1]) if len(close) >= 50 else ema20
        ema_gap = (ema20 / ema50 - 1.0) if ema50 > 0 else 0.0
        price_vs_ema = (last / ema20 - 1.0) if ema20 > 0 else 0.0

        # Recent range position (0=at low, 1=at high) — real S/R context
        look_r = min(48, len(close))
        r_hi = float(high.tail(look_r).max())
        r_lo = float(low.tail(look_r).min())
        range_span = max(r_hi - r_lo, last * 1e-6)
        range_position = float(clamp((last - r_lo) / range_span, 0.0, 1.0))

        # Support / resistance from rolling window + fib touch
        sr = calculate_support_resistance(close.tolist(), window=min(40, len(close)))
        support = safe_float(sr.get("support"), r_lo)
        resistance = safe_float(sr.get("resistance"), r_hi)
        sr_bias = 0.0
        if support > 0 and abs(last - support) / last < 0.012:
            sr_bias += 0.55  # near support → bounce bias
        if resistance > 0 and abs(last - resistance) / last < 0.012:
            sr_bias -= 0.55  # near resistance → reject bias
        if range_position <= 0.18:
            sr_bias += 0.25
        elif range_position >= 0.82:
            sr_bias -= 0.25

        # Base drift from mean + momentum + structure
        mu_adj = (
            mu * 0.22
            + mom3 * 0.16
            + mom5 * 0.20
            + mom12 * 0.14
            + mom24 * 0.08
            + ema_gap * 0.18
            + sr_bias * abs(sigma) * 1.8
        )
        # Soft mean-reversion when stretched vs EMA20
        if abs(price_vs_ema) > 0.022:
            mu_adj -= price_vs_ema * 0.18

        # Pattern tilt
        pbias = safe_float((patterns or {}).get("score_bias"), 0) / 100.0
        mu_adj += pbias * abs(sigma) * 2.4

        # MACD / Stoch
        macd = macd or {}
        stoch = stoch or {}
        if macd.get("cross") == "bull":
            mu_adj += abs(sigma) * 0.38
        elif macd.get("cross") == "bear":
            mu_adj -= abs(sigma) * 0.38
        hist = safe_float(macd.get("hist"), 0)
        if hist != 0:
            mu_adj += float(np.clip(hist / max(last * 0.01, 1e-12), -0.8, 0.8)) * abs(sigma) * 0.28
        zone = str(stoch.get("zone") or "mid")
        if zone == "oversold":
            mu_adj += abs(sigma) * 0.22
        elif zone == "overbought":
            mu_adj -= abs(sigma) * 0.22

        # Regime / structure
        regime_name = str((regime or {}).get("regime", "")).lower()
        if "up" in regime_name or "bull" in regime_name:
            mu_adj += abs(sigma) * 0.14
        elif "down" in regime_name or "bear" in regime_name:
            mu_adj -= abs(sigma) * 0.14
        struct_bias = str((structure or {}).get("bias", "") or "")
        if struct_bias == "صعودی":
            mu_adj += abs(sigma) * 0.12
        elif struct_bias == "نزولی":
            mu_adj -= abs(sigma) * 0.12

        # Volume confirmation
        try:
            v_tail = vol.tail(12)
            c_tail = close.tail(12)
            if len(v_tail) >= 4 and float(v_tail.mean()) > 0:
                up_vol = float(v_tail[c_tail.diff() > 0].sum())
                dn_vol = float(v_tail[c_tail.diff() < 0].sum())
                if up_vol + dn_vol > 0:
                    vol_skew = (up_vol - dn_vol) / (up_vol + dn_vol)
                    mu_adj += vol_skew * abs(sigma) * 0.22
        except Exception:
            _swallow()

        # Historical analogue — V76: always attempt for decision quality (stride for speed)
        analogue_note = ""
        best_corr, best_fwd = 0.0, None
        try:
            window = 14 if len(close) > 90 else 10
            target = close.pct_change().dropna().tail(window).values
            rets_all = close.pct_change().dropna().values
            _step = 2 if len(rets_all) > 120 else 1
            for i in range(window, max(window + 1, len(rets_all) - horizon - 1), _step):
                seg = rets_all[i - window:i]
                if len(seg) != window:
                    continue
                if float(np.std(seg)) < 1e-12 or float(np.std(target)) < 1e-12:
                    continue
                corr = float(np.corrcoef(seg, target)[0, 1])
                if math.isfinite(corr) and corr > best_corr and corr > 0.45:
                    best_corr = corr
                    best_fwd = rets_all[i:i + horizon]
            if best_fwd is not None and len(best_fwd) >= 1:
                fwd_sum = float(np.sum(best_fwd))
                analogue_note = (
                    f"نزدیک‌ترین الگوی تاریخی با همبستگی {best_corr:.0%} در ادامه "
                    f"{'مثبت' if fwd_sum > 0 else 'منفی'} حدود {abs(fwd_sum)*100:.2f}% حرکت داشته است."
                )
                # Blend analogue drift into mu_adj
                ana_mu = float(np.mean(best_fwd[: min(8, len(best_fwd))]))
                mu_adj = 0.68 * mu_adj + 0.32 * ana_mu
        except Exception:
            _swallow()

        candles = []
        px = last
        for step in range(1, horizon + 1):
            damp = 1.0 / (1.0 + 0.042 * (step - 1))
            step_mu = mu_adj * damp
            drift = step_mu * step
            vol_scale = 1.0
            try:
                if step > 1 and abs(mu_adj) > 0:
                    vol_scale = float(np.clip(1.0 + 0.15 * abs(mu_adj) / max(sigma, 1e-8), 0.85, 1.55))
            except Exception:
                _swallow()
                vol_scale = 1.0
            fat = 1.18 + 0.02 * min(step, 24)
            band = sigma * (step ** 0.52) * (1.35 + 0.035 * step) * vol_scale * fat
            atr_frac = (atr / last) if last > 0 else 0.01
            band = max(band, atr_frac * 0.55 * (step ** 0.45))
            mid = last * (1 + drift)
            if best_fwd is not None and step <= len(best_fwd):
                ana = last * (1 + float(np.sum(best_fwd[:step])))
                mid = 0.58 * mid + 0.42 * ana
            # Pull path gently toward S/R when approaching
            if resistance > last and mid > resistance:
                mid = 0.7 * mid + 0.3 * resistance
            if support < last and mid < support:
                mid = 0.7 * mid + 0.3 * support
            lo = mid * (1 - band) - 0.12 * atr * (1 + 0.03 * step)
            hi = mid * (1 + band) + 0.12 * atr * (1 + 0.03 * step)
            o = px
            c = mid
            h = max(o, c, hi * 0.35 + mid * 0.65)
            l = min(o, c, lo * 0.35 + mid * 0.65)
            direction = "صعودی" if c >= o else "نزولی"
            conf = clamp(80 - step * 3.0 + abs(pbias) * 70 + (best_corr * 14 if best_corr else 0), 22, 86)
            candles.append({
                "step": step,
                "open": round(float(o), 8),
                "high": round(float(h), 8),
                "low": round(float(l), 8),
                "close": round(float(c), 8),
                "mid": round(float(mid), 8),
                "band_low": round(float(lo), 8),
                "band_high": round(float(hi), 8),
                "direction": direction,
                "confidence": round(conf, 1),
                "analogue_corr": round(best_corr, 3) if best_corr else None,
            })
            px = float(c)

        primary = (patterns or {}).get("primary")
        if primary:
            pname = primary.get("id", "")
            guide = primary.get("guide") or {}
            narrative = (
                f"پیش‌بینی واقعی {horizon} کندل با مدل چندعاملی (بازده، مومنتوم، EMA، MACD/Stoch، "
                f"موقعیت رنج، حمایت/مقاومت، الگوی «{pname}» و آنالوگ تاریخی). {guide.get('expect', '')} "
                f"{analogue_note} این خروجی سناریویی است و تضمین سود نیست."
            )
        else:
            narrative = (
                f"پیش‌بینی واقعی {horizon} کندل با توزیع بازده، مومنتوم، ساختار EMA، رنج و شباهت تاریخی. "
                f"{analogue_note} خروجی سناریویی است، نه قطعی."
            )
        up_steps = sum(1 for c in candles if c["direction"] == "صعودی")
        overall = "صعودی" if up_steps > horizon * 0.55 else "نزولی" if up_steps < horizon * 0.45 else "خنثی"
        expected_move = (candles[-1]["close"] / last - 1.0) if candles else 0.0
        path_strength = float(clamp(abs(expected_move) / max(sigma * (horizon ** 0.5), 1e-9) * 28, 0, 48))
        # Decision impact score: -1 .. +1 for downstream gates
        decision_impact = float(np.clip(expected_move / max(atr / last * 100 * 0.35, 0.15) * 100, -1.0, 1.0))
        if overall == "صعودی":
            decision_impact = abs(decision_impact)
        elif overall == "نزولی":
            decision_impact = -abs(decision_impact)
        else:
            decision_impact *= 0.25

        return {
            "ok": True,
            "horizon": horizon,
            "overall_bias": overall,
            "candles": candles,
            "narrative": narrative,
            "last_price": round(last, 8),
            "mu": round(mu_adj, 6),
            "sigma": round(sigma, 6),
            "expected_move_pct": round(expected_move * 100, 3),
            "path_strength": round(path_strength, 1),
            "analogue_corr": round(best_corr, 3) if best_corr else None,
            "range_position": round(range_position, 3),
            "sr_bias": round(sr_bias, 3),
            "support": round(support, 8) if support else None,
            "resistance": round(resistance, 8) if resistance else None,
            "decision_impact": round(decision_impact, 4),
            "components": {
                "mom3": round(mom3, 6), "mom5": round(mom5, 6), "mom12": round(mom12, 6),
                "mom24": round(mom24, 6), "ema_gap": round(ema_gap, 6),
                "pattern_bias": round(pbias, 4), "sr_bias": round(sr_bias, 3),
                "range_position": round(range_position, 3),
            },
        }
    except Exception as exc:
        LOGGER.debug("forecast_future_candles failed: %s", exc)
        return {"ok": False, "candles": [], "narrative": str(exc)[:200], "horizon": horizon}


def fetch_binance_long_short_ratio(symbol: str) -> dict[str, Any]:
    """Global long/short account ratio from Binance Futures (free public endpoint)."""
    pair = _binance_symbol(symbol)
    out: dict[str, Any] = {"long_ratio": None, "short_ratio": None, "long_short_ratio": None, "source": "N/A"}
    try:
        r = _http_session().get(
            "https://fapi.binance.com/futures/data/globalLongShortAccountRatio",
            params={"symbol": pair, "period": "1h", "limit": 1},
            timeout=8,
        )
        if r.ok:
            data = r.json()
            if isinstance(data, list) and data:
                row = data[-1]
                lr = safe_float(row.get("longAccount"))
                sr = safe_float(row.get("shortAccount"))
                ratio = safe_float(row.get("longShortRatio"))
                out.update({
                    "long_ratio": round(lr * 100, 2) if lr else None,
                    "short_ratio": round(sr * 100, 2) if sr else None,
                    "long_short_ratio": round(ratio, 4) if ratio else None,
                    "source": "Binance-LSR",
                })
    except Exception as exc:
        LOGGER.debug("LSR fetch failed %s: %s", symbol, exc)
    try:
        r = _http_session().get(
            "https://fapi.binance.com/futures/data/topLongShortAccountRatio",
            params={"symbol": pair, "period": "1h", "limit": 1},
            timeout=8,
        )
        if r.ok:
            data = r.json()
            if isinstance(data, list) and data:
                row = data[-1]
                out["top_long_ratio"] = round(safe_float(row.get("longAccount")) * 100, 2)
                out["top_short_ratio"] = round(safe_float(row.get("shortAccount")) * 100, 2)
                out["top_long_short_ratio"] = round(safe_float(row.get("longShortRatio")), 4)
                out["source"] = (out.get("source") or "") + "+TopTrader"
    except Exception as exc:
        LOGGER.debug("Top trader ratio failed %s: %s", symbol, exc)
    return out


def fetch_binance_taker_buy_sell(symbol: str) -> dict[str, Any]:
    """Taker buy/sell volume ratio — real order-flow proxy."""
    pair = _binance_symbol(symbol)
    try:
        r = _http_session().get(
            "https://fapi.binance.com/futures/data/takerlongshortRatio",
            params={"symbol": pair, "period": "1h", "limit": 1},
            timeout=8,
        )
        if r.ok:
            data = r.json()
            if isinstance(data, list) and data:
                row = data[-1]
                buy = safe_float(row.get("buyVol"))
                sell = safe_float(row.get("sellVol"))
                ratio = safe_float(row.get("buySellRatio"))
                total = buy + sell
                return {
                    "buy_vol": buy, "sell_vol": sell,
                    "buy_sell_ratio": round(ratio, 4) if ratio else None,
                    "buy_pct": round(buy / total * 100, 1) if total > 0 else None,
                    "sell_pct": round(sell / total * 100, 1) if total > 0 else None,
                    "source": "Binance-Taker",
                    "available": True,
                }
    except Exception as exc:
        LOGGER.debug("Taker ratio failed %s: %s", symbol, exc)
    return {"buy_pct": None, "sell_pct": None, "buy_sell_ratio": None, "source": "N/A", "available": False}


def _ls_bias(ls: dict[str, Any], direction_wanted: int) -> tuple[float, str]:
    """Crowd positioning bias: extreme long crowding is short-friendly and vice versa."""
    ratio = safe_float(ls.get("long_short_ratio"), 1.0)
    if ratio <= 0:
        return 0.0, "فاقد داده L/S"
    if ratio >= 1.8:
        return (-5.0 if direction_wanted >= 0 else 4.0), "ازدحام شدید لانگ (ضدجمعیت نزولی)"
    if ratio >= 1.35:
        return (-2.5 if direction_wanted >= 0 else 2.0), "فشار لانگ بالا"
    if ratio <= 0.55:
        return (5.0 if direction_wanted <= 0 else -4.0), "ازدحام شدید شورت (ضدجمعیت صعودی)"
    if ratio <= 0.75:
        return (2.5 if direction_wanted <= 0 else -2.0), "فشار شورت بالا"
    return 0.0, "نسبت لانگ/شورت متعادل"



def clamp(value: float, lo: float, hi: float) -> float:
    return float(max(lo, min(hi, value)))
