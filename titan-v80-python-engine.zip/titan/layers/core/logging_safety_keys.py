# [TITAN V77 layer] core/logging_safety_keys - Logging, _swallow safety net, API-key files
# Original V76 source lines 315-556 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# LOGGING / SAFETY
# ============================================================

LOGGER = logging.getLogger("TITAN")
LOGGER.setLevel(getattr(logging, str(os.environ.get("TITAN_LOG_LEVEL", "INFO")).upper(), logging.INFO))
LOGGER.propagate = False
if not LOGGER.handlers:
    _file_handler = RotatingFileHandler(
        LOG_PATH, maxBytes=5 * 1024 * 1024, backupCount=3, encoding="utf-8"
    )
    _file_handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(message)s"))
    LOGGER.addHandler(_file_handler)


_SWALLOWED: dict[str, int] = {}
_SWALLOW_LOCK = threading.Lock()
_STARTED_AT = time.time()


# Engine error categories for professional diagnostics
# data | signal | storage | forecast | dashboard | decision | network | other
_ENGINE_ERRORS: dict[str, list] = {}
_ENGINE_ERROR_LOCK = threading.Lock()
_ENGINE_ERROR_CAP = 40  # per category ring buffer


def _record_engine_error(category: str, message: str, symbol: str = "", **extra) -> None:
    """Structured error log by subsystem. Safe — never raises."""
    try:
        cat = str(category or "other").lower()[:32]
        if cat not in {
            "data", "signal", "storage", "forecast", "dashboard",
            "decision", "network", "ai", "other",
        }:
            cat = "other"
        entry = {
            "ts": time.time(),
            "category": cat,
            "message": str(message)[:240],
            "symbol": str(symbol)[:32] if symbol else "",
        }
        if extra:
            entry["extra"] = {k: str(v)[:80] for k, v in list(extra.items())[:6]}
        with _ENGINE_ERROR_LOCK:
            buf = _ENGINE_ERRORS.setdefault(cat, [])
            buf.append(entry)
            if len(buf) > _ENGINE_ERROR_CAP:
                del buf[: len(buf) - _ENGINE_ERROR_CAP]
        LOGGER.warning("[engine:%s] %s %s", cat, entry.get("symbol") or "-", entry["message"])
    except Exception:
        pass


def _engine_error_snapshot() -> dict:
    """Return recent categorized errors for diagnostics API."""
    try:
        with _ENGINE_ERROR_LOCK:
            return {k: list(v[-10:]) for k, v in _ENGINE_ERRORS.items()}
    except Exception:
        return {}


def _swallow(note: str = "") -> None:
    """Replacement for a silent `except: pass`.

    Never raises. Counts every swallowed exception per call-site (visible at
    /api/v53/diagnostics) and logs the first occurrences at WARNING and the
    rest at DEBUG so real faults are no longer invisible, without log spam.

    Optional note may encode a category prefix: ``data:fetch_failed``.
    """
    try:
        et, ev, _tb = sys.exc_info()
        if et is None or issubclass(et, (KeyboardInterrupt, SystemExit)):
            return
        if "duplicate column" in str(ev).lower():   # expected idempotent ALTER TABLE migrations
            return
        fr = sys._getframe(1)
        key = f"{fr.f_code.co_name}:{fr.f_lineno}:{et.__name__}"
        with _SWALLOW_LOCK:
            n = _SWALLOWED.get(key, 0) + 1
            if len(_SWALLOWED) < 2000 or key in _SWALLOWED:
                _SWALLOWED[key] = n
        # Optional category from note like "data:..." or "forecast:..."
        cat = "other"
        if note and ":" in str(note):
            maybe = str(note).split(":", 1)[0].strip().lower()
            if maybe in {"data", "signal", "storage", "forecast", "dashboard", "decision", "network", "ai"}:
                cat = maybe
                try:
                    _record_engine_error(cat, f"{et.__name__}: {ev}", note=str(note)[:80])
                except Exception:
                    pass
        if n <= 3:
            LOGGER.warning("suppressed %s at %s (#%d) %s %s", et.__name__, key, n, str(ev)[:160], note or "")
        elif n in (10, 100, 1000):
            LOGGER.warning("suppressed %s at %s x%d", et.__name__, key, n)
        else:
            LOGGER.debug("suppressed %s at %s: %s", et.__name__, key, ev)
    except Exception:
        pass  # never recurse; _swallow itself must never raise


def _now_iso() -> str:
    """Return a timezone-aware UTC timestamp for dashboard/cache metadata."""
    return datetime.now(timezone.utc).isoformat(timespec="seconds")

CACHE_LOCK = threading.RLock()
DB_LOCK = threading.RLock()
JSON_LOCK = threading.RLock()
_HTTP_LOCAL = threading.local()
KEY_LOCK = threading.RLock()
OI_LOCK = threading.RLock()
UPDATE_LOCK = threading.Lock()

# --- V9 Performance: shared pools + short-TTL kline/derivative memory cache ---
KLINE_CACHE: dict[str, tuple[float, "pd.DataFrame"]] = {}
KLINE_CACHE_LOCK = threading.RLock()
KLINE_CACHE_TTL = 60.0  # V75: longer reuse for faster scans          # V61: reuse candles longer across progressive scans
KLINE_CACHE_MAX = 160           # hard cap entries (symbols × TFs)
DERIV_CACHE: dict[str, tuple[float, dict]] = {}
DERIV_CACHE_TTL = 28.0
_ANALYSIS_POOL: Optional[ThreadPoolExecutor] = None
_ANALYSIS_POOL_LOCK = threading.Lock()
_KLINE_POOL: Optional[ThreadPoolExecutor] = None
_KLINE_POOL_LOCK = threading.Lock()


def _get_analysis_pool(size: int = 5) -> ThreadPoolExecutor:
    global _ANALYSIS_POOL
    with _ANALYSIS_POOL_LOCK:
        if _ANALYSIS_POOL is None:
            # 8GB Android balanced: 5 parallel symbol analyses keep the bar moving
            # without saturating SSL/RAM. Pool is process-wide and reused.
            n = max(2, min(int(size), int(os.environ.get("TITAN_SCAN_WORKERS", "8") or 8)))
            _ANALYSIS_POOL = ThreadPoolExecutor(max_workers=n, thread_name_prefix="titan-an")
        return _ANALYSIS_POOL


def _get_kline_pool(size: int = 5) -> ThreadPoolExecutor:
    global _KLINE_POOL
    with _KLINE_POOL_LOCK:
        if _KLINE_POOL is None:
            _KLINE_POOL = ThreadPoolExecutor(max_workers=max(2, min(int(size), int(os.environ.get("TITAN_KLINE_WORKERS", "8") or 8))), thread_name_prefix="titan-kl")
        return _KLINE_POOL


_AI_POOL: Optional[ThreadPoolExecutor] = None
_AI_POOL_LOCK = threading.Lock()
_AI_ENRICH_LOCK = threading.Lock()
_AI_SUMMARY_LOCK = threading.Lock()
_AI_SUMMARY_LAST_RUN = 0.0
DERIV_CACHE_MAX = 50


def _append_capped(target: list, value: Any, max_items: int = 256) -> None:
    """Append to an in-memory history without allowing unbounded growth."""
    target.append(value)
    overflow = len(target) - int(max_items)
    if overflow > 0:
        del target[:overflow]


def _get_ai_pool(size: int = 1) -> ThreadPoolExecutor:
    """Reuse one AI thread pool across symbols (avoids create/destroy per coin)."""
    global _AI_POOL
    with _AI_POOL_LOCK:
        if _AI_POOL is None:
            _AI_POOL = ThreadPoolExecutor(max_workers=max(1, min(int(size), 2)), thread_name_prefix="titan-ai")
        return _AI_POOL


def _kline_cache_key(symbol: str, tf: str, limit: int, start_ms: Optional[int], end_ms: Optional[int]) -> str:
    return f"{_binance_symbol(symbol)}|{tf}|{limit}|{start_ms or 0}|{end_ms or 0}"


def _kline_cache_get(key: str) -> Optional["pd.DataFrame"]:
    with KLINE_CACHE_LOCK:
        row = KLINE_CACHE.get(key)
        if not row:
            return None
        ts, df = row
        if time.time() - ts > KLINE_CACHE_TTL:
            KLINE_CACHE.pop(key, None)
            return None
        # Shallow copy is enough for OHLCV: analysis creates new columns (CoW)
        # and never mutates raw open/high/low/close arrays in-place.
        return df.copy(deep=False)


def _kline_cache_put(key: str, df: "pd.DataFrame") -> None:
    with KLINE_CACHE_LOCK:
        # Snapshot once at insert; readers get shallow copies (see _kline_cache_get).
        KLINE_CACHE[key] = (time.time(), df.copy(deep=False))
        if len(KLINE_CACHE) > KLINE_CACHE_MAX:
            # drop oldest ~20%
            items = sorted(KLINE_CACHE.items(), key=lambda x: x[1][0])
            for k, _ in items[: max(1, len(items) // 5)]:
                KLINE_CACHE.pop(k, None)



def _safe_app_path(path: Path) -> Path:
    candidate = Path(path).resolve()
    root = APP_HOME.resolve()
    try:
        candidate.relative_to(root)
    except ValueError:
        raise RuntimeError(f"TITAN path escaped MMM root: {candidate}")
    return candidate


def _http_session() -> requests.Session:
    """Return one requests.Session per worker thread.

    requests.Session is not guaranteed to be safely mutable across concurrent
    workers; TITAN performs many parallel market/API calls. Thread-local sessions
    preserve connection pooling without sharing mutable session state.
    """
    session = getattr(_HTTP_LOCAL, "session", None)
    if session is None:
        session = requests.Session()
        session.headers.update({"User-Agent": "TITAN-ENTERPRISE/3.0", "Accept": "application/json"})
        retry = Retry(
            total=3, connect=3, read=3, backoff_factor=0.6,
            status_forcelist=(429, 500, 502, 503, 504),
            allowed_methods=frozenset(["GET", "HEAD", "OPTIONS"]),
            respect_retry_after_header=True,
        )
        adapter = HTTPAdapter(max_retries=retry, pool_connections=32, pool_maxsize=32)
        session.mount("https://", adapter)
        session.mount("http://", adapter)
        _HTTP_LOCAL.session = session
    return session

# ============================================================
# API KEYS - FILE ONLY
# ============================================================

OPENAI_API_KEY = ""
GEMINI_API_KEY = ""
GROK_API_KEY = ""
CLAUDE_API_KEY = ""
DEEPSEEK_API_KEY = ""
COINGLASS_API_KEY = ""

KEY_FILES = {
    "OPENAI_API_KEY": ["openai_api_key.txt", "chatgpt_api_key.txt", "titan_llm_key.txt", "openai.txt", "OPENAI_API_KEY.txt"],
    "GEMINI_API_KEY": ["gemini_api_key.txt", "gemini_key.txt", "api gemini_key.txt", "gemini.txt", "GEMINI_API_KEY.txt", "google_gemini_key.txt"],
    "GROK_API_KEY": ["grok_api_key.txt", "xai_api_key.txt", "grok_key.txt", "xai.txt", "GROK_API_KEY.txt"],
    "CLAUDE_API_KEY": ["claude_api_key.txt", "anthropic_api_key.txt", "claude_key.txt", "claude.txt"],
    "DEEPSEEK_API_KEY": ["deepseek_api_key.txt", "deepseek_key.txt", "deepseek.txt"],
    "COINGLASS_API_KEY": ["coinglass_api_key.txt", "coinglass_key.txt", "coinglass.txt", "CG-API-KEY.txt", "COINGLASS_API_KEY.txt"],
}


def _clean_key(value: str) -> str:
    value = (value or "").lstrip("\ufeff").strip()
    if not value:
        return ""
    if "=" in value and "\n" not in value:
        left, right = value.split("=", 1)
        normalized = left.strip().upper().replace("_", "").replace("-", "")
        if normalized.endswith("APIKEY"):
            value = right.strip()
    if len(value) >= 2 and value[0] == value[-1] and value[0] in "\"'":
        value = value[1:-1].strip()
    # Reject obviously invalid placeholders
    low = value.lower()
    if low in {"your_api_key", "changeme", "xxx", "todo", "none", "null", "undefined"}:
        return ""
    # Require a minimum plausible length for real API keys
    if len(value) < 8:
        return ""
    return value


def _read_key(name: str) -> str:
    for filename in KEY_FILES.get(name, []):
        for base in (SECRETS_DIR, APP_HOME, DATA_DIR):
            path = base / filename
            try:
                if path.is_file():
                    value = _clean_key(path.read_text(encoding="utf-8"))
                    if value:
                        return value
            except OSError as exc:
                LOGGER.warning("Key read failed for %s: %s", filename, exc)
    return ""


def reload_keys() -> None:
    global OPENAI_API_KEY, GEMINI_API_KEY, GROK_API_KEY, CLAUDE_API_KEY, DEEPSEEK_API_KEY, COINGLASS_API_KEY
    with KEY_LOCK:
        OPENAI_API_KEY = _read_key("OPENAI_API_KEY")
        GEMINI_API_KEY = _read_key("GEMINI_API_KEY")
        GROK_API_KEY = _read_key("GROK_API_KEY")
        CLAUDE_API_KEY = _read_key("CLAUDE_API_KEY")
        DEEPSEEK_API_KEY = _read_key("DEEPSEEK_API_KEY")
        COINGLASS_API_KEY = _read_key("COINGLASS_API_KEY")
        present = {
            "openai": bool(OPENAI_API_KEY),
            "gemini": bool(GEMINI_API_KEY),
            "grok": bool(GROK_API_KEY),
            "claude": bool(CLAUDE_API_KEY),
            "deepseek": bool(DEEPSEEK_API_KEY),
            "coinglass": bool(COINGLASS_API_KEY),
        }
        LOGGER.info(
            "API keys loaded · present=%s secrets_dir=%s",
            {k: v for k, v in present.items() if v} or "none",
            SECRETS_DIR,
        )

reload_keys()
