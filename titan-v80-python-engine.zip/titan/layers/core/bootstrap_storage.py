from __future__ import annotations

import hashlib
import copy
import json
import logging
import math
import os
import sqlite3
import statistics
import sys
import socket
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional
from logging.handlers import RotatingFileHandler

import numpy as np
import pandas as pd
import requests
from flask import Flask, jsonify, redirect, render_template_string, request, url_for
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

try:
    import websocket as _websocket_client
except Exception:
    _websocket_client = None

# ============================================================
# TITAN
# Technical layers: Fibonacci / Support-Resistance / Multi TF scoring integrated ENTERPRISE V32
# Analysis only. No order execution.
# V60: ALL files, data, cache, logs, temp, bytecode, Flask instance, SQLite
# journals, history and secrets are HARD-LOCKED to Internal Storage/MMM.
# Nothing is written anywhere else on the phone.
# ============================================================

# TITAN storage is HARD-LOCKED to one user-visible folder on Android shared
# internal storage. Nothing is written outside this root by TITAN.
#
# Required layout (all contained inside one folder):
#   /storage/emulated/0/MMM/
#       data/              -> database, settings, logs, replay, flask instance
#       cache/             -> market + AI caches, history, tmp, pycache
#       memory/            -> learning/adaptive memory
#       secrets/           -> optional API-key files
#
# There is intentionally NO fallback to the script directory, current working
# directory, /tmp, /data/data, Android app cache, a desktop profile,
# TITAN_HOME, SD card, or any other path. Only MMM.
TITAN_FOLDER_NAME = "MMM"
TITAN_SHARED_STORAGE = Path("/storage/emulated/0")
TITAN_ANDROID_HOME = TITAN_SHARED_STORAGE / TITAN_FOLDER_NAME

def _select_app_home() -> Path:
    """Return the TITAN persistent root: folder MMM.

    Phone: Internal Storage/MMM (/storage/emulated/0, /sdcard, /storage/self/primary).
    Desktop/sandbox: TITAN_HOME, /workspace/MMM, ~/MMM, or script-dir/MMM.
    Never writes outside a folder named MMM.
    """
    candidates = (
        TITAN_SHARED_STORAGE,
        Path("/sdcard"),
        Path("/storage/self/primary"),
    )
    root = None
    for cand in candidates:
        try:
            if cand.exists() and cand.is_dir():
                kroot = cand / TITAN_FOLDER_NAME
                probe = kroot / ".titan_jjj_probe"
                try:
                    kroot.mkdir(parents=True, exist_ok=True)
                    probe.write_text("ok", encoding="utf-8")
                    probe.unlink(missing_ok=True)
                    root = cand
                    break
                except OSError:
                    continue
        except OSError:
            continue
    if root is not None:
        return root / TITAN_FOLDER_NAME
    # Hard-lock Android: if shared-storage roots are present but unwritable,
    # fail closed instead of silently persisting data in the app/script folder.
    android_storage_present = False
    for cand in candidates:
        try:
            if cand.exists() and cand.is_dir():
                android_storage_present = True
                break
        except OSError:
            continue
    if android_storage_present:
        raise RuntimeError(
            "MMM storage is present but not writable. TITAN will not fall back "
            "to the script directory or another location. Grant storage permission "
            "and make Internal Storage/MMM writable."
        )
    extras = []
    env_home = str(os.environ.get("TITAN_HOME") or "").strip()
    if env_home:
        extras.append(Path(env_home))
    extras.extend((
        Path("/workspace") / TITAN_FOLDER_NAME,
        Path.home() / TITAN_FOLDER_NAME,
        Path(__file__).resolve().parent / TITAN_FOLDER_NAME,
    ))
    for extra in extras:
        try:
            kroot = extra if extra.name == TITAN_FOLDER_NAME else extra / TITAN_FOLDER_NAME
            probe = kroot / ".titan_jjj_probe"
            kroot.mkdir(parents=True, exist_ok=True)
            probe.write_text("ok", encoding="utf-8")
            probe.unlink(missing_ok=True)
            return kroot
        except OSError:
            continue
    raise RuntimeError(
        "TITAN requires a writable MMM folder. On Android grant All-files permission "
        "and create Internal Storage/MMM. On desktop set TITAN_HOME or create ./MMM."
    )

APP_HOME = _select_app_home()
DATA_DIR = APP_HOME / "data"
CACHE_DIR = APP_HOME / "cache"
MEMORY_DIR = APP_HOME / "memory"
SECRETS_DIR = APP_HOME / "secrets"
LOG_DIR = DATA_DIR
TMP_DIR = CACHE_DIR / "tmp"
PYCACHE_DIR = CACHE_DIR / "pycache"
HIST_DIR = CACHE_DIR / "history"
REPLAY_DIR = DATA_DIR / "replay"
FLASK_INSTANCE_DIR = DATA_DIR / "flask_instance"

for directory in (
    APP_HOME, DATA_DIR, CACHE_DIR, MEMORY_DIR, SECRETS_DIR,
    TMP_DIR, PYCACHE_DIR, HIST_DIR, REPLAY_DIR, FLASK_INSTANCE_DIR,
):
    directory.mkdir(parents=True, exist_ok=True)

# Force every OS / Python / SQLite / XDG temp+cache write into MMM.
# This covers tempfile, sqlite spill, bytecode, requests/certifi caches, etc.
os.environ["TMPDIR"] = str(TMP_DIR)
os.environ["TEMP"] = str(TMP_DIR)
os.environ["TMP"] = str(TMP_DIR)
os.environ["SQLITE_TMPDIR"] = str(TMP_DIR)
os.environ["PYTHONPYCACHEPREFIX"] = str(PYCACHE_DIR)
os.environ["PYTHONDONTWRITEBYTECODE"] = "1"
os.environ["XDG_CACHE_HOME"] = str(CACHE_DIR)
os.environ["XDG_DATA_HOME"] = str(DATA_DIR)
os.environ["XDG_STATE_HOME"] = str(DATA_DIR)
os.environ["XDG_CONFIG_HOME"] = str(DATA_DIR)
sys.dont_write_bytecode = True
try:
    import tempfile as _titan_tempfile
    _titan_tempfile.tempdir = str(TMP_DIR)
except Exception:
    _swallow()

DB_PATH = DATA_DIR / "titan_enterprise.db"
LOG_PATH = LOG_DIR / "titan_engine.log"
AI_CACHE_PATH = CACHE_DIR / "ai_responses.json"
MARKET_CACHE_PATH = CACHE_DIR / "market_cache.json"
USER_SETTINGS_PATH = DATA_DIR / "user_settings.json"
MODEL_SETTINGS_PATH = DATA_DIR / "model_settings.json"
AI_SYMBOL_CACHE_PATH = CACHE_DIR / "ai_symbol_responses.json"


def _startup_storage_audit() -> dict[str, Any]:
    """Verify that every persistent TITAN root is physically inside MMM."""
    root = APP_HOME.resolve()
    if root.name != TITAN_FOLDER_NAME:
        raise RuntimeError(f"TITAN storage root must be folder {TITAN_FOLDER_NAME}, got {root}")
    required = (
        DATA_DIR, CACHE_DIR, MEMORY_DIR, SECRETS_DIR, LOG_DIR,
        TMP_DIR, PYCACHE_DIR, HIST_DIR, REPLAY_DIR, FLASK_INSTANCE_DIR,
    )
    root.mkdir(parents=True, exist_ok=True)
    for directory in required:
        directory.mkdir(parents=True, exist_ok=True)
        try:
            directory.resolve().relative_to(root)
        except ValueError:
            raise RuntimeError(f"TITAN storage escape: {directory}")
    probe = root / ".titan_storage_probe"
    try:
        probe.write_text("TITAN_STORAGE_OK", encoding="utf-8")
        if probe.read_text(encoding="utf-8") != "TITAN_STORAGE_OK":
            raise OSError("storage verification mismatch")
    finally:
        try:
            probe.unlink()
        except OSError:
            pass
    persistent = (
        DB_PATH, LOG_PATH, AI_CACHE_PATH, MARKET_CACHE_PATH,
        USER_SETTINGS_PATH, MODEL_SETTINGS_PATH, AI_SYMBOL_CACHE_PATH,
        TMP_DIR, PYCACHE_DIR, HIST_DIR, REPLAY_DIR, FLASK_INSTANCE_DIR,
    )
    for path in persistent:
        try:
            path.resolve().relative_to(root)
        except ValueError:
            raise RuntimeError(f"Persistent path escaped MMM root: {path}")
    return {
        "root": str(root),
        "writable": True,
        "persistent_paths_locked": True,
        "single_folder": TITAN_FOLDER_NAME,
        "no_external_writes": True,
    }


STARTUP_STORAGE_AUDIT = _startup_storage_audit()

# V29 autonomous loop:
# - live prices are streamed/polled continuously;
# - the expensive multi-timeframe scan runs automatically in the background;
# - outcome/performance learning is maintained independently of page requests;
# - Gemini enrichment is asynchronous and is fed back into the next scan.
AUTO_SCAN_INTERVAL_SECONDS = 8  # V75: faster first paint + scan  # V61: snappier first paint + tighter refresh
AUTO_MAINTENANCE_INTERVAL_SECONDS = 10
AUTO_AI_TOP_N = 3
AUTO_AI_REFRESH_SECONDS = 240
# Progressive publish: push partial analysis into CACHE every N completed symbols
SCAN_PARTIAL_PUBLISH_EVERY = 1

MARKET_CACHE_TTL = 18  # V75: faster perceived refresh
# Fast dashboard scan: skip external LLM calls during bulk market refresh (biggest latency win).
# Detail endpoints can still request AI on demand.
DASHBOARD_FAST_SCAN = True
RENDER_PERF_LOG = True
AI_CACHE_TTL = 300
LIVE_PRICE_POLL_SECONDS = 1.2  # V61: fresher tickers, still gentle on REST
MAX_BACKTEST_CANDLES = 3500
SIGNAL_COOLDOWN_SECONDS = 2700
MIN_DIRECTIONAL_QUALITY = 52  # V75: raise bar, especially for low TFs
MIN_PRECISION_SCORE = 50
MIN_TREND_STABILITY = 0.40
MAX_STRETCH_ATR = 2.8
MIN_EFFECTIVE_RR = 1.25  # V75: better RR after cost

# ============================================================
# V75.6 PROFESSIONAL EDGE POLICY — analysis-only, no execution
# ============================================================
TITAN_SAFE_MODE = True                    # default: only 4h + 1d directional publish
TITAN_LIVE_TIMEFRAMES = ("4h", "1d")      # when SAFE_MODE
TITAN_SHADOW_TIMEFRAMES = ("15m", "1h")   # score only, force WAIT for publish
TITAN_REQUIRE_EDGE_SUPPORTED = True       # block LONG/SHORT without historical edge
TITAN_MIN_OOS_SAMPLES = 30
TITAN_MIN_EDGE_EXPECTANCY = 0.15          # net pct expectancy floor
TITAN_MIN_EDGE_SHARPE = 0.08
TITAN_MIN_EDGE_TRADES = 25
TITAN_AI_MAX_WEIGHT = 0.12                # AI cannot dominate quant
TITAN_FORECAST_MAX_WEIGHT = 0.14           # V76: real forecast path has meaningful weight
TITAN_FORECAST_MIN_SAMPLES_HARD = 10       # hard veto/align when path history exists
TITAN_FORECAST_ALIGN_BONUS = 6.0           # score bonus when path agrees
TITAN_FORECAST_CONFLICT_PENALTY = 10.0     # score penalty / soft WAIT when path conflicts
TITAN_UNIFIED_PIPELINE = True             # single publish path for scan + deep
TITAN_MANDATORY_CHECKLIST_MIN = 5         # of 8
TITAN_AUTO_THRESHOLD_BOOST = True         # learn from v75_deep_ledger
TITAN_THRESHOLD_BOOST_MAX = 12.0
TITAN_DEEP_EVAL_INTERVAL_SEC = 900
TITAN_COST_ROUND_TRIP_PCT = round((0.0004 + 0.0002 + 0.0002) * 2 * 100, 4)  # fee+spread+slip

HTTP_TIMEOUT = 8
FEE_RATE = 0.0004
SPREAD_RATE = 0.0002
SLIPPAGE_RATE = 0.0002
TOTAL_ENTRY_BUFFER = FEE_RATE + SPREAD_RATE + SLIPPAGE_RATE

# --- V8 Professional confidence gates ---
# V28.5: deep audit — residual WAIT kills softened, hero board fixed,
# refine_bias balanced, neural demotion only on real conflict.
TITAN_PARAM_VERSION = "V80.0-UNIFIED-ENTERPRISE"
TITAN_BUILD_ID = "V80.0-MODULAR-MONOLITH-ENTERPRISE-2026-10"
TITAN_ENGINE_MODE = "V80_MODULAR_MONOLITH_ENTERPRISE"
TITAN_ACTIVE_DECISION_PATH = "DATA -> TF-PROFILE -> QUANT -> FORECAST_REAL -> NEURAL -> V60_EDGE -> UNIFIED_PUBLISH -> V55_DESK -> LEDGER"
TITAN_V51_AUTHORITATIVE = True
TITAN_V51_PUBLISH_LOCK = threading.Lock()
MAX_LIVE_PRICE_AGE_SEC = 18.0
MIN_CLOSED_CANDLES_1H = 36
MIN_CLOSED_CANDLES_15M = 28
MIN_DATA_QUALITY_SCORE = 50
ENTRY_LADDER_MIN_HTF_SCORE = 52
ENTRY_LADDER_MIN_MTF_SCORE = 51
ENTRY_LADDER_MIN_LTF_ALIGN = 0.0  # soft; hard check is direction match
MAX_PORTFOLIO_SAME_SIDE = 3
FORECAST_TRACK_PATH = None  # set after APP_HOME exists
CALIB_MIN_SAMPLES_FULL = 20
CALIB_CAP_LOW_N = 62.0
CALIB_CAP_MID_N = 72.0
CALIB_CAP_HIGH_N = 86.0

# Android optimization profile
TITAN_ANDROID_RAM_GB = 8
TITAN_ANDROID_API_LEVEL = 35  # Android 15
TITAN_ANDROID_PROFILE = "XIAOMI_8GB_BALANCED"

# Keep runtime memory controlled and avoid unnecessary filesystem writes.
os.environ.setdefault("PYTHONUNBUFFERED", "1")
try:
    import gc as _titan_gc
    _titan_gc.set_threshold(700, 10, 10)
except Exception:
    _swallow()
