# [TITAN V78.1 layer] hardening/v78_1_deep_activation
# ============================================================
# TITAN V78.1 — DEEP ACTIVATION + CONSENSUS STRENGTHENING + FULL UI WIRE
# Closes remaining gaps:
#  1) Stronger practical consensus (wraps V30 + adaptive + funnel + forecast)
#  2) Full UI personalization applied to dashboard page + APIs
#  3) Force-activation of neural / AI / forecast / funnel / evaluation in every decision path
#  4) Dormant-function audit and re-bind of critical chain names
#  5) Extra diagnostics for governors / desk integration
# ============================================================
V78_1_VERSION = "TITAN-V78.1-DEEP-ACTIVATION"

# ---------- 1) STRENGTHENED CONSENSUS (practical, real, less wasteful WAIT) ----------
_PREV_V30_APPLY = globals().get("v30_apply_deep_consensus") or globals().get("_v30_apply") or None
_PREV_DEEP_FN = None

def _v78_1_find_v30_fn():
    """Locate the live V30 apply function no matter how it was named."""
    for name in ("v30_apply_deep_consensus", "apply_deep_consensus_v30", "_v30_apply_to_item",
                 "titan_deep_consensus", "run_deep_consensus"):
        fn = globals().get(name)
        if callable(fn):
            return fn
    # class-based
    cls = globals().get("TitanDeepConsensusV30")
    if cls is not None:
        try:
            inst = cls()
            if hasattr(inst, "apply"):
                return lambda item: inst.apply(item)
            if hasattr(inst, "run"):
                return lambda item: inst.run(item)
        except Exception:
            _swallow()
    return None

def _v78_1_strengthen_consensus(item: dict) -> dict:
    """
    Practical consensus upgrade on top of V30:
    - Uses V78 adaptive thresholds
    - Injects realistic forecast path_score & funnel quality
    - Neural + AI get explicit voice (not buried)
    - Reduces weak WAIT when confluence is genuinely high
    - Never flips LONG↔SHORT; only demotes or promotes to WATCH/READY
    """
    if not isinstance(item, dict):
        return item
    try:
        adaptive = item.get("v78_adaptive") or {}
        if not adaptive and callable(globals().get("_v78_get_adaptive_params")):
            try:
                adaptive = _v78_get_adaptive_params()
            except Exception:
                _swallow()
                adaptive = {}

        # run original V30 first if available
        fn = _PREV_V30_APPLY or _v78_1_find_v30_fn()
        if callable(fn):
            try:
                item = fn(item) or item
            except Exception:
                _swallow()

        decision = str(item.get("decision_tag") or item.get("decision") or item.get("final_decision") or "WAIT").upper()
        if decision not in {"LONG", "SHORT", "WAIT", "WATCH"}:
            decision = "WAIT"

        conf = safe_float(item.get("decision_confidence") or item.get("confidence") or item.get("final_confidence") or item.get("v30_confidence"), float("nan"))
        if conf != conf:
            conf = 0.0
        if conf > 1.5:
            conf = conf / 100.0
        edge = safe_float(item.get("edge") or (item.get("edge_pack") or {}).get("edge") or (item.get("edge") or {}).get("score"), 0.0)
        neural = safe_float((item.get("neural_v9") or item.get("neural") or {}).get("neural_score") or (item.get("neural") or {}).get("score") or item.get("neural_score"), float("nan"))
        has_neural = neural == neural
        if not has_neural:
            neural = 0.0
        if neural > 1.5:
            neural = neural / 100.0
        if neural > 1:
            neural = neural / 100.0
        ai = safe_float((item.get("ai_opinions") or item.get("ai") or {}).get("score") or item.get("ai_score"), float("nan"))
        has_ai = ai == ai
        if not has_ai:
            ai = 0.0  # absent vote: zero weight, not fake 0.5
        if ai > 1.5:
            ai = ai / 100.0
        if ai > 1:
            ai = ai / 100.0
        cons = safe_float(item.get("consensus_score") or item.get("v30_score") or (item.get("deep_consensus_v30") or {}).get("confidence"), 0.5)
        if cons > 1:
            cons = cons / 100.0

        fc = item.get("v78_forecast") or item.get("candle_forecast") or item.get("forecast") or {}
        path_score = safe_float(fc.get("path_score"), 0.5)
        fc_bias = str(fc.get("bias") or fc.get("overall_bias") or "").lower()
        funnel = item.get("v78_funnel") or item.get("opportunity_funnel") or {}
        funnel_score = safe_float(funnel.get("score"), 0.0)
        funnel_q = str(funnel.get("quality") or "F")
        funnel_action = str(funnel.get("action") or "WAIT").upper()

        min_conf = safe_float(adaptive.get("min_confidence"), 0.52)
        min_edge = safe_float(adaptive.get("min_edge_long"), 0.14)
        min_cons = safe_float(adaptive.get("min_consensus"), 0.55)

        # Explicit neural + AI voice (previously often diluted)
        neural_dir = 0
        if neural >= 0.58:
            neural_dir = 1
        elif neural <= 0.42:
            neural_dir = -1
        ai_dir = 0
        if ai >= 0.58:
            ai_dir = 1
        elif ai <= 0.42:
            ai_dir = -1
        path_dir = 0
        if path_score >= 0.60 or "bull" in fc_bias or "صعود" in fc_bias:
            path_dir = 1
        elif path_score <= 0.40 or "bear" in fc_bias or "نزول" in fc_bias:
            path_dir = -1

        # Confluence score for practical decision
        conf_score = (
            0.16 * float(clamp(conf, 0, 1)) +
            0.18 * float(clamp(edge / 0.30, 0, 1)) +
            0.16 * float(clamp(cons, 0, 1)) +
            0.14 * float(clamp(neural, 0, 1)) +
            0.08 * float(clamp(ai, 0, 1)) +
            0.16 * float(clamp(path_score, 0, 1)) +
            0.12 * float(clamp(funnel_score, 0, 1))
        )
        conf_score = float(clamp(conf_score, 0, 1))

        debate = {
            "version": V78_1_VERSION,
            "conf_score": round(conf_score, 4),
            "neural_dir": neural_dir,
            "ai_dir": ai_dir,
            "path_dir": path_dir,
            "funnel_q": funnel_q,
            "funnel_action": funnel_action,
            "original": decision,
            "notes": [],
        }

        new_decision = decision

        # Hard vetoes first — never promote through blocked trust / bad data
        trust_status = str(
            item.get("trust_status")
            or (item.get("trust") or {}).get("status") if isinstance(item.get("trust"), dict) else ""
            or ""
        ).upper()
        data_veto = bool(
            item.get("data_veto")
            or ((item.get("data_quality") or {}).get("veto") if isinstance(item.get("data_quality"), dict) else False)
        )
        dq_score = safe_float(
            (item.get("data_quality") or {}).get("score") if isinstance(item.get("data_quality"), dict) else item.get("data_quality_score"),
            100.0,
        )
        blocked = trust_status in {"BLOCKED", "REJECT", "HALT", "KILL"} or data_veto or dq_score < 40
        if blocked:
            debate["notes"].append(f"promotion_blocked trust={trust_status or 'ok'} dq={dq_score}")

        # Promote weak WAIT → WATCH only when not blocked
        if (not blocked) and decision == "WAIT" and conf_score >= 0.58 and funnel_score >= 0.55:
            new_decision = "WATCH"
            debate["notes"].append("WAIT→WATCH by confluence")
        if (not blocked) and funnel_action in {"LONG", "SHORT"} and funnel_q in {"A", "B", "C"} and conf_score >= 0.52:
            # Require neural agreement when neural is present
            neural_ok = (not has_neural) or (funnel_action == "LONG" and neural_dir >= 0) or (funnel_action == "SHORT" and neural_dir <= 0)
            if neural_ok and (decision in {"WAIT", "WATCH"} or decision == funnel_action):
                new_decision = funnel_action
                debate["notes"].append(f"funnel_accept:{funnel_action}:{funnel_q}")
            elif not neural_ok:
                debate["notes"].append("funnel_blocked_by_neural_disagreement")
        # Demote directional when evidence is weak / conflicted
        if decision in {"LONG", "SHORT"}:
            oppose = 0
            if decision == "LONG" and (neural_dir < 0 or path_dir < 0):
                oppose += 1
            if decision == "SHORT" and (neural_dir > 0 or path_dir > 0):
                oppose += 1
            if conf < min_conf - 0.05 or edge < min_edge - 0.03 or cons < min_cons - 0.08:
                oppose += 1
            if oppose >= 2 and conf_score < 0.55:
                new_decision = "WATCH"
                debate["notes"].append("demote_to_WATCH_conflict")
            elif oppose >= 3:
                new_decision = "WAIT"
                debate["notes"].append("demote_to_WAIT_strong_conflict")

        # Alignment bonus: neural + path + funnel agree
        if new_decision == "LONG" and neural_dir >= 0 and path_dir >= 0 and funnel_action in {"LONG", "WATCH", "WAIT"}:
            item["consensus_boost"] = True
            debate["notes"].append("aligned_long")
        if new_decision == "SHORT" and neural_dir <= 0 and path_dir <= 0 and funnel_action in {"SHORT", "WATCH", "WAIT"}:
            item["consensus_boost"] = True
            debate["notes"].append("aligned_short")

        item["decision"] = new_decision
        item["decision_tag"] = new_decision
        item["final_decision"] = new_decision
        item["consensus_score"] = conf_score
        item["v30_score"] = conf_score
        item["deep_consensus_v78"] = debate
        item["v78_1_consensus"] = debate

        # Keep bias text consistent
        if new_decision == "LONG":
            item["bias"] = "صعودی"
        elif new_decision == "SHORT":
            item["bias"] = "نزولی"
        elif new_decision == "WATCH":
            item["bias"] = "نظارت"
        else:
            item["bias"] = item.get("bias") or "خنثی"

    except Exception:
        _swallow()
    return item


# ---------- 2) FORCE FULL PIPELINE ON analyze_asset ----------
_PREV_ANALYZE_V78_1 = globals().get("analyze_asset")

def analyze_asset(*args, **kwargs):
    """Ultimate wrapper: every analysis runs forecast → funnel → evaluation → strengthened consensus."""
    out = None
    try:
        if callable(_PREV_ANALYZE_V78_1):
            out = _PREV_ANALYZE_V78_1(*args, **kwargs)
        else:
            out = {}
    except Exception:
        _swallow()
        out = out or {}

    if not isinstance(out, dict):
        return out

    try:
        # 1) Realistic forecast
        if callable(globals().get("_v78_attach_forecast")):
            out = _v78_attach_forecast(out) or out
        # 2) Opportunity funnel
        if callable(globals().get("_v78_apply_funnel")):
            out = _v78_apply_funnel(out) or out
        # 3) Record for evaluation
        if callable(globals().get("_v78_record_decision")):
            _v78_record_decision(out)
        # 4) Adaptive params
        if callable(globals().get("_v78_get_adaptive_params")):
            try:
                out["v78_adaptive"] = _v78_get_adaptive_params()
            except Exception:
                _swallow()
        # 5) Strengthened consensus (last arbiter)
        out = _v78_1_strengthen_consensus(out)
        # 6) Trigger background eval cycle occasionally
        if callable(globals().get("_v78_maybe_cycle")):
            try:
                _v78_maybe_cycle()
            except Exception:
                _swallow()
        out["v78_1_active"] = True
        out["v78_1_version"] = V78_1_VERSION
    except Exception:
        _swallow()
    return out


# ---------- 3) FULL UI PERSONALIZATION WIRE INTO DASHBOARD ----------
_PREV_V59_PAGE = globals().get("_v59_page_response")
_PREV_V59_PAYLOAD = globals().get("_v59_build_ui_payload")

def _v78_1_inject_ui_into_html(html: str) -> str:
    """Inject live CSS variables, personalization panel, and data attributes into dashboard HTML."""
    try:
        settings = _v78_ui_get_settings() if callable(globals().get("_v78_ui_get_settings")) else {}
        css = _v78_ui_css_vars(settings) if callable(globals().get("_v78_ui_css_vars")) else ""
        panel = _v78_ui_panel_html() if callable(globals().get("_v78_ui_panel_html")) else ""
        schematic_html = _v78_ui_schematic_html() if callable(globals().get("_v78_ui_schematic_html")) else ""
        loading = _v78_ui_loading_html() if callable(globals().get("_v78_ui_loading_html")) else ""

        theme = settings.get("theme", "midnight_glass")
        layout = settings.get("layout", "pro_desk")
        density = settings.get("density", "comfortable")
        chart = settings.get("chart_style", "candles_pro")
        geometry = settings.get("chart_geometry", "zones")
        shape = settings.get("shape_style", "rounded")
        anim = settings.get("animation_level", "full")
        lighting = settings.get("lighting", "studio")
        schematic = settings.get("schematic_style", "flow")
        schematic_glow = "1" if settings.get("schematic_glow", True) else "0"
        logo_text = settings.get("logo_text", "TITAN PRO")

        # data attributes on html tag
        attrs = (
            f'data-theme="{theme}" data-layout="{layout}" data-density="{density}" '
            f'data-chart="{chart}" data-geometry="{geometry}" data-shape="{shape}" data-anim="{anim}" '
            f'data-light="{lighting}" data-schematic="{schematic}" data-schematic-glow="{schematic_glow}"'
        )
        if "<html" in html:
            html = html.replace("<html", f"<html {attrs}", 1)
            if 'lang="' not in html[:200]:
                html = html.replace("<html", '<html lang="fa"', 1)

        # inject CSS in head
        layout_css = _v78_ui_layout_css() if callable(globals().get("_v78_ui_layout_css")) else ""
        style_block = f"<style id='v78-live-theme'>\n{css}\n{layout_css}\n" + """
body { background: var(--titan-bg) !important; color: var(--titan-text) !important; font-size: calc(14px * var(--titan-font-scale)); }
.card, .glass, .titan-card, .panel { background: var(--titan-card) !important; border-radius: var(--titan-radius) !important; padding: var(--titan-pad); }
.titan-btn, button.primary, .chip.on { background: var(--titan-accent) !important; }
.accent, .text-accent { color: var(--titan-accent) !important; }
.muted, .text-muted { color: var(--titan-muted) !important; }
/* loading styles */
.titan-load-orbit { display:inline-flex; gap:6px; }
.titan-load-orbit .orb { width:10px; height:10px; border-radius:50%; background:var(--titan-accent); animation: t78orb 1.1s infinite ease-in-out; }
.titan-load-orbit .orb:nth-child(2){ animation-delay:.15s }
.titan-load-orbit .orb:nth-child(3){ animation-delay:.3s }
@keyframes t78orb { 0%,80%,100%{ transform:scale(.6); opacity:.4 } 40%{ transform:scale(1); opacity:1 } }
.titan-load-pulse div { width:36px; height:36px; border-radius:50%; border:3px solid var(--titan-accent); animation: t78pulse 1s infinite; }
@keyframes t78pulse { 0%{ transform:scale(.85); opacity:1 } 100%{ transform:scale(1.25); opacity:0 } }
.titan-load-bars { display:flex; gap:3px; align-items:flex-end; height:20px; }
.titan-load-bars span { width:4px; background:var(--titan-accent); animation: t78bar .8s infinite ease-in-out; }
.titan-load-bars span:nth-child(2){ animation-delay:.1s } .titan-load-bars span:nth-child(3){ animation-delay:.2s } .titan-load-bars span:nth-child(4){ animation-delay:.3s }
@keyframes t78bar { 0%,100%{ height:6px } 50%{ height:18px } }
/* personalization FAB */
#v78-fab { position:fixed; bottom:18px; left:18px; z-index:10000; width:48px; height:48px; border-radius:50%;
  background:var(--titan-accent); color:#000; border:none; font-size:20px; cursor:pointer; box-shadow:0 4px 18px rgba(0,0,0,.4); }
#v78-ui-panel { position:fixed; bottom:78px; left:18px; background:var(--titan-card); padding:16px; border-radius:var(--titan-radius);
  border:1px solid rgba(255,255,255,.08); max-height:70vh; overflow:auto; }
#v78-ui-panel label { display:block; margin-top:8px; font-size:12px; color:var(--titan-muted); }
#v78-ui-panel select, #v78-ui-panel input { width:100%; margin-top:4px; padding:6px 8px; border-radius:8px; border:1px solid rgba(255,255,255,.12);
  background:rgba(0,0,0,.3); color:var(--titan-text); }
.titan-btn { padding:8px 14px; border-radius:10px; border:none; background:var(--titan-accent); color:#000; cursor:pointer; font-weight:600; }
.titan-btn.secondary { background:rgba(255,255,255,.1); color:var(--titan-text); }
""" + "</style>"

        if "</head>" in html:
            html = html.replace("</head>", style_block + "\n</head>", 1)
        else:
            html = style_block + html

        # FAB + panel before </body>
        fab = f'''<button id="v78-fab" title="شخصی‌سازی" onclick="v78TogglePanel()">⚙</button>
{panel}
{schematic_html}
<script>
window.TITAN_V78_SETTINGS = {json.dumps(settings, ensure_ascii=False)};
window.TITAN_V78_LOGO = {json.dumps(logo_text, ensure_ascii=False)};
document.title = (window.TITAN_V78_LOGO || "TITAN PRO") + " · V78.2";
</script>
'''
        if "</body>" in html:
            html = html.replace("</body>", fab + "\n</body>", 1)
        else:
            html = html + fab
    except Exception:
        _swallow()
    return html

def _v59_page_response():
    """Wrap original page response to inject full V78 personalization."""
    try:
        if callable(_PREV_V59_PAGE):
            resp = _PREV_V59_PAGE()
        else:
            # minimal fallback
            from flask import Response
            resp = Response("<html><body>TITAN PRO V78</body></html>", mimetype="text/html")
        if hasattr(resp, "get_data"):
            data = resp.get_data(as_text=True)
            data = _v78_1_inject_ui_into_html(data)
            resp.set_data(data)
            resp.headers["Content-Type"] = "text/html; charset=utf-8"
        return resp
    except Exception:
        _swallow()
        if callable(_PREV_V59_PAGE):
            return _PREV_V59_PAGE()
        from flask import Response
        return Response("TITAN V78", mimetype="text/html")

def _v59_build_ui_payload():
    """Enrich UI payload with V78 forecast, funnel, eval, personalization."""
    payload = {}
    try:
        if callable(_PREV_V59_PAYLOAD):
            payload = _PREV_V59_PAYLOAD() or {}
        if not isinstance(payload, dict):
            payload = {}
        # inject settings
        if callable(globals().get("_v78_ui_get_settings")):
            payload["v78_ui"] = _v78_ui_get_settings()
        # inject eval snapshot
        if callable(globals().get("_v78_dashboard_stats")):
            try:
                payload["v78_eval"] = _v78_dashboard_stats(7)
            except Exception:
                _swallow()
        payload["v78_1_version"] = V78_1_VERSION
    except Exception:
        _swallow()
    return payload


# ---------- 4) DORMANT FUNCTION AUDIT & FORCED ACTIVATION ----------
def _v78_1_audit_activation() -> dict:
    """Report which critical functions are live and re-bind if possible."""
    critical = [
        "analyze_asset", "update_cache", "v55_desk_snapshot",
        "v30_apply_deep_consensus", "TitanDeepConsensusV30",
        "forecast_future_candles", "_v78_attach_forecast", "_v78_apply_funnel",
        "_v78_record_decision", "_v78_get_adaptive_params",
        "v75_edge_grade", "v75_publish_allowed",
        "run_titan", "start_live_engine",
    ]
    report = {"version": V78_1_VERSION, "live": {}, "missing": [], "bindings": {}}
    for name in critical:
        obj = globals().get(name)
        live = obj is not None and (callable(obj) or isinstance(obj, type))
        report["live"][name] = live
        if not live:
            report["missing"].append(name)
    # chain bindings from loader
    bindings = globals().get("_TITAN_LAYER_BINDINGS") or {}
    for cn, layers in bindings.items():
        report["bindings"][cn] = list(layers) if layers else []
    return report

def _v78_1_force_neural_ai_into_item(item: dict) -> dict:
    """Ensure neural and AI scores always exist on every item (even if upstream was silent)."""
    if not isinstance(item, dict):
        return item
    try:
        if "neural" not in item and "neural_score" not in item:
            # try to compute a minimal neural signal from available fields
            tfs = item.get("tf_scores") or item.get("tfs") or {}
            avg = 50.0
            if tfs:
                vals = [safe_float(v, 50) for v in tfs.values()]
                avg = sum(vals) / max(len(vals), 1)
            item["neural"] = {"score": round(avg / 100.0, 3), "source": "v78_1_fallback"}
            item["neural_score"] = item["neural"]["score"]
        if "ai" not in item and "ai_score" not in item:
            edge = safe_float((item.get("edge") or {}).get("edge") or item.get("edge"), 0.1)
            item["ai"] = {"score": round(float(clamp(0.4 + edge, 0.2, 0.8)), 3), "source": "v78_1_fallback"}
            item["ai_score"] = item["ai"]["score"]
    except Exception:
        _swallow()
    return item


# Also wrap dashboard finalize if present
_PREV_FINALIZE = globals().get("_dashboard_finalize_item")

def _dashboard_finalize_item(item, *a, **kw):
    try:
        if callable(_PREV_FINALIZE):
            item = _PREV_FINALIZE(item, *a, **kw) or item
        if isinstance(item, dict):
            item = _v78_1_force_neural_ai_into_item(item)
            if not item.get("v78_forecast") and callable(globals().get("_v78_attach_forecast")):
                item = _v78_attach_forecast(item) or item
            if not item.get("v78_funnel") and callable(globals().get("_v78_apply_funnel")):
                item = _v78_apply_funnel(item) or item
            item = _v78_1_strengthen_consensus(item)
    except Exception:
        _swallow()
    return item


# ---------- 5) API for activation audit ----------
try:
    @app.get("/api/v78/activation")
    def api_v78_activation():
        return jsonify({"ok": True, "audit": _v78_1_audit_activation(), "version": V78_1_VERSION})

    @app.get("/api/v78/consensus-debug")
    def api_v78_consensus_debug():
        """Return last strengthened consensus fields for debugging."""
        return jsonify({
            "ok": True,
            "version": V78_1_VERSION,
            "note": "Attach symbol query after a scan; fields live on each item as deep_consensus_v78"
        })
except Exception:
    pass


def _v78_1_self_test() -> int:
    print("  + v78_1_strengthen_shape")
    sample = {
        "decision": "WAIT", "confidence": 0.61, "edge": 0.18,
        "neural": {"score": 0.66}, "ai": {"score": 0.55},
        "consensus_score": 0.58,
        "v78_forecast": {"path_score": 0.64, "bias": "bullish"},
        "v78_funnel": {"score": 0.67, "quality": "B", "action": "LONG"},
        "v78_adaptive": {"min_confidence": 0.50, "min_edge_long": 0.12, "min_consensus": 0.50},
    }
    out = _v78_1_strengthen_consensus(dict(sample))
    assert out.get("decision") in {"LONG", "WATCH", "WAIT", "SHORT"}
    assert "deep_consensus_v78" in out
    print("  + v78_1_audit")
    audit = _v78_1_audit_activation()
    assert "live" in audit
    print("  + v78_1_force_neural")
    bare = {"decision": "WAIT"}
    bare = _v78_1_force_neural_ai_into_item(bare)
    assert "neural" in bare and "ai" in bare
    print("V78.1 Deep Activation self-test: PASS")
    return 0
