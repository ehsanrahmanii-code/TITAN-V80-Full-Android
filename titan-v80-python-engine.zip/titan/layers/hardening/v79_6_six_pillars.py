# [TITAN V79.6] Six pillars — data/forecast, decision authority, learning,
# models/ensemble, performance architecture, product trust surfaces.
V79_6_VERSION = "TITAN-V79.6.7-SIX-PILLARS-CONTRACT"

import json
import threading
import time
from typing import Any, Optional

# =============================================================================
# PILLAR 1 — Data foundation + forecast integrity
# =============================================================================

_V79_OHLCV_MEM: dict[str, dict] = {}
_V79_OHLCV_LOCK = threading.RLock()
_V79_OHLCV_TTL = 45.0  # seconds soft cache for repeated TF pulls in one scan

def _v79_ohlcv_key(symbol: str, tf: str) -> str:
    return f"{symbol}|{tf}"

# Capture the *previous* fetch_ohlcv (from market_http / earlier layers) BEFORE we redefine it.
# Critical: never call the current globals()["fetch_ohlcv"] from inside the cache helper —
# that caused infinite recursion when the wrapper fell through to _v79_cached_ohlcv.
_PREV_FETCH_OHLCV = globals().get("fetch_ohlcv")
_PREV_FETCH_KLINES = globals().get("fetch_klines")

def _v79_cached_ohlcv(symbol: str, tf: str, limit: int = 200):
    """Local soft-cache around the *previous* OHLCV loader (never self)."""
    key = _v79_ohlcv_key(symbol, tf)
    now = time.time()
    with _V79_OHLCV_LOCK:
        row = _V79_OHLCV_MEM.get(key)
        if row and (now - row["ts"]) < _V79_OHLCV_TTL and row.get("limit", 0) >= limit:
            return row["df"]
    df = None
    try:
        if callable(_PREV_FETCH_OHLCV):
            df = _PREV_FETCH_OHLCV(symbol, tf, limit=limit)
        elif callable(_PREV_FETCH_KLINES):
            df = _PREV_FETCH_KLINES(symbol, tf, limit)
    except Exception:
        df = None
    if df is not None:
        with _V79_OHLCV_LOCK:
            _V79_OHLCV_MEM[key] = {"ts": now, "df": df, "limit": limit}
            if len(_V79_OHLCV_MEM) > 128:
                oldest = sorted(_V79_OHLCV_MEM.items(), key=lambda kv: kv[1]["ts"])[:40]
                for k, _ in oldest:
                    _V79_OHLCV_MEM.pop(k, None)
    return df

def fetch_ohlcv(symbol: str, timeframe: str = "1h", limit: int = 200, **kwargs):
    """Soft-cached OHLCV. Always delegates to the pre-V79.6 loader — never recurses."""
    key = _v79_ohlcv_key(symbol, timeframe)
    now = time.time()
    with _V79_OHLCV_LOCK:
        row = _V79_OHLCV_MEM.get(key)
        if row and (now - row["ts"]) < _V79_OHLCV_TTL and row.get("limit", 0) >= limit:
            return row["df"]
    df = None
    try:
        if callable(_PREV_FETCH_OHLCV):
            df = _PREV_FETCH_OHLCV(symbol, timeframe, limit=limit, **kwargs)
        elif callable(_PREV_FETCH_KLINES):
            df = _PREV_FETCH_KLINES(symbol, timeframe, limit)
    except Exception:
        df = None
    if df is not None:
        with _V79_OHLCV_LOCK:
            _V79_OHLCV_MEM[key] = {"ts": now, "df": df, "limit": limit}
            if len(_V79_OHLCV_MEM) > 128:
                oldest = sorted(_V79_OHLCV_MEM.items(), key=lambda kv: kv[1]["ts"])[:40]
                for k, _ in oldest:
                    _V79_OHLCV_MEM.pop(k, None)
    return df

def _v79_pillar1_attach(item: dict) -> dict:
    """Forecast is informational; never silently becomes the decision."""
    if not isinstance(item, dict):
        return item
    try:
        flags = _v79_ensure_status_flags(item)
        fc = item.get("candle_forecast") or item.get("v78_forecast") or item.get("forecast")
        if isinstance(fc, dict):
            item["forecast_role"] = "scenario_only"
            item["forecast_is_decision"] = False
            if not fc.get("candles"):
                flags["forecast"] = "EMPTY"
            else:
                flags["forecast"] = "OK"
                flags["cone"] = "OK" if fc.get("cone") else "NO_CONE"
        else:
            flags["forecast"] = "NO_DATA"
        # data freshness
        dq = item.get("data_quality") if isinstance(item.get("data_quality"), dict) else {}
        age = safe_float(item.get("live_price_age_sec"), safe_float(dq.get("live_age_sec"), -1))
        if age < 0:
            flags["price"] = "UNKNOWN_AGE"
        elif age > 120:
            flags["price"] = "STALE"
        else:
            flags["price"] = "LIVE"
        item["data_updated_at"] = time.time()
    except Exception as _e:
        try:
            flags = _v79_ensure_status_flags(item)
            flags["pillar1"] = "ERROR"
            flags["pillar1_msg"] = str(_e)[:120]
            if callable(globals().get("_record_engine_error")):
                _record_engine_error("forecast", str(_e)[:160], symbol=str(item.get("symbol") or ""))
        except Exception:
            _swallow("forecast:pillar1")
    return item


# =============================================================================
# PILLAR 2 — Single decision authority + hard veto + WATCH vs WAIT
# =============================================================================

# ---------------------------------------------------------------------------
# Contract helpers — status_flags + fail-closed decision authority
# ---------------------------------------------------------------------------

_VALID_FLAG_KEYS = frozenset({
    "price", "forecast", "cone", "ai", "neural", "fate", "decision",
    "pillar1", "pillar1_msg", "data", "engine",
})

def _v79_ensure_status_flags(item: dict) -> dict:
    """Guarantee item['status_flags'] is always a plain dict[str, str-ish].

    Invalid structures (list, str, None, nested non-dict) are replaced so
    downstream quality checks never raise AttributeError / TypeError.
    """
    if not isinstance(item, dict):
        return {}
    flags = item.get("status_flags")
    if not isinstance(flags, dict):
        flags = {}
        item["status_flags"] = flags
    # coerce non-scalar values to short strings to keep consumers safe
    dirty = False
    clean: dict = {}
    for k, v in list(flags.items()):
        ks = str(k)[:48]
        if isinstance(v, (str, int, float, bool)) or v is None:
            clean[ks] = v
        else:
            clean[ks] = str(v)[:80]
            dirty = True
    if dirty or flags is not clean:
        item["status_flags"] = clean
        flags = clean
    return flags


def _v79_force_unvalidated_wait(item: dict, reason: str) -> dict:
    """Fail-closed: never leave a directional decision after an authority error."""
    if not isinstance(item, dict):
        return item
    item["decision"] = "WAIT"
    item["decision_tag"] = "WAIT"
    item["final_decision"] = "WAIT"
    item["authoritative_decision"] = "WAIT"
    item["trade_allowed"] = False
    item["watch_only"] = False
    item["sizing_blocked"] = True
    item["decision_vetoed"] = True
    item["veto_reason"] = reason
    item["decision_validated"] = False
    item["decision_authority"] = {
        "source": "V79.6-SIX-PILLARS",
        "trust_status": "ERROR",
        "data_ok": False,
        "blocked": True,
        "trade_allowed": False,
        "validated": False,
        "error": str(reason)[:160],
    }
    flags = _v79_ensure_status_flags(item)
    flags["decision"] = "UNVALIDATED"
    flags["engine"] = "AUTHORITY_ERROR"
    try:
        if callable(globals().get("_record_engine_error")):
            _record_engine_error("decision", reason, symbol=str(item.get("symbol") or ""))
    except Exception:
        pass
    return item


def _v79_trust_status(item: dict) -> str:
    try:
        ts = item.get("trust_status")
        if ts:
            return str(ts).upper()
        tr = item.get("trust")
        if isinstance(tr, dict):
            return str(tr.get("status") or tr.get("state") or "").upper()
        v52 = item.get("v52") or item.get("v52_gate") or {}
        if isinstance(v52, dict) and v52.get("status"):
            return str(v52.get("status")).upper()
    except Exception:
        if callable(globals().get("_swallow")):
            _swallow("trust_status")
    return ""


def _v79_data_ok(item: dict) -> tuple[bool, str]:
    """Safe data-quality gate. Never raises on bad status_flags shape."""
    try:
        dq = item.get("data_quality") if isinstance(item.get("data_quality"), dict) else {}
        score = safe_float(dq.get("score"), safe_float(item.get("data_quality_score"), 70))
        if dq.get("veto") or item.get("data_veto"):
            return False, "data_veto"
        if score < 40:
            return False, "data_quality_low"
        flags = _v79_ensure_status_flags(item)
        if flags.get("price") == "STALE":
            return False, "price_stale"
        if flags.get("engine") == "AUTHORITY_ERROR":
            return False, "authority_error"
        return True, "ok"
    except Exception as exc:
        if callable(globals().get("_record_engine_error")):
            try:
                _record_engine_error("data", str(exc)[:160])
            except Exception:
                pass
        return False, "data_check_error"


def _v79_authoritative_decision(item: dict) -> dict:
    """One source of truth after all layers. Fail-closed on any error."""
    if not isinstance(item, dict):
        return item
    try:
        _v79_ensure_status_flags(item)
        raw = str(
            item.get("decision_tag")
            or item.get("final_decision")
            or item.get("decision")
            or "WAIT"
        ).upper()
        if raw not in {"LONG", "SHORT", "WAIT", "WATCH"}:
            raw = "WAIT"

        trust = _v79_trust_status(item)
        data_ok, data_reason = _v79_data_ok(item)
        blocked = trust in {"BLOCKED", "REJECT", "HALT", "KILL"} or not data_ok

        reasons = list(item.get("decision_reasons") or [])
        if not isinstance(reasons, list):
            reasons = [str(reasons)]

        # Hard veto: directional decisions collapse to WAIT
        if blocked and raw in {"LONG", "SHORT", "WATCH"}:
            reasons.append(f"veto:{trust or data_reason}")
            raw = "WAIT"
            item["decision_vetoed"] = True
            item["veto_reason"] = trust or data_reason
        else:
            item["decision_vetoed"] = False

        # Normalize WATCH: ready-but-not-fired (never size as trade)
        if raw == "WATCH":
            item["trade_allowed"] = False
            item["watch_only"] = True
        elif raw in {"LONG", "SHORT"} and not blocked:
            item["trade_allowed"] = True
            item["watch_only"] = False
        else:
            item["trade_allowed"] = False
            item["watch_only"] = False

        # Single authority fields
        item["decision"] = raw
        item["decision_tag"] = raw
        item["final_decision"] = raw
        item["authoritative_decision"] = raw
        item["decision_validated"] = True
        item["decision_authority"] = {
            "source": "V79.6-SIX-PILLARS",
            "trust_status": trust or "UNSET",
            "data_ok": data_ok,
            "blocked": blocked,
            "trade_allowed": bool(item.get("trade_allowed")),
            "validated": True,
        }
        item["decision_reasons"] = reasons[-12:]

        if not item.get("trade_allowed"):
            item["sizing_blocked"] = True
        else:
            item["sizing_blocked"] = False

        # Bias text sync
        if raw == "LONG":
            item["bias"] = item.get("bias") if item.get("bias") in {"صعودی", "قوی صعودی"} else "صعودی"
        elif raw == "SHORT":
            item["bias"] = item.get("bias") if item.get("bias") in {"نزولی", "قوی نزولی"} else "نزولی"
        elif raw == "WATCH":
            item["bias"] = "نظارت"
        else:
            if item.get("bias") not in {"صعودی", "نزولی", "خنثی", "نظارت"}:
                item["bias"] = "خنثی"

        flags = _v79_ensure_status_flags(item)
        if blocked:
            flags["decision"] = "BLOCKED"
        elif raw == "WATCH":
            flags["decision"] = "WATCH"
        elif raw in {"LONG", "SHORT"}:
            flags["decision"] = "OK"
        else:
            flags["decision"] = "WAIT"
    except Exception as exc:
        if callable(globals().get("_swallow")):
            _swallow("authoritative_decision")
        return _v79_force_unvalidated_wait(item, f"authority_exception:{type(exc).__name__}:{exc}")
    return item


# =============================================================================
# PILLAR 3 — Closed-loop learning already in V79.5; ensure cycle + record
# =============================================================================

def _v79_pillar3_on_item(item: dict) -> dict:
    try:
        if callable(globals().get("_v78_record_decision")):
            # only record authoritative directional or explicit WAIT for fate tracking
            d = str(item.get("authoritative_decision") or item.get("decision_tag") or "")
            if d in {"LONG", "SHORT", "WAIT", "WATCH"}:
                _v78_record_decision(item)
        item.setdefault("status_flags", {})
        item["status_flags"]["fate"] = "RECORDED"
    except Exception:
        item.setdefault("status_flags", {})["fate"] = "RECORD_FAIL"
    return item


# =============================================================================
# PILLAR 4 — Model honesty + dynamic ensemble weights
# =============================================================================

_V79_ENSEMBLE_WEIGHTS = {
    "quant": 0.40,
    "neural": 0.30,
    "ai": 0.15,
    "forecast": 0.15,
}
_V79_ENSEMBLE_LOCK = threading.RLock()

def _v79_refresh_ensemble_weights() -> dict:
    """Blend default weights with recent layer outcomes from v78 fate / error log."""
    weights = dict(_V79_ENSEMBLE_WEIGHTS)
    try:
        _v78_init()
        with DB_LOCK, db_conn() as con:
            rows = con.execute(
                """SELECT root_cause, outcome FROM v78_decision_fate
                   WHERE outcome IN ('WIN','LOSS','WIN_TIMEOUT','LOSS_TIMEOUT')
                   ORDER BY evaluated_at DESC LIMIT 80"""
            ).fetchall()
        if len(rows) < 12:
            return weights
        # If neural_weak / ai_weak appear often on losses, reduce those weights
        loss_n = 0
        neural_bad = ai_bad = quant_ok = 0
        for r in rows:
            oc = str(r["outcome"] if not isinstance(r, (list, tuple)) else r[1])
            root = str(r["root_cause"] if not isinstance(r, (list, tuple)) else r[0] or "")
            if oc.startswith("LOSS"):
                loss_n += 1
                if "neural_weak" in root:
                    neural_bad += 1
                if "ai_weak" in root:
                    ai_bad += 1
                if "confidence_low" in root or "edge_thin" in root:
                    quant_ok += 1  # quant side was weak too — keep balanced
        if loss_n >= 8:
            if neural_bad / loss_n > 0.35:
                weights["neural"] = max(0.12, weights["neural"] - 0.08)
                weights["quant"] = min(0.55, weights["quant"] + 0.05)
            if ai_bad / loss_n > 0.35:
                weights["ai"] = max(0.05, weights["ai"] - 0.07)
                weights["quant"] = min(0.55, weights["quant"] + 0.04)
        # renormalize
        s = sum(weights.values()) or 1.0
        weights = {k: round(v / s, 3) for k, v in weights.items()}
        with _V79_ENSEMBLE_LOCK:
            _V79_ENSEMBLE_WEIGHTS.clear()
            _V79_ENSEMBLE_WEIGHTS.update(weights)
    except Exception:
        _swallow()
    return weights

def _v79_pillar4_models(item: dict) -> dict:
    try:
        weights = dict(_V79_ENSEMBLE_WEIGHTS)
        # AI honesty: no fabricated score
        ai = item.get("ai_opinions") or item.get("ai") or {}
        has_ai = False
        if isinstance(ai, dict):
            providers = ai.get("providers") or []
            score = ai.get("score", item.get("ai_score", None))
            if providers or (score is not None and score == score):
                has_ai = True
            else:
                # explicit no-vote
                ai = dict(ai)
                ai["vote_status"] = "NO_AI"
                ai["score"] = None
                item["ai_opinions"] = ai
                item.setdefault("status_flags", {})["ai"] = "NO_AI"
                weights["ai"] = 0.0
        if has_ai:
            item.setdefault("status_flags", {})["ai"] = "OK"
        # Neural abstain flag
        neural = item.get("neural_v9") or item.get("neural") or {}
        if isinstance(neural, dict):
            n_side = str(neural.get("side") or neural.get("decision") or "").upper()
            n_conf = safe_float(neural.get("confidence") or neural.get("neural_score"), float("nan"))
            if not n_side or n_side == "WAIT" or (n_conf == n_conf and n_conf < 45):
                neural = dict(neural)
                neural["abstain"] = True
                item["neural_v9"] = neural
                item.setdefault("status_flags", {})["neural"] = "ABSTAIN"
            else:
                item.setdefault("status_flags", {})["neural"] = "OK"
        else:
            item.setdefault("status_flags", {})["neural"] = "NO_DATA"
            weights["neural"] = max(0.0, weights.get("neural", 0) * 0.5)

        # renormalize after zeros
        s = sum(weights.values()) or 1.0
        weights = {k: round(v / s, 3) for k, v in weights.items()}
        item["ensemble_weights"] = weights
        item["ensemble_version"] = V79_6_VERSION
    except Exception:
        _swallow()
    return item


# =============================================================================
# PILLAR 5 — Scan prioritization + architecture hygiene
# =============================================================================

_CORE_PRIORITY = [
    "BTC/USDT", "ETH/USDT", "BNB/USDT", "SOL/USDT", "XRP/USDT",
    "DOGE/USDT", "ADA/USDT", "AVAX/USDT", "LINK/USDT", "DOT/USDT",
]

def _v79_prioritized_symbols(symbols=None):
    """Core majors first, then the rest — keeps scan useful under load."""
    src = list(symbols or USER_SETTINGS.get("active_coins") or DEFAULT_COINS)
    seen = set()
    ordered = []
    for s in _CORE_PRIORITY:
        if s in src and s not in seen:
            ordered.append(s)
            seen.add(s)
    for s in src:
        if s not in seen:
            ordered.append(s)
            seen.add(s)
    return ordered

# Wrap update_cache / background refresh order when possible
_PREV_UPDATE_CACHE = globals().get("update_cache")

def _v79_priority_update_cache(force: bool = False, *a, **kw):
    """If update_cache respects USER_SETTINGS active_coins order, reorder first."""
    try:
        if isinstance(USER_SETTINGS, dict):
            coins = USER_SETTINGS.get("active_coins")
            if isinstance(coins, list) and coins:
                USER_SETTINGS["active_coins"] = _v79_prioritized_symbols(coins)
    except Exception:
        pass
    if callable(_PREV_UPDATE_CACHE):
        return _PREV_UPDATE_CACHE(force, *a, **kw) if force is not None else _PREV_UPDATE_CACHE(*a, **kw)
    return None

try:
    if callable(_PREV_UPDATE_CACHE):
        update_cache = _v79_priority_update_cache  # noqa: F841
except Exception:
    pass


# =============================================================================
# PILLAR 6 — Product trust surfaces (status flags + weekly digest API)
# =============================================================================

def _v79_finalize_trust_surface(item: dict) -> dict:
    try:
        flags = dict(item.get("status_flags") or {})
        # decision state
        auth = str(item.get("authoritative_decision") or "WAIT")
        if item.get("decision_vetoed"):
            flags["decision"] = "BLOCKED"
        elif auth == "WATCH":
            flags["decision"] = "WATCH"
        elif auth in {"LONG", "SHORT"}:
            flags["decision"] = "ACTIVE"
        else:
            flags["decision"] = "WAIT"
        # required keys for UI honesty
        for k in ("price", "forecast", "ai", "neural", "fate", "decision"):
            flags.setdefault(k, "UNKNOWN")
        item["status_flags"] = flags
        item["ui_trust"] = {
            "version": V79_6_VERSION,
            "updated_at": item.get("data_updated_at") or time.time(),
            "flags": flags,
            "trade_allowed": bool(item.get("trade_allowed")),
            "authoritative_decision": auth,
            "disclaimer": "تحلیل آماری است؛ تضمین سود نیست",
        }
    except Exception:
        _swallow()
    return item

def _v79_weekly_digest() -> dict:
    out = {
        "ok": True,
        "version": V79_6_VERSION,
        "period_hours": 168,
        "signals": {"LONG": 0, "SHORT": 0, "WAIT": 0, "WATCH": 0},
        "outcomes": {},
        "win_rate": None,
        "expectancy": None,
        "cone_coverage": None,
        "ensemble_weights": dict(_V79_ENSEMBLE_WEIGHTS),
        "learning": {},
        "notes": [],
    }
    try:
        since = time.time() - 168 * 3600
        _v78_init()
        with DB_LOCK, db_conn() as con:
            rows = con.execute(
                """SELECT decision, outcome, return_pct FROM v78_decision_fate
                   WHERE created_at>?""",
                (since,),
            ).fetchall()
        wins = losses = 0
        rets = []
        for r in rows:
            d = str(r["decision"] if not isinstance(r, (list, tuple)) else r[0] or "").upper()
            o = str(r["outcome"] if not isinstance(r, (list, tuple)) else r[1] or "")
            if d in out["signals"]:
                out["signals"][d] += 1
            out["outcomes"][o] = out["outcomes"].get(o, 0) + 1
            if o.startswith("WIN"):
                wins += 1
            if o.startswith("LOSS") or o == "MISSED_MOVE":
                losses += 1
            try:
                rp = r["return_pct"] if not isinstance(r, (list, tuple)) else r[2]
                if rp is not None:
                    rets.append(float(rp))
            except Exception:
                pass
        dec = wins + losses
        if dec:
            out["win_rate"] = round(wins / dec * 100, 1)
        if rets:
            out["expectancy"] = round(sum(rets) / len(rets), 3)
        # cone
        try:
            if callable(globals().get("_v79_cone_calibration_report")):
                cr = _v79_cone_calibration_report(limit=200)
                out["cone_coverage"] = cr.get("coverage")
                out["cone_verdict"] = cr.get("verdict")
        except Exception:
            pass
        try:
            if callable(globals().get("_v79_learning_status")):
                ls = _v79_learning_status()
                out["learning"] = {
                    "decisive_n": ls.get("decisive_n"),
                    "pending_fate": ls.get("pending_fate"),
                    "learning_ready": ls.get("learning_ready"),
                    "params": ls.get("params"),
                }
        except Exception:
            pass
        if dec < 8:
            out["notes"].append("نمونهٔ هفتگی هنوز کم است")
        out["notes"].append("این گزارش تضمین عملکرد آینده نیست")
    except Exception as exc:
        out["ok"] = False
        out["error"] = str(exc)[:200]
    return out


# =============================================================================
# UNIFIED analyze_asset WRAPPER (runs after V78.1 / V79.5)
# =============================================================================

_PREV_ANALYZE_V79_6 = globals().get("analyze_asset")

def analyze_asset(*args, **kwargs):
    item = None
    try:
        item = _PREV_ANALYZE_V79_6(*args, **kwargs) if callable(_PREV_ANALYZE_V79_6) else {}
    except Exception as exc:
        _swallow("signal:analyze_prev")
        try:
            _record_engine_error("signal", f"prev_analyze:{exc}", symbol=str(args[0] if args else ""))
        except Exception:
            pass
        item = item if isinstance(item, dict) else {}
    if not isinstance(item, dict):
        # Fail-closed skeleton — never a naked LONG/SHORT without validation
        return _v79_force_unvalidated_wait(
            {"symbol": str(args[0] if args else ""), "decision": "WAIT"},
            "non_dict_analyze_result",
        )
    _v79_ensure_status_flags(item)
    # Apply pillars independently so one failure does not skip the rest
    for _fn in (
        _v79_pillar1_attach,
        _v79_pillar4_models,
        _v79_authoritative_decision,
        _v79_pillar3_on_item,
        _v79_finalize_trust_surface,
    ):
        try:
            item = _fn(item) or item
        except Exception as exc:
            _swallow(f"decision:{_fn.__name__}")
            try:
                flags = _v79_ensure_status_flags(item)
                flags[_fn.__name__] = "ERROR"
                _record_engine_error("decision", f"{_fn.__name__}:{exc}", symbol=str(item.get("symbol") or ""))
            except Exception:
                pass
            # Authority stage failure → force unvalidated WAIT
            if _fn is _v79_authoritative_decision:
                item = _v79_force_unvalidated_wait(item, f"pillar_crash:{_fn.__name__}")
    try:
        item["v79_6_version"] = V79_6_VERSION
        # Final safety: directional without validated flag is forced WAIT
        if item.get("authoritative_decision") in {"LONG", "SHORT"} and item.get("decision_validated") is not True:
            item = _v79_force_unvalidated_wait(item, "missing_validation_flag")
    except Exception:
        _swallow("decision:post_check")
        item = _v79_force_unvalidated_wait(item if isinstance(item, dict) else {}, "post_check_error")
    return item

# Also wrap dashboard finalize if present
_PREV_FINALIZE_V79_6 = globals().get("_dashboard_finalize_item")

def _dashboard_finalize_item(item, *a, **kw):
    try:
        if callable(_PREV_FINALIZE_V79_6):
            item = _PREV_FINALIZE_V79_6(item, *a, **kw)
    except Exception:
        _swallow("dashboard:finalize_prev")
    if isinstance(item, dict):
        try:
            _v79_ensure_status_flags(item)
            item = _v79_authoritative_decision(item)
            item = _v79_finalize_trust_surface(item)
            if item.get("authoritative_decision") in {"LONG", "SHORT"} and item.get("decision_validated") is not True:
                item = _v79_force_unvalidated_wait(item, "finalize_unvalidated")
        except Exception as exc:
            _swallow("dashboard:finalize")
            try:
                _record_engine_error("dashboard", str(exc)[:160])
            except Exception:
                pass
            item = _v79_force_unvalidated_wait(item, "finalize_exception")
    return item


# =============================================================================
# HTTP APIs for pillars
# =============================================================================

@app.get("/api/v79/pillars")
def api_v79_pillars():
    return jsonify({
        "ok": True,
        "version": V79_6_VERSION,
        "pillars": {
            "1_data_forecast": {
                "ohlcv_cache_entries": len(_V79_OHLCV_MEM),
                "forecast_role": "scenario_only",
                "cone_api": "/api/v79/cone-calibration",
            },
            "2_decision_authority": {
                "states": ["LONG", "SHORT", "WAIT", "WATCH"],
                "hard_veto": ["BLOCKED", "REJECT", "HALT", "KILL", "data_veto", "stale_price"],
            },
            "3_learning_loop": {
                "status_api": "/api/v79/learning",
                "cycle_api": "/api/v79/learning/cycle",
            },
            "4_models_ensemble": {
                "weights": dict(_V79_ENSEMBLE_WEIGHTS),
                "refresh": "auto_on_weekly_and_cycle",
            },
            "5_performance": {
                "symbol_priority": _CORE_PRIORITY,
                "heavy_jobs": "/api/v79/jobs",
            },
            "6_trust_surface": {
                "weekly_digest": "/api/v79/weekly-digest",
                "flags": ["NO_DATA", "NO_AI", "ABSTAIN", "BLOCKED", "WATCH", "STALE", "OK"],
            },
        },
    })

@app.get("/api/v79/engine-errors")
def api_v79_engine_errors():
    """Categorized recent engine errors: data|signal|storage|forecast|dashboard|decision|network|ai."""
    snap = {}
    try:
        if callable(globals().get("_engine_error_snapshot")):
            snap = _engine_error_snapshot()
    except Exception:
        _swallow("dashboard:engine_errors")
    return jsonify({"ok": True, "version": V79_6_VERSION, "errors": snap})


@app.get("/api/v79/weekly-digest")
def api_v79_weekly_digest():
    return jsonify(_v79_weekly_digest())

@app.get("/api/v79/ensemble")
def api_v79_ensemble():
    w = _v79_refresh_ensemble_weights()
    return jsonify({"ok": True, "weights": w, "version": V79_6_VERSION})

@app.get("/api/v79/scan-priority")
def api_v79_scan_priority():
    coins = []
    try:
        coins = list(USER_SETTINGS.get("active_coins") or DEFAULT_COINS)
    except Exception:
        coins = list(_CORE_PRIORITY)
    return jsonify({
        "ok": True,
        "priority_order": _v79_prioritized_symbols(coins),
        "core": _CORE_PRIORITY,
    })


# Refresh ensemble occasionally on learning cycle
_PREV_LEARNING_CYCLE = globals().get("api_v79_learning_cycle")

def _v79_6_on_cycle():
    try:
        _v79_refresh_ensemble_weights()
    except Exception:
        pass
    try:
        if callable(globals().get("_v79_background_tick")):
            _v79_background_tick()
    except Exception:
        pass

# Hook supervisor
_PREV_SUP_V79_6 = globals().get("_scan_supervisor_tick")
if callable(_PREV_SUP_V79_6):
    def _scan_supervisor_tick(*a, **k):
        try:
            _v79_6_on_cycle()
        except Exception:
            pass
        return _PREV_SUP_V79_6(*a, **k)

try:
    LOGGER.info("[%s] six pillars active", V79_6_VERSION)
except Exception:
    pass
