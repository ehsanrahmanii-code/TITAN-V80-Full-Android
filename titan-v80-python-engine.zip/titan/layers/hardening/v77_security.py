# [TITAN V77 layer] hardening/v77_security - access control for the local dashboard.
# NEW code (not part of V76). Analysis only; adds no trading capability.
#
# Policy
#   * TITAN_HOST defaults to 127.0.0.1 (set in web/flask_app). 
#   * /download/*  : needs the token, or - when no token is configured - a loopback client.
#   * /api/*       : open by default (local use); if TITAN_API_TOKEN (or secrets/api_token.txt)
#                    is set, every /api/* call needs it (header X-Titan-Token, Bearer,
#                    ?token=, or the titan_token cookie that a valid ?token= sets).
import hmac as _v77_hmac


def _v77_load_token() -> str:
    tok = str(os.environ.get("TITAN_API_TOKEN", "") or "").strip()
    if tok:
        return tok
    try:
        fp = SECRETS_DIR / "api_token.txt"
        if fp.exists():
            return fp.read_text(encoding="utf-8").strip()
    except Exception:
        _swallow()
    return ""


V77_API_TOKEN = _v77_load_token()
_V77_LOOPBACK = {"127.0.0.1", "::1", "::ffff:127.0.0.1"}


def _v77_request_token() -> str:
    try:
        h = request.headers.get("X-Titan-Token", "")
        if h:
            return h
        auth = request.headers.get("Authorization", "")
        if auth.lower().startswith("bearer "):
            return auth[7:].strip()
        q = request.args.get("token", "")
        if q:
            return q
        return request.cookies.get("titan_token", "") or ""
    except Exception:
        _swallow()
        return ""


def _v77_token_ok(supplied: str) -> bool:
    if not V77_API_TOKEN:
        return False
    try:
        return _v77_hmac.compare_digest(str(supplied).encode("utf-8"), V77_API_TOKEN.encode("utf-8"))
    except Exception:
        _swallow()
        return False


def _v77_is_loopback() -> bool:
    try:
        return (request.remote_addr or "") in _V77_LOOPBACK
    except Exception:
        _swallow()
        return False


def v77_access_decision(path: str, supplied_token: str, loopback: bool) -> bool:
    """Pure function: may this request proceed?  (unit-testable without Flask)"""
    if path.startswith("/download/"):
        return _v77_token_ok(supplied_token) if V77_API_TOKEN else loopback
    if path.startswith("/api/") and V77_API_TOKEN:
        return _v77_token_ok(supplied_token)
    return True


@app.before_request
def _v77_guard():
    try:
        ok = v77_access_decision(request.path, _v77_request_token(), _v77_is_loopback())
    except Exception:
        _swallow()
        ok = False
    if not ok:
        return jsonify({"ok": False, "error": "forbidden", "hint": "token required"}), 403
    return None


@app.after_request
def _v77_cookie(resp):
    try:
        q = request.args.get("token", "")
        if q and _v77_token_ok(q):
            resp.set_cookie("titan_token", q, httponly=True, samesite="Lax", max_age=86400 * 30)
    except Exception:
        _swallow()
    return resp


_V77_ORIG_RUN_TITAN = run_titan


def run_titan(open_browser: bool = False) -> None:  # noqa: F811
    exposed = str(HOST) not in {"127.0.0.1", "localhost", "::1"}
    if exposed and not V77_API_TOKEN:
        LOGGER.warning(
            "TITAN is listening on %s without TITAN_API_TOKEN: /api/* is open to the network "
            "(only /download/* is protected). Set TITAN_API_TOKEN or use TITAN_HOST=127.0.0.1.", HOST,
        )
    return _V77_ORIG_RUN_TITAN(open_browser=open_browser)
