# [TITAN V77 layer] hardening/v77_diagnostics - layer map, trace API, V77 self-test.
V77_VERSION = "77.1"


@app.get("/api/v77/status")
def api_v77_status():
    return jsonify({
        "ok": True, "version": V77_VERSION, "analysis_only": True, "host": HOST, "port": PORT,
        "token_required_for_api": bool(V77_API_TOKEN), "layers": len(_TITAN_LAYER_LOG),
        "trace_installed": list(V77_TRACE_INSTALLED),
    })


@app.get("/api/v77/layers")
def api_v77_layers():
    """Which layer (re)bound each wrapped name, in order - makes V53/V55/V56/V62 chains explicit."""
    return jsonify({"ok": True, "bindings": _TITAN_LAYER_BINDINGS, "log": _TITAN_LAYER_LOG})


@app.get("/api/v77/trace")
def api_v77_trace():
    try:
        limit = int(request.args.get("limit", "100"))
    except (TypeError, ValueError):
        limit = 100
    return jsonify(v77_trace_snapshot(request.args.get("symbol") or None, limit))


def _v77_self_test() -> int:
    fails = []

    def chk(name, ok):
        print(("  + " if ok else "  - FAIL ") + name)
        if not ok:
            fails.append(name)

    # chain order: each wrapper layer appears after the layer it wraps
    chain = _TITAN_LAYER_BINDINGS.get("analyze_asset", [])
    want = ["desk/v53_decision_dna", "desk/v54_replay_telegram", "desk/v55_signal_desk", "desk/v56_unified_desk"]
    idx = [chain.index(w) if w in chain else -1 for w in want]
    chk("analyze_asset_chain_v53_v54_v55_v56_in_order", all(i >= 0 for i in idx) and idx == sorted(idx))
    uc = _TITAN_LAYER_BINDINGS.get("update_cache", [])
    chk("update_cache_chain_v53_v55_v56_v56_2",
        [x for x in uc if x.startswith("desk/")] == ["desk/v53_decision_dna", "desk/v55_signal_desk", "desk/v56_unified_desk", "desk/v56_2_governed_learning"])
    chk("v55_desk_snapshot_wrapped_by_v56", _TITAN_LAYER_BINDINGS.get("v55_desk_snapshot", [])[-2:] == ["desk/v55_signal_desk", "desk/v56_unified_desk"])
    chk("trace_installed", len(V77_TRACE_INSTALLED) >= 6)
    chk("host_default_not_wildcard", HOST != "0.0.0.0" or bool(os.environ.get("TITAN_HOST")))
    # access policy (pure function)
    tmp = V77_API_TOKEN
    globals()["V77_API_TOKEN"] = ""
    chk("download_denied_for_remote_without_token", not v77_access_decision("/download/titan.py", "", False))
    chk("download_allowed_for_loopback_without_token", v77_access_decision("/download/titan.py", "", True))
    chk("api_open_without_token", v77_access_decision("/api/v77/status", "", False))
    globals()["V77_API_TOKEN"] = "unit-test-token"
    chk("api_denied_with_wrong_token", not v77_access_decision("/api/v77/status", "x", True))
    chk("api_allowed_with_right_token", v77_access_decision("/api/v77/status", "unit-test-token", False))
    chk("download_denied_loopback_when_token_set", not v77_access_decision("/download/titan.py", "", True))
    globals()["V77_API_TOKEN"] = tmp
    # trace never changes results
    def _probe(item):
        out = dict(item); out["decision_tag"] = "WAIT"; return out
    w = _v77_trace_wrap("probe", _probe)
    r = w({"decision_tag": "LONG", "symbol": "TEST/USDT", "tf": "15m"})
    chk("trace_wrapper_transparent", r.get("decision_tag") == "WAIT")
    chk("trace_records_change", any(e["layer"] == "probe" for e in v77_trace_snapshot("TEST/USDT")["events"]))
    print("V77 self-test:", "PASS" if not fails else f"FAIL {fails}")
    return 1 if fails else 0
