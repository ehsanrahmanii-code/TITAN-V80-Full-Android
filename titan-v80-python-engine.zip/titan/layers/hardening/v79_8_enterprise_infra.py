# [TITAN V79.8] Enterprise infrastructure — PostgreSQL ledger, Redis queue, RBAC
"""Optional organizational infrastructure with safe fallbacks.

Environment:
  TITAN_DATABASE_URL   postgresql://user:pass@host:5432/titan  (optional)
  TITAN_REDIS_URL      redis://localhost:6379/0                 (optional)
  TITAN_API_TOKEN      single token (legacy, role=admin)
  TITAN_API_TOKENS     JSON: {"tok1":"admin","tok2":"analyst","tok3":"viewer"}
  TITAN_RBAC=1         enable role checks on sensitive routes (default on when multi-token set)

Fallbacks:
  - No Postgres → SQLite-only (existing behavior) + in-process ledger mirror table
  - No Redis → in-process job queue (V79.5)
  - No tokens → open local / loopback as before
"""
from __future__ import annotations

import json
import os
import threading
import time
from typing import Any, Optional

V79_8_VERSION = "TITAN-V79.8-ENTERPRISE-INFRA"
PIPELINE_VERSION = globals().get("PIPELINE_VERSION") or "79.8.0-infra"

# ---------------------------------------------------------------------------
# Roles
# ---------------------------------------------------------------------------

ROLE_RANK = {"viewer": 1, "analyst": 2, "admin": 3}
# Minimum role required per path prefix / exact
_RBAC_RULES: list[tuple[str, str]] = [
    # (path_prefix or exact, min_role)
    ("/api/v79/ops", "analyst"),
    ("/api/v79/engine-errors", "analyst"),
    ("/api/v79/pipeline", "viewer"),
    ("/api/v79/learning/cycle", "admin"),
    ("/api/v78/eval", "analyst"),
    ("/api/v72/backup", "admin"),
    ("/api/v72/sqlite", "admin"),
    ("/rescan", "analyst"),
    ("/api/v75/pro-policy", "admin"),
    ("/download/", "admin"),
]


def _v79_load_token_roles() -> dict[str, str]:
    """Map token → role. Supports TITAN_API_TOKENS JSON or legacy single token=admin."""
    out: dict[str, str] = {}
    raw = str(os.environ.get("TITAN_API_TOKENS", "") or "").strip()
    if raw:
        try:
            data = json.loads(raw)
            if isinstance(data, dict):
                for k, v in data.items():
                    tok = str(k).strip()
                    role = str(v).strip().lower()
                    if tok and role in ROLE_RANK:
                        out[tok] = role
        except Exception:
            try:
                _swallow("storage:token_roles_json")
            except Exception:
                pass
    # legacy single token
    single = str(os.environ.get("TITAN_API_TOKEN", "") or "").strip()
    if not single:
        try:
            single = str(globals().get("V77_API_TOKEN") or "").strip()
        except Exception:
            single = ""
    if single and single not in out:
        out[single] = "admin"
    # secrets file multi-line: token role
    try:
        secrets_dir = globals().get("SECRETS_DIR")
        if secrets_dir is not None:
            fp = secrets_dir / "api_tokens.json"
            if fp.is_file():
                data = json.loads(fp.read_text(encoding="utf-8"))
                if isinstance(data, dict):
                    for k, v in data.items():
                        tok = str(k).strip()
                        role = str(v).strip().lower()
                        if tok and role in ROLE_RANK:
                            out[tok] = role
    except Exception:
        pass
    return out


_TOKEN_ROLES = _v79_load_token_roles()
_RBAC_ENABLED = str(os.environ.get("TITAN_RBAC", "1" if len(_TOKEN_ROLES) > 1 else "0")).lower() in {
    "1", "true", "yes",
}


def _v79_request_role() -> str:
    """Resolve role for current request. Empty string = anonymous."""
    try:
        tok = ""
        if callable(globals().get("_v77_request_token")):
            tok = str(_v77_request_token() or "")
        else:
            tok = str(request.args.get("token") or request.headers.get("X-Titan-Token") or "")
        if not tok:
            return ""
        roles = _v79_load_token_roles()  # refresh env each call for ops flexibility
        return roles.get(tok, "")
    except Exception:
        return ""


def _v79_role_at_least(role: str, minimum: str) -> bool:
    return ROLE_RANK.get(str(role).lower(), 0) >= ROLE_RANK.get(str(minimum).lower(), 99)


def _v79_rbac_required(path: str) -> Optional[str]:
    """Return minimum role for path, or None if no extra RBAC rule."""
    for prefix, role in _RBAC_RULES:
        if path == prefix or path.startswith(prefix):
            return role
    return None


@app.before_request
def _v79_8_rbac_guard():
    if not _RBAC_ENABLED and not _TOKEN_ROLES:
        return None
    path = request.path or ""
    need = _v79_rbac_required(path)
    if not need:
        return None
    # If no tokens configured at all, keep legacy open/local behavior
    roles_map = _v79_load_token_roles()
    if not roles_map:
        return None
    role = _v79_request_role()
    if not role or not _v79_role_at_least(role, need):
        return jsonify({
            "ok": False,
            "error": "forbidden_role",
            "required_role": need,
            "your_role": role or "anonymous",
            "pipeline_version": PIPELINE_VERSION,
        }), 403
    return None


@app.get("/api/v79/whoami")
def api_v79_whoami():
    role = _v79_request_role()
    return jsonify({
        "ok": True,
        "role": role or "anonymous",
        "rbac_enabled": bool(_RBAC_ENABLED or _TOKEN_ROLES),
        "roles_configured": len(_v79_load_token_roles()),
        "pipeline_version": PIPELINE_VERSION,
    })


# ---------------------------------------------------------------------------
# PostgreSQL optional ledger (dual-write; SQLite remains primary for app tables)
# ---------------------------------------------------------------------------

_PG_LOCK = threading.RLock()
_PG_POOL = None  # simple single-connection cache
_PG_URL = str(os.environ.get("TITAN_DATABASE_URL") or os.environ.get("DATABASE_URL") or "").strip()
_PG_AVAILABLE = False
_PG_LAST_ERROR = ""


def _v79_pg_connect():
    """Return a psycopg2 connection or None."""
    global _PG_AVAILABLE, _PG_LAST_ERROR, _PG_POOL
    if not _PG_URL or not _PG_URL.startswith(("postgres://", "postgresql://")):
        _PG_AVAILABLE = False
        return None
    try:
        import psycopg2
        from psycopg2.extras import RealDictCursor
        with _PG_LOCK:
            if _PG_POOL is not None:
                try:
                    _PG_POOL.cursor().execute("SELECT 1")
                    return _PG_POOL
                except Exception:
                    try:
                        _PG_POOL.close()
                    except Exception:
                        pass
                    _PG_POOL = None
            conn = psycopg2.connect(_PG_URL, connect_timeout=5)
            conn.autocommit = True
            _PG_POOL = conn
            _PG_AVAILABLE = True
            _PG_LAST_ERROR = ""
            return conn
    except Exception as exc:
        _PG_AVAILABLE = False
        _PG_LAST_ERROR = str(exc)[:200]
        try:
            _record_engine_error("storage", f"postgres:{exc}")
        except Exception:
            pass
        return None


def _v79_pg_init_ledger() -> bool:
    con = _v79_pg_connect()
    if con is None:
        return False
    try:
        cur = con.cursor()
        cur.execute(
            """
            CREATE TABLE IF NOT EXISTS titan_decision_ledger (
                id BIGSERIAL PRIMARY KEY,
                created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
                symbol TEXT NOT NULL,
                decision TEXT NOT NULL,
                validated BOOLEAN NOT NULL DEFAULT FALSE,
                trade_allowed BOOLEAN NOT NULL DEFAULT FALSE,
                pipeline_version TEXT,
                status_flags JSONB,
                authority JSONB,
                payload JSONB,
                input_hash TEXT
            )
            """
        )
        cur.execute(
            "CREATE INDEX IF NOT EXISTS idx_ledger_symbol_ts ON titan_decision_ledger(symbol, created_at DESC)"
        )
        cur.close()
        return True
    except Exception as exc:
        try:
            _record_engine_error("storage", f"pg_init:{exc}")
        except Exception:
            pass
        return False


def _v79_sqlite_ensure_ledger() -> None:
    """Mirror ledger table in SQLite so enterprise features work offline."""
    try:
        with DB_LOCK, db_conn() as con:
            con.execute(
                """
                CREATE TABLE IF NOT EXISTS titan_decision_ledger (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    created_at REAL NOT NULL,
                    symbol TEXT NOT NULL,
                    decision TEXT NOT NULL,
                    validated INTEGER NOT NULL DEFAULT 0,
                    trade_allowed INTEGER NOT NULL DEFAULT 0,
                    pipeline_version TEXT,
                    status_flags TEXT,
                    authority TEXT,
                    payload TEXT,
                    input_hash TEXT
                )
                """
            )
            con.execute(
                "CREATE INDEX IF NOT EXISTS idx_sql_ledger_sym ON titan_decision_ledger(symbol, created_at DESC)"
            )
    except Exception:
        try:
            _swallow("storage:sqlite_ledger")
        except Exception:
            pass


def record_decision_ledger(item: dict) -> bool:
    """Append-only decision ledger (SQLite always; Postgres when configured)."""
    if not isinstance(item, dict):
        return False
    try:
        import hashlib
        sym = str(item.get("symbol") or "")
        dec = str(item.get("authoritative_decision") or item.get("decision") or "WAIT")
        validated = bool(item.get("decision_validated") is True)
        trade = bool(item.get("trade_allowed") is True)
        flags = item.get("status_flags") if isinstance(item.get("status_flags"), dict) else {}
        authority = item.get("decision_authority") if isinstance(item.get("decision_authority"), dict) else {}
        slim = {
            "score": item.get("score"),
            "bias": item.get("bias"),
            "veto_reason": item.get("veto_reason"),
            "pipeline_ms": item.get("pipeline_ms"),
        }
        payload = json.dumps(slim, ensure_ascii=False, default=str)
        flags_s = json.dumps(flags, ensure_ascii=False, default=str)
        auth_s = json.dumps(authority, ensure_ascii=False, default=str)
        ih = hashlib.sha256(
            f"{sym}|{dec}|{validated}|{item.get('pipeline_version')}|{flags_s}".encode()
        ).hexdigest()[:32]
        ts = time.time()
        # SQLite
        try:
            _v79_sqlite_ensure_ledger()
            with DB_LOCK, db_conn() as con:
                con.execute(
                    """INSERT INTO titan_decision_ledger
                       (created_at, symbol, decision, validated, trade_allowed,
                        pipeline_version, status_flags, authority, payload, input_hash)
                       VALUES (?,?,?,?,?,?,?,?,?,?)""",
                    (
                        ts, sym, dec, 1 if validated else 0, 1 if trade else 0,
                        str(item.get("pipeline_version") or PIPELINE_VERSION),
                        flags_s, auth_s, payload, ih,
                    ),
                )
        except Exception as exc:
            try:
                _record_engine_error("storage", f"sqlite_ledger:{exc}", symbol=sym)
            except Exception:
                pass
        # Postgres dual-write
        con = _v79_pg_connect()
        if con is not None:
            try:
                cur = con.cursor()
                cur.execute(
                    """INSERT INTO titan_decision_ledger
                       (symbol, decision, validated, trade_allowed,
                        pipeline_version, status_flags, authority, payload, input_hash)
                       VALUES (%s,%s,%s,%s,%s,%s::jsonb,%s::jsonb,%s::jsonb,%s)""",
                    (
                        sym, dec, validated, trade,
                        str(item.get("pipeline_version") or PIPELINE_VERSION),
                        flags_s, auth_s, payload, ih,
                    ),
                )
                cur.close()
            except Exception as exc:
                try:
                    _record_engine_error("storage", f"pg_ledger:{exc}", symbol=sym)
                except Exception:
                    pass
        return True
    except Exception:
        try:
            _swallow("storage:ledger")
        except Exception:
            pass
        return False


# Hook: after enterprise pipeline / finalize, write ledger
_PREV_RUN_PIPE_V79_8 = globals().get("run_enterprise_pipeline")
if callable(_PREV_RUN_PIPE_V79_8):
    def run_enterprise_pipeline(item, *, symbol: str = ""):  # noqa: F811
        out = _PREV_RUN_PIPE_V79_8(item, symbol=symbol)
        try:
            record_decision_ledger(out if isinstance(out, dict) else {})
        except Exception:
            pass
        return out


_PREV_ANALYZE_V79_8 = globals().get("analyze_asset")


def analyze_asset(*args, **kwargs):
    item = None
    try:
        item = _PREV_ANALYZE_V79_8(*args, **kwargs) if callable(_PREV_ANALYZE_V79_8) else {}
    except Exception:
        try:
            _swallow("signal:analyze_v79_8")
        except Exception:
            pass
        item = item if isinstance(item, dict) else {}
    if isinstance(item, dict):
        try:
            record_decision_ledger(item)
        except Exception:
            pass
    return item


# ---------------------------------------------------------------------------
# Redis optional job queue
# ---------------------------------------------------------------------------

_REDIS_URL = str(os.environ.get("TITAN_REDIS_URL") or os.environ.get("REDIS_URL") or "").strip()
_REDIS_CLIENT = None
_REDIS_AVAILABLE = False
_REDIS_LAST_ERROR = ""
_REDIS_PREFIX = str(os.environ.get("TITAN_REDIS_PREFIX") or "titan:").strip() or "titan:"


def _v79_redis():
    global _REDIS_CLIENT, _REDIS_AVAILABLE, _REDIS_LAST_ERROR
    if not _REDIS_URL:
        _REDIS_AVAILABLE = False
        return None
    try:
        import redis
        if _REDIS_CLIENT is not None:
            try:
                _REDIS_CLIENT.ping()
                return _REDIS_CLIENT
            except Exception:
                _REDIS_CLIENT = None
        client = redis.from_url(_REDIS_URL, socket_connect_timeout=2, socket_timeout=3, decode_responses=True)
        client.ping()
        _REDIS_CLIENT = client
        _REDIS_AVAILABLE = True
        _REDIS_LAST_ERROR = ""
        return client
    except Exception as exc:
        _REDIS_AVAILABLE = False
        _REDIS_LAST_ERROR = str(exc)[:200]
        try:
            _record_engine_error("network", f"redis:{exc}")
        except Exception:
            pass
        return None


def redis_enqueue(job_type: str, payload: dict, *, ttl: int = 3600) -> Optional[str]:
    """Enqueue a job in Redis. Returns job_id or None if Redis unavailable."""
    r = _v79_redis()
    if r is None:
        return None
    try:
        import uuid
        jid = str(uuid.uuid4())
        key = f"{_REDIS_PREFIX}job:{jid}"
        meta = {
            "id": jid,
            "type": job_type,
            "status": "queued",
            "created_at": time.time(),
            "payload": json.dumps(payload, ensure_ascii=False, default=str),
        }
        r.hset(key, mapping=meta)
        r.expire(key, int(ttl))
        r.lpush(f"{_REDIS_PREFIX}queue", jid)
        return jid
    except Exception as exc:
        try:
            _record_engine_error("network", f"redis_enqueue:{exc}")
        except Exception:
            pass
        return None


def redis_job_status(job_id: str) -> Optional[dict]:
    r = _v79_redis()
    if r is None:
        return None
    try:
        key = f"{_REDIS_PREFIX}job:{job_id}"
        data = r.hgetall(key)
        return data or None
    except Exception:
        return None


# Prefer Redis for heavy job ids when V79.5 queue is used — soft enhance
_PREV_V79_SUBMIT = globals().get("_v79_submit_job")


def _v79_submit_job_redis(job_type: str, fn, *args, **kwargs):
    """Try Redis enqueue metadata; still run local if previous submit exists."""
    payload = {"type": job_type, "args_len": len(args)}
    jid_r = redis_enqueue(job_type, payload)
    if callable(_PREV_V79_SUBMIT):
        jid = _PREV_V79_SUBMIT(job_type, fn, *args, **kwargs)
        return jid
    return jid_r


# ---------------------------------------------------------------------------
# Status API
# ---------------------------------------------------------------------------

@app.get("/api/v79/infra")
def api_v79_infra():
    pg_ok = False
    if _PG_URL:
        pg_ok = _v79_pg_connect() is not None
    redis_ok = _v79_redis() is not None if _REDIS_URL else False
    return jsonify({
        "ok": True,
        "version": V79_8_VERSION,
        "pipeline_version": PIPELINE_VERSION,
        "postgres": {
            "configured": bool(_PG_URL),
            "available": pg_ok,
            "last_error": _PG_LAST_ERROR or None,
        },
        "redis": {
            "configured": bool(_REDIS_URL),
            "available": redis_ok,
            "last_error": _REDIS_LAST_ERROR or None,
        },
        "rbac": {
            "enabled": bool(_RBAC_ENABLED or _TOKEN_ROLES),
            "tokens_configured": len(_v79_load_token_roles()),
            "roles": list(ROLE_RANK.keys()),
        },
        "fallbacks": {
            "storage": "sqlite" if not pg_ok else "sqlite+postgres",
            "queue": "in_process" if not redis_ok else "redis+in_process",
        },
    })


@app.get("/api/v79/ledger")
def api_v79_ledger():
    """Recent decision ledger rows (SQLite primary)."""
    role = _v79_request_role()
    if _TOKEN_ROLES and role and not _v79_role_at_least(role, "analyst"):
        return jsonify({"ok": False, "error": "forbidden_role", "required_role": "analyst"}), 403
    limit = 50
    try:
        limit = max(1, min(int(request.args.get("limit", 50)), 200))
    except Exception:
        limit = 50
    rows = []
    try:
        _v79_sqlite_ensure_ledger()
        with DB_LOCK, db_conn() as con:
            cur = con.execute(
                """SELECT id, created_at, symbol, decision, validated, trade_allowed,
                          pipeline_version, status_flags, authority, input_hash
                   FROM titan_decision_ledger ORDER BY id DESC LIMIT ?""",
                (limit,),
            )
            for r in cur.fetchall():
                rows.append({
                    "id": r["id"] if not isinstance(r, tuple) else r[0],
                    "created_at": r["created_at"] if not isinstance(r, tuple) else r[1],
                    "symbol": r["symbol"] if not isinstance(r, tuple) else r[2],
                    "decision": r["decision"] if not isinstance(r, tuple) else r[3],
                    "validated": bool(r["validated"] if not isinstance(r, tuple) else r[4]),
                    "trade_allowed": bool(r["trade_allowed"] if not isinstance(r, tuple) else r[5]),
                    "pipeline_version": r["pipeline_version"] if not isinstance(r, tuple) else r[6],
                    "input_hash": r["input_hash"] if not isinstance(r, tuple) else r[9],
                })
    except Exception as exc:
        try:
            _record_engine_error("storage", f"ledger_read:{exc}")
        except Exception:
            pass
        return jsonify({"ok": False, "error": str(exc)[:160], "pipeline_version": PIPELINE_VERSION}), 500
    return jsonify({
        "ok": True,
        "rows": rows,
        "count": len(rows),
        "pipeline_version": PIPELINE_VERSION,
        "postgres_mirror": bool(_PG_AVAILABLE),
    })


# Init on load
try:
    _v79_sqlite_ensure_ledger()
except Exception:
    pass
try:
    if _PG_URL:
        _v79_pg_init_ledger()
except Exception:
    pass
try:
    if _REDIS_URL:
        _v79_redis()
except Exception:
    pass


def _v79_8_self_test() -> int:
    print("  + sqlite_ledger_init")
    _v79_sqlite_ensure_ledger()
    sample = {
        "symbol": "TEST/USDT",
        "decision": "WAIT",
        "authoritative_decision": "WAIT",
        "decision_validated": True,
        "trade_allowed": False,
        "status_flags": {"price": "LIVE"},
        "decision_authority": {"blocked": False},
        "pipeline_version": PIPELINE_VERSION,
    }
    print("  + record_ledger")
    assert record_decision_ledger(sample) is True
    print("  + roles_map_loads")
    roles = _v79_load_token_roles()
    assert isinstance(roles, dict)
    print("  + role_rank")
    assert _v79_role_at_least("admin", "viewer") is True
    assert _v79_role_at_least("viewer", "admin") is False
    print("V79.8 Enterprise Infra self-test: PASS")
    return 0
