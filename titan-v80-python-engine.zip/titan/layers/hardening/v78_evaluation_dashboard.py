# [TITAN V78 layer] hardening/v78_evaluation_dashboard
# ============================================================
# TITAN V78 — REAL DECISION FATE EVALUATION + CONTINUOUS SELF-IMPROVEMENT
# Practical outcome analysis: every LONG/SHORT/WAIT is tracked, diagnosed,
# scored, and used to auto-correct thresholds / weights in a governed way.
# All modules (neural, AI, governors, forecast, opportunity) feed this layer.
# ============================================================
V78_EVAL_VERSION = "TITAN-V78-EVALUATION-DASHBOARD-1.0"

_V78_EVAL_READY = False
_V78_EVAL_LOCK = threading.RLock()
_V78_LAST_CYCLE = 0.0
_V78_CYCLE_SEC = 300  # 5 min governed cycle

def _v78_ensure_schema(con) -> None:
    con.execute("""
        CREATE TABLE IF NOT EXISTS v78_decision_fate(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at REAL NOT NULL,
            symbol TEXT NOT NULL,
            timeframe TEXT NOT NULL,
            decision TEXT NOT NULL,
            confidence REAL DEFAULT 0,
            edge REAL DEFAULT 0,
            price REAL NOT NULL,
            levels_json TEXT,
            evidence_json TEXT,
            forecast_json TEXT,
            neural_score REAL,
            ai_score REAL,
            consensus_score REAL,
            opportunity_score REAL,
            regime TEXT,
            outcome TEXT DEFAULT 'PENDING',
            return_pct REAL,
            mfe_pct REAL,
            mae_pct REAL,
            bars_to_outcome INTEGER,
            diagnosis TEXT DEFAULT '',
            root_cause TEXT DEFAULT '',
            correction_applied TEXT DEFAULT '',
            evaluated_at REAL,
            UNIQUE(symbol, timeframe, created_at)
        )
    """)
    con.execute("CREATE INDEX IF NOT EXISTS idx_v78_pending ON v78_decision_fate(outcome, created_at)")
    con.execute("CREATE INDEX IF NOT EXISTS idx_v78_perf ON v78_decision_fate(symbol, timeframe, outcome)")
    con.execute("""
        CREATE TABLE IF NOT EXISTS v78_learning_params(
            key TEXT PRIMARY KEY,
            value REAL NOT NULL,
            updated_at REAL NOT NULL,
            reason TEXT DEFAULT ''
        )
    """)
    con.execute("""
        CREATE TABLE IF NOT EXISTS v78_error_log(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at REAL NOT NULL,
            symbol TEXT,
            timeframe TEXT,
            decision TEXT,
            error_type TEXT,
            detail TEXT,
            suggested_fix TEXT,
            applied INTEGER DEFAULT 0
        )
    """)

def _v78_init() -> None:
    global _V78_EVAL_READY
    if _V78_EVAL_READY:
        return
    with DB_LOCK, db_conn() as con:
        _v78_ensure_schema(con)
        # seed adaptive params if missing
        defaults = {
            "min_edge_long": 0.14,
            "min_edge_short": 0.14,
            "min_confidence": 0.52,
            "min_consensus": 0.55,
            "wait_penalty": 0.08,
            "forecast_weight": 0.22,
            "neural_weight": 0.18,
            "ai_weight": 0.10,
            "opportunity_threshold": 0.62,
        }
        now = time.time()
        for k, v in defaults.items():
            con.execute(
                "INSERT OR IGNORE INTO v78_learning_params(key, value, updated_at, reason) VALUES (?,?,?,?)",
                (k, v, now, "seed")
            )
    _V78_EVAL_READY = True

def _v78_record_decision(item: dict) -> None:
    """Record every authoritative decision for later fate analysis."""
    try:
        _v78_init()
        symbol = str(item.get("symbol") or item.get("pair") or "").upper()
        tf = str(item.get("timeframe") or item.get("tf") or "1h")
        decision = str(item.get("decision") or item.get("final_decision") or "WAIT").upper()
        if decision not in {"LONG", "SHORT", "WAIT"}:
            decision = "WAIT"
        price = safe_float(item.get("price") or item.get("last") or item.get("close"), 0.0)
        if price <= 0 or not symbol:
            return
        # Canonical field map (real analysis output keys)
        conf = safe_float(
            item.get("decision_confidence"),
            safe_float(item.get("confidence"),
                       safe_float(item.get("final_confidence"),
                                  safe_float(item.get("signal_quality"), 0.0))),
        )
        if conf > 1.5:
            conf = conf / 100.0
        edge_obj = item.get("edge") if isinstance(item.get("edge"), dict) else {}
        edge = safe_float(
            item.get("edge_score"),
            safe_float(edge_obj.get("score") if edge_obj else None,
                       safe_float(item.get("edge") if not isinstance(item.get("edge"), dict) else None, 0.0)),
        )
        if edge > 1.5:
            edge = edge / 100.0
        levels = {}
        if isinstance(item.get("levels"), dict):
            levels.update(item.get("levels") or {})
        if isinstance(item.get("price_levels"), dict):
            levels.update(item.get("price_levels") or {})
        sl_raw = safe_float(item.get("stop_loss_raw"), safe_float(levels.get("sl") or levels.get("stop"), 0.0))
        tp1_raw = safe_float(item.get("tp1_raw"), safe_float(levels.get("tp1") or levels.get("target1"), 0.0))
        tp2_raw = safe_float(item.get("tp2_raw"), safe_float(levels.get("tp2") or levels.get("target2"), 0.0))
        if sl_raw > 0:
            levels["sl"] = sl_raw
            levels["stop"] = sl_raw
        if tp1_raw > 0:
            levels["tp1"] = tp1_raw
            levels["target1"] = tp1_raw
        if tp2_raw > 0:
            levels["tp2"] = tp2_raw
        evidence = item.get("evidence") or item.get("votes") or {}
        forecast = item.get("candle_forecast") or item.get("v78_forecast") or item.get("forecast") or {}
        neural_obj = item.get("neural_v9") or item.get("neural") or {}
        if not isinstance(neural_obj, dict):
            neural_obj = {}
        neural = safe_float(neural_obj.get("neural_score"), safe_float(neural_obj.get("score") or item.get("neural_score"), 0.0))
        if neural > 1.5:
            neural = neural / 100.0
        ai_obj = item.get("ai_opinions") or item.get("ai") or {}
        if not isinstance(ai_obj, dict):
            ai_obj = {}
        _ai_raw = ai_obj.get("score", item.get("ai_score", None))
        if _ai_raw is None:
            ai = None
        else:
            ai = safe_float(_ai_raw, float("nan"))
            if ai != ai:
                ai = None
            elif ai > 1.5:
                ai = ai / 100.0
        consensus = safe_float(item.get("consensus_score") or item.get("v30_score"), 0.0)
        if consensus > 1.5:
            consensus = consensus / 100.0
        _opp = item.get("opportunity_score")
        if _opp is None and isinstance(item.get("opportunity"), dict):
            _opp = (item.get("opportunity") or {}).get("score")
        opp = safe_float(_opp, 0.0)
        if opp > 1.5:
            opp = opp / 100.0
        regime = "unknown"
        try:
            r = item.get("regime") or item.get("market_regime")
            if r is None and edge_obj:
                r = edge_obj.get("regime")
            if isinstance(r, dict):
                regime = str(r.get("label") or r.get("name") or r.get("regime") or "unknown")
            elif r:
                regime = str(r)
        except Exception:
            regime = "unknown"
        now = time.time()
        with DB_LOCK, db_conn() as con:
            con.execute("""
                INSERT OR IGNORE INTO v78_decision_fate(
                    created_at, symbol, timeframe, decision, confidence, edge, price,
                    levels_json, evidence_json, forecast_json,
                    neural_score, ai_score, consensus_score, opportunity_score, regime
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """, (
                now, symbol, tf, decision, conf, edge, price,
                json.dumps(levels, ensure_ascii=False, default=str)[:4000],
                json.dumps(evidence, ensure_ascii=False, default=str)[:4000],
                json.dumps(forecast, ensure_ascii=False, default=str)[:4000],
                (neural if neural is not None else 0.0), (ai if ai is not None else None), consensus, opp, regime
            ))
    except Exception:
        _swallow()

def _v78_evaluate_pending(max_rows: int = 80) -> dict:
    """Evaluate PENDING decisions against current market data. Diagnose root causes."""
    _v78_init()
    results = {"evaluated": 0, "wins": 0, "losses": 0, "timeouts": 0, "diagnoses": []}
    try:
        with DB_LOCK, db_conn() as con:
            rows = con.execute("""
                SELECT id, created_at, symbol, timeframe, decision, confidence, edge, price,
                       levels_json, neural_score, ai_score, consensus_score, opportunity_score, regime
                FROM v78_decision_fate
                WHERE outcome = 'PENDING' AND created_at > ?
                ORDER BY created_at ASC LIMIT ?
            """, (time.time() - 14 * 86400, max_rows)).fetchall()
        for row in rows:
            rid, created, symbol, tf, decision, conf, edge, entry_price, levels_js, neural, ai, cons, opp, regime = row
            try:
                df = None
                try:
                    df = fetch_ohlcv(symbol, tf, limit=120)
                except Exception:
                    _swallow()
                if df is None or len(df) < 5:
                    continue
                # find bars after decision
                ages = time.time() - created
                # approximate bars by timeframe minutes
                tf_min = {"15m": 15, "1h": 60, "4h": 240, "1d": 1440}.get(tf, 60)
                bars_elapsed = int(ages / (tf_min * 60)) + 1
                closes = df["close"].astype(float).to_numpy()
                highs = df["high"].astype(float).to_numpy()
                lows = df["low"].astype(float).to_numpy()
                last = float(closes[-1])
                ret = (last - entry_price) / entry_price * 100.0
                if decision == "SHORT":
                    ret = -ret
                # MFE / MAE from high/low of post-entry bars (not close-only)
                nbar = min(len(closes), max(bars_elapsed, 3))
                w_hi = highs[-nbar:]
                w_lo = lows[-nbar:]
                w_cl = closes[-nbar:]
                if decision == "LONG":
                    mfe = (float(np.max(w_hi)) - entry_price) / entry_price * 100.0
                    mae = (float(np.min(w_lo)) - entry_price) / entry_price * 100.0
                else:
                    mfe = (entry_price - float(np.min(w_lo))) / entry_price * 100.0
                    mae = (entry_price - float(np.max(w_hi))) / entry_price * 100.0
                # Outcome rules
                levels = {}
                try:
                    levels = json.loads(levels_js or "{}")
                except Exception:
                    _swallow()
                sl = safe_float(levels.get("sl") or levels.get("stop"), 0.0)
                tp1 = safe_float(levels.get("tp1") or levels.get("target1"), 0.0)
                outcome = "PENDING"
                diagnosis = ""
                root = ""
                if decision == "WAIT":
                    # WAIT is "correct" if no strong move in either direction within horizon
                    if abs(ret) < 0.35 and bars_elapsed >= 4:
                        outcome = "CORRECT_WAIT"
                        diagnosis = "بازار خنثی بود؛ WAIT درست بود"
                    elif abs(ret) >= 1.2 and bars_elapsed >= 3:
                        outcome = "MISSED_MOVE"
                        diagnosis = f"حرکت قوی {ret:+.2f}% از دست رفت"
                        root = "threshold_too_high" if conf < 0.6 else "consensus_weak"
                    else:
                        continue  # still pending
                else:
                    # directional
                    # Intra-bar path: walk each candle open→high/low order.
                    # Conservative: if both SL and TP touched in same bar, count SL first
                    # (adverse fill assumption) unless open already beyond TP without SL.
                    hit_tp = False
                    hit_sl = False
                    for i in range(len(w_cl)):
                        o = float(w_cl[i]) if i == 0 else float(w_cl[i-1])  # proxy open≈prev close
                        hi = float(w_hi[i]); lo = float(w_lo[i]); cl = float(w_cl[i])
                        if decision == "LONG":
                            sl_hit = sl > 0 and lo <= sl
                            tp_hit = tp1 > 0 and hi >= tp1
                            if sl_hit and tp_hit:
                                # both in same bar → assume SL first unless open was already past TP
                                if o >= tp1 and o > sl:
                                    hit_tp = True
                                else:
                                    hit_sl = True
                                break
                            if sl_hit:
                                hit_sl = True; break
                            if tp_hit:
                                hit_tp = True; break
                        else:  # SHORT
                            sl_hit = sl > 0 and hi >= sl
                            tp_hit = tp1 > 0 and lo <= tp1
                            if sl_hit and tp_hit:
                                if o <= tp1 and (sl <= 0 or o < sl):
                                    hit_tp = True
                                else:
                                    hit_sl = True
                                break
                            if sl_hit:
                                hit_sl = True; break
                            if tp_hit:
                                hit_tp = True; break
                    if hit_sl and not hit_tp:
                        outcome = "LOSS"
                        diagnosis = "استاپ خورده"
                        root = _v78_diagnose_loss(conf, edge, neural, ai, cons, opp, regime, mae)
                    elif hit_tp:
                        outcome = "WIN"
                        diagnosis = "تارگت رسیده"
                    elif bars_elapsed >= 12:
                        if ret > 0.4:
                            outcome = "WIN_TIMEOUT"
                            diagnosis = f"سود جزئی {ret:+.2f}% در افق"
                        elif ret < -0.5:
                            outcome = "LOSS_TIMEOUT"
                            diagnosis = f"ضرر زمانی {ret:+.2f}%"
                            root = _v78_diagnose_loss(conf, edge, neural, ai, cons, opp, regime, mae)
                        else:
                            outcome = "FLAT"
                            diagnosis = "بدون نتیجه معنی‌دار"
                    else:
                        continue  # still open
                correction = ""
                if outcome in {"LOSS", "LOSS_TIMEOUT", "MISSED_MOVE"} and root:
                    correction = _v78_apply_correction(root, symbol, tf, decision)
                with DB_LOCK, db_conn() as con:
                    con.execute("""
                        UPDATE v78_decision_fate SET
                            outcome=?, return_pct=?, mfe_pct=?, mae_pct=?, bars_to_outcome=?,
                            diagnosis=?, root_cause=?, correction_applied=?, evaluated_at=?
                        WHERE id=?
                    """, (outcome, round(ret, 4), round(mfe, 4), round(mae, 4), bars_elapsed,
                          diagnosis, root, correction, time.time(), rid))
                results["evaluated"] += 1
                if outcome.startswith("WIN"):
                    results["wins"] += 1
                elif outcome.startswith("LOSS") or outcome == "MISSED_MOVE":
                    results["losses"] += 1
                else:
                    results["timeouts"] += 1
                results["diagnoses"].append({
                    "symbol": symbol, "tf": tf, "decision": decision,
                    "outcome": outcome, "diagnosis": diagnosis, "root": root, "correction": correction
                })
            except Exception:
                _swallow()
    except Exception:
        _swallow()
    return results

def _v78_diagnose_loss(conf, edge, neural, ai, cons, opp, regime, mae) -> str:
    if ai is None:
        ai = -1.0  # missing AI vote marker
    """Root-cause analysis for a losing decision."""
    causes = []
    if conf < 0.55:
        causes.append("confidence_low")
    if edge < 0.12:
        causes.append("edge_thin")
    if neural is not None and neural < 0.45:
        causes.append("neural_weak")
    if ai is not None and ai < 0.40:
        causes.append("ai_weak")
    if cons is not None and cons < 0.50:
        causes.append("consensus_conflict")
    if opp is not None and opp < 0.55:
        causes.append("opportunity_overrated")
    if str(regime).lower() in {"high_vol", "chaotic", "transition"}:
        causes.append("regime_hostile")
    if mae is not None and mae < -1.5:
        causes.append("adverse_excursion_large")
    return "|".join(causes) if causes else "unknown_market"

def _v78_apply_correction(root: str, symbol: str, tf: str, decision: str) -> str:
    """Governed, small, bounded parameter adjustment based on diagnosed root cause."""
    try:
        _v78_init()
        adjustments = {
            "confidence_low": ("min_confidence", +0.015),
            "edge_thin": ("min_edge_long" if decision == "LONG" else "min_edge_short", +0.01),
            "neural_weak": ("neural_weight", -0.01),
            "ai_weak": ("ai_weight", -0.008),
            "consensus_conflict": ("min_consensus", +0.02),
            "opportunity_overrated": ("opportunity_threshold", +0.015),
            "threshold_too_high": ("min_confidence", -0.01),
            "consensus_weak": ("min_consensus", -0.01),
        }
        applied = []
        with DB_LOCK, db_conn() as con:
            for cause in root.split("|"):
                if cause not in adjustments:
                    continue
                key, delta = adjustments[cause]
                row = con.execute("SELECT value FROM v78_learning_params WHERE key=?", (key,)).fetchone()
                if not row:
                    continue
                old = float(row[0])
                new = float(clamp(old + delta, 0.05, 0.95))
                if abs(new - old) < 1e-6:
                    continue
                con.execute(
                    "UPDATE v78_learning_params SET value=?, updated_at=?, reason=? WHERE key=?",
                    (new, time.time(), f"auto:{cause}:{symbol}:{tf}", key)
                )
                applied.append(f"{key}:{old:.3f}->{new:.3f}")
                con.execute(
                    "INSERT INTO v78_error_log(created_at, symbol, timeframe, decision, error_type, detail, suggested_fix, applied) VALUES (?,?,?,?,?,?,?,1)",
                    (time.time(), symbol, tf, decision, cause, root, f"{key} adjusted by {delta:+.3f}")
                )
        return ";".join(applied) if applied else ""
    except Exception:
        _swallow()
        return ""

def _v78_get_adaptive_params() -> dict:
    """Return current learned parameters for all governors/AI to consume."""
    _v78_init()
    out = {}
    try:
        with DB_LOCK, db_conn() as con:
            for row in con.execute("SELECT key, value FROM v78_learning_params").fetchall():
                out[row[0]] = float(row[1])
    except Exception:
        _swallow()
    return out

def _v78_dashboard_stats(days: int = 7) -> dict:
    """Rich stats for the real evaluation dashboard."""
    _v78_init()
    cutoff = time.time() - days * 86400
    stats = {
        "version": V78_EVAL_VERSION,
        "period_days": days,
        "total": 0, "wins": 0, "losses": 0, "waits_correct": 0, "missed": 0, "flat": 0,
        "win_rate": None, "avg_return": None, "avg_mfe": None, "avg_mae": None,
        "by_tf": {}, "by_regime": {}, "top_errors": [], "recent_corrections": [],
        "adaptive_params": _v78_get_adaptive_params(),
        "learning_health": "unknown"
    }
    try:
        with DB_LOCK, db_conn() as con:
            rows = con.execute("""
                SELECT decision, outcome, return_pct, mfe_pct, mae_pct, timeframe, regime, root_cause, correction_applied, diagnosis
                FROM v78_decision_fate
                WHERE evaluated_at IS NOT NULL AND created_at > ?
            """, (cutoff,)).fetchall()
            stats["total"] = len(rows)
            rets, mfes, maes = [], [], []
            error_count = {}
            for d, o, r, mfe, mae, tf, reg, root, corr, diag in rows:
                if o and o.startswith("WIN"):
                    stats["wins"] += 1
                elif o and (o.startswith("LOSS") or o == "MISSED_MOVE"):
                    stats["losses"] += 1
                elif o == "CORRECT_WAIT":
                    stats["waits_correct"] += 1
                elif o == "MISSED_MOVE":
                    stats["missed"] += 1
                else:
                    stats["flat"] += 1
                if r is not None:
                    rets.append(float(r))
                if mfe is not None:
                    mfes.append(float(mfe))
                if mae is not None:
                    maes.append(float(mae))
                # by tf
                tfb = stats["by_tf"].setdefault(tf or "?", {"n": 0, "wins": 0, "losses": 0})
                tfb["n"] += 1
                if o and o.startswith("WIN"):
                    tfb["wins"] += 1
                if o and o.startswith("LOSS"):
                    tfb["losses"] += 1
                # by regime
                rb = stats["by_regime"].setdefault(reg or "unknown", {"n": 0, "wins": 0, "losses": 0})
                rb["n"] += 1
                if o and o.startswith("WIN"):
                    rb["wins"] += 1
                if o and o.startswith("LOSS"):
                    rb["losses"] += 1
                if root:
                    for c in str(root).split("|"):
                        error_count[c] = error_count.get(c, 0) + 1
                if corr:
                    stats["recent_corrections"].append({"tf": tf, "root": root, "corr": corr, "diag": diag})
            if stats["wins"] + stats["losses"] > 0:
                stats["win_rate"] = round(stats["wins"] / (stats["wins"] + stats["losses"]) * 100, 1)
            if rets:
                stats["avg_return"] = round(float(np.mean(rets)), 3)
            if mfes:
                stats["avg_mfe"] = round(float(np.mean(mfes)), 3)
            if maes:
                stats["avg_mae"] = round(float(np.mean(maes)), 3)
            stats["top_errors"] = sorted(error_count.items(), key=lambda x: -x[1])[:8]
            stats["recent_corrections"] = stats["recent_corrections"][-12:]
            # health
            n = stats["wins"] + stats["losses"]
            if n >= 15 and stats["win_rate"] is not None:
                if stats["win_rate"] >= 55:
                    stats["learning_health"] = "excellent"
                elif stats["win_rate"] >= 48:
                    stats["learning_health"] = "good"
                elif stats["win_rate"] >= 40:
                    stats["learning_health"] = "needs_attention"
                else:
                    stats["learning_health"] = "critical"
            elif n < 8:
                stats["learning_health"] = "collecting_data"
            else:
                stats["learning_health"] = "stabilizing"
    except Exception:
        _swallow()
    return stats

def _v78_run_cycle(force: bool = False) -> dict:
    """Governed continuous improvement cycle."""
    global _V78_LAST_CYCLE
    now = time.time()
    if not force and (now - _V78_LAST_CYCLE) < _V78_CYCLE_SEC:
        return {"skipped": True, "reason": "interval"}
    with _V78_EVAL_LOCK:
        _V78_LAST_CYCLE = now
        eval_res = _v78_evaluate_pending()
        stats = _v78_dashboard_stats(7)
        return {
            "version": V78_EVAL_VERSION,
            "evaluated": eval_res,
            "stats": stats,
            "ts": now
        }

def _v78_self_test() -> int:
    print("  + v78_schema")
    _v78_init()
    print("  + v78_params")
    p = _v78_get_adaptive_params()
    assert "min_confidence" in p
    print("  + v78_dashboard")
    s = _v78_dashboard_stats(1)
    assert "learning_health" in s
    print("V78 Evaluation self-test: PASS")
    return 0

# Wire into analyze_asset chain if possible
_PREV_ANALYZE_V78 = None
if "analyze_asset" in dir() or "analyze_asset" in globals():
    _PREV_ANALYZE_V78 = globals().get("analyze_asset")

def analyze_asset(*args, **kwargs):
    """Wrap analyze_asset to always record decision fate."""
    out = _PREV_ANALYZE_V78(*args, **kwargs) if callable(_PREV_ANALYZE_V78) else {}
    try:
        if isinstance(out, dict):
            _v78_record_decision(out)
            # inject adaptive params for downstream
            out["v78_adaptive"] = _v78_get_adaptive_params()
            out["v78_eval_version"] = V78_EVAL_VERSION
    except Exception:
        _swallow()
    return out

# periodic trigger helper
def _v78_maybe_cycle():
    try:
        _v78_run_cycle(force=False)
    except Exception:
        _swallow()


# ---- V78 API routes (registered when this layer executes) ----
try:
    @app.get("/api/v78/eval")
    def api_v78_eval():
        days = _query_int("days", 7, 1, 30) if "_query_int" in dir() else 7
        try:
            days = int(request.args.get("days", 7))
        except Exception:
            days = 7
        force = str(request.args.get("force", "0")).lower() in {"1", "true", "yes"}
        cycle = _v78_run_cycle(force=force)
        stats = _v78_dashboard_stats(days)
        return jsonify({"ok": True, "cycle": cycle, "stats": stats, "version": V78_EVAL_VERSION})

    @app.get("/api/v78/params")
    def api_v78_params():
        return jsonify({"ok": True, "params": _v78_get_adaptive_params(), "version": V78_EVAL_VERSION})

    @app.get("/api/v78/fates")
    def api_v78_fates():
        limit = 40
        try:
            limit = min(100, max(5, int(request.args.get("limit", 40))))
        except Exception:
            pass
        rows = []
        try:
            with DB_LOCK, db_conn() as con:
                for r in con.execute("""
                    SELECT symbol, timeframe, decision, confidence, edge, outcome, return_pct,
                           diagnosis, root_cause, correction_applied, created_at, evaluated_at
                    FROM v78_decision_fate ORDER BY created_at DESC LIMIT ?
                """, (limit,)).fetchall():
                    rows.append({
                        "symbol": r[0], "tf": r[1], "decision": r[2], "conf": r[3], "edge": r[4],
                        "outcome": r[5], "return_pct": r[6], "diagnosis": r[7], "root": r[8],
                        "correction": r[9], "created": r[10], "evaluated": r[11]
                    })
        except Exception:
            _swallow()
        return jsonify({"ok": True, "fates": rows, "version": V78_EVAL_VERSION})
except Exception:
    pass
