# [TITAN V77 layer] hardening/v77_trace - decision trace (observability only).
# NEW code. Wraps the item-level gates so every time a layer CHANGES the decision of an
# item, a record is kept in a ring buffer. Wrappers never alter inputs/outputs and never raise.
import collections as _v77_collections
import functools as _v77_functools

V77_TRACE_MAX = 1000
_V77_TRACE = _v77_collections.deque(maxlen=V77_TRACE_MAX)
_V77_TRACE_LOCK = threading.Lock()
_V77_TRACE_COUNTS: dict = {}
V77_TRACED_FUNCTIONS = (
    "_v40_precision_gate", "_v47_apply_policy", "_v49_apply", "_v51_finalize_decision",
    "_v52_trust_gate", "_v55_apply_to_item", "_v56_apply_to_item", "v76_unified_publish_gate",
)


def _v77_decision_of(obj) -> Optional[str]:
    try:
        if isinstance(obj, dict):
            v = obj.get("decision_tag") or obj.get("decision")
            return str(v).upper() if v is not None else None
    except Exception:
        _swallow()
    return None


def _v77_trace_wrap(fn_name: str, fn):
    if getattr(fn, "_v77_traced", False):
        return fn

    @_v77_functools.wraps(fn)
    def _wrapped(*args, **kwargs):
        before = _v77_decision_of(args[0]) if args else None
        sym = tf = None
        try:
            src = args[0] if args and isinstance(args[0], dict) else {}
            sym, tf = src.get("symbol"), src.get("tf")
        except Exception:
            _swallow()
        out = fn(*args, **kwargs)
        try:
            after = _v77_decision_of(out) if isinstance(out, dict) else _v77_decision_of(args[0] if args else None)
            if before is not None and after is not None and before != after:
                rec = {"ts": time.time(), "layer": fn_name, "symbol": sym, "tf": tf, "from": before, "to": after}
                with _V77_TRACE_LOCK:
                    _V77_TRACE.append(rec)
                    _V77_TRACE_COUNTS[fn_name] = _V77_TRACE_COUNTS.get(fn_name, 0) + 1
        except Exception:
            _swallow()
        return out

    _wrapped._v77_traced = True
    return _wrapped


def v77_install_trace() -> list:
    installed = []
    for nm in V77_TRACED_FUNCTIONS:
        fn = globals().get(nm)
        if callable(fn):
            globals()[nm] = _v77_trace_wrap(nm, fn)
            installed.append(nm)
    return installed


V77_TRACE_INSTALLED = v77_install_trace()


def v77_trace_snapshot(symbol: Optional[str] = None, limit: int = 100) -> dict:
    with _V77_TRACE_LOCK:
        rows = list(_V77_TRACE)
        counts = dict(_V77_TRACE_COUNTS)
    if symbol:
        rows = [r for r in rows if str(r.get("symbol") or "").upper() == symbol.upper()]
    limit = max(1, min(int(limit or 100), V77_TRACE_MAX))
    return {"ok": True, "installed": list(V77_TRACE_INSTALLED), "changes_by_layer": counts, "events": rows[-limit:]}
