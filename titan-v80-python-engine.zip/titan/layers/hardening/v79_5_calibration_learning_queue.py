# [TITAN V79.5] Cone calibration + governed fate learning + heavy-API background queue
# ============================================================================
# 1) Cone coverage calibration (label pending, report, auto vol_scale nudge)
# 2) Fate → threshold loop with min sample size + daily change caps
# 3) Background job queue so /api/backtest, performance, all-performance stay non-blocking
# ============================================================================
V79_5_VERSION = "TITAN-V79.5-CALIBRATION-LEARNING-QUEUE"

import json
import queue
import threading
import time
import traceback
from typing import Any, Callable, Optional

# ---------------------------------------------------------------------------
# 1) CONE CALIBRATION
# ---------------------------------------------------------------------------

_V79_CONE_SCALE_KEY = "cone_vol_scale"
_V79_CONE_TARGET = 80.0  # ideal empirical coverage %
_V79_CONE_BAND = (72.0, 88.0)  # acceptable band
_V79_CONE_LAST_CAL = 0.0
_V79_CONE_CAL_SEC = 600.0

def _v79_ensure_cone_param(con) -> None:
    try:
        con.execute(
            "INSERT OR IGNORE INTO v78_learning_params(key, value, updated_at, reason) VALUES (?,?,?,?)",
            (_V79_CONE_SCALE_KEY, 1.0, time.time(), "init"),
        )
    except Exception:
        pass

def _v79_get_cone_vol_scale() -> float:
    try:
        _v78_init()
        with DB_LOCK, db_conn() as con:
            _v79_ensure_cone_param(con)
            row = con.execute(
                "SELECT value FROM v78_learning_params WHERE key=?", (_V79_CONE_SCALE_KEY,)
            ).fetchone()
            if row:
                return float(clamp(float(row[0]), 0.55, 1.85))
    except Exception:
        pass
    return 1.0

def _v79_set_cone_vol_scale(new_scale: float, reason: str) -> None:
    try:
        _v78_init()
        with DB_LOCK, db_conn() as con:
            _v79_ensure_cone_param(con)
            con.execute(
                "UPDATE v78_learning_params SET value=?, updated_at=?, reason=? WHERE key=?",
                (float(clamp(new_scale, 0.55, 1.85)), time.time(), reason[:200], _V79_CONE_SCALE_KEY),
            )
    except Exception:
        _swallow()

def _v79_record_forecast_cone(item: dict) -> None:
    """Push V78 / candle_forecast cone into v69 ledger for later coverage scoring."""
    try:
        symbol = str(item.get("symbol") or "")
        tf = str(item.get("timeframe") or item.get("tf") or "1h")
        if not symbol:
            return
        fc = item.get("v78_forecast") or item.get("candle_forecast") or item.get("forecast") or {}
        if not isinstance(fc, dict):
            return
        cone = fc.get("cone")
        if not cone or not isinstance(cone, dict):
            return
        if not (cone.get("q10") and cone.get("q50") and cone.get("q90")):
            return
        last = safe_float(item.get("price") or item.get("price_raw") or item.get("live_price"), 0.0)
        if last <= 0:
            return
        # apply live vol scale into a copy so ledger reflects scaled bands when available
        scale = _v79_get_cone_vol_scale()
        if abs(scale - 1.0) > 1e-6 and last > 0:
            try:
                q50 = [float(x) for x in cone["q50"]]
                scaled = dict(cone)
                for band in ("q10", "q90", "q25", "q75"):
                    if band not in cone or not cone[band]:
                        continue
                    arr = [float(x) for x in cone[band]]
                    scaled[band] = [
                        q50[i] + (arr[i] - q50[i]) * scale for i in range(min(len(arr), len(q50)))
                    ]
                cone = scaled
            except Exception:
                pass
        if callable(globals().get("_v69_record")):
            _v69_record(symbol, tf, cone, last)
    except Exception:
        _swallow()

def _v79_cone_calibration_report(limit: int = 500) -> dict:
    """Empirical coverage / pinball + verdict + suggested vol scale."""
    out = {
        "ok": True,
        "version": V79_5_VERSION,
        "n": 0,
        "pending": 0,
        "coverage": None,
        "pinball": None,
        "target": _V79_CONE_TARGET,
        "band": list(_V79_CONE_BAND),
        "verdict": "collecting_data",
        "vol_scale": _v79_get_cone_vol_scale(),
        "suggested_scale": None,
        "by_tf": [],
        "recent": [],
        "notes": [],
    }
    try:
        if callable(globals().get("_v69_init")):
            _v69_init()
        # label as many pending as reasonable
        labeled = 0
        if callable(globals().get("_v69_label")):
            try:
                labeled = int(_v69_label(max_rows=40) or 0)
            except Exception:
                labeled = 0
        out["just_labeled"] = labeled
        with DB_LOCK, db_conn() as con:
            pend = con.execute(
                "SELECT COUNT(*) c FROM v69_cone_ledger WHERE outcome='PENDING'"
            ).fetchone()
            out["pending"] = int(pend["c"] if isinstance(pend, dict) or hasattr(pend, "keys") else pend[0])
            rows = con.execute(
                """SELECT timeframe, coverage, pinball, symbol, created_at, evaluated_at
                   FROM v69_cone_ledger WHERE outcome='DONE' AND coverage IS NOT NULL
                   ORDER BY evaluated_at DESC LIMIT ?""",
                (int(limit),),
            ).fetchall()
        n = len(rows)
        out["n"] = n
        if n == 0:
            out["notes"].append("هنوز نمونهٔ بسته‌شده برای مخروط وجود ندارد")
            return out
        covs, pins = [], []
        by: dict = {}
        for r in rows:
            try:
                c = float(r["coverage"] if not isinstance(r, (list, tuple)) else r[1])
                covs.append(c)
                p = r["pinball"] if not isinstance(r, (list, tuple)) else r[2]
                if p is not None:
                    pins.append(float(p))
                tf = r["timeframe"] if not isinstance(r, (list, tuple)) else r[0]
                by.setdefault(str(tf), []).append(c)
            except Exception:
                continue
        if not covs:
            return out
        cov = sum(covs) / len(covs)
        out["coverage"] = round(cov, 2)
        out["pinball"] = round(sum(pins) / len(pins), 4) if pins else None
        out["by_tf"] = [
            {"k": k, "n": len(v), "cov": round(sum(v) / len(v), 1)} for k, v in sorted(by.items())
        ]
        out["recent"] = [
            {
                "symbol": (r["symbol"] if not isinstance(r, (list, tuple)) else ""),
                "tf": (r["timeframe"] if not isinstance(r, (list, tuple)) else r[0]),
                "coverage": float(r["coverage"] if not isinstance(r, (list, tuple)) else r[1]),
            }
            for r in rows[:12]
        ]
        # verdict + suggested scale
        lo, hi = _V79_CONE_BAND
        cur = _v79_get_cone_vol_scale()
        if n < 12:
            out["verdict"] = "collecting_data"
            out["notes"].append(f"نمونهٔ کافی نیست ({n}/12)")
        elif cov < lo:
            out["verdict"] = "too_narrow"
            # widen bands
            suggested = float(clamp(cur * (1.0 + min(0.25, (_V79_CONE_TARGET - cov) / 100.0)), 0.55, 1.85))
            out["suggested_scale"] = round(suggested, 3)
            out["notes"].append("پوشش کم → مخروط باید پهن‌تر شود")
        elif cov > hi:
            out["verdict"] = "too_wide"
            suggested = float(clamp(cur * (1.0 - min(0.20, (cov - _V79_CONE_TARGET) / 120.0)), 0.55, 1.85))
            out["suggested_scale"] = round(suggested, 3)
            out["notes"].append("پوشش زیاد → مخروط باید باریک‌تر شود")
        else:
            out["verdict"] = "calibrated"
            out["suggested_scale"] = round(cur, 3)
            out["notes"].append("پوشش در باند هدف است")
    except Exception as exc:
        out["ok"] = False
        out["error"] = str(exc)[:200]
    return out

def _v79_apply_cone_calibration(force: bool = False) -> dict:
    """If coverage is off-band and sample is enough, nudge cone_vol_scale (capped)."""
    global _V79_CONE_LAST_CAL
    now = time.time()
    if not force and (now - _V79_CONE_LAST_CAL) < _V79_CONE_CAL_SEC:
        return {"ok": True, "skipped": True, "reason": "rate_limited"}
    report = _v79_cone_calibration_report()
    _V79_CONE_LAST_CAL = now
    applied = None
    try:
        if report.get("n", 0) >= 20 and report.get("suggested_scale") is not None:
            cur = _v79_get_cone_vol_scale()
            sug = float(report["suggested_scale"])
            # max 8% move per calibration cycle
            delta = sug - cur
            capped = cur + float(clamp(delta, -0.08, 0.08))
            if abs(capped - cur) >= 0.01:
                _v79_set_cone_vol_scale(capped, f"auto_cal:cov={report.get('coverage')}:n={report.get('n')}")
                applied = {"from": round(cur, 3), "to": round(capped, 3)}
    except Exception:
        _swallow()
    report["applied"] = applied
    return report

# Wrap realistic path to scale cone bands + record
_PREV_V78_REALISTIC = globals().get("_v78_realistic_path")

def _v78_realistic_path(*args, **kwargs):
    fn = _PREV_V78_REALISTIC
    out = fn(*args, **kwargs) if callable(fn) else {
        "candles": [], "scenarios": {}, "path_score": 0.5, "cone": None,
        "bias": "neutral", "confidence": 0.0, "notes": ["no_prev_path"],
    }
    try:
        if isinstance(out, dict) and out.get("cone") and isinstance(out["cone"], dict):
            scale = _v79_get_cone_vol_scale()
            if abs(scale - 1.0) > 1e-6:
                cone = dict(out["cone"])
                q50 = [float(x) for x in (cone.get("q50") or [])]
                if q50:
                    for band in ("q10", "q90", "q25", "q75"):
                        if band not in cone or not cone[band]:
                            continue
                        arr = [float(x) for x in cone[band]]
                        cone[band] = [
                            q50[i] + (arr[i] - q50[i]) * scale
                            for i in range(min(len(arr), len(q50)))
                        ]
                    cone["vol_scale"] = round(scale, 3)
                    out["cone"] = cone
                    out.setdefault("notes", []).append(f"cone_vol_scale={scale:.3f}")
    except Exception:
        _swallow()
    return out

_PREV_V78_ATTACH = globals().get("_v78_attach_forecast") or globals().get("v78_attach_forecast")

def _v79_wrap_analyze_for_cone(prev_analyze):
    def analyze_asset(*args, **kwargs):
        item = prev_analyze(*args, **kwargs) if callable(prev_analyze) else None
        if isinstance(item, dict):
            try:
                _v79_record_forecast_cone(item)
            except Exception:
                _swallow()
        return item
    return analyze_asset

# ---------------------------------------------------------------------------
# 2) GOVERNED FATE → THRESHOLD LEARNING
# ---------------------------------------------------------------------------

_V79_LEARN_MIN_SAMPLE = 12          # min decisive outcomes before any auto adjust
_V79_LEARN_MAX_DELTA_PER_KEY = 0.04 # max |Δ| per key per day
_V79_LEARN_MAX_KEYS_PER_CYCLE = 3
_V79_LEARN_COOLDOWN_SEC = 900

def _v79_learning_budget(con, key: str) -> float:
    """Remaining absolute change allowed today for this key."""
    try:
        day_ago = time.time() - 86400
        rows = con.execute(
            """SELECT detail FROM v78_error_log
               WHERE created_at>? AND error_type='param_adjust' AND detail LIKE ?""",
            (day_ago, f"%{key}:%"),
        ).fetchall()
        used = 0.0
        for r in rows:
            try:
                detail = r["detail"] if not isinstance(r, (list, tuple)) else r[0]
                # format key:old->new
                if f"{key}:" in str(detail):
                    part = str(detail).split(f"{key}:", 1)[1].split()[0]
                    a, b = part.split("->")
                    used += abs(float(b) - float(a))
            except Exception:
                continue
        return max(0.0, _V79_LEARN_MAX_DELTA_PER_KEY - used)
    except Exception:
        return _V79_LEARN_MAX_DELTA_PER_KEY

def _v79_decisive_count(con) -> int:
    try:
        row = con.execute(
            """SELECT COUNT(*) c FROM v78_decision_fate
               WHERE outcome IN ('WIN','LOSS','WIN_TIMEOUT','LOSS_TIMEOUT','MISSED_MOVE')"""
        ).fetchone()
        return int(row["c"] if hasattr(row, "keys") or isinstance(row, dict) else row[0])
    except Exception:
        return 0

def _v78_apply_correction(root: str, symbol: str, tf: str, decision: str) -> str:
    """Governed correction: requires sample size, daily budget, small deltas."""
    try:
        _v78_init()
        adjustments = {
            "confidence_low": ("min_confidence", +0.012),
            "edge_thin": ("min_edge_long" if decision == "LONG" else "min_edge_short", +0.008),
            "neural_weak": ("neural_weight", -0.008),
            "ai_weak": ("ai_weight", -0.006),
            "consensus_conflict": ("min_consensus", +0.015),
            "opportunity_overrated": ("opportunity_threshold", +0.012),
            "threshold_too_high": ("min_confidence", -0.008),
            "consensus_weak": ("min_consensus", -0.008),
            "regime_hostile": ("min_confidence", +0.01),
        }
        applied = []
        with DB_LOCK, db_conn() as con:
            n = _v79_decisive_count(con)
            if n < _V79_LEARN_MIN_SAMPLE:
                return f"deferred_sample:{n}/{_V79_LEARN_MIN_SAMPLE}"
            n_keys = 0
            for cause in str(root or "").split("|"):
                if cause not in adjustments or n_keys >= _V79_LEARN_MAX_KEYS_PER_CYCLE:
                    continue
                key, delta = adjustments[cause]
                budget = _v79_learning_budget(con, key)
                if budget < 0.004:
                    applied.append(f"{key}:budget_exhausted")
                    continue
                step = float(clamp(delta, -budget, budget))
                row = con.execute(
                    "SELECT value FROM v78_learning_params WHERE key=?", (key,)
                ).fetchone()
                if not row:
                    continue
                old = float(row[0] if not isinstance(row, (list, tuple)) else row[0])
                new = float(clamp(old + step, 0.08, 0.92))
                if abs(new - old) < 1e-6:
                    continue
                con.execute(
                    "UPDATE v78_learning_params SET value=?, updated_at=?, reason=? WHERE key=?",
                    (new, time.time(), f"v79.5:{cause}:{symbol}:{tf}", key),
                )
                detail = f"{key}:{old:.3f}->{new:.3f}"
                applied.append(detail)
                try:
                    con.execute(
                        """INSERT INTO v78_error_log(created_at, symbol, timeframe, decision,
                           error_type, detail, suggested_fix, applied)
                           VALUES (?,?,?,?,?,?,?,?)""",
                        (
                            time.time(), symbol, tf, decision,
                            "param_adjust", detail, cause, 1,
                        ),
                    )
                except Exception:
                    pass
                n_keys += 1
        return "|".join(applied) if applied else "no_change"
    except Exception as exc:
        return f"error:{str(exc)[:80]}"

def _v79_learning_status() -> dict:
    out = {
        "ok": True,
        "version": V79_5_VERSION,
        "min_sample": _V79_LEARN_MIN_SAMPLE,
        "max_delta_per_key_day": _V79_LEARN_MAX_DELTA_PER_KEY,
        "params": {},
        "decisive_n": 0,
        "pending_fate": 0,
        "recent_adjustments": [],
        "fate_stats": {},
        "cone": {},
    }
    try:
        _v78_init()
        # evaluate pending fates
        eval_res = {}
        if callable(globals().get("_v78_evaluate_pending")):
            try:
                eval_res = _v78_evaluate_pending(max_rows=60) or {}
            except Exception as exc:
                eval_res = {"error": str(exc)[:120]}
        out["last_eval"] = eval_res
        with DB_LOCK, db_conn() as con:
            out["decisive_n"] = _v79_decisive_count(con)
            try:
                pend = con.execute(
                    "SELECT COUNT(*) c FROM v78_decision_fate WHERE outcome='PENDING'"
                ).fetchone()
                out["pending_fate"] = int(
                    pend["c"] if hasattr(pend, "keys") or isinstance(pend, dict) else pend[0]
                )
            except Exception:
                pass
            try:
                rows = con.execute(
                    "SELECT key, value, updated_at, reason FROM v78_learning_params ORDER BY key"
                ).fetchall()
                for r in rows:
                    k = r["key"] if not isinstance(r, (list, tuple)) else r[0]
                    v = r["value"] if not isinstance(r, (list, tuple)) else r[1]
                    reason = r["reason"] if not isinstance(r, (list, tuple)) else r[3]
                    out["params"][str(k)] = {
                        "value": round(float(v), 4),
                        "reason": str(reason or "")[:120],
                    }
            except Exception:
                pass
            try:
                logs = con.execute(
                    """SELECT created_at, symbol, detail, suggested_fix FROM v78_error_log
                       WHERE error_type='param_adjust' ORDER BY created_at DESC LIMIT 15"""
                ).fetchall()
                for r in logs:
                    out["recent_adjustments"].append({
                        "ts": r["created_at"] if not isinstance(r, (list, tuple)) else r[0],
                        "symbol": r["symbol"] if not isinstance(r, (list, tuple)) else r[1],
                        "detail": r["detail"] if not isinstance(r, (list, tuple)) else r[2],
                        "cause": r["suggested_fix"] if not isinstance(r, (list, tuple)) else r[3],
                    })
            except Exception:
                pass
        if callable(globals().get("_v78_dashboard_stats")):
            try:
                out["fate_stats"] = _v78_dashboard_stats() or {}
            except Exception:
                pass
        out["cone"] = _v79_cone_calibration_report(limit=200)
        out["learning_ready"] = out["decisive_n"] >= _V79_LEARN_MIN_SAMPLE
    except Exception as exc:
        out["ok"] = False
        out["error"] = str(exc)[:200]
    return out

# ---------------------------------------------------------------------------
# 3) BACKGROUND JOB QUEUE FOR HEAVY APIs
# ---------------------------------------------------------------------------

_JOB_Q: queue.Queue = queue.Queue(maxsize=64)
_JOB_RESULTS: dict[str, dict] = {}
_JOB_LOCK = threading.RLock()
_JOB_WORKER_STARTED = False
_JOB_TTL = 600.0

def _v79_job_worker():
    while True:
        try:
            job = _JOB_Q.get()
            if job is None:
                break
            jid, kind, fn, args, kwargs = job
            with _JOB_LOCK:
                _JOB_RESULTS[jid] = {
                    "id": jid, "kind": kind, "status": "running",
                    "started_at": time.time(),
                }
            try:
                result = fn(*args, **kwargs)
                # seed TTL cache so subsequent sync/async calls are instant
                try:
                    if callable(globals().get("_heavy_cache_put")) and isinstance(result, dict):
                        if kind == "backtest" and len(args) >= 3:
                            _heavy_cache_put(f"backtest:{args[0]}:{args[1]}:{args[2]}", result)
                        elif kind == "performance" and len(args) >= 3:
                            _heavy_cache_put(f"performance:{args[0]}:{args[1]}:{args[2]}", result)
                        elif kind == "all_performance":
                            syms = args[0] if args else []
                            _heavy_cache_put("all_performance:" + ",".join(syms), result)
                except Exception:
                    pass
                with _JOB_LOCK:
                    _JOB_RESULTS[jid] = {
                        "id": jid, "kind": kind, "status": "done",
                        "finished_at": time.time(),
                        "result": result,
                    }
            except Exception as exc:
                with _JOB_LOCK:
                    _JOB_RESULTS[jid] = {
                        "id": jid, "kind": kind, "status": "error",
                        "finished_at": time.time(),
                        "error": str(exc)[:300],
                        "trace": traceback.format_exc()[-500:],
                    }
            finally:
                _JOB_Q.task_done()
                # GC old jobs
                with _JOB_LOCK:
                    now = time.time()
                    dead = [
                        k for k, v in _JOB_RESULTS.items()
                        if now - float(v.get("finished_at") or v.get("started_at") or now) > _JOB_TTL
                    ]
                    for k in dead:
                        _JOB_RESULTS.pop(k, None)
        except Exception:
            time.sleep(0.5)

def _v79_ensure_worker():
    global _JOB_WORKER_STARTED
    if _JOB_WORKER_STARTED:
        return
    t = threading.Thread(target=_v79_job_worker, name="v79-heavy-jobs", daemon=True)
    t.start()
    _JOB_WORKER_STARTED = True

def _v79_submit_job(kind: str, fn: Callable, *args, **kwargs) -> str:
    _v79_ensure_worker()
    jid = f"{kind}-{int(time.time()*1000)%100000000}-{threading.get_ident()%10000}"
    with _JOB_LOCK:
        _JOB_RESULTS[jid] = {"id": jid, "kind": kind, "status": "queued", "queued_at": time.time()}
    try:
        _JOB_Q.put_nowait((jid, kind, fn, args, kwargs))
    except queue.Full:
        with _JOB_LOCK:
            _JOB_RESULTS[jid] = {"id": jid, "status": "error", "error": "queue_full"}
    return jid

def _v79_job_status(jid: str) -> dict:
    with _JOB_LOCK:
        row = _JOB_RESULTS.get(jid)
    if not row:
        return {"ok": False, "status": "unknown", "id": jid}
    out = dict(row)
    out["ok"] = True
    # don't dump huge result twice in list endpoints
    return out

def _v79_run_backtest_job(symbol: str, tf: str, limit: int) -> dict:
    return backtest_signal_logic(symbol, tf, limit)

def _v79_run_performance_job(symbol: str, tf: str, limit: int) -> dict:
    result = backtest_signal_logic(symbol, tf, limit)
    wf = {"ok": False}
    try:
        if result.get("ok"):
            wf = walk_forward_backtest(
                symbol, tf, limit,
                max(200, min(300, limit // 3)),
                max(50, min(100, limit // 8)),
            )
    except Exception as exc:
        wf = {"ok": False, "error": str(exc)[:120]}
    audit = {}
    try:
        audit = get_audit_stats() if callable(globals().get("get_audit_stats")) else {}
    except Exception:
        pass
    strategies = {}
    try:
        strategies = (result.get("professional") or {}).get("strategy_lab") or {}
    except Exception:
        pass
    return {
        "ok": bool(result.get("ok")),
        "symbol": symbol,
        "timeframe": tf,
        "backtest": result,
        "walk_forward": wf,
        "historical": audit,
        "strategies": strategies,
    }

def _v79_run_all_performance_job(symbols: list) -> dict:
    out = []
    audit = {}
    try:
        audit = get_audit_stats() if callable(globals().get("get_audit_stats")) else {}
    except Exception:
        pass
    for symbol in symbols:
        try:
            sym = _normalize_symbol(symbol) if callable(globals().get("_normalize_symbol")) else symbol
            result = backtest_signal_logic(sym, "1h", 500)
            m = result.get("metrics", {}) if isinstance(result, dict) and result.get("ok") else {}
            out.append({
                "symbol": sym,
                "win_rate": m.get("win_rate", audit.get("win_rate", 0) if isinstance(audit, dict) else 0),
                "wins": m.get("wins", 0),
                "losses": m.get("losses", 0),
                "expectancy": m.get("expectancy", 0),
                "profit_factor": m.get("profit_factor", 0),
            })
        except Exception as e:
            out.append({"symbol": symbol, "error": str(e)[:160]})
    return {"ok": True, "items": out, "audit": audit}

# ---------------------------------------------------------------------------
# HTTP routes
# ---------------------------------------------------------------------------

@app.get("/api/v79/cone-calibration")
def api_v79_cone_calibration():
    force = str(request.args.get("apply", "0")).lower() in {"1", "true", "yes"}
    if force:
        return jsonify(_v79_apply_cone_calibration(force=True))
    return jsonify(_v79_cone_calibration_report())

@app.get("/api/v79/learning")
def api_v79_learning():
    return jsonify(_v79_learning_status())

@app.post("/api/v79/learning/cycle")
@app.get("/api/v79/learning/cycle")
def api_v79_learning_cycle():
    """Force: evaluate pending fates + cone calibration + return learning snapshot."""
    fate = {}
    try:
        if callable(globals().get("_v78_evaluate_pending")):
            fate = _v78_evaluate_pending(max_rows=80) or {}
    except Exception as exc:
        fate = {"error": str(exc)[:160]}
    cone = _v79_apply_cone_calibration(force=True)
    status = _v79_learning_status()
    status["forced_fate_eval"] = fate
    status["forced_cone_cal"] = cone
    return jsonify(status)

@app.get("/api/v79/jobs/<jid>")
def api_v79_job(jid: str):
    st = _v79_job_status(jid)
    code = 200 if st.get("ok") else 404
    return jsonify(st), code

@app.get("/api/v79/jobs")
def api_v79_jobs():
    with _JOB_LOCK:
        items = sorted(
            ({"id": k, "status": v.get("status"), "kind": v.get("kind")} for k, v in _JOB_RESULTS.items()),
            key=lambda x: x["id"],
            reverse=True,
        )[:40]
    return jsonify({"ok": True, "jobs": items, "queue_size": _JOB_Q.qsize()})

# Safe rebind of heavy endpoints (Flask view_functions overwrite)
def api_backtest():
    symbol = _normalize_symbol(request.args.get("symbol", "BTC/USDT"))
    tf = _query_timeframe()
    limit = _query_int("limit", 1000, 100, MAX_BACKTEST_CANDLES)
    async_mode = str(request.args.get("async", "0")).lower() in {"1", "true", "yes"}
    force = str(request.args.get("refresh", "0")).lower() in {"1", "true", "yes"}
    ck = f"backtest:{symbol}:{tf}:{limit}"
    if not force and callable(globals().get("_heavy_cache_get")):
        hit = _heavy_cache_get(ck, (_HEAVY_API_TTL.get("backtest", 120) if isinstance(globals().get("_HEAVY_API_TTL"), dict) else 120))
        if hit is not None:
            return jsonify(hit)
    if async_mode:
        jid = _v79_submit_job("backtest", _v79_run_backtest_job, symbol, tf, limit)
        return jsonify({"ok": True, "async": True, "job_id": jid, "status_url": f"/api/v79/jobs/{jid}"})
    payload = backtest_signal_logic(symbol, tf, limit)
    if callable(globals().get("_heavy_cache_put")):
        _heavy_cache_put(ck, payload)
    return jsonify(payload)

def api_performance():
    symbol = _normalize_symbol(
        request.args.get("symbol", (USER_SETTINGS.get("active_coins") or ["BTC/USDT"])[0])
    )
    tf = _query_timeframe()
    limit = _query_int("limit", 1200, 200, MAX_BACKTEST_CANDLES)
    async_mode = str(request.args.get("async", "1")).lower() in {"1", "true", "yes"}
    force = str(request.args.get("refresh", "0")).lower() in {"1", "true", "yes"}
    ck = f"performance:{symbol}:{tf}:{limit}"
    if not force and callable(globals().get("_heavy_cache_get")):
        hit = _heavy_cache_get(ck, (_HEAVY_API_TTL.get("performance", 90) if isinstance(globals().get("_HEAVY_API_TTL"), dict) else 90))
        if hit is not None:
            return jsonify(hit)
    if async_mode:
        jid = _v79_submit_job("performance", _v79_run_performance_job, symbol, tf, limit)
        return jsonify({"ok": True, "async": True, "job_id": jid, "status_url": f"/api/v79/jobs/{jid}"})
    payload = _v79_run_performance_job(symbol, tf, limit)
    if callable(globals().get("_heavy_cache_put")):
        _heavy_cache_put(ck, payload)
    return jsonify(payload)

def api_all_performance():
    symbols = USER_SETTINGS.get("active_coins") or DEFAULT_COINS
    async_mode = str(request.args.get("async", "1")).lower() in {"1", "true", "yes"}
    force = str(request.args.get("refresh", "0")).lower() in {"1", "true", "yes"}
    cache_key = "all_performance:" + ",".join(symbols)
    if not force and callable(globals().get("_heavy_cache_get")):
        hit = _heavy_cache_get(cache_key, (_HEAVY_API_TTL.get("all_performance", 180) if isinstance(globals().get("_HEAVY_API_TTL"), dict) else 180))
        if hit is not None:
            return jsonify(hit)
    if async_mode:
        jid = _v79_submit_job("all_performance", _v79_run_all_performance_job, list(symbols))
        return jsonify({"ok": True, "async": True, "job_id": jid, "status_url": f"/api/v79/jobs/{jid}"})
    payload = _v79_run_all_performance_job(list(symbols))
    if callable(globals().get("_heavy_cache_put")):
        _heavy_cache_put(cache_key, payload)
    return jsonify(payload)

def _v79_rebind_route(rule_path: str, view_fn, endpoint: Optional[str] = None):
    """Replace an existing Flask view for a path without duplicate-rule errors."""
    try:
        ep = endpoint or view_fn.__name__
        # drop old rule(s) for this path
        app.url_map._rules = [r for r in app.url_map._rules if r.rule != rule_path]
        app.url_map._rules_by_endpoint = {
            k: [r for r in v if r.rule != rule_path]
            for k, v in getattr(app.url_map, "_rules_by_endpoint", {}).items()
        }
        app.view_functions[ep] = view_fn
        app.add_url_rule(rule_path, endpoint=ep, view_func=view_fn, methods=["GET"])
    except Exception as exc:
        try:
            LOGGER.warning("v79 rebind %s failed: %s", rule_path, exc)
        except Exception:
            pass

try:
    _v79_rebind_route("/api/backtest", api_backtest, "api_backtest")
    _v79_rebind_route("/api/performance", api_performance, "api_performance")
    _v79_rebind_route("/api/all-performance", api_all_performance, "api_all_performance")
except Exception:
    _swallow()

# ---------------------------------------------------------------------------
# Wire analyze_asset + periodic light cycle
# ---------------------------------------------------------------------------

try:
    _prev_aa = globals().get("analyze_asset")
    if callable(_prev_aa):
        analyze_asset = _v79_wrap_analyze_for_cone(_prev_aa)
except Exception:
    _swallow()

_V79_BG_LAST = 0.0

def _v79_background_tick():
    """Lightweight periodic: label cones, evaluate a few fates, maybe calibrate."""
    global _V79_BG_LAST
    now = time.time()
    if now - _V79_BG_LAST < 120:
        return
    _V79_BG_LAST = now
    try:
        if callable(globals().get("_v69_label")):
            _v69_label(max_rows=15)
    except Exception:
        pass
    try:
        if callable(globals().get("_v78_evaluate_pending")):
            _v78_evaluate_pending(max_rows=20)
    except Exception:
        pass
    try:
        _v79_apply_cone_calibration(force=False)
    except Exception:
        pass

# Hook into existing scan supervisor if present
_PREV_SUPERVISOR = globals().get("_scan_supervisor_tick")
if callable(_PREV_SUPERVISOR):
    def _scan_supervisor_tick(*a, **k):
        try:
            _v79_background_tick()
        except Exception:
            pass
        return _PREV_SUPERVISOR(*a, **k)

_v79_ensure_worker()

try:
    LOGGER.info("[%s] cone-calibration + governed learning + heavy job queue ready", V79_5_VERSION)
except Exception:
    pass
