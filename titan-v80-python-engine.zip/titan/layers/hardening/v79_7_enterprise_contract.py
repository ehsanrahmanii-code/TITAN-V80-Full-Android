# [TITAN V79.7] Enterprise contract — schema, explicit pipeline, ops metrics, pipeline_version
"""Organizational hardening layer.

1. AnalysisItem schema normalize (required fields always present & typed)
2. Explicit pipeline registry (named stages, inspectable, testable)
3. Ops metrics: rates of STALE / NO_AI / UNVALIDATED / BLOCKED
4. pipeline_version stamped on every JSON API response
"""
from __future__ import annotations

import json
import time
import threading
from typing import Any, Callable

V79_7_VERSION = "TITAN-V79.7-ENTERPRISE-CONTRACT"
PIPELINE_VERSION = "79.7.0-enterprise"

# ---------------------------------------------------------------------------
# 1) AnalysisItem schema
# ---------------------------------------------------------------------------

_REQUIRED_DEFAULTS: dict[str, Any] = {
    "decision": "WAIT",
    "decision_tag": "WAIT",
    "final_decision": "WAIT",
    "authoritative_decision": "WAIT",
    "trade_allowed": False,
    "watch_only": False,
    "sizing_blocked": True,
    "decision_validated": False,
    "decision_vetoed": False,
    "forecast_role": "scenario_only",
    "forecast_is_decision": False,
    "status_flags": {},
    "decision_authority": {},
    "pipeline_version": PIPELINE_VERSION,
}


def _v79_normalize_status_flags(flags: Any) -> dict:
    if not isinstance(flags, dict):
        return {}
    out: dict = {}
    for k, v in list(flags.items())[:64]:
        ks = str(k)[:48]
        if isinstance(v, (str, int, float, bool)) or v is None:
            out[ks] = v
        else:
            out[ks] = str(v)[:80]
    return out


def normalize_analysis_item(item: Any, *, symbol: str = "") -> dict:
    """Force a safe AnalysisItem contract. Never raises."""
    if not isinstance(item, dict):
        item = {"symbol": symbol or "UNKNOWN", "decision": "WAIT"}
    try:
        for k, v in _REQUIRED_DEFAULTS.items():
            if k not in item:
                item[k] = dict(v) if isinstance(v, dict) else v
        item["status_flags"] = _v79_normalize_status_flags(item.get("status_flags"))
        if not isinstance(item.get("decision_authority"), dict):
            item["decision_authority"] = {}
        auth = str(item.get("authoritative_decision") or item.get("decision") or "WAIT").upper()
        if auth in {"LONG", "SHORT"} and item.get("decision_validated") is not True:
            item["decision"] = "WAIT"
            item["decision_tag"] = "WAIT"
            item["final_decision"] = "WAIT"
            item["authoritative_decision"] = "WAIT"
            item["trade_allowed"] = False
            item["sizing_blocked"] = True
            item["decision_validated"] = False
            item["decision_vetoed"] = True
            item["veto_reason"] = item.get("veto_reason") or "schema_unvalidated"
            item["status_flags"]["decision"] = "UNVALIDATED"
        item["pipeline_version"] = PIPELINE_VERSION
        if symbol and not item.get("symbol"):
            item["symbol"] = symbol
    except Exception:
        try:
            _swallow("decision:normalize_item")
        except Exception:
            pass
    return item


def validate_analysis_item(item: Any) -> tuple[bool, list[str]]:
    """Return (ok, list of contract violations). Pure check — no mutation."""
    errs: list[str] = []
    if not isinstance(item, dict):
        return False, ["not_a_dict"]
    for k in ("decision", "authoritative_decision", "status_flags", "decision_validated"):
        if k not in item:
            errs.append(f"missing:{k}")
    if not isinstance(item.get("status_flags"), dict):
        errs.append("status_flags_not_dict")
    auth = str(item.get("authoritative_decision") or "").upper()
    if auth in {"LONG", "SHORT"}:
        if item.get("decision_validated") is not True:
            errs.append("directional_unvalidated")
    if auth not in {"LONG", "SHORT", "WAIT", "WATCH", ""}:
        errs.append(f"invalid_decision:{auth}")
    if item.get("forecast_is_decision") is True:
        errs.append("forecast_marked_as_decision")
    return (len(errs) == 0), errs


# ---------------------------------------------------------------------------
# 2) Explicit pipeline registry + ops counters
# ---------------------------------------------------------------------------

_PIPELINE_LOCK = threading.RLock()
_PIPELINE_RUNS: list[dict] = []
_PIPELINE_RUN_CAP = 100

_OPS_LOCK = threading.RLock()
_OPS_COUNTERS: dict[str, int] = {
    "items_seen": 0,
    "stale": 0,
    "no_ai": 0,
    "abstain": 0,
    "unvalidated": 0,
    "blocked": 0,
    "long": 0,
    "short": 0,
    "wait": 0,
    "watch": 0,
    "trade_allowed": 0,
}


def _v79_ops_observe(item: dict) -> None:
    if not isinstance(item, dict):
        return
    try:
        flags = item.get("status_flags") if isinstance(item.get("status_flags"), dict) else {}
        auth = str(item.get("authoritative_decision") or item.get("decision") or "WAIT").upper()
        with _OPS_LOCK:
            _OPS_COUNTERS["items_seen"] += 1
            if flags.get("price") == "STALE":
                _OPS_COUNTERS["stale"] += 1
            if flags.get("ai") == "NO_AI":
                _OPS_COUNTERS["no_ai"] += 1
            if flags.get("neural") == "ABSTAIN":
                _OPS_COUNTERS["abstain"] += 1
            if flags.get("decision") == "UNVALIDATED" or (
                item.get("decision_validated") is False and auth == "WAIT"
            ):
                _OPS_COUNTERS["unvalidated"] += 1
            if flags.get("decision") == "BLOCKED" or (item.get("decision_authority") or {}).get("blocked"):
                _OPS_COUNTERS["blocked"] += 1
            lk = auth.lower()
            if lk in {"long", "short", "wait", "watch"}:
                _OPS_COUNTERS[lk] += 1
            if item.get("trade_allowed") is True:
                _OPS_COUNTERS["trade_allowed"] += 1
    except Exception:
        pass


def _v79_pipeline_stages() -> list[tuple[str, Callable]]:
    stages: list[tuple[str, Callable]] = []
    for name, fn in (
        ("pillar1_data_forecast", globals().get("_v79_pillar1_attach")),
        ("pillar4_models", globals().get("_v79_pillar4_models")),
        ("authority", globals().get("_v79_authoritative_decision")),
        ("pillar3_learning", globals().get("_v79_pillar3_on_item")),
        ("trust_surface", globals().get("_v79_finalize_trust_surface")),
        ("schema_normalize", normalize_analysis_item),
    ):
        if callable(fn):
            stages.append((name, fn))
    return stages


def run_enterprise_pipeline(item: Any, *, symbol: str = "") -> dict:
    """Execute explicit named stages; isolate failures; always return normalized item."""
    if not isinstance(item, dict):
        item = {"symbol": symbol or "UNKNOWN"}
    t0 = time.perf_counter()
    log: list[dict] = []
    for name, fn in _v79_pipeline_stages():
        st = time.perf_counter()
        err = None
        try:
            if name == "schema_normalize":
                item = fn(item, symbol=symbol or str(item.get("symbol") or ""))  # type: ignore[misc]
            else:
                item = fn(item) or item  # type: ignore[operator]
        except Exception as exc:
            err = f"{type(exc).__name__}:{exc}"
            try:
                _swallow(f"decision:{name}")
                if callable(globals().get("_record_engine_error")):
                    _record_engine_error(
                        "decision",
                        f"pipeline:{name}:{exc}",
                        symbol=str(item.get("symbol") or symbol or ""),
                    )
            except Exception:
                pass
            if name == "authority" and callable(globals().get("_v79_force_unvalidated_wait")):
                try:
                    item = _v79_force_unvalidated_wait(item, f"pipeline_crash:{name}")
                except Exception:
                    pass
        log.append({"stage": name, "ms": round((time.perf_counter() - st) * 1000, 2), "error": err})
    item = normalize_analysis_item(item, symbol=symbol or str(item.get("symbol") or ""))
    total_ms = round((time.perf_counter() - t0) * 1000, 2)
    item["pipeline_log"] = log[-12:]
    item["pipeline_ms"] = total_ms
    item["pipeline_version"] = PIPELINE_VERSION
    _v79_ops_observe(item)
    with _PIPELINE_LOCK:
        _PIPELINE_RUNS.append(
            {"ts": time.time(), "symbol": item.get("symbol"), "ms": total_ms, "stages": len(log)}
        )
        if len(_PIPELINE_RUNS) > _PIPELINE_RUN_CAP:
            del _PIPELINE_RUNS[: len(_PIPELINE_RUNS) - _PIPELINE_RUN_CAP]
    return item


def _v79_ops_snapshot() -> dict:
    with _OPS_LOCK:
        c = dict(_OPS_COUNTERS)
    n = max(1, c.get("items_seen", 0))
    rates = {
        "stale_pct": round(c.get("stale", 0) / n * 100, 2),
        "no_ai_pct": round(c.get("no_ai", 0) / n * 100, 2),
        "unvalidated_pct": round(c.get("unvalidated", 0) / n * 100, 2),
        "blocked_pct": round(c.get("blocked", 0) / n * 100, 2),
        "trade_allowed_pct": round(c.get("trade_allowed", 0) / n * 100, 2),
    }
    errors: dict = {}
    try:
        if callable(globals().get("_engine_error_snapshot")):
            errors = _engine_error_snapshot()
    except Exception:
        pass
    with _PIPELINE_LOCK:
        recent = list(_PIPELINE_RUNS[-20:])
    return {
        "ok": True,
        "version": V79_7_VERSION,
        "pipeline_version": PIPELINE_VERSION,
        "counters": c,
        "rates": rates,
        "pipeline_stages": [s[0] for s in _v79_pipeline_stages()],
        "recent_pipeline_runs": recent,
        "engine_errors": errors,
    }


# ---------------------------------------------------------------------------
# Wrappers
# ---------------------------------------------------------------------------

_PREV_ANALYZE_V79_7 = globals().get("analyze_asset")


def analyze_asset(*args, **kwargs):
    item = None
    sym = str(args[0] if args else kwargs.get("symbol") or "")
    try:
        item = _PREV_ANALYZE_V79_7(*args, **kwargs) if callable(_PREV_ANALYZE_V79_7) else {}
    except Exception as exc:
        try:
            _swallow("signal:analyze_v79_7")
            if callable(globals().get("_record_engine_error")):
                _record_engine_error("signal", f"analyze:{exc}", symbol=sym)
        except Exception:
            pass
        item = item if isinstance(item, dict) else {"symbol": sym, "decision": "WAIT"}
    if not isinstance(item, dict):
        item = {"symbol": sym, "decision": "WAIT"}
    try:
        item = run_enterprise_pipeline(item, symbol=sym)
    except Exception as exc:
        try:
            _swallow("decision:enterprise_pipeline")
            if callable(globals().get("_v79_force_unvalidated_wait")):
                item = _v79_force_unvalidated_wait(
                    item if isinstance(item, dict) else {}, f"enterprise:{exc}"
                )
            item = normalize_analysis_item(item, symbol=sym)
        except Exception:
            item = normalize_analysis_item({"symbol": sym}, symbol=sym)
    return item


_PREV_FINALIZE_V79_7 = globals().get("_dashboard_finalize_item")


def _dashboard_finalize_item(item, *a, **kw):
    try:
        if callable(_PREV_FINALIZE_V79_7):
            item = _PREV_FINALIZE_V79_7(item, *a, **kw)
    except Exception:
        try:
            _swallow("dashboard:finalize_v79_7")
        except Exception:
            pass
    if isinstance(item, dict):
        try:
            item = normalize_analysis_item(item, symbol=str(item.get("symbol") or ""))
            if callable(globals().get("_v79_authoritative_decision")):
                item = _v79_authoritative_decision(item)
            item = normalize_analysis_item(item)
            _v79_ops_observe(item)
        except Exception:
            try:
                if callable(globals().get("_v79_force_unvalidated_wait")):
                    item = _v79_force_unvalidated_wait(item, "finalize_v79_7")
            except Exception:
                pass
            item = normalize_analysis_item(item if isinstance(item, dict) else {})
    return item


# ---------------------------------------------------------------------------
# 4) HTTP APIs + pipeline_version stamp
# ---------------------------------------------------------------------------

@app.get("/api/v79/ops")
def api_v79_ops():
    return jsonify(_v79_ops_snapshot())


@app.get("/api/v79/pipeline")
def api_v79_pipeline():
    return jsonify({
        "ok": True,
        "pipeline_version": PIPELINE_VERSION,
        "stages": [s[0] for s in _v79_pipeline_stages()],
        "contract": {
            "required_fields": list(_REQUIRED_DEFAULTS.keys()),
            "fail_closed": True,
            "forecast_role": "scenario_only",
        },
    })


@app.get("/api/v79/contract/validate")
def api_v79_contract_validate():
    sample = {
        "decision": request.args.get("decision", "WAIT"),
        "authoritative_decision": request.args.get("decision", "WAIT"),
        "decision_validated": request.args.get("validated", "0") in {"1", "true", "True"},
        "status_flags": {},
        "trade_allowed": request.args.get("trade", "0") in {"1", "true", "True"},
        "forecast_is_decision": False,
    }
    ok, errs = validate_analysis_item(sample)
    return jsonify({
        "ok": ok,
        "errors": errs,
        "sample": sample,
        "pipeline_version": PIPELINE_VERSION,
    })


@app.after_request
def _v79_7_stamp_pipeline_version(resp):
    try:
        resp.headers["X-TITAN-Pipeline"] = PIPELINE_VERSION
        resp.headers["X-TITAN-Version"] = V79_7_VERSION
        ctype = (resp.headers.get("Content-Type") or "")
        if "application/json" in ctype and resp.status_code < 500:
            data = resp.get_json(silent=True)
            if isinstance(data, dict) and "pipeline_version" not in data:
                data["pipeline_version"] = PIPELINE_VERSION
                resp.set_data(json.dumps(data, ensure_ascii=False, default=str).encode("utf-8"))
                resp.headers["Content-Type"] = "application/json; charset=utf-8"
    except Exception:
        try:
            _swallow("dashboard:stamp_pipeline")
        except Exception:
            pass
    return resp


def _v79_7_self_test() -> int:
    print("  + schema_normalize_non_dict")
    x = normalize_analysis_item(None, symbol="BTC/USDT")
    assert x["decision"] == "WAIT" and isinstance(x["status_flags"], dict)
    print("  + schema_fail_closed_unvalidated_long")
    y = normalize_analysis_item({
        "decision": "LONG",
        "authoritative_decision": "LONG",
        "decision_validated": False,
    })
    assert y["authoritative_decision"] == "WAIT" and y["decision_validated"] is False
    print("  + validate_directional_unvalidated")
    ok, errs = validate_analysis_item({
        "decision": "LONG",
        "authoritative_decision": "LONG",
        "decision_validated": False,
        "status_flags": {},
    })
    assert not ok and "directional_unvalidated" in errs
    print("  + ops_snapshot")
    snap = _v79_ops_snapshot()
    assert snap.get("pipeline_version") == PIPELINE_VERSION
    print("V79.7 Enterprise Contract self-test: PASS")
    return 0
