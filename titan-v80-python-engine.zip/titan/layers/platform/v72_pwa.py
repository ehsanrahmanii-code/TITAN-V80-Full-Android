# [TITAN V77 layer] platform/v72_pwa - V72 PWA + notifications
# Original V76 source lines 28344-28992 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# V72: PWA (manifest, service worker, generated icons) + local signal notifications.
# Service workers and notifications need a secure context: http://localhost / 127.0.0.1 or HTTPS.
# Real push while the app is fully closed would need Web Push (VAPID + HTTPS); this uses open-app scanning
# plus Periodic Background Sync where Android Chrome allows it.
# ============================================================
_V72_ICONS: dict[int, bytes] = {}


def _v72_icon(size: int) -> bytes:
    if size in _V72_ICONS:
        return _V72_ICONS[size]
    import struct
    import zlib
    yy, xx = np.mgrid[0:size, 0:size] / float(size)
    r = np.hypot(xx - .5, yy - .5); t = (np.sin(np.arctan2(yy - .5, xx - .5)) + 1) / 2
    bg = np.stack([5 + 8 * yy, 8 + 20 * yy, 22 + 40 * yy], -1)
    col = np.array([34, 211, 238.])[None, None, :] * (1 - t)[..., None] + np.array([244, 114, 182.])[None, None, :] * t[..., None]
    ring = np.exp(-((r - .30) / .03) ** 2)[..., None]; halo = np.exp(-((r - .30) / .10) ** 2)[..., None] * .35
    img = bg * (1 - ring) + col * (ring + halo)
    bar = ((xx > .34) & (xx < .66) & (yy > .34) & (yy < .41)) | ((xx > .465) & (xx < .535) & (yy > .34) & (yy < .68))
    img[bar] = [255, 255, 255]
    img = np.clip(img, 0, 255).astype(np.uint8)
    raw = b"".join(b"\x00" + img[i].tobytes() for i in range(size))

    def ch(tag: bytes, d: bytes) -> bytes:
        return struct.pack(">I", len(d)) + tag + d + struct.pack(">I", zlib.crc32(tag + d) & 0xFFFFFFFF)
    png = b"\x89PNG\r\n\x1a\n" + ch(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 2, 0, 0, 0)) + ch(b"IDAT", zlib.compress(raw, 9)) + ch(b"IEND", b"")
    _V72_ICONS[size] = png
    return png


@app.get("/icon-<int:size>.png")
def v72_icon(size: int):
    from flask import Response as _R
    if size not in (192, 512):
        return ("", 404)
    return _R(_v72_icon(size), mimetype="image/png", headers={"Cache-Control": "public, max-age=86400"})


@app.get("/manifest.webmanifest")
def v72_manifest():
    from flask import Response as _R
    m = {"name": "TITAN Pro", "short_name": "TITAN", "start_url": "/", "scope": "/", "display": "standalone",
         "orientation": "portrait", "dir": "rtl", "lang": "fa", "background_color": "#050816", "theme_color": "#050816",
         "icons": [{"src": "/icon-192.png", "sizes": "192x192", "type": "image/png", "purpose": "any maskable"},
                   {"src": "/icon-512.png", "sizes": "512x512", "type": "image/png", "purpose": "any maskable"}]}
    return _R(json.dumps(m, ensure_ascii=False), mimetype="application/manifest+json")


@app.get("/sw.js")
def v72_sw():
    from flask import Response as _R
    return _R(_V72_SW, mimetype="application/javascript", headers={"Service-Worker-Allowed": "/", "Cache-Control": "no-cache"})


_V72_SW = r'''var V="titan-pro-v72",SHELL=["/","/manifest.webmanifest","/icon-192.png"],busy=false;
function rd(k){return caches.open("titan-state").then(function(c){return c.match("/__"+k)}).then(function(r){return r?r.json():null})}
function wr(k,o){return caches.open("titan-state").then(function(c){return c.put("/__"+k,new Response(JSON.stringify(o)))})}
self.addEventListener("install",function(e){e.waitUntil(caches.open(V).then(function(c){return c.addAll(SHELL)}).then(function(){return self.skipWaiting()}))});
self.addEventListener("activate",function(e){e.waitUntil(caches.keys().then(function(ks){return Promise.all(ks.filter(function(k){return k.indexOf("titan-pro-")===0&&k!==V}).map(function(k){return caches.delete(k)}))}).then(function(){return self.clients.claim()}))});
self.addEventListener("fetch",function(e){var r=e.request,u=new URL(r.url);if(r.method!=="GET"||u.origin!==self.location.origin)return;if(/^\/(rescan|download|health|update_settings|api\/v64\/final|api\/v64\/gemini)/.test(u.pathname))return;
var ok=u.pathname.indexOf("/api/")===0||r.mode==="navigate"||SHELL.indexOf(u.pathname)>=0;if(!ok)return;
e.respondWith(fetch(r).then(function(res){if(res.ok){var cp=res.clone();caches.open(V).then(function(c){c.put(r,cp);c.keys().then(function(k){if(k.length>150)c.delete(k[3])})})}return res}).catch(function(){return caches.match(r).then(function(m){if(!m&&r.mode==="navigate")return caches.match("/");if(!m)return new Response(JSON.stringify({ok:false,offline:true}),{status:503,headers:{"Content-Type":"application/json"}});var h=new Headers(m.headers);h.set("X-TITAN-Cache","1");return m.blob().then(function(b){return new Response(b,{status:200,headers:h})})})}))});
function note(r,d,k){return self.registration.showNotification(r.symbol.split("/")[0]+(d==="LONG"?" ▲ لانگ":" ▼ شورت"),{body:"اطمینان "+Math.round(r.conf)+"٪ · امتیاز "+Math.round(r.score)+" · قیمت "+r.price,tag:k,icon:"/icon-192.png",badge:"/icon-192.png",lang:"fa",dir:"rtl",data:{sym:r.symbol}})}
function scan(rows,strict){if(busy)return Promise.resolve();busy=true;
return Promise.all([rd("cfg"),rd("seen"),rd("prev")]).then(function(a){var cfg=a[0],seen=a[1]||{},prev=a[2]||{};if(!cfg||!cfg.on)return;var now=Date.now(),base=!seen.__init,n=0,cur={},jobs=[];
(rows||[]).forEach(function(r){var d=r.decision;if(d!=="LONG"&&d!=="SHORT")return;if(cfg.dirs&&cfg.dirs.indexOf(d)<0)return;if((+r.conf||0)<cfg.nmin)return;var k=r.symbol+"|"+d;cur[k]=1;
if(base){seen[k]=now;return}if(strict&&!prev[k])return;if(now-(seen[k]||0)<cfg.cool*3600000)return;if(n>=3)return;seen[k]=now;n++;jobs.push(note(r,d,k))});
seen.__init=1;return Promise.all(jobs).then(function(){return Promise.all([wr("seen",seen),wr("prev",cur)])})}).catch(function(){}).then(function(){busy=false})}
self.addEventListener("message",function(e){var m=e.data||{};
if(m.t==="cfg")e.waitUntil(wr("cfg",m.cfg));
else if(m.t==="reset")e.waitUntil(Promise.all([wr("seen",{}),wr("prev",{})]));
else if(m.t==="rows")e.waitUntil(scan(m.rows,true));
else if(m.t==="test")e.waitUntil(self.registration.showNotification("اعلان آزمایشی TITAN",{body:"اعلان‌ها فعال است",icon:"/icon-192.png",lang:"fa",dir:"rtl"}))});
self.addEventListener("periodicsync",function(e){if(e.tag==="titan-check")e.waitUntil(fetch("/api/v59/ui-data",{cache:"no-store"}).then(function(r){return r.json()}).then(function(d){return scan((d.rows||[]).map(function(r){return{symbol:r.symbol,decision:r.decision,conf:r.conf,score:r.score,price:r.price}}),false)}).catch(function(){}))});
self.addEventListener("notificationclick",function(e){e.notification.close();var sym=(e.notification.data||{}).sym||"";e.waitUntil(self.clients.matchAll({type:"window",includeUncontrolled:true}).then(function(cs){for(var i=0;i<cs.length;i++){if("focus" in cs[i]){cs[i].postMessage({t:"open",sym:sym});return cs[i].focus()}}return self.clients.openWindow("/?sym="+encodeURIComponent(sym))}))});
'''


_V73_UI = r'''<!doctype html>
<html lang="fa" dir="rtl"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
<meta name="theme-color" content="#050816"><link rel="manifest" href="/manifest.webmanifest"><link rel="apple-touch-icon" href="/icon-192.png"><title>TITAN V75</title>
<style>
:root{box-sizing:border-box;padding-top:env(safe-area-inset-top,0px);padding-bottom:env(safe-area-inset-bottom,0px);--bg1:#050816;--bg2:#0b1236;--a:#22d3ee;--b:#a78bfa;--c:#f472b6;--up:#22e5a0;--dn:#ff5d7a;--go:#fbbf24;--gl:1;--bl:18px;--r:20px;--tx:#e8ecff;--mu:#8e98c9}
*,*::before,*::after{box-sizing:inherit}html{scroll-padding-top:env(safe-area-inset-top,0px)}
body{margin:0;font-family:Vazirmatn,Tahoma,sans-serif;color:var(--tx);background:var(--bg1);min-height:100vh;overflow-x:hidden}
.bgfx{position:fixed;inset:-20%;z-index:-1;background:radial-gradient(40% 35% at 80% 10%,color-mix(in srgb,var(--a) 38%,transparent),transparent 70%),radial-gradient(40% 35% at 10% 45%,color-mix(in srgb,var(--b) 32%,transparent),transparent 70%),radial-gradient(45% 40% at 75% 90%,color-mix(in srgb,var(--c) 30%,transparent),transparent 70%),linear-gradient(160deg,var(--bg1),var(--bg2));animation:drift 18s ease-in-out infinite alternate}
@keyframes drift{to{transform:translate(4%,3%) scale(1.08)}}
.wrap{max-width:1280px;margin:0 auto;padding:10px 14px 100px}
.sub{color:var(--mu);font-size:12px}.up{color:var(--up)}.dn{color:var(--dn)}
.glass{background:linear-gradient(135deg,#ffffff1c,#ffffff08);border:1px solid #ffffff26;border-radius:var(--r);backdrop-filter:blur(var(--bl));-webkit-backdrop-filter:blur(var(--bl));box-shadow:0 8px 30px #0006,inset 0 1px 0 #ffffff30}
.card{padding:14px;margin:0;position:relative;--k:var(--a)}
.card::before{content:"";position:absolute;inset:0;border-radius:inherit;padding:1px;background:linear-gradient(135deg,var(--k),transparent 45%,var(--b));opacity:calc(.3 + .35*var(--gl));-webkit-mask:linear-gradient(#000 0 0) content-box,linear-gradient(#000 0 0);-webkit-mask-composite:xor;mask-composite:exclude;pointer-events:none}
h3{margin:0 0 10px;font-size:13px;display:flex;align-items:center;gap:8px}
h3 .d{width:8px;height:8px;border-radius:50%;background:var(--k);box-shadow:0 0 calc(10px*var(--gl)) var(--k);animation:pl 2s infinite}
@keyframes pl{50%{opacity:.4;transform:scale(.7)}}
.tabs{display:flex;gap:6px;overflow-x:auto;padding:4px 0;scrollbar-width:none}
.chip,.btn{flex:none;border:1px solid #ffffff2a;background:#ffffff0d;color:var(--tx);border-radius:999px;padding:8px 14px;font:inherit;font-size:12px;cursor:pointer;transition:transform .18s,box-shadow .25s;position:relative;overflow:hidden}
.chip:active,.btn:active{transform:scale(.93)}
.chip.on{background:linear-gradient(135deg,var(--a),var(--b));color:#06091c;font-weight:700;border-color:transparent;box-shadow:0 0 calc(18px*var(--gl)) color-mix(in srgb,var(--a) 70%,transparent)}
.btn{border-radius:12px;background:linear-gradient(135deg,var(--a),var(--c));color:#06091c;font-weight:700;border:0;box-shadow:0 0 calc(18px*var(--gl)) color-mix(in srgb,var(--c) 60%,transparent)}
.btn.g{background:#ffffff14;color:var(--tx);box-shadow:none;border:1px solid #ffffff2a}
.rp{position:absolute;border-radius:50%;background:#ffffff55;transform:scale(0);animation:rpl .6s ease-out;pointer-events:none}@keyframes rpl{to{transform:scale(1);opacity:0}}
.nav{position:fixed;bottom:0;inset-inline:0;z-index:5;display:flex;justify-content:center;padding:8px 10px calc(8px + env(safe-area-inset-bottom,0px))}
.nav>div{display:flex;gap:4px;padding:6px;max-width:560px;width:100%}.nav button{flex:1;border:0;background:none;color:var(--mu);font:inherit;font-size:11px;padding:8px 2px;border-radius:14px;cursor:pointer;transition:.25s}
.nav button.on{background:linear-gradient(135deg,var(--a),var(--b));color:#06091c;font-weight:700;box-shadow:0 0 calc(16px*var(--gl)) var(--a)}
.row{display:flex;align-items:center;gap:10px}.price{font-size:32px;font-weight:800;text-shadow:0 0 calc(16px*var(--gl)) var(--a)}
.tag{padding:3px 12px;border-radius:999px;font-size:12px;font-weight:700;border:1px solid currentColor;box-shadow:0 0 calc(12px*var(--gl)) currentColor;animation:pl 2s infinite}
.LONG,.WIN{color:var(--up)}.SHORT,.LOSS{color:var(--dn)}.WAIT,.PENDING{color:var(--go)}
.g2{display:contents}
.glow{filter:drop-shadow(0 0 calc(5px*var(--gl)) currentColor)}
.kp{display:grid;grid-template-columns:repeat(4,1fr);gap:8px}.kp div{padding:10px 4px;text-align:center;border-radius:14px;font-size:10px;color:var(--mu)}.kp b{display:block;font-size:16px;color:var(--tx);text-shadow:0 0 calc(10px*var(--gl)) var(--k,var(--a))}
.tick{overflow:hidden;white-space:nowrap;padding:8px 0;font-size:12px}.tick div{display:inline-block;animation:mq 30s linear infinite;padding-inline-start:100%}.tick b{margin:0 14px}@keyframes mq{to{transform:translateX(100%)}}
.eq{display:flex;align-items:flex-end;gap:4px;height:80px}.eq i{flex:1;border-radius:5px 5px 2px 2px;background:linear-gradient(to top,var(--c),var(--a));box-shadow:0 0 calc(10px*var(--gl)) var(--a);transition:height .7s}
.bar{height:9px;border-radius:9px;background:#ffffff14;overflow:hidden;margin:5px 0 11px;position:relative}.bar i{display:block;height:100%;border-radius:9px;background:linear-gradient(90deg,var(--a),var(--b),var(--c));box-shadow:0 0 calc(12px*var(--gl)) var(--a);position:relative;overflow:hidden}
.bar i::after{content:"";position:absolute;inset:0;background:linear-gradient(90deg,transparent,#fff9,transparent);transform:translateX(-100%);animation:sh 2.4s infinite}@keyframes sh{to{transform:translateX(100%)}}
.dv{height:10px;border-radius:9px;background:#ffffff14;position:relative;margin:5px 0 11px}.dv i{position:absolute;top:0;bottom:0;border-radius:9px;box-shadow:0 0 calc(12px*var(--gl)) currentColor}.dv::after{content:"";position:absolute;left:50%;top:-3px;bottom:-3px;width:1px;background:#fff6}
.heat{display:grid;grid-template-columns:repeat(4,1fr);gap:6px}.heat button{border:0;border-radius:10px;padding:11px 2px;font:inherit;font-size:11px;font-weight:700;color:#04101a;cursor:pointer}
.lst>div{display:flex;justify-content:space-between;align-items:center;padding:9px 0;border-bottom:1px solid #ffffff12;font-size:13px;cursor:pointer}.lst>div:last-child{border:0}
.fl{stroke-dasharray:4 6;animation:fl 1.4s linear infinite}@keyframes fl{to{stroke-dashoffset:-20}}.nd{animation:pl 2.4s infinite}
.ctrl{display:grid;gap:12px}.ctrl label{display:flex;justify-content:space-between;align-items:center;font-size:12px;gap:10px}
input[type=range]{width:55%;accent-color:var(--a)}input[type=color]{width:42px;height:28px;border:0;background:none;padding:0}
input[type=search]{width:100%;padding:10px 14px;border-radius:14px;border:1px solid #ffffff2a;background:#ffffff0d;color:var(--tx);font:inherit;margin:6px 0}
.sw{width:44px;height:24px;border-radius:99px;background:#ffffff22;position:relative;cursor:pointer;border:0;flex:none;transition:.3s}.sw::after{content:"";position:absolute;top:3px;right:3px;width:18px;height:18px;border-radius:50%;background:#fff;transition:.25s}.sw.on{background:var(--a);box-shadow:0 0 calc(12px*var(--gl)) var(--a)}.sw.on::after{right:23px}
.themes{display:grid;grid-template-columns:repeat(4,1fr);gap:7px}.th{border:1px solid #ffffff22;border-radius:13px;padding:6px 4px;background:#ffffff0a;color:var(--tx);font:inherit;font-size:11px;cursor:pointer}.th i{display:block;height:22px;border-radius:7px;margin-bottom:5px}.th.on{border-color:var(--a);box-shadow:0 0 calc(16px*var(--gl)) var(--a)}
.tx{font-size:13px;line-height:1.9;white-space:pre-wrap}
.nobg .bgfx{animation:none}.calm *{animation-play-state:paused!important}@media (prefers-reduced-motion:reduce){*{animation:none!important}}

.ctools{display:flex;flex-wrap:wrap;gap:6px;margin:6px 0;align-items:center}
.ctools .chip{padding:6px 10px;font-size:11px}
.ctools .chip.on{background:linear-gradient(135deg,var(--a),var(--b));color:#06091c;font-weight:700}
.chwrap{position:relative;touch-action:none;user-select:none;overflow:hidden;border-radius:12px}
.chwrap svg{display:block;width:100%;height:auto}
.chhint{font-size:10px;color:var(--mu);margin:4px 0}
.detgrid{display:grid;grid-template-columns:1fr 1fr;gap:8px}
.detgrid .glass{padding:10px;border-radius:14px;text-align:center}
.detgrid b{display:block;font-size:14px;margin-top:2px}
.kv{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #ffffff12;font-size:12px}
.kv:last-child{border:0}
.pill{display:inline-block;padding:2px 8px;border-radius:999px;font-size:11px;border:1px solid currentColor}

/* ===== V73: dark colorful glass windows ===== */
:root{--bg1:#03040d;--bg2:#070a1f}
.bgfx{background:radial-gradient(38% 32% at 88% 6%,color-mix(in srgb,var(--a) 42%,transparent),transparent 70%),radial-gradient(36% 32% at 6% 38%,color-mix(in srgb,var(--c) 36%,transparent),transparent 70%),radial-gradient(40% 34% at 70% 62%,color-mix(in srgb,var(--b) 34%,transparent),transparent 70%),radial-gradient(34% 30% at 20% 95%,color-mix(in srgb,var(--up) 24%,transparent),transparent 70%),linear-gradient(160deg,var(--bg1),var(--bg2))}
.glass{background:linear-gradient(145deg,color-mix(in srgb,var(--k,var(--a)) 22%,transparent),color-mix(in srgb,var(--k,var(--a)) 5%,transparent) 62%,color-mix(in srgb,var(--b) 8%,transparent));border-color:color-mix(in srgb,var(--k,var(--a)) 50%,#ffffff22);box-shadow:0 12px 44px #000a,0 0 calc(28px*var(--gl)) color-mix(in srgb,var(--k,var(--a)) 28%,transparent),inset 0 1px 0 #ffffff38}
#view{display:grid;grid-template-columns:repeat(auto-fit,minmax(min(100%,340px),1fr));gap:12px;align-items:stretch}
#view>:not(.card){grid-column:1/-1}.win.wide{grid-column:1/-1}
.top{display:flex;align-items:center;gap:10px;flex-wrap:wrap;padding:9px 14px;margin:4px 0 12px;position:sticky;top:calc(4px + env(safe-area-inset-top,0px));z-index:6;--k:var(--b)}
.brand{font-weight:800;font-size:16px;letter-spacing:1.5px;background:linear-gradient(90deg,var(--a),var(--c));-webkit-background-clip:text;background-clip:text;color:transparent;filter:drop-shadow(0 0 calc(8px*var(--gl)) var(--a))}
.top .sp{flex:1}.top .chip{padding:5px 11px;font-size:11px}
.wh{display:flex;align-items:center;justify-content:space-between;margin:-14px -14px 10px;padding:9px 14px;border-radius:var(--r) var(--r) 0 0;background:linear-gradient(90deg,color-mix(in srgb,var(--k) 42%,transparent),transparent 85%);border-bottom:1px solid color-mix(in srgb,var(--k) 42%,transparent)}
.wh h3{margin:0}.wc{display:flex;gap:4px}.wc button{border:0;background:#ffffff16;color:var(--tx);width:26px;height:26px;border-radius:9px;cursor:pointer;font:inherit;font-size:13px;line-height:1}
.win.shut .wb{display:none}.win.shut .wh{margin-bottom:-14px;border-radius:var(--r);border-bottom:0}.win.shut .wc button:first-child{transform:rotate(90deg)}
.win.max{position:fixed;z-index:30;grid-column:auto;inset:calc(10px + env(safe-area-inset-top,0px)) 10px calc(88px + env(safe-area-inset-bottom,0px));overflow:auto;background:var(--bg2);box-shadow:0 0 0 100vmax #000b,0 0 40px color-mix(in srgb,var(--k) 45%,transparent)}
.nav button{display:flex;flex-direction:column;align-items:center;gap:2px}.nav .ic{font-size:15px;line-height:1}
.heat button{box-shadow:0 0 calc(14px*var(--gl)) currentColor}
.kp div,.detgrid .glass{border:1px solid color-mix(in srgb,var(--k,var(--a)) 35%,#ffffff18)}
/* svg sizing */
.wb svg{display:block;margin:0 auto;max-height:290px}.chwrap svg{max-height:440px}
@media (max-width:600px){.top .chip.hm{display:none}}

/* ===== V74 details / timeframe signals ===== */
.sm{font-size:11px}.tfp{color:var(--a);margin-inline-end:5px;padding:0 7px}
.tfs{display:flex;gap:4px;flex-wrap:wrap;margin-top:5px}.tfc{font-size:10px;padding:2px 7px;border-radius:8px;border:1px solid #ffffff22;background:#ffffff0a;color:var(--mu)}.tfc b{margin-inline-end:4px;opacity:.85}
.tfc.LONG{color:var(--up);border-color:color-mix(in srgb,var(--up) 55%,transparent)}.tfc.SHORT{color:var(--dn);border-color:color-mix(in srgb,var(--dn) 55%,transparent)}.tfc.pri{font-weight:800;box-shadow:0 0 calc(10px*var(--gl)) currentColor}
.rk{width:22px;height:22px;display:inline-flex;align-items:center;justify-content:center;border-radius:8px;background:linear-gradient(135deg,var(--a),var(--c));color:#06091c;font-size:11px;flex:none}
.mxw{overflow-x:auto}.mx{width:100%;border-collapse:separate;border-spacing:3px;font-size:11px}.mx th{color:var(--mu);font-weight:400;padding:4px}.mx td{text-align:center;padding:7px 4px;border-radius:8px;background:#ffffff0c}.mx tr{cursor:pointer}
.mx td.LONG{background:color-mix(in srgb,var(--up) 26%,transparent);color:var(--up)}.mx td.SHORT{background:color-mix(in srgb,var(--dn) 26%,transparent);color:var(--dn)}.mx td.WAIT{color:var(--mu)}
.tag.STRONG,.tag.POSITIVE{color:var(--up)}.tag.NEUTRAL{color:var(--go)}.tag.WEAK,.tag.TOXIC{color:var(--dn)}.tag.SPARSE{color:var(--mu)}
.lst>div{gap:10px}.kv b{text-align:end;max-width:62%;overflow-wrap:anywhere}.kp{grid-template-columns:repeat(auto-fit,minmax(86px,1fr))}.kp b{font-size:14px;overflow-wrap:anywhere}
@media (max-width:480px){.nav button{font-size:10px;padding:8px 0}}

/* ===== V75: Windows 11 Fluent — Acrylic / Mica · light & dark · shapes ===== */
:root{--ao:.62;--sa:1.6;--zm:1;--rvc:rgb(255 255 255/.6);--fill:rgb(28 30 42/var(--ao));--fill2:rgb(255 255 255/.08);--ln:rgb(255 255 255/.14);--ink:rgb(255 255 255/.10);--shd:0 10px 36px rgb(0 0 0/.45);--solidc:#1f2230}
html.lt{color-scheme:light;--tx:#1a2036;--mu:#5b6684;--up:#0e9f6e;--dn:#e11d48;--go:#d97706;--fill:rgb(255 255 255/var(--ao));--fill2:rgb(255 255 255/.6);--ln:rgb(255 255 255/.78);--ink:rgb(20 30 70/.10);--shd:0 8px 28px rgb(40 60 120/.13);--solidc:#f7f9fd}
html.lt body{background:var(--bg1)}
html.lt .bgfx{background:radial-gradient(42% 36% at 88% 6%,color-mix(in srgb,var(--a) 34%,transparent),transparent 70%),radial-gradient(40% 34% at 6% 40%,color-mix(in srgb,var(--c) 30%,transparent),transparent 70%),radial-gradient(44% 38% at 72% 66%,color-mix(in srgb,var(--b) 28%,transparent),transparent 70%),radial-gradient(34% 30% at 18% 96%,color-mix(in srgb,var(--up) 22%,transparent),transparent 70%),linear-gradient(160deg,var(--bg1),var(--bg2))}
.wrap{zoom:var(--zm)}

/* shapes layer */
.shp{position:fixed;inset:0;z-index:-1;overflow:hidden;pointer-events:none}
.sh{position:absolute;display:block;color:var(--c);animation:shf 20s ease-in-out infinite alternate;will-change:transform}
.sh svg{width:100%;height:100%;display:block;overflow:visible;transform:rotate(var(--r,0deg))}
@keyframes shf{from{transform:translate3d(0,0,0) scale(1)}to{transform:translate3d(var(--dx,20px),var(--dy,-30px),0) scale(1.12)}}
.nobg .sh{animation:none}
html.nz body::after{content:"";position:fixed;inset:0;z-index:-1;pointer-events:none;opacity:.07;background-image:url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='140' height='140'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.85' numOctaves='2' stitchTiles='stitch'/><feColorMatrix values='0 0 0 0 .5 0 0 0 0 .5 0 0 0 0 .5 0 0 0 .9 0'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>")}

/* glass styles (everything except neon) */
html:not([data-look="neon"]) .glass{background:radial-gradient(260px circle at var(--mx,-999px) var(--my,-999px),var(--rvc),transparent 70%),var(--fill);border:1px solid var(--ln);box-shadow:var(--shd),inset 0 1px 0 rgb(255 255 255/.35);backdrop-filter:blur(var(--bl)) saturate(var(--sa));-webkit-backdrop-filter:blur(var(--bl)) saturate(var(--sa))}
html[data-look="mica"] .glass{background:radial-gradient(260px circle at var(--mx,-999px) var(--my,-999px),var(--rvc),transparent 70%),color-mix(in srgb,var(--fill) 55%,var(--solidc));backdrop-filter:blur(calc(var(--bl)*.35)) saturate(1.1);-webkit-backdrop-filter:blur(calc(var(--bl)*.35)) saturate(1.1);box-shadow:0 1px 3px rgb(0 0 0/.12)}
html[data-look="frost"] .glass{backdrop-filter:blur(calc(var(--bl)*1.6)) saturate(calc(var(--sa)*1.25));-webkit-backdrop-filter:blur(calc(var(--bl)*1.6)) saturate(calc(var(--sa)*1.25));border-width:1.5px;box-shadow:var(--shd),inset 0 0 22px rgb(255 255 255/.18),inset 0 1px 0 rgb(255 255 255/.5)}
html[data-look="solid"] .glass{background:var(--solidc);backdrop-filter:none;-webkit-backdrop-filter:none;box-shadow:0 1px 4px rgb(0 0 0/.14)}
html:not([data-look="neon"]) .card::before{opacity:calc(.1 + .2*var(--gl))}
html:not([data-look="neon"]) .win.max{background:var(--solidc);box-shadow:0 0 0 100vmax rgb(0 0 0/.38),0 18px 60px rgb(0 0 0/.35)}
html:not([data-look="neon"]) .glass,html:not([data-look="neon"]) .glass *{text-shadow:none}

/* card: decorative shapes in titles + watermark */
.card{overflow:hidden}
.card>*{position:relative;z-index:1}
.card::after{content:"";position:absolute;width:130px;height:130px;inset-inline-start:-34px;bottom:-40px;background:color-mix(in srgb,var(--k) 13%,transparent);border-radius:50%;pointer-events:none;z-index:0}
.card:nth-child(4n+2)::after{border-radius:30px;transform:rotate(18deg)}
.card:nth-child(4n+3)::after{clip-path:polygon(50% 0,100% 100%,0 100%);border-radius:0}
.card:nth-child(4n)::after{clip-path:polygon(25% 5%,75% 5%,100% 50%,75% 95%,25% 95%,0 50%);border-radius:0}
h3 .d{width:10px;height:10px}
.win:nth-child(5n+2) .wh h3 .d{clip-path:polygon(50% 0,100% 50%,50% 100%,0 50%);border-radius:0}
.win:nth-child(5n+3) .wh h3 .d{clip-path:polygon(50% 0,100% 100%,0 100%);border-radius:0}
.win:nth-child(5n+4) .wh h3 .d{clip-path:polygon(25% 5%,75% 5%,100% 50%,75% 95%,25% 95%,0 50%);border-radius:0}
.win:nth-child(5n) .wh h3 .d{border-radius:3px}
.brand::before{content:"⬡ ";font-weight:400}

/* Windows-11 caption buttons & taskbar */
html:not([data-look="neon"]) .wc button{border-radius:6px;background:transparent;transition:background .15s}
html:not([data-look="neon"]) .wc button:hover{background:var(--ink)}
html:not([data-look="neon"]) .nav>div{border-radius:calc(var(--r) + 6px);padding:5px}
html:not([data-look="neon"]) .nav button{border-radius:calc(var(--r) - 2px);position:relative;color:var(--mu)}
html:not([data-look="neon"]) .nav button:hover{background:var(--ink)}
html:not([data-look="neon"]) .nav button.on{background:var(--fill2);color:var(--a);font-weight:700;box-shadow:inset 0 0 0 1px var(--ink)}
html:not([data-look="neon"]) .nav button.on::after{content:"";position:absolute;bottom:2px;left:50%;width:16px;height:3px;margin-left:-8px;border-radius:3px;background:var(--a)}
.nav>div{overflow-x:auto;scrollbar-width:none;gap:1px}.nav button{min-width:0;padding:7px 0;font-size:9.5px;letter-spacing:-.2px}.nav .ic{font-size:14px}

/* light-mode details */
html.lt .chip{background:rgb(255 255 255/.55);border-color:var(--ink);color:var(--tx)}
html.lt .chip.on,html.lt .ctools .chip.on{background:linear-gradient(135deg,var(--a),color-mix(in srgb,var(--a) 62%,var(--b)));color:#fff;border-color:transparent;box-shadow:0 2px 10px color-mix(in srgb,var(--a) 45%,transparent)}
html.lt .btn{color:#fff;background:linear-gradient(135deg,var(--a),color-mix(in srgb,var(--a) 55%,var(--b)));box-shadow:0 2px 10px color-mix(in srgb,var(--a) 40%,transparent)}
html.lt .btn.g{background:rgb(255 255 255/.6);color:var(--tx);border:1px solid var(--ink);box-shadow:none}
html.lt .wh{background:linear-gradient(90deg,color-mix(in srgb,var(--k) 15%,transparent),transparent 80%);border-bottom-color:color-mix(in srgb,var(--k) 22%,transparent)}
html.lt .wc button{color:var(--tx)}
html.lt .bar,html.lt .dv{background:rgb(0 0 0/.07)}
html.lt .sw{background:rgb(0 0 0/.2)}html.lt .sw.on{background:var(--a)}
html.lt .kv,html.lt .lst>div{border-bottom-color:var(--ink)}
html.lt .tfc{border-color:var(--ink);background:rgb(255 255 255/.5)}
html.lt .mx td{background:rgb(0 0 0/.045)}
html.lt .th{border-color:var(--ink);background:rgb(255 255 255/.5);color:var(--tx)}html.lt .th.on{border-color:var(--a)}
html.lt input[type=search]{background:rgb(255 255 255/.6);border-color:var(--ink);color:var(--tx)}
html.lt .kp div,html.lt .detgrid .glass{border-color:var(--ink)}
html.lt .heat button{color:#fff;box-shadow:none}
html.lt .tag,html.lt .tfc.pri,html.lt .bar i,html.lt .eq i,html.lt .chip.on,html.lt h3 .d{box-shadow:none}
html.lt .price,html.lt .kp b{text-shadow:none}
html.lt .brand,html.lt .glow{filter:none}
html.lt .rk{color:#fff}
html.lt #off{background:rgb(255 255 255/.85)}
html.lt svg text[fill="#fff"]{fill:var(--tx)}
html.lt svg text[fill="#8e98c9"]{fill:var(--mu)}
html.lt svg [stroke="#fff"]{stroke:var(--tx)}
html.lt svg circle[fill="#fff"]{fill:var(--tx)}
html.lt svg [stroke^="#ffffff"]{stroke:rgb(20 30 70/.16)}
html.lt .sh{opacity:.9}

/* schematic tab helpers */
.scs{display:block;width:100%;direction:ltr}
.scs .nodeg{cursor:pointer}
.scs .nodeg:hover{filter:brightness(1.15)}
.shpgrid{display:flex;flex-wrap:wrap;gap:6px}
.shpgrid .chip{padding:6px 11px}
.thp{height:54px;border-radius:9px;margin-bottom:5px;position:relative;overflow:hidden}
.thp em{position:absolute;display:block}
.pr{padding:6px 4px!important}
html:not([data-look="neon"]) .nav>div.glass{background:color-mix(in srgb,var(--fill) 72%,var(--solidc))}
.drag-grip{opacity:.45;margin-inline-end:6px;font-size:12px}.drag-handle{user-select:none;-webkit-user-select:none}.drag-panel.dragging{opacity:.8}
</style></head><body><div class="bgfx"></div><div class="shp" id="shp"></div>
<div id="off" class="tag WAIT" style="display:none;position:fixed;top:calc(8px + env(safe-area-inset-top,0px));inset-inline:0;margin:0 auto;width:max-content;z-index:9;background:#000a">آفلاین — آخرین داده ذخیره‌شده</div><div class="wrap"><header class="top glass"><span class="brand">TITAN</span><span class="sub" id="stat"></span><span class="sp"></span><button class="chip" data-wa="open">باز کردن همه</button><button class="chip" data-wa="close">جمع کردن همه</button><button class="chip hm" data-wa="reset">چیدمان پیش‌فرض</button></header><div id="view"></div></div>
<div class="nav"><div class="glass" id="nav"></div></div>
<script>
var $=function(i){return document.getElementById(i)},esc=function(s){return String(s==null?"":s).replace(/[&<>"]/g,function(c){return{"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[c]})},get=function(u){return fetch(u,{cache:"no-store"}).then(function(r){if(u.indexOf("/api/v59/ui-data")===0){var b=document.getElementById("off");if(b)b.style.display=r.headers.get("X-TITAN-Cache")==="1"?"block":"none"}return r.json()})};
var TH={"شفق نئون":["#050816","#0b1236","#22d3ee","#a78bfa","#f472b6"],"سایبر سرخابی":["#12031c","#2a0a3d","#ff3cac","#784ba0","#2b86c5"],"طلای سلطنتی":["#0d0a04","#241a06","#fbbf24","#f97316","#fde68a"],"اقیانوس":["#03121c","#06314a","#38bdf8","#2dd4bf","#818cf8"],"ماتریکس":["#020a05","#05200f","#22e5a0","#a3e635","#14b8a6"],"بنفش شاهانه":["#0a0420","#1e0a4a","#a78bfa","#e879f9","#60a5fa"],"آتشفشان":["#150404","#3a0d08","#ff6b35","#ff2e63","#ffd166"],"یخ قطبی":["#04101a","#0a2236","#9be7ff","#b8c0ff","#caffbf"],"ویندوز ۱۱ روشن":["#f3f6fb","#dfe9f7","#0067c0","#7a5af8","#00b7c3",1],"Mica آسمانی":["#eef6ff","#d6ecff","#0a84ff","#5e5ce6","#30d5c8",1],"گل‌صورتی":["#fff3f8","#ffe0ee","#e0408f","#a855f7","#fb923c",1],"نعنای یخی":["#effcf8","#d3f5ea","#0f9d8a","#2563eb","#84cc16",1],"کهربای گرم":["#fff8ec","#ffe9c7","#d97706","#e11d48","#0ea5a4",1],"اسطوخودوس":["#f6f2ff","#e6dcff","#7c3aed","#2563eb","#ec4899",1],"ماسه‌ای":["#faf6f0","#efe4d3","#b45309","#0f766e","#be185d",1],"ویندوز ۱۱ تیره":["#0b0f1a","#16213a","#60cdff","#a78bfa","#4ade80"],"Mica گرافیت":["#1b1b1f","#2b2b33","#4cc2ff","#c4a7ff","#6ee7b7"],"شب قطبی":["#020617","#0f172a","#38bdf8","#818cf8","#22d3ee"],"زغال اتمی":["#0a0a0c","#17171c","#94a3b8","#e2e8f0","#64748b"],"نئون سبز تیره":["#020b06","#0a1f12","#00ff9d","#39ff14","#0ea5e9"],"ارغوانی تاریک":["#0c0118","#1a0533","#c026d3","#7c3aed","#f472b6"],"کهکشان آبی":["#01030a","#0b1229","#3b82f6","#06b6d4","#8b5cf6"],"خون‌سیاه":["#0c0000","#1a0505","#ef4444","#f97316","#fbbf24"],"زمرد تاریک":["#01140c","#052e1c","#10b981","#34d399","#2dd4bf"],"کروم شب":["#0c0c10","#1c1c24","#e5e7eb","#60a5fa","#a78bfa"],"غروب شهری":["#0f0a12","#1e1328","#f472b6","#fb923c","#facc15"],"آبی عمیق OLED":["#000000","#001018","#00d4ff","#0077ff","#7c3aed"],"سپیده‌دم":["#fffaf5","#ffe8d6","#ff7a59","#ffb703","#8ecae6",1],"چمن روشن":["#f4fff8","#e0fbe2","#2ecc71","#27ae60","#1abc9c",1],"آسمان پاستلی":["#f0f9ff","#e0f2fe","#38bdf8","#818cf8","#f472b6",1],"مریم‌گلی":["#f8faf8","#eef2ea","#84a98c","#52796f","#cad2c5",1],"مرجانی روشن":["#fff5f5","#ffe3e3","#ff6b6b","#fcc419","#748ffc",1],"لیمویی":["#fffef0","#fff9db","#fab005","#82c91e","#15aabf",1],"یاقوت روشن":["#fff0f6","#ffdeeb","#e64980","#be4bdb","#4c6ef5",1],"مه آبی":["#f8fafc","#e2e8f0","#64748b","#0ea5e9","#8b5cf6",1],"نئون صورتی تاریک":["#120010","#2a0020","#ff2d95","#00f0ff","#b537f2"],"کوبالت تاریک":["#000814","#001d3d","#003566","#ffc300","#00b4d8"],"جنگل شب":["#0b1a0f","#14261c","#3d5a40","#a3b18a","#dad7cd"]};
function ld(){try{return JSON.parse(localStorage.getItem("titan_pro")||"{}")}catch(e){return{}}}
var LOOK={th:"ویندوز ۱۱ روشن",md:"th",st:"w11",ao:62,bl:28,rr:12,sa:160,gl:.6,nz:1,sh:1,sp:18,shT:null,zm:100,rv:1,cu:null,fx:1,an:1,layout:"classic",nav:"bottom",density:"comfy",card:"glass",tabs:"pill",menu:"round",accentBar:1,hero:"on",group:"decision"};
function dflt(){return Object.assign({gl:1,bl:18,rr:20,fx:1,an:1,cu:null,nt:{on:0,nmin:75,cool:4,L:1,S:1}},LOOK,{v:75})}
var _l=ld(),CF=Object.assign(dflt(),_l,_l.v===75?{}:LOOK,{v:75});
function sv(){try{localStorage.setItem("titan_pro",JSON.stringify(CF))}catch(e){}}
var SHT={c:'<circle cx="50" cy="50" r="46" fill="currentColor" fill-opacity=".5"/>',r:'<circle cx="50" cy="50" r="42" fill="none" stroke="currentColor" stroke-width="6"/>',s:'<rect x="8" y="8" width="84" height="84" rx="22" fill="currentColor" fill-opacity=".45"/>',h:'<polygon points="50,4 91,27 91,73 50,96 9,73 9,27" fill="none" stroke="currentColor" stroke-width="5"/>',t:'<polygon points="50,8 94,88 6,88" fill="currentColor" fill-opacity=".45"/>',w:'<path d="M0 50 Q12.5 20 25 50 T50 50 T75 50 T100 50" fill="none" stroke="currentColor" stroke-width="5" stroke-linecap="round"/>',d:'<g fill="currentColor"><circle cx="20" cy="20" r="6"/><circle cx="50" cy="20" r="6"/><circle cx="80" cy="20" r="6"/><circle cx="20" cy="50" r="6"/><circle cx="50" cy="50" r="6"/><circle cx="80" cy="50" r="6"/><circle cx="20" cy="80" r="6"/><circle cx="50" cy="80" r="6"/><circle cx="80" cy="80" r="6"/></g>',p:'<path d="M50 12V88M12 50H88" stroke="currentColor" stroke-width="12" stroke-linecap="round" fill="none"/>',g:'<polygon points="50,4 96,50 50,96 4,50" fill="currentColor" fill-opacity=".45"/>',o:'<path d="M10 90A80 80 0 0 1 90 10M28 90A62 62 0 0 1 90 28M46 90A44 44 0 0 1 90 46" fill="none" stroke="currentColor" stroke-width="6" stroke-linecap="round"/>'};
var SHN={c:"دایره",r:"حلقه",s:"مربع گرد",h:"شش‌ضلعی",t:"مثلث",w:"موج",d:"نقطه",p:"بعلاوه",g:"لوزی",o:"کمان"};
var KEYS=["th","cu","md","st","ao","bl","rr","sa","nz","sh","sp","shT","zm","rv","gl","fx","an"];
function mixc(c,p,w){return"color-mix(in srgb,"+c+" "+p+"%,"+w+")"}
function curTh(){return CF.cu||TH[CF.th]||TH["شفق نئون"]}
function isLt(){var t=curTh();if(CF.md==="lt")return 1;if(CF.md==="dk")return 0;if(CF.md==="sys")return(window.matchMedia&&matchMedia("(prefers-color-scheme: light)").matches)?1:0;return t[5]?1:0}
function shp(){var el=$("shp");if(!el)return;var T=(CF.shT&&CF.shT.length?CF.shT:Object.keys(SHT)),N=CF.sh?Math.min(48,+CF.sp||0):0,k=N+"|"+T.join("");if(el.getAttribute("data-k")===k)return;el.setAttribute("data-k",k);
var seed=11,rnd=function(){seed=seed*16807%2147483647;return(seed-1)/2147483646},cl=["a","b","c","up","go"],s="",i;
for(i=0;i<N;i++){var ty=T[i%T.length],z=26+rnd()*96,x=rnd()*104-4,y=rnd()*104-4;s+='<i class="sh" style="left:'+x.toFixed(1)+'%;top:'+y.toFixed(1)+'%;width:'+z.toFixed(0)+'px;height:'+z.toFixed(0)+'px;--c:var(--'+cl[(i*3+1)%5]+');--r:'+Math.round(rnd()*360)+'deg;--dx:'+Math.round(rnd()*80-40)+'px;--dy:'+Math.round(rnd()*80-40)+'px;opacity:'+(.14+rnd()*.24).toFixed(2)+';animation-duration:'+(14+rnd()*24).toFixed(1)+'s;animation-delay:-'+(rnd()*20).toFixed(1)+'s"><svg viewBox="0 0 100 100">'+SHT[ty]+'</svg></i>'}
el.innerHTML=s}
function ap(){var t=curTh(),r=document.documentElement.style,h=document.documentElement,lt=isLt(),flag=!!t[5],st=CF.st||"w11",b1=t[0],b2=t[1];
if(lt&&!flag){b1=mixc(t[2],7,"#ffffff");b2=mixc(t[3],16,"#f4f7fc")}else if(!lt&&flag){b1=mixc(t[2],10,"#0b0f1a");b2=mixc(t[3],18,"#121a2e")}
r.setProperty("--bg1",b1);r.setProperty("--bg2",b2);["a","b","c"].forEach(function(k,i){r.setProperty("--"+k,t[i+2])});
r.setProperty("--gl",CF.gl);r.setProperty("--bl",CF.bl+"px");r.setProperty("--r",CF.rr+"px");r.setProperty("--ao",(CF.ao||62)/100);r.setProperty("--sa",(CF.sa||160)/100);r.setProperty("--zm",(CF.zm||100)/100);
r.setProperty("--rvc",!CF.rv?"transparent":lt?"rgb(255 255 255/.6)":"rgb(255 255 255/.12)");
if(lt&&st==="neon")st="w11";
h.classList.toggle("lt",!!lt);h.classList.toggle("nz",!!CF.nz);h.setAttribute("data-look",st);
h.setAttribute("data-layout",CF.layout||"classic");
h.setAttribute("data-nav",CF.nav||"bottom");
h.setAttribute("data-density",CF.density||"comfy");
h.setAttribute("data-card",CF.card||"glass");
h.setAttribute("data-tabs",CF.tabs||"pill");
h.setAttribute("data-menu",CF.menu||"round");
h.setAttribute("data-group",CF.group||"decision");
h.classList.toggle("no-accent",CF.accentBar===0);
h.classList.toggle("no-hero",CF.hero===0||CF.hero==="off");
document.body.setAttribute("data-layout",CF.layout||"classic");

document.body.classList.toggle("nobg",!CF.fx);document.body.classList.toggle("calm",!CF.an);
var m=document.querySelector('meta[name="theme-color"]');if(m)m.setAttribute("content",lt?"#f3f6fb":"#050816");
shp()}
if(window.matchMedia)try{matchMedia("(prefers-color-scheme: light)").addEventListener("change",function(){if(CF.md==="sys")ap()})}catch(e){}
document.addEventListener("pointermove",function(e){if(!CF.rv)return;var t=e.target.closest&&e.target.closest(".glass");if(!t)return;var r=t.getBoundingClientRect(),z=+getComputedStyle(document.querySelector(".wrap")).zoom||1;t.style.setProperty("--mx",((e.clientX-r.left)/z)+"px");t.style.setProperty("--my",((e.clientY-r.top)/z)+"px")},{passive:true});
document.addEventListener("pointerout",function(e){var t=e.target.closest&&e.target.closest(".glass");if(t&&!t.contains(e.relatedTarget)){t.style.removeProperty("--mx");t.style.removeProperty("--my")}},{passive:true});

/* ---------- ready-made presets ---------- */
var PR=[
{n:"ویندوز ۱۱ روشن",th:"ویندوز ۱۱ روشن",md:"th",st:"w11",ao:62,bl:28,rr:12,sa:160,gl:.6,sp:18},
{n:"میکا آسمانی",th:"Mica آسمانی",md:"th",st:"mica",ao:70,bl:14,rr:10,sa:120,gl:.4,sp:14},
{n:"اکریلیک شفاف",th:"نعنای یخی",md:"th",st:"w11",ao:34,bl:40,rr:14,sa:200,gl:.5,sp:28},
{n:"گل‌صورتی یخی",th:"گل‌صورتی",md:"th",st:"frost",ao:50,bl:34,rr:26,sa:190,gl:.6,sp:26},
{n:"کهربای گرم",th:"کهربای گرم",md:"th",st:"w11",ao:58,bl:26,rr:16,sa:170,gl:.5,sp:22},
{n:"اسطوخودوس",th:"اسطوخودوس",md:"th",st:"frost",ao:46,bl:36,rr:22,sa:200,gl:.6,sp:30},
{n:"ویندوز ۱۱ تیره",th:"ویندوز ۱۱ تیره",md:"th",st:"w11",ao:55,bl:30,rr:12,sa:160,gl:.8,sp:16},
{n:"نئون اصلی",th:"شفق نئون",md:"dk",st:"neon",ao:60,bl:18,rr:20,sa:160,gl:1,sp:10},
{n:"شب قطبی",th:"شب قطبی",md:"dk",st:"frost",ao:50,bl:32,rr:14,sa:170,gl:.7,sp:20},
{n:"زغال اتمی",th:"زغال اتمی",md:"dk",st:"mica",ao:58,bl:22,rr:10,sa:120,gl:.5,sp:12},
{n:"نئون سبز تیره",th:"نئون سبز تیره",md:"dk",st:"neon",ao:55,bl:16,rr:18,sa:180,gl:1.1,sp:14},
{n:"ارغوانی تاریک",th:"ارغوانی تاریک",md:"dk",st:"frost",ao:52,bl:30,rr:20,sa:190,gl:.8,sp:22},
{n:"کهکشان آبی",th:"کهکشان آبی",md:"dk",st:"w11",ao:56,bl:26,rr:14,sa:160,gl:.9,sp:16},
{n:"خون‌سیاه",th:"خون‌سیاه",md:"dk",st:"neon",ao:54,bl:18,rr:16,sa:150,gl:1,sp:12},
{n:"زمرد تاریک",th:"زمرد تاریک",md:"dk",st:"mica",ao:50,bl:24,rr:12,sa:140,gl:.7,sp:15},
{n:"کروم شب",th:"کروم شب",md:"dk",st:"w11",ao:60,bl:28,rr:12,sa:130,gl:.6,sp:10},
{n:"آبی عمیق OLED",th:"آبی عمیق OLED",md:"dk",st:"neon",ao:48,bl:20,rr:16,sa:170,gl:1.2,sp:18}];
function prThumb(p,i){var t=TH[p.th]||TH["شفق نئون"],lt=p.md==="lt"||(p.md==="th"&&!!t[5]),b1=lt?t[0]:(t[5]?mixc(t[2],10,"#0b0f1a"):t[0]),b2=lt?t[1]:(t[5]?mixc(t[3],18,"#121a2e"):t[1]),fill=lt?"rgba(255,255,255,"+(p.ao/100)+")":"rgba(28,30,42,"+(p.ao/100)+")",ln=lt?"rgba(255,255,255,.8)":"rgba(255,255,255,.18)",neon=p.st==="neon";
return'<button class="th pr" data-pre="'+i+'"><div class="thp" style="background:linear-gradient(135deg,'+b1+','+b2+')"><em style="width:30px;height:30px;border-radius:50%;background:'+t[2]+';opacity:.55;left:6px;top:4px"></em><em style="width:24px;height:24px;border-radius:6px;background:'+t[4]+';opacity:.55;right:8px;bottom:3px;transform:rotate(20deg)"></em><em style="width:0;height:0;border-left:11px solid transparent;border-right:11px solid transparent;border-bottom:19px solid '+t[3]+';opacity:.5;right:30px;top:4px"></em><em style="inset:11px 9px;border-radius:'+Math.min(14,p.rr)+'px;background:'+(neon?"rgba(255,255,255,.12)":fill)+';border:1px solid '+(neon?t[2]:ln)+';backdrop-filter:blur(3px)"></em></div>'+esc(p.n||"نمونه")+"</button>"}
function presetCard(){var my=CF.my||[];return card("نمونه‌های آماده (یک‌لمسی)",'<div class="themes">'+PR.map(prThumb).join("")+my.map(function(p,i){return prThumb(Object.assign({ao:60,rr:16,st:"w11",md:"th"},p),"m"+i)}).join("")+'</div><div class="row" style="flex-wrap:wrap;margin-top:10px"><button class="btn" data-act="savep">ذخیره تنظیمات فعلی به‌عنوان نمونه من</button>'+(my.length?'<button class="btn g" data-act="clrp">حذف نمونه‌های من</button>':"")+"</div>","c")}
function lookCard(){var mo=[["th","طبق تم"],["lt","روشن"],["dk","تیره"],["sys","سیستم"]],sy=[["w11","اکریلیک ویندوز ۱۱"],["mica","میکا"],["frost","یخی"],["solid","تخت"],["neon","نئونی"]],T=CF.shT&&CF.shT.length?CF.shT:Object.keys(SHT),AC=["#0067c0","#0a84ff","#7c3aed","#e0408f","#e11d48","#ea580c","#d97706","#0f9d8a","#16a34a","#00b7c3","#64748b","#60cdff","#22d3ee","#f472b6","#a3e635"];
var sl=function(k,l,mn,mx,sp){return"<label>"+l+'<input type="range" data-k="'+k+'" min="'+mn+'" max="'+mx+'" step="'+(sp||1)+'" value="'+CF[k]+'"><b>'+CF[k]+"</b></label>"},sw=function(k,l){return"<label>"+l+'<button class="sw'+(CF[k]?" on":"")+'" data-sw="'+k+'"></button></label>'};
var lay=[["classic","کلاسیک"],["compact","فشرده"],["wide","عریض"],["magazine","مجله‌ای"]];
var nav=[["bottom","منوی پایین"],["top","منوی بالا"]];
var dens=[["comfy","عادی"],["dense","فشرده"],["airy","باز"]];
var cards=[["glass","شیشه‌ای"],["solid","توپر"],["outline","خطی"],["flat","تخت"]];
var tabs=[["pill","کپسول"],["underline","زیرخط"],["square","مربعی"]];
var menus=[["round","گرد"],["square","مربعی"],["pill","کپسولی"]];
var groups=[["decision","بر اساس تصمیم"],["tf","بر اساس تایم‌فریم"],["score","بر اساس امتیاز"]];
return card("ظاهر و نمایش",'<div class="sub">حالت روشن/تیره</div>'+chips(mo,CF.md||"th","data-mod")+'<div class="sub" style="margin-top:6px">سبک شیشه</div>'+chips(sy,CF.st||"w11","data-sty")+'<div class="ctrl" style="margin-top:10px">'+sl("ao","شفافیت پنجره‌ها ٪",15,98)+sl("bl","شدت بلور (اکریلیک)",0,60)+sl("sa","اشباع رنگ پشت شیشه ٪",100,260)+sl("rr","گردی گوشه‌ها",4,32)+sl("zm","اندازه رابط ٪",80,130)+sl("gl","شدت درخشش",0,2,.1)+sw("nz","بافت نویز اکریلیک")+sw("rv","نور Reveal هنگام لمس")+"</div>","a")
+card("چینش و ساختار رابط",'<div class="sub">چیدمان کلی</div>'+chips(lay,CF.layout||"classic","data-lay")+'<div class="sub" style="margin-top:6px">جایگاه منو</div>'+chips(nav,CF.nav||"bottom","data-navx")+'<div class="sub" style="margin-top:6px">تراکم</div>'+chips(dens,CF.density||"comfy","data-dens")+'<div class="sub" style="margin-top:6px">شکل کارت‌ها</div>'+chips(cards,CF.card||"glass","data-cardx")+'<div class="sub" style="margin-top:6px">شکل تب‌ها</div>'+chips(tabs,CF.tabs||"pill","data-tabx")+'<div class="sub" style="margin-top:6px">شکل دکمه‌های منو</div>'+chips(menus,CF.menu||"round","data-menux")+'<div class="sub" style="margin-top:6px">دسته‌بندی لیست‌ها</div>'+chips(groups,CF.group||"decision","data-groupx")+'<div class="ctrl" style="margin-top:8px">'+sw("accentBar","نوار رنگی کارت‌ها")+sw("hero","نوار قیمت زنده بالا")+"</div>","b")
+card("اشکال و شماتیک پس‌زمینه",'<div class="ctrl">'+sw("sh","نمایش اشکال")+sl("sp","تعداد اشکال",0,48)+'</div><div class="sub" style="margin:8px 0 4px">نوع اشکال</div><div class="shpgrid">'+Object.keys(SHT).map(function(k){return'<button class="chip'+(T.indexOf(k)>=0?" on":"")+'" data-sht="'+k+'">'+SHN[k]+"</button>"}).join("")+"</div>","b")
+card("رنگ تأکید (Accent)",'<div class="shpgrid">'+AC.map(function(c){return'<button class="chip" data-acc="'+c+'" style="width:34px;height:34px;padding:0;border-radius:50%;background:'+c+';border:2px solid #fff8"></button>'}).join("")+"</div>","go")}
function pst(){return presetCard()+lookCard()+pst0()}

/* ---------- schematic tab ---------- */
function dcol(d){return d==="LONG"?"var(--up)":d==="SHORT"?"var(--dn)":"var(--go)"}
function dsym(d){return d==="LONG"?"▲":d==="SHORT"?"▼":"•"}
function hexp(cx,cy,r,rot){var a=[],k;for(k=0;k<6;k++){var q=Math.PI/180*(60*k+(rot==null?-30:rot));a.push((cx+r*Math.cos(q)).toFixed(1)+","+(cy+r*Math.sin(q)).toFixed(1))}return a.join(" ")}
function scFlow(){var r=cur(),F=(r&&r.funnel)||{},stages=F.stages||[],style=(document.documentElement.getAttribute("data-schematic")||"flow");
var LABELS=[["data","داده"],["safety","ایمنی"],["regime","رژیم"],["confluence","هم‌گرایی"],["thresholds","آستانه"],["urgency","فوریت"]];
if(!stages.length){stages=LABELS.map(function(x,i){return{id:x[0],label:x[1],state:i<2?"pass":"skip",ok:i<2,detail:""}})}
var w=340,h=110,n=stages.length,gap=w/Math.max(n,1),s="";
function shape(i,x,y,col,st){
  var op=st==="fail"?".35":(st==="skip"?".2":".55");
  if(style==="circuit"||style==="orbital")return'<circle cx="'+x+'" cy="'+y+'" r="20" fill="'+col+'" fill-opacity="'+op+'" stroke="'+col+'" stroke-width="'+(st==="pass"?2.4:1.2)+'"/>';
  if(style==="hex")return'<polygon points="'+hexp(x,y,22)+'" fill="'+col+'" fill-opacity="'+op+'" stroke="'+col+'" stroke-width="'+(st==="pass"?2.2:1.2)+'"/>';
  if(style==="diamond")return'<polygon points="'+x+","+(y-22)+" "+(x+22)+","+y+" "+x+","+(y+22)+" "+(x-22)+","+y+'" fill="'+col+'" fill-opacity="'+op+'" stroke="'+col+'"/>';
  if(style==="chevron")return'<polygon points="'+(x-18)+","+(y-18)+" "+(x+8)+","+(y-18)+" "+(x+20)+","+y+" "+(x+8)+","+(y+18)+" "+(x-18)+","+(y+18)+" "+(x-8)+","+y+'" fill="'+col+'" fill-opacity="'+op+'" stroke="'+col+'"/>';
  if(style==="neural")return'<rect x="'+(x-20)+'" y="'+(y-16)+'" width="40" height="32" rx="12" fill="'+col+'" fill-opacity="'+op+'" stroke="'+col+'" stroke-width="'+(st==="pass"?2.2:1.2)+'"/>';
  return'<rect x="'+(x-22)+'" y="'+(y-18)+'" width="44" height="36" rx="12" fill="'+col+'" fill-opacity="'+op+'" stroke="'+col+'" stroke-width="'+(st==="pass"?2.2:1.2)+'"/>';
}
stages.forEach(function(st,i){var x=gap*i+gap/2,y=42,state=st.state||(st.ok?"pass":"fail");
  var col=state==="pass"?"var(--up)":(state==="fail"?"var(--dn)":"var(--go)");
  if(i)s+='<line x1="'+(gap*(i-1)+gap/2+18)+'" y1="'+y+'" x2="'+(x-18)+'" y2="'+y+'" stroke="'+col+'" stroke-opacity=".45" stroke-width="1.6" stroke-dasharray="'+(state==="skip"?"3 4":"0")+'"/>';
  s+='<g class="nodeg">'+shape(i,x,y,col,state)+'<text x="'+x+'" y="'+(y+3)+'" text-anchor="middle" font-size="9" font-weight="700" fill="#fff">'+esc(st.label||st.id)+'</text>';
  if(st.detail)s+='<text x="'+x+'" y="'+(y+34)+'" text-anchor="middle" font-size="7.5" fill="#8e98c9">'+esc(String(st.detail).slice(0,14))+'</text>';
  s+='</g>'});
var meta="";
if(r){meta='<div class="sub" style="margin-top:8px">'+esc(r.symbol)+' · قیف '+(F.quality||"—")+' · اقدام '+(F.action||"—")+' · امتیاز '+((F.score!=null)?Math.round(F.score*100):"—")+' · فوریت '+((F.urgency!=null)?Math.round(F.urgency*100)+"%":"—")+"</div>";
if(F.reasons&&F.reasons.length)meta+='<div class="sub">'+F.reasons.slice(0,4).map(esc).join(" · ")+"</div>"}
return'<svg class="scs" viewBox="0 0 '+w+" "+h+'" width="100%">'+s+"</svg>"+meta}

function tm(a,x,y,w,h,out){if(!a.length)return;if(a.length===1){out.push([a[0],x,y,w,h]);return}var tot=0,i=0,acc=0,wa=0;a.forEach(function(q){tot+=q.w});while(i<a.length-2&&acc+a[i].w<tot/2){acc+=a[i].w;i++}var A=a.slice(0,i+1),B=a.slice(i+1);A.forEach(function(q){wa+=q.w});wa/=tot;if(w>=h){tm(A,x,y,w*wa,h,out);tm(B,x+w*wa,y,w*(1-wa),h,out)}else{tm(A,x,y,w,h*wa,out);tm(B,x,y+h*wa,w,h*(1-wa),out)}}
function scTree(){var a=S.rows.slice().sort(function(x,y){return y.conf-x.conf}).slice(0,28).map(function(r){return{r:r,w:Math.max(8,+r.conf||0)}}),out=[];tm(a,0,0,340,220,out);
return'<svg class="scs" viewBox="0 0 340 220">'+out.map(function(o){var r=o[0].r,x=o[1],y=o[2],w=o[3],h=o[4],c=r.change>=0?"var(--up)":"var(--dn)",op=Math.min(.8,.22+Math.abs(r.change)/9);return'<g class="nodeg" data-s="'+esc(r.symbol)+'"><rect x="'+(x+1)+'" y="'+(y+1)+'" width="'+Math.max(0,w-2)+'" height="'+Math.max(0,h-2)+'" rx="7" fill="'+c+'" fill-opacity="'+op.toFixed(2)+'" stroke="'+dcol(r.decision)+'" stroke-width="'+(r.symbol===S.sel?2.8:1)+'"/>'+(w>34&&h>22?'<text x="'+(x+w/2)+'" y="'+(y+h/2-1)+'" text-anchor="middle" font-size="'+Math.min(13,w/4.2).toFixed(1)+'" font-weight="700" fill="#fff">'+esc(r.symbol.split("/")[0])+'</text><text x="'+(x+w/2)+'" y="'+(y+h/2+10)+'" text-anchor="middle" font-size="8" fill="#fff" fill-opacity=".85">'+(r.change>0?"+":"")+(+r.change).toFixed(1)+"٪</text>":"")+"</g>"}).join("")+"</svg>"}
function scBub(){var R=S.rows.slice(0,60),mc=Math.max.apply(0,R.map(function(r){return Math.abs(+r.change||0)}).concat([1])),w=340,h=210,X=function(v){return 26+(v+mc)/(2*mc)*(w-44)},Y=function(v){return h-20-Math.max(0,Math.min(100,v))/100*(h-36)},s="";
s+='<rect x="'+X(0)+'" y="6" width="'+(w-18-X(0))+'" height="'+(h-26)+'" fill="var(--up)" opacity=".08" rx="8"/><rect x="26" y="6" width="'+(X(0)-26)+'" height="'+(h-26)+'" fill="var(--dn)" opacity=".08" rx="8"/><line x1="'+X(0)+'" x2="'+X(0)+'" y1="6" y2="'+(h-20)+'" stroke="#ffffff33" stroke-dasharray="4 4"/>';
[25,50,75].forEach(function(v){s+='<line x1="26" x2="'+(w-18)+'" y1="'+Y(v)+'" y2="'+Y(v)+'" stroke="#ffffff14" stroke-dasharray="3 5"/><text x="4" y="'+(Y(v)+3)+'" font-size="8" fill="#8e98c9">'+v+"</text>"});
R.forEach(function(r){var x=X(+r.change||0),y=Y(+r.conf||0),z=4+Math.max(0,Math.min(100,+r.score||0))/100*9,sel=r.symbol===S.sel;s+='<g class="nodeg" data-s="'+esc(r.symbol)+'"><circle cx="'+x+'" cy="'+y+'" r="'+z.toFixed(1)+'" fill="'+dcol(r.decision)+'" fill-opacity=".5" stroke="'+dcol(r.decision)+'" stroke-width="'+(sel?2.6:1)+'"/>'+(sel||z>9?'<text x="'+x+'" y="'+(y-z-3)+'" text-anchor="middle" font-size="8" font-weight="700" fill="#fff">'+esc(r.symbol.split("/")[0])+"</text>":"")+"</g>"});
return'<svg class="scs" viewBox="0 0 '+w+" "+h+'">'+s+'<text x="'+(w-18)+'" y="'+(h-5)+'" text-anchor="end" font-size="8" fill="#8e98c9">تغییر ٪ ←</text><text x="30" y="16" font-size="8" fill="#8e98c9">اطمینان ↑ · اندازه = امتیاز</text></svg>'}
function scHex(){var R=S.rows.slice().sort(function(a,b){return b.conf-a.conf}).slice(0,30),cols=6,sz=26,dx=sz*1.73,dy=sz*1.5,s="";R.forEach(function(r,i){var row=Math.floor(i/cols),col=i%cols,cx=38+col*dx+(row%2?dx/2:0),cy=28+row*dy,c=dcol(r.decision);s+='<g class="nodeg" data-s="'+esc(r.symbol)+'"><polygon points="'+hexp(cx,cy,sz*.92)+'" fill="'+c+'" fill-opacity="'+(.18+(+r.conf||0)/170).toFixed(2)+'" stroke="'+c+'" stroke-width="'+(r.symbol===S.sel?2.8:1)+'"/><text x="'+cx+'" y="'+(cy-1)+'" text-anchor="middle" font-size="9" font-weight="700" fill="#fff">'+esc(r.symbol.split("/")[0].slice(0,5))+'</text><text x="'+cx+'" y="'+(cy+9)+'" text-anchor="middle" font-size="7.5" fill="'+c+'">'+dsym(r.decision)+" "+Math.round(+r.conf||0)+"</text></g>"});
return'<svg class="scs" viewBox="0 0 340 '+(Math.ceil(R.length/cols)*dy+26).toFixed(0)+'">'+s+"</svg>"}
function scOrb(){var r0=cur(),R=S.rows.filter(function(r){return!r0||r.symbol!==r0.symbol}).sort(function(a,b){return b.conf-a.conf}).slice(0,18),cx=170,cy=125,rg=[48,80,112],s="",ps=[];
rg.forEach(function(r,i){s+='<circle class="fl" cx="'+cx+'" cy="'+cy+'" r="'+r+'" fill="none" stroke="#ffffff22" stroke-width="1" style="animation-duration:'+(3+i*1.5)+'s"/>'});
R.forEach(function(r,i){var ring=i<5?0:i<11?1:2,idx=ring===0?i:ring===1?i-5:i-11,n=ring===0?5:ring===1?6:7,an=idx/n*6.2832+ring*.6-1.2,x=cx+Math.cos(an)*rg[ring],y=cy+Math.sin(an)*rg[ring]*.92;ps.push([r,x,y]);s+='<line x1="'+cx+'" y1="'+cy+'" x2="'+x.toFixed(1)+'" y2="'+y.toFixed(1)+'" stroke="'+dcol(r.decision)+'" stroke-opacity=".18"/>'});
ps.forEach(function(p){var r=p[0],c=dcol(r.decision),z=6+(+r.conf||0)/100*7;s+='<g class="nodeg" data-s="'+esc(r.symbol)+'"><circle cx="'+p[1].toFixed(1)+'" cy="'+p[2].toFixed(1)+'" r="'+z.toFixed(1)+'" fill="'+c+'" fill-opacity=".45" stroke="'+c+'" stroke-width="1.4"/><text x="'+p[1].toFixed(1)+'" y="'+(p[2]+z+9).toFixed(1)+'" text-anchor="middle" font-size="8" fill="#fff">'+esc(r.symbol.split("/")[0])+"</text></g>"});
if(r0){var c0=dcol(r0.decision);s+='<g class="glow" style="color:'+c0+'"><circle cx="'+cx+'" cy="'+cy+'" r="27" fill="'+c0+'" fill-opacity=".25" stroke="'+c0+'" stroke-width="2"/></g><text x="'+cx+'" y="'+(cy-1)+'" text-anchor="middle" font-size="12" font-weight="800" fill="#fff">'+esc(r0.symbol.split("/")[0])+'</text><text x="'+cx+'" y="'+(cy+11)+'" text-anchor="middle" font-size="8" fill="'+c0+'">'+esc(r0.decision)+"</text>"}
return'<svg class="scs" viewBox="0 0 340 250">'+s+"</svg>"}
function scTfRings(){var rs=[56,44,32,20],s="",lg="",cc=[["LONG","var(--up)"],["SHORT","var(--dn)"],["WAIT","var(--go)"]];
TFS.forEach(function(t,i){var r=rs[i],c=2*Math.PI*r,n={LONG:0,SHORT:0,WAIT:0},o=0;S.rows.forEach(function(x){var d=((x.tfs||{})[t]||{}).dir||"WAIT";if(n[d]==null)d="WAIT";n[d]++});var tot=n.LONG+n.SHORT+n.WAIT||1;s+='<circle cx="70" cy="70" r="'+r+'" fill="none" stroke="#ffffff14" stroke-width="9"/>';
cc.forEach(function(q){var L=c*n[q[0]]/tot;if(L>0)s+='<circle class="glow" style="color:'+q[1]+'" cx="70" cy="70" r="'+r+'" fill="none" stroke="'+q[1]+'" stroke-width="9" stroke-dasharray="'+Math.max(0,L-1.5).toFixed(1)+" "+(c-L+1.5).toFixed(1)+'" stroke-dashoffset="'+(-o).toFixed(1)+'" transform="rotate(-90 70 70)"/>';o+=L});
lg+='<text x="160" y="'+(30+i*28)+'" font-size="10" font-weight="700" fill="#fff">'+t+'</text><text x="196" y="'+(30+i*28)+'" font-size="9" fill="var(--up)">▲'+n.LONG+'</text><text x="236" y="'+(30+i*28)+'" font-size="9" fill="var(--dn)">▼'+n.SHORT+'</text><text x="276" y="'+(30+i*28)+'" font-size="9" fill="var(--go)">•'+n.WAIT+'</text><line x1="160" x2="316" y1="'+(36+i*28)+'" y2="'+(36+i*28)+'" stroke="#ffffff14"/>'});
return'<svg class="scs" viewBox="0 0 340 140">'+s+'<text x="70" y="74" text-anchor="middle" font-size="15" font-weight="800" fill="#fff">'+S.rows.length+"</text>"+lg+"</svg>"}
function scDecide(){var r=cur();if(!r)return'<div class="sub">ارزی انتخاب نشده</div>';var s="",dc=dcol(r.decision);
s+='<rect x="115" y="8" width="110" height="42" rx="21" fill="'+dc+'" fill-opacity=".18" stroke="'+dc+'" stroke-width="1.8"/><text x="170" y="26" text-anchor="middle" font-size="13" font-weight="800" fill="#fff">'+esc(r.symbol)+'</text><text x="170" y="40" text-anchor="middle" font-size="8.5" fill="#8e98c9">'+esc(r.grade_fa||r.grade||"")+"</text>";
TFS.forEach(function(t,i){var v=(r.tfs||{})[t]||{},d=v.dir||"WAIT",c=dcol(d),x=48+i*81;s+='<path class="fl" d="M170,50 C170,76 '+x+',72 '+x+',98" fill="none" stroke="'+c+'" stroke-width="'+(1+(+v.conf||0)/40).toFixed(1)+'" stroke-opacity=".75"/><rect x="'+(x-31)+'" y="98" width="62" height="52" rx="13" fill="'+c+'" fill-opacity=".16" stroke="'+c+'"/><text x="'+x+'" y="116" text-anchor="middle" font-size="10.5" font-weight="700" fill="#fff">'+t+'</text><text x="'+x+'" y="130" text-anchor="middle" font-size="9" fill="'+c+'">'+dsym(d)+" "+d+'</text><text x="'+x+'" y="143" text-anchor="middle" font-size="8.5" fill="#8e98c9">'+(v.conf!=null?v.conf:"—")+'٪</text><path d="M'+x+',150 C'+x+',176 170,170 170,192" fill="none" stroke="'+c+'" stroke-opacity=".4" stroke-dasharray="3 4"/>'});
s+='<g class="glow" style="color:'+dc+'"><polygon points="'+hexp(170,216,30)+'" fill="'+dc+'" fill-opacity=".22" stroke="'+dc+'" stroke-width="2"/></g><text x="170" y="214" text-anchor="middle" font-size="11" font-weight="800" fill="#fff">'+esc(r.decision)+'</text><text x="170" y="227" text-anchor="middle" font-size="8.5" fill="#8e98c9">اطمینان '+Math.round(+r.conf||0)+"</text>";
return'<svg class="scs" viewBox="0 0 340 250">'+s+"</svg>"}
function psc(){if(!S.rows.length)return card("شماتیک",'<div class="sub">در حال دریافت داده بازار…</div>');var r=cur(),nm=r?r.symbol.split("/")[0]:"";
return chips(S.rows.map(function(x){return[x.symbol,x.symbol.split("/")[0]]}),S.sel,"data-s")+card("قیف فرصت · مراحل زنده",scFlow(),"a")+card("نقشه درختی ارزها · اندازه = اطمینان",scTree(),"b")+card("بابل‌چارت · تغییر × اطمینان",scBub(),"c")+card("لانه‌زنبوری سیگنال‌ها",scHex(),"go")+card("مدار ارزها دور "+nm,scOrb(),"b")+card("حلقه‌های تایم‌فریم",scTfRings(),"a")+card("درخت تصمیم "+nm,scDecide(),"up")}

var S={rows:[],sel:null,tf:"1h",tab:"ov",kl:{},fc:{},fin:{},ev:null,pd:30,evf:"ALL",q:"",busy:0,lr:null,coin:null,ctab:"ov",zoom:1,pan:0,tool:"pan",draws:{},drawTmp:null,cs:null,vl:{}};
var TABS=[["ov","داشبورد","◈"],["dt","جزئیات","▤"],["tp","برترین‌ها","★"],["ch","نمودار","◭"],["ai","هوش","✦"],["mk","بازار","▦"],["pf","ارزیابی","◎"],["sc","شماتیک","⬡"],["st","تنظیم","⚙"]];
function cur(){return S.rows.filter(function(r){return r.symbol===S.sel})[0]||S.rows[0]||null}
function pf(v){v=+v;return v>=100?v.toLocaleString("en-US",{maximumFractionDigits:2}):v.toLocaleString("en-US",{maximumFractionDigits:6})}
function kk(){return S.sel+"|"+S.tf}
function hs(t){t=String(t).replace(/<[^>]*>/g,"");var h=0,i;for(i=0;i<t.length;i++)h=(h*31+t.charCodeAt(i))>>>0;return h.toString(36)}
function card(t,b,k){var id="w"+hs(t),c=CF.cl||{},ord=(CF.po||{})[id];return'<section class="card glass win drag-panel'+(c[id]?" shut":"")+(S.mx===id?" max":"")+(/نمودار شمعی|منحنی سرمایه/.test(t)?" wide":"")+'" data-pid="'+id+'" style="--k:var(--'+(k||"a")+');'+(ord!=null?'order:'+ord+';':'')+'"><header class="wh drag-handle" title="بکشید تا جابه‌جا شود"><h3><span class="d"></span><span class="drag-grip" aria-hidden="true">⠿</span> '+t+'</h3><span class="wc"><button data-cl="'+id+'" title="جمع / باز">▾</button><button data-mx="'+id+'" title="تمام‌صفحه">⤢</button></span></header><div class="wb">'+b+"</div></section>"}
function chips(a,on,att){return'<div class="tabs">'+a.map(function(x){return'<button class="chip'+(x[0]===on?" on":"")+'" '+att+'="'+esc(x[0])+'">'+esc(x[1])+"</button>"}).join("")+"</div>"}
function ring(v,col,l){v=Math.round(+v||0);var r=26,c=2*Math.PI*r;return'<div style="text-align:center;font-size:11px;color:var(--mu)"><svg class="glow" style="color:'+col+'" width="64" height="64" viewBox="0 0 68 68"><circle cx="34" cy="34" r="'+r+'" fill="none" stroke="#ffffff18" stroke-width="7"/><circle cx="34" cy="34" r="'+r+'" fill="none" stroke="currentColor" stroke-width="7" stroke-linecap="round" stroke-dasharray="'+c*Math.min(v,100)/100+" "+c+'" transform="rotate(-90 34 34)"/><text x="34" y="39" text-anchor="middle" font-size="15" font-weight="700" fill="#fff">'+v+"</text></svg><div>"+l+"</div></div>"}
function gauge(v){v=Math.max(0,Math.min(100,+v||0));var L=188.5;return'<svg viewBox="0 0 140 90" width="100%"><defs><linearGradient id="gg"><stop offset="0" stop-color="var(--dn)"/><stop offset=".5" stop-color="var(--go)"/><stop offset="1" stop-color="var(--up)"/></linearGradient></defs><path d="M10,72 A60,60 0 0 1 130,72" fill="none" stroke="#ffffff18" stroke-width="11" stroke-linecap="round"/><path class="glow" style="color:var(--go)" d="M10,72 A60,60 0 0 1 130,72" fill="none" stroke="url(#gg)" stroke-width="11" stroke-linecap="round" stroke-dasharray="'+L*v/100+" "+L+'"/><g style="transform-origin:70px 72px;transform:rotate('+(v*1.8-90)+'deg);transition:transform 1s"><line x1="70" y1="72" x2="70" y2="26" stroke="#fff" stroke-width="3" stroke-linecap="round"/></g><circle cx="70" cy="72" r="6" fill="#fff"/><text x="70" y="88" text-anchor="middle" font-size="11" font-weight="700" fill="#fff">'+Math.round(v)+"</text></svg>"}
function neural(act){var X=[30,115,200,285],N=[3,5,5,2],P=X.map(function(x,l){return Array.from({length:N[l]},function(_,i){return[x,20+(i+.5)*150/N[l]]})}),s="",cl=["a","b","c","up"];
for(var l=0;l<3;l++)P[l].forEach(function(a,i){P[l+1].forEach(function(b,j){s+='<line class="fl" style="animation-duration:'+(1+((i+j)%4)*.4)+'s" x1="'+a[0]+'" y1="'+a[1]+'" x2="'+b[0]+'" y2="'+b[1]+'" stroke="var(--'+cl[l]+')" stroke-opacity=".5"/>'})});
P.forEach(function(L,l){L.forEach(function(q,i){var on=l===3&&((act==="LONG"&&i===0)||(act==="SHORT"&&i===1));s+='<circle class="nd glow" style="color:var(--'+cl[l]+');animation-delay:'+(l+i)*.3+'s" cx="'+q[0]+'" cy="'+q[1]+'" r="'+(l===3?(on?12:8):6)+'" fill="var(--'+cl[l]+')"/>';if(l===3)s+='<text x="'+(q[0]+15)+'" y="'+(q[1]+3)+'" font-size="9" fill="#fff">'+["LONG","SHORT"][i]+"</text>"})});
return'<svg viewBox="0 0 345 190" width="100%">'+["ورودی","لایه ۱","لایه ۲","خروجی"].map(function(t,i){return'<text x="'+X[i]+'" y="10" text-anchor="middle" font-size="8" fill="#8e98c9">'+t+"</text>"}).join("")+s+"</svg>"}
function chart(){var k=kk(),all=S.kl[k]||[],F=S.fc[k]||{},fc=F.candles||[];
if(!all.length)return'<div class="sub">در حال بارگذاری نمودار…</div>';
var style=(document.documentElement.getAttribute("data-chart")||(window.TITAN_V78_SETTINGS&&TITAN_V78_SETTINGS.chart_style)||"candles_pro");
var geo=(document.documentElement.getAttribute("data-geometry")||(window.TITAN_V78_SETTINGS&&TITAN_V78_SETTINGS.chart_geometry)||"zones");
var showGrid=!(window.TITAN_V78_SETTINGS&&TITAN_V78_SETTINGS.chart_grid===false);
var showVol=!(window.TITAN_V78_SETTINGS&&TITAN_V78_SETTINGS.chart_volume===false);
var showEma=!(window.TITAN_V78_SETTINGS&&TITAN_V78_SETTINGS.chart_ema===false);
function toHA(src){var out=[],pho=null,phc=null;src.forEach(function(q){var hc=(q.o+q.h+q.l+q.c)/4,ho=pho==null?(q.o+q.c)/2:(pho+phc)/2,hh=Math.max(q.h,ho,hc),hl=Math.min(q.l,ho,hc);out.push({o:ho,h:hh,l:hl,c:hc,v:q.v,t:q.t});pho=ho;phc=hc});return out}
var baseAll=(style==="heikin")?toHA(all):all;
var z=S.zoom||1,pan=S.pan||0,maxVis=Math.min(baseAll.length,Math.max(20,Math.round(baseAll.length/z)));
var start=Math.max(0,Math.min(baseAll.length-maxVis,baseAll.length-maxVis-Math.round(pan)));
var c=baseAll.slice(start,start+maxVis),off=start,nf=fc.length,T=c.length+nf,w=340,h=190,vh=showVol?34:0,bw=w/Math.max(T,1),mx=-1e99,mn=1e99,s="";
c.forEach(function(q){mx=Math.max(mx,q.h);mn=Math.min(mn,q.l)});fc.forEach(function(q){mx=Math.max(mx,q.high);mn=Math.min(mn,q.low)});
var CN=F.cone;if(CN&&CN.q10){CN.q10.forEach(function(v){mn=Math.min(mn,v)});CN.q90.forEach(function(v){mx=Math.max(mx,v)})}
var pd=(mx-mn)*.05||1;mx+=pd;mn-=pd;
var Y=function(v){return 6+(mx-v)/(mx-mn)*(h-12)},vm=Math.max.apply(0,c.map(function(q){return q.v}))||1;
var X=function(i){return i*bw+bw/2};
if(showGrid)[.25,.5,.75].forEach(function(f){s+='<line x1="0" x2="'+w+'" y1="'+h*f+'" y2="'+h*f+'" stroke="#ffffff10" stroke-dasharray="3 5"/>'});
/* geometry overlays */
if(geo==="zones"||geo==="swings"){var piv=[];for(var i=2;i<c.length-2;i++){var q=c[i];if(q.h>=c[i-1].h&&q.h>=c[i-2].h&&q.h>=c[i+1].h&&q.h>=c[i+2].h)piv.push({i:i,p:q.h,t:"h"});if(q.l<=c[i-1].l&&q.l<=c[i-2].l&&q.l<=c[i+1].l&&q.l<=c[i+2].l)piv.push({i:i,p:q.l,t:"l"})}
piv.slice(-6).forEach(function(pv){var col=pv.t==="h"?"var(--dn)":"var(--up)";if(geo==="zones")s+='<rect x="0" y="'+(Y(pv.p)-4)+'" width="'+w+'" height="8" fill="'+col+'" opacity=".08"/><line x1="0" x2="'+w+'" y1="'+Y(pv.p)+'" y2="'+Y(pv.p)+'" stroke="'+col+'" stroke-width="1" opacity=".35" stroke-dasharray="4 3"/>';else s+='<circle cx="'+X(pv.i)+'" cy="'+Y(pv.p)+'" r="3.5" fill="'+col+'" opacity=".9"/>'})}
if(geo==="channel"&&c.length>10){var n=c.length,sx=0,sy=0,sxy=0,sx2=0;c.forEach(function(q,i){sx+=i;sy+=q.c;sxy+=i*q.c;sx2+=i*i});var den=n*sx2-sx*sx||1,sl=(n*sxy-sx*sy)/den,b0=(sy-sl*sx)/n;var resid=c.map(function(q,i){return Math.abs(q.c-(sl*i+b0))});resid.sort(function(a,b){return a-b});var band=resid[Math.floor(resid.length*.8)]||(mx-mn)*.05;s+='<line x1="'+X(0)+'" y1="'+Y(b0)+'" x2="'+X(n-1)+'" y2="'+Y(sl*(n-1)+b0)+'" stroke="var(--go)" stroke-width="1.4"/><line x1="'+X(0)+'" y1="'+Y(b0+band)+'" x2="'+X(n-1)+'" y2="'+Y(sl*(n-1)+b0+band)+'" stroke="var(--b)" stroke-width="1" stroke-dasharray="4 3"/><line x1="'+X(0)+'" y1="'+Y(b0-band)+'" x2="'+X(n-1)+'" y2="'+Y(sl*(n-1)+b0-band)+'" stroke="var(--b)" stroke-width="1" stroke-dasharray="4 3"/>'}
if(geo==="fib"&&c.length>5){var hi=-1e99,lo=1e99,hiI=0,loI=0;c.forEach(function(q,i){if(q.h>hi){hi=q.h;hiI=i}if(q.l<lo){lo=q.l;loI=i}});var df=hi-lo||1;[0,.236,.382,.5,.618,.786,1].forEach(function(r){var p=hi-df*r;s+='<line x1="0" x2="'+w+'" y1="'+Y(p)+'" y2="'+Y(p)+'" stroke="var(--b)" stroke-width="1" opacity=".55"/><text x="4" y="'+(Y(p)-2)+'" font-size="8" fill="var(--b)">'+r+"</text>"})}
/* series by style */
function candleBody(q,i,op){var x=X(i),up=q.c>=q.o,col=up?"var(--up)":"var(--dn)",yo=Y(q.o),yc=Y(q.c),yh=Y(q.h),yl=Y(q.l),top=Math.min(yo,yc),bot=Math.max(yo,yc),bh=Math.max(1.5,bot-top),half=bw*.32;
if(style==="ohlc"){var t=half*.7;return'<g opacity="'+(op||1)+'" class="glow" style="color:'+col+'"><line x1="'+x+'" x2="'+x+'" y1="'+yh+'" y2="'+yl+'" stroke="'+col+'" stroke-width="1.4"/><line x1="'+(x-t)+'" x2="'+x+'" y1="'+yo+'" y2="'+yo+'" stroke="'+col+'" stroke-width="1.6"/><line x1="'+x+'" x2="'+(x+t)+'" y1="'+yc+'" y2="'+yc+'" stroke="'+col+'" stroke-width="1.6"/></g>'}
if(style==="hollow"){var fill=up?"none":col,sw=up?1.6:0;return'<g opacity="'+(op||1)+'" class="glow" style="color:'+col+'"><line x1="'+x+'" x2="'+x+'" y1="'+yh+'" y2="'+yl+'" stroke="'+col+'"/><rect x="'+(x-half)+'" y="'+top+'" width="'+(half*2)+'" height="'+bh+'" fill="'+fill+'" stroke="'+col+'" stroke-width="'+sw+'"/></g>'}
return'<g opacity="'+(op||1)+'" class="glow" style="color:'+col+'"><line x1="'+x+'" x2="'+x+'" y1="'+yh+'" y2="'+yl+'" stroke="'+col+'"/><rect x="'+(x-half)+'" y="'+top+'" width="'+(half*2)+'" height="'+bh+'" fill="'+col+'"/></g>'}
if(style==="line"||style==="area"||style==="baseline"){var pts=c.map(function(q,i){return X(i)+","+Y(q.c)}).join(" ");
if(style==="area"){s+='<polygon points="'+X(0)+","+Y(mn)+" "+pts+" "+X(c.length-1)+","+Y(mn)+'" fill="var(--a)" opacity=".18"/>'}
if(style==="baseline"){var base=c[0].c;s+='<line x1="0" x2="'+w+'" y1="'+Y(base)+'" y2="'+Y(base)+'" stroke="#ffffff30" stroke-dasharray="4 3"/>';var up=[],dn=[];c.forEach(function(q,i){var p=X(i)+","+Y(q.c);if(q.c>=base)up.push(p);else dn.push(p)});
if(up.length)s+='<polyline points="'+up.join(" ")+'" fill="none" stroke="var(--up)" stroke-width="1.8"/>';
if(dn.length)s+='<polyline points="'+dn.join(" ")+'" fill="none" stroke="var(--dn)" stroke-width="1.8"/>'}
else s+='<polyline class="glow" style="color:var(--a)" points="'+pts+'" fill="none" stroke="var(--a)" stroke-width="2"/>';
c.forEach(function(q,i){if(showVol)s+='<rect x="'+(X(i)-bw*.32)+'" y="'+(h+vh+6-q.v/vm*vh)+'" width="'+bw*.64+'" height="'+q.v/vm*vh+'" fill="'+(q.c>=q.o?"var(--up)":"var(--dn)")+'" opacity=".4"/>'})}
else{c.forEach(function(q,i){s+=candleBody(q,i,1);if(showVol)s+='<rect x="'+(X(i)-bw*.32)+'" y="'+(h+vh+6-q.v/vm*vh)+'" width="'+bw*.64+'" height="'+q.v/vm*vh+'" fill="'+(q.c>=q.o?"var(--up)":"var(--dn)")+'" opacity=".45"/>'})}
if(showEma){var ma=[];c.forEach(function(q,i){if(i<19)return;var t=0;for(var j=i-19;j<=i;j++)t+=c[j].c;ma.push(X(i)+","+Y(t/20))});if(ma.length)s+='<polyline class="glow" style="color:var(--go)" points="'+ma.join(" ")+'" fill="none" stroke="var(--go)" stroke-width="1.8"/>'}
if(nf){var fx=c.length*bw;s+='<rect x="'+fx+'" y="0" width="'+(w-fx)+'" height="'+h+'" fill="var(--a)" opacity=".08"/><line x1="'+fx+'" x2="'+fx+'" y1="0" y2="'+h+'" stroke="var(--a)" stroke-dasharray="4 4"/><text x="'+(fx+3)+'" y="10" font-size="8" fill="var(--a)">پیش‌بینی '+nf+" شمع</text>";
if(CN&&CN.q10){var poly=function(lo,hi,op){var p=[];lo.forEach(function(v,i){p.push(X(c.length+i)+","+Y(v))});for(var i=hi.length-1;i>=0;i--)p.push(X(c.length+i)+","+Y(hi[i]));s+='<polygon points="'+p.join(" ")+'" fill="var(--a)" opacity="'+op+'"/>'};poly(CN.q10,CN.q90,.13);poly(CN.q25,CN.q75,.2);s+='<polyline class="glow" style="color:var(--a)" points="'+CN.q50.map(function(v,i){return X(c.length+i)+","+Y(v)}).join(" ")+'" fill="none" stroke="var(--a)" stroke-width="1.6" stroke-dasharray="3 3"/>'}
fc.forEach(function(q,i){var x=X(c.length+i),col=q.close>=q.open?"var(--up)":"var(--dn)";if(style==="line"||style==="area"||style==="baseline"){/* skip body */}else s+='<g class="glow" opacity=".6" style="color:'+col+'"><line x1="'+x+'" x2="'+x+'" y1="'+Y(q.high)+'" y2="'+Y(q.low)+'" stroke="'+col+'"/><rect x="'+(x-bw*.32)+'" y="'+Y(Math.max(q.open,q.close))+'" width="'+bw*.64+'" height="'+Math.max(1.5,Math.abs(Y(q.open)-Y(q.close)))+'" fill="'+col+'"/></g>'})}
var P=(F.adv||[]).filter(function(p){return p.levels&&p.levels.upper});if(P.length){var Lv=P[0].levels;["upper","lower"].forEach(function(n,ii){var a=Lv[n],sl=(a[3]-a[1])/((a[2]-a[0])||1),s0=all.length-140+a[0]-off,e=T-1,i0=Math.max(0,s0),col="var(--"+(ii?"c":"b")+")";s+='<line class="glow" style="color:'+col+'" x1="'+X(i0)+'" y1="'+Y(a[1]+sl*(i0-s0))+'" x2="'+X(e)+'" y2="'+Y(a[1]+sl*(e-s0))+'" stroke="'+col+'" stroke-width="2" stroke-dasharray="6 4"/>'});s+='<text x="4" y="10" font-size="9" fill="var(--b)">'+esc(P[0].id)+" "+P[0].confidence+"</text>"}
/* user drawings */
var D=S.draws[k]||[];
D.forEach(function(d){if(d.t==="hline"){s+='<line x1="0" x2="'+w+'" y1="'+Y(d.p)+'" y2="'+Y(d.p)+'" stroke="var(--go)" stroke-width="1.5" stroke-dasharray="5 3"/><text x="4" y="'+(Y(d.p)-3)+'" font-size="9" fill="var(--go)">'+pf(d.p)+"</text>"}
else if(d.t==="trend"&&d.x1!=null){var x1=X(d.i1-off),x2=X(d.i2-off);if(d.i1>=off&&d.i1<off+c.length)s+='<line x1="'+x1+'" y1="'+Y(d.p1)+'" x2="'+x2+'" y2="'+Y(d.p2)+'" stroke="var(--c)" stroke-width="2"/>'}
else if(d.t==="rect"&&d.i1!=null){var xa=X(Math.min(d.i1,d.i2)-off),xb=X(Math.max(d.i1,d.i2)-off),ya=Y(Math.max(d.p1,d.p2)),yb=Y(Math.min(d.p1,d.p2));s+='<rect x="'+xa+'" y="'+ya+'" width="'+(xb-xa)+'" height="'+(yb-ya)+'" fill="var(--a)" opacity=".15" stroke="var(--a)" stroke-width="1"/>'}
else if(d.t==="fib"&&d.p1!=null){var hi=Math.max(d.p1,d.p2),lo=Math.min(d.p1,d.p2),df=hi-lo;[0,.236,.382,.5,.618,.786,1].forEach(function(r){var p=hi-df*r;s+='<line x1="0" x2="'+w+'" y1="'+Y(p)+'" y2="'+Y(p)+'" stroke="var(--b)" stroke-width="1" opacity=".7"/><text x="4" y="'+(Y(p)-2)+'" font-size="8" fill="var(--b)">'+r+" · "+pf(p)+"</text>"})}});
if(S.drawTmp){var t=S.drawTmp;if(t.t==="hline")s+='<line x1="0" x2="'+w+'" y1="'+Y(t.p)+'" y2="'+Y(t.p)+'" stroke="#fff" stroke-width="1" stroke-dasharray="3 2"/>';
else if(t.t==="trend"&&t.i2!=null)s+='<line x1="'+X(t.i1-off)+'" y1="'+Y(t.p1)+'" x2="'+X(t.i2-off)+'" y2="'+Y(t.p2)+'" stroke="#fff" stroke-width="1.5"/>'}
s+='<text x="'+(w-4)+'" y="'+(h+vh+4)+'" text-anchor="end" font-size="8" fill="#8e98c9">'+style+' · ×'+z.toFixed(1)+' · '+c.length+' شمع</text>';
return'<div class="chwrap" id="chwrap"><svg viewBox="0 0 '+w+" "+(h+vh+8)+'" width="100%" id="chsvg">'+s+"</svg></div>"}
function ctools(){var tools=[["pan","جابه‌جایی"],["zoom","بزرگ‌نمایی"],["hline","خط افقی"],["trend","روند"],["rect","مستطیل"],["fib","فیبو"],["erase","پاک"]];return'<div class="ctools">'+tools.map(function(t){return'<button class="chip'+(S.tool===t[0]?" on":"")+'" data-tool="'+t[0]+'">'+t[1]+"</button>"}).join("")+'<button class="chip" data-tool="zreset">۱×</button><button class="chip" data-tool="zclear">پاک‌کردن رسم‌ها</button></div><div class="chhint">چرخ ماوس / دو انگشت: بزرگ‌نمایی · کشیدن: جابه‌جایی یا رسم</div>'}
function line(a,col){if(!a||a.length<2)return'<div class="sub">داده کافی نیست</div>';var w=320,h=100,mx=Math.max.apply(0,a),mn=Math.min.apply(0,a),r=(mx-mn)||1,p=a.map(function(v,i){return[i*w/(a.length-1),h-6-(v-mn)/r*(h-14)]}),l=p.map(function(q){return q.join(",")}).join(" ");return'<svg viewBox="0 0 '+w+" "+h+'" width="100%" style="overflow:visible"><defs><linearGradient id="lg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="'+col+'" stop-opacity=".5"/><stop offset="1" stop-color="'+col+'" stop-opacity="0"/></linearGradient></defs><polygon points="0,'+h+" "+l+" "+w+","+h+'" fill="url(#lg)"/><polyline class="glow" style="color:'+col+'" points="'+l+'" fill="none" stroke="'+col+'" stroke-width="2.5" stroke-linejoin="round"/></svg>'}
function donut(seg,mid,sub){var r=36,c=2*Math.PI*r,o=0,tot=seg.reduce(function(t,x){return t+x[0]},0)||1,s="";seg.forEach(function(x){var L=c*x[0]/tot;s+='<circle cx="52" cy="52" r="'+r+'" fill="none" stroke="'+x[1]+'" stroke-width="12" stroke-dasharray="'+Math.max(0,L-2)+" "+(c-L+2)+'" stroke-dashoffset="'+-o+'" transform="rotate(-90 52 52)"/>';o+=L});return'<svg class="glow" style="color:var(--b);display:block;margin:auto" width="104" height="104" viewBox="0 0 104 104">'+s+'<text x="52" y="52" text-anchor="middle" font-size="17" font-weight="800" fill="#fff">'+mid+'</text><text x="52" y="66" text-anchor="middle" font-size="8" fill="#8e98c9">'+sub+"</text></svg>"}
function cols(a){a=(a||[]).filter(function(x){return x.wr!=null});if(!a.length)return'<div class="sub">داده‌ای نیست</div>';var bw=300/a.length;return'<svg viewBox="0 0 320 130" width="100%">'+a.map(function(x,i){var hh=x.wr/100*90,xx=10+i*bw+bw*.2;return'<rect class="glow" style="color:var(--a)" x="'+xx+'" y="'+(100-hh)+'" width="'+bw*.6+'" height="'+hh+'" rx="6" fill="url(#cg)"/><text x="'+(xx+bw*.3)+'" y="'+(94-hh)+'" text-anchor="middle" font-size="9" fill="#fff">'+Math.round(x.wr)+'%</text><text x="'+(xx+bw*.3)+'" y="116" text-anchor="middle" font-size="9" fill="#8e98c9">'+esc(x.k)+"</text>"}).join("")+'<defs><linearGradient id="cg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--c)"/><stop offset="1" stop-color="var(--a)"/></linearGradient></defs></svg>'}
function calib(a){if(!a||!a.length)return'<div class="sub">داده کافی نیست</div>';return'<svg viewBox="0 0 140 130" width="60%" style="display:block;margin:auto"><rect x="10" y="5" width="120" height="110" fill="none" stroke="#ffffff22"/><line x1="10" y1="115" x2="130" y2="5" stroke="var(--a)" stroke-dasharray="4 4"/>'+a.map(function(c){return'<circle class="glow" style="color:var(--c)" cx="'+(10+c.pred*1.2)+'" cy="'+(115-c.actual*1.1)+'" r="'+Math.min(9,3+c.n/4)+'" fill="var(--c)"/>'}).join("")+'<text x="70" y="127" text-anchor="middle" font-size="8" fill="#8e98c9">پیش‌بینی ← / واقعی ↑</text></svg>'}
function pvw(){var r=cur();return pvw0()+(r?pdx():"")}
function pvw0(){var r=cur();if(!r)return card("داده","<div class=sub>در حال دریافت داده بازار…</div>");var k=kk(),F=S.fin[k],eq=(S.kl[k]||[]).slice(-18).map(function(q){return q.v}),m=Math.max.apply(0,eq)||1;
return'<div class="tick glass"><div>'+S.rows.slice(0,30).map(function(x){return'<b class="'+(x.change>=0?"up":"dn")+'">'+esc(x.symbol.split("/")[0])+" "+pf(x.price)+" "+(x.change>=0?"▲":"▼")+Math.abs(x.change).toFixed(1)+"</b>"}).join("")+"</div></div>"+chips(S.rows.map(function(x){return[x.symbol,x.symbol.split("/")[0]]}),S.sel,"data-s")+
'<section class="card glass"><div class="row"><div><div class="price">'+pf(r.price)+'</div><div class="'+(r.change>=0?"up":"dn")+'">'+(r.change>=0?"▲ ":"▼ ")+Math.abs(r.change).toFixed(2)+"٪ · "+esc(r.symbol)+'</div></div><div style="margin-inline-start:auto;text-align:center"><span class="tag '+esc(r.decision)+'">'+esc(r.decision)+'</span><div class="sub" style="margin-top:6px">'+esc(r.grade_fa||r.grade||"")+'</div></div></div><div style="display:flex;justify-content:space-around;margin-top:12px">'+ring(r.conf,"var(--up)","اطمینان")+ring(r.score,"var(--a)","امتیاز")+ring(r.trust,"var(--b)","اعتماد")+ring(r.prob,"var(--go)","احتمال")+"</div></section>"+
'<div class="g2">'+card("امتیاز نهایی",gauge(F&&F.ok?F.score:r.score),"go")+card("حجم زنده",'<div class="eq">'+eq.map(function(v){return'<i style="height:'+Math.max(8,v/m*100)+'%"></i>'}).join("")+"</div>","c")+card("رادار قدرت سیگنال",radar4(r),"b")+"</div>"}
function pcs(){var C=S.cs;if(!C||!C.ok)return"";var tf=(C.by_tf||[]).map(function(x){return'<div class="row sub" style="justify-content:space-between"><b>'+esc(x.k)+"</b><span>پوشش "+x.cov+"٪ · "+x.n+'</span></div><div class="bar"><i style="width:'+x.cov+'%"></i></div>'}).join("");return card("اعتبار مخروط احتمال (باند ۱۰ تا ۹۰)",'<div class="kp"><div class="glass"><b>'+(C.n||0)+'</b>نمونه</div><div class="glass"><b>'+(C.coverage==null?"—":C.coverage+"٪")+'</b>پوشش (هدف ۸۰)</div><div class="glass"><b>'+(C.pinball==null?"—":C.pinball+"٪")+'</b>خطای pinball</div><div class="glass"><b>'+(C.n<20?"کم‌نمونه":esc(C.verdict||"—"))+"</b>وضعیت</div></div>"+tf+'<div class="sub" style="margin-top:6px">پوشش یعنی چند درصد قیمت‌های واقعی داخل باند افتاده‌اند؛ در ۴۸ شمع آینده منتظر نتیجه: '+(C.pending||0)+"</div>","c")}
function pvl(){var V=(S.vl||{})[S.tf];if(!V)return"";if(V.computing)return card("اعتبار آماری الگوها",'<div class="sub">در حال محاسبه روی چند ارز… ممکن است تا یک دقیقه طول بکشد</div>',"b");if(!V.ok)return"";var row=function(x){var col=x.status==="معتبر"?"up":x.status==="بی‌اثر"?"dn":"go";return'<div class="row sub" style="justify-content:space-between;margin:6px 0"><span><b>'+esc(x.name)+"</b> · n="+x.n+" · برد "+x.hit+"٪ ("+x.lo+"–"+x.hi+") · خالص "+x.mean+"٪ · t="+x.t+" · تست "+(x.test_hit==null?"—":x.test_hit+"٪")+'</span><span class="tag" style="color:var(--'+col+')">'+esc(x.status)+"</span></div>"};var P=V.params||{};return card("اعتبار آماری الگوهای شمعی",(V.candle||[]).map(row).join("")||'<div class="sub">داده‌ای نیست</div>',"b")+card("اعتبار آماری الگوهای نموداری",(V.chart||[]).map(row).join("")||'<div class="sub">داده‌ای نیست</div>',"c")+'<div class="sub" style="margin-bottom:8px">افق '+P.cl+" شمع (شمعی) و "+P.chl+" شمع (نموداری)، هزینه رفت‌وبرگشت "+P.cost+"٪، کنترل FDR="+P.q+"، "+P.symbols+" ارز، حدود "+P.bars+" شمع. «معتبر» یعنی از آزمون FDR گذشته، میانگین خالص مثبت و بخش آزمون زمانی هم مثبت است.</div>"}
function prg(F){var R=F.regime;if(!R)return"";var col=R.key==="trend_up"?"up":R.key==="trend_down"?"dn":R.key==="volatile"?"c":"go";return card("رژیم بازار",'<div class="row"><span class="tag" style="color:var(--'+col+')">'+esc(R.fa)+'</span><span class="sub">اطمینان '+R.confidence+'٪</span></div><div class="kp" style="margin-top:8px"><div class="glass"><b>'+R.adx+'</b>ADX</div><div class="glass"><b>'+R.er+'</b>کارایی</div><div class="glass"><b>'+R.vol_pct+'٪</b>صدک نوسان</div><div class="glass"><b>'+R.slope+'</b>EMA20/50</div></div>',col)}
function pch(){var F=S.fc[kk()]||{},cp=F.cp||{},h=chips([["15m","15m"],["1h","1h"],["4h","4h"],["1d","1d"]],S.tf,"data-tf")+ctools()+card("نمودار شمعی، مخروط احتمال ۴۸ شمع و خطوط الگو",chart(),"up");
h+=prg(F);if(F.ok)h+=card("پیش‌بینی",'<div class="row"><span class="tag '+(/صعود/.test(F.bias)?"LONG":/نزول/.test(F.bias)?"SHORT":"WAIT")+'">'+esc(F.bias||"—")+'</span><span class="sub">'+esc(F.narrative||"")+"</span></div>","a");
h+=pvl();h+=pcs();h+=card("الگوهای شمعی",(cp.recent&&cp.recent.length?'<div class="tabs">'+cp.recent.map(function(p){return'<span class="chip on">'+esc(p.name)+" · "+esc(p.bias)+" · "+p.ago+"</span>"}).join("")+"</div>":'<div class="sub">الگوی تازه‌ای نیست</div>')+(cp.stats||[]).map(function(s){return'<div class="row sub" style="justify-content:space-between"><b>'+esc(s.name)+" ("+s.count+")"+(s.status?" · "+esc(s.status):"")+"</b><span>برد "+s.hit+"٪ · میانگین "+s.avg+"٪</span></div><div class=\"bar\"><i style=\"width:"+s.hit+'%"></i></div>'}).join(""),"c");
h+=card("الگوهای نموداری",(F.adv&&F.adv.length?F.adv:[]).map(function(p){return'<div class="row" style="margin:4px 0"><span class="chip on">'+esc(p.id)+" "+p.confidence+'</span><span class="sub">'+esc(p.bias)+(p.regime_factor&&p.regime_factor!==1?" · ضریب رژیم ×"+p.regime_factor:"")+" · "+esc(p.desc||"")+"</span></div>"}).join("")||'<div class="sub">الگوی پیشرفته‌ای دیده نشد</div>',"b");return h}
function pai(){var F=S.fin[kk()],r=cur(),h=card("شماتیک شبکه تصمیم",neural(F&&F.decision),"b")+'<button class="btn" data-act="fin" style="width:100%;margin:6px 0">تصمیم نهایی با Gemini + CoinGlass + الگوها</button>';
if(F==="busy")h+=card("در حال تحلیل","<div class=sub>Gemini در حال بررسی…</div>","go");else if(F&&F.ok){h+='<section class="card glass" style="--k:var(--go)"><div class="row"><div><div class="price">'+F.score+'</div><div class="sub">امتیاز نهایی · اطمینان '+F.conf+'٪'+(F.regime_fa?' · رژیم '+esc(F.regime_fa):'')+'</div></div><span class="tag '+esc(F.decision)+'" style="margin-inline-start:auto">'+esc(F.decision)+"</span></div></section>"+card("سهم هر منبع در تصمیم",F.parts.map(function(p){var v=Math.max(-1,Math.min(1,p.val)),col=v>=0?"var(--up)":"var(--dn)";return'<div class="row sub" style="justify-content:space-between"><b>'+esc(p.name)+" ("+Math.round(p.w*100)+'٪)</b><span>'+esc(p.note)+'</span></div><div class="dv"><i style="color:'+col+";background:"+col+";width:"+Math.abs(v)*50+"%;"+(v>=0?"right:50%":"left:50%")+'"></i></div>'}).join(""),"a")+(F.gemini?card("متن Gemini","<div class=tx>"+esc(F.gemini)+"</div>","c"):"")}else if(F&&!F.ok)h+=card("خطا","<div class=sub>"+esc(F.error||"تحلیل ممکن نشد")+"</div>","dn");
else h+='<div class="sub" style="text-align:center">برای '+esc(r?r.symbol:"")+" دکمه را بزنید.</div>";return h}
function mlist(){var q=(S.q||"").toLowerCase(),f=S.mf||"ALL",s=S.ms||"conf",t=S.mt||"ALL";return S.rows.filter(function(r){return(!q||r.symbol.toLowerCase().indexOf(q)>=0)&&(f==="ALL"||r.decision===f)&&(t==="ALL"||r.tf===t)}).sort(function(x,y){return s==="chg"?Math.abs(y.change)-Math.abs(x.change):s==="name"?x.symbol.localeCompare(y.symbol):y.conf-x.conf})}
function pmk(){var n={LONG:0,SHORT:0,WAIT:0};S.rows.forEach(function(r){if(n[r.decision]!=null)n[r.decision]++});var hm=S.rows.slice().sort(function(x,y){return Math.abs(y.change)-Math.abs(x.change)}).slice(0,16);
return'<input type="search" id="q" placeholder="جستجوی ارز…" value="'+esc(S.q)+'">'+chips([["ALL","همه ("+S.rows.length+")"],["LONG","LONG ("+n.LONG+")"],["SHORT","SHORT ("+n.SHORT+")"],["WAIT","WAIT ("+n.WAIT+")"]],S.mf||"ALL","data-mf")+chips([["ALL","همه تایم‌فریم‌ها"],["15m","15m"],["1h","1h"],["4h","4h"],["1d","1d"]],S.mt||"ALL","data-mtf")+chips([["conf","مرتب‌سازی: اطمینان"],["chg","تغییر"],["name","نام"]],S.ms||"conf","data-ms")+
card("طبقه‌بندی سیگنال‌ها",donut([[n.LONG,"var(--up)"],[n.SHORT,"var(--dn)"],[n.WAIT,"var(--go)"]],S.rows.length,"ارز"),"b")+
card("نقشه حرارتی",'<div class="heat">'+hm.map(function(r){var c=r.change>1?"--up":r.change<-1?"--dn":"--go";return'<button data-s="'+esc(r.symbol)+'" style="background:var('+c+');color:#04101a">'+esc(r.symbol.split("/")[0])+" "+(r.change>0?"+":"")+r.change.toFixed(1)+"</button>"}).join("")+"</div>","c")+
card("سیگنال‌ها (جهت · تایم‌فریم · زمان)",'<div class="lst" id="ml">'+ml(mlist())+"</div>","a")}
function ml(a){return a.slice(0,120).map(function(r){return'<div data-s="'+esc(r.symbol)+'"><span style="flex:1;min-width:0"><b>'+esc(r.symbol)+'</b> <span class="sub">'+esc(r.name||"")+"</span>"+sigMeta(r)+tfchips(r)+'</span><span style="text-align:end"><span class="tag '+esc(r.decision)+'">'+esc(r.decision)+'</span><div class="sub sm">'+pf(r.price)+'</div><div class="sm '+(r.change>=0?"up":"dn")+'">'+r.change.toFixed(1)+"٪ · اطمینان "+r.conf+"</div></span></div>"}).join("")}
function plr(){var L=S.lr;if(!L||!L.ok)return"";var RGF={trend_up:"روند صعودی",trend_down:"روند نزولی",range:"رنج",volatile:"نوسان بالا",transition:"گذار"};var bar=function(n,a,b,v){return'<div class="row sub" style="justify-content:space-between"><b>'+esc(n)+"</b><span>"+a+'</span></div><div class="bar"><i style="width:'+Math.max(0,Math.min(100,v))+'%"></i></div>'};
var cs=(L.components||[]).map(function(c){return bar(c.name,c.hits+"/"+c.n+" · "+c.hit+"٪ · مزیت "+(c.edge>0?"+":"")+c.edge+"٪",0,c.hit)}).join("")||'<div class="sub">هنوز نتیجه‌ای ثبت نشده؛ بعد از گذشتن افق هر تصمیم (۸ شمع) محاسبه می‌شود</div>',G=L.gemini||{},ct=L.counts||{},ws=Object.keys(L.weights||{}).map(function(k){return bar(k,Math.round(L.weights[k]*100)+"٪",0,L.weights[k]*200)}).join("");
return card("تصمیم‌های ثبت‌شده",'<div class="kp">'+["PENDING","WIN","LOSS","FLAT"].map(function(k){return'<div class="glass"><b>'+(ct[k]||0)+"</b>"+k+"</div>"}).join("")+"</div>"+'<div class="sub" style="margin-top:8px">نرخ برد تصمیم نهایی: '+(L.win_rate==null?"—":L.win_rate+"٪")+"</div>","a")+card("دقت هر منبع تصمیم",cs,"go")+card("دقت Gemini",'<div class="kp"><div class="glass"><b>'+(G.n||0)+'</b>نمونه</div><div class="glass"><b>'+(G.hit==null?"—":G.hit+"٪")+'</b>درستی جهت</div><div class="glass"><b>'+(G.brier==null?"—":G.brier)+'</b>Brier</div><div class="glass"><b>'+(G.avg_conf==null?"—":G.avg_conf+"٪")+"</b>اطمینان</div></div>"+'<div class="sub" style="margin-top:8px">Brier پایین‌تر بهتر است؛ حدود ۰٫۲۵ یعنی تصادفی</div>',"c")+card("دقت هر منبع در هر رژیم",(L.by_regime||[]).filter(function(x){return x.n>=5}).map(function(x){return bar((RGF[x.regime]||x.regime)+" · "+x.name,x.hit+"٪ ("+x.n+")",0,x.hit)}).join("")||'<div class="sub">نمونه کافی نیست؛ با ثبت تصمیم‌ها پر می‌شود</div>',"a")+card("وزن منابع — "+(L.mode==="learned"?"یادگرفته از نتایج":"پیش‌فرض"),ws,"b")}
function ppf(){var E=S.ev;if(!E)return card("ارزیابی","<div class=sub>در حال دریافت…</div>");if(!E.ok)return card("ارزیابی","<div class=sub>در دسترس نیست</div>","dn");var F=E.forecasts||{},P=E.paper||{},A=E.audit||{},f=function(v,s){return v==null?"—":v+(s||"")},dt=function(t){return new Date(t*1000).toLocaleString("fa-IR")};
var h=chips([[7,"۷ روز"],[30,"۳۰ روز"],[90,"۹۰ روز"],[365,"۱ سال"]],S.pd,"data-pd")+'<div class="kp">'+[[f(F.total),"پیش‌بینی","a"],[f(F.win_rate,"٪"),"نرخ برد","up"],[f(F.pending),"در انتظار","go"],[f(P.closed),"کاغذی","b"],[f(P.avg_r),"میانگین R","a"],[f(P.profit_factor),"Profit F.","go"],[f(P.max_dd_r),"افت R","dn"],[f(P.win_rate,"٪"),"برد کاغذی","up"]].map(function(k){return'<div class="glass" style="--k:var(--'+k[2]+')"><b>'+k[0]+"</b>"+k[1]+"</div>"}).join("")+"</div>";
h+='<div class="g2" style="margin-top:10px">'+card("نتایج",donut([[F.wins||0,"var(--up)"],[F.losses||0,"var(--dn)"],[F.pending||0,"var(--go)"]],f(F.win_rate,"٪"),"نرخ برد"),"b")+card("منحنی سرمایه (R)",line(P.equity,"#22e5a0"),"up")+"</div>";
h+=card("نرخ برد هر تایم‌فریم",cols(F.by_tf),"a")+card("کالیبراسیون احتمال",calib(F.calib),"go")+card("جهت و منبع",[].concat(F.by_dir||[],F.by_source||[]).map(function(x){var v=x.wr==null?0:x.wr;return'<div class="row sub" style="justify-content:space-between"><b>'+esc(x.k)+"</b><span>"+x.wins+"/"+(x.wins+x.losses)+" · "+(x.wr==null?"—":Math.round(x.wr)+"٪")+'</span></div><div class="bar"><i style="width:'+v+'%"></i></div>'}).join(""),"c");
if(A.n!=null)h+=card("ممیزی V32",'<div class="kp"><div class="glass"><b>'+A.n+"</b>تعداد</div><div class=\"glass\"><b>"+f(A.avg_return,"٪")+'</b>بازده</div><div class="glass"><b>'+f(A.avg_mfe,"٪")+'</b>MFE</div><div class="glass"><b>'+f(A.avg_mae,"٪")+"</b>MAE</div></div>","b");
h+=plr();
var PL=S.perfLive;if(PL&&PL.ok&&PL.rows&&PL.rows.length){h+=card("عملکرد زنده هر نماد/تایم‌فریم + خوداصلاحی",'<div class="lst">'+PL.rows.slice(0,40).map(function(r){return'<div><span style="flex:1"><b>'+esc(r.symbol)+'</b> <span class="pill">'+esc(r.timeframe)+'</span> <span class="tag '+esc(r.grade)+'">'+esc(r.grade)+'</span><div class="sub sm">برد '+fv(r.win_rate)+'% · امید '+fv(r.expectancy)+' · شارپ '+fv(r.sharpe)+' · DD '+fv(r.max_drawdown)+'% · '+fv(r.trades)+' معامله</div><div class="sub sm">'+esc(r.self_correct||"")+'</div>'+(r.lessons&&r.lessons.length?'<div class="sub dn">'+r.lessons.map(function(x){return'• '+esc(x)}).join(' · ')+'</div>':'')+'</span></div>'}).join('')+'</div>',"go")}

var DS=S.deepStats;if(DS&&DS.ok){h+=card("عملکرد فقط تحلیل عمیق",'<div class="kp"><div class="glass"><b>'+(DS.total||0)+'</b>کل</div><div class="glass"><b>'+(DS.win_rate==null?"—":DS.win_rate+"٪")+'</b>نرخ برد</div><div class="glass"><b>'+(DS.wins||0)+"/"+((DS.wins||0)+(DS.losses||0))+'</b>برد/باخت</div><div class="glass"><b>'+(DS.pending||0)+'</b>در انتظار</div><div class="glass"><b>'+(DS.avg_return_pct==null?"—":DS.avg_return_pct+"٪")+'</b>میانگین بازده</div></div><div class="sub" style="margin-top:6px">'+esc(DS.note||"")+'</div>'+Object.keys(DS.by_tf||{}).map(function(t){var x=DS.by_tf[t]||{};return'<div class="row sub" style="justify-content:space-between"><b>'+t+"</b><span>برد "+(x.win_rate==null?"—":x.win_rate+"٪")+" · n="+x.n+" · انتظار "+x.pending+"</span></div>"}).join("")+'<div class="lst" style="margin-top:8px">'+(DS.recent||[]).slice(0,25).map(function(r){return'<div><span><b>'+esc(r.s)+'</b> <span class="pill">'+esc(r.tf)+'</span> <span class="tag '+esc(r.d)+'">'+esc(r.d)+'</span><div class="sub sm">'+esc(r.notes||"")+" · چک "+esc(r.check||"—")+'</div></span><span class="tag '+esc(r.o)+'">'+esc(r.o)+'</span></div>'}).join("")+"</div>","up")}
var hs=(F.history||[]).filter(function(r){return S.evf==="ALL"||r.o===S.evf});h+=card("تاریخچه پیش‌بینی‌ها",chips([["ALL","همه"],["WIN","برد"],["LOSS","باخت"],["PENDING","منتظر"]],S.evf,"data-evf")+'<div class="lst">'+hs.map(function(r){return'<div><span><b>'+esc(r.s)+'</b> <span class="sub">'+r.tf+" · "+esc(r.d)+" · "+esc(r.hit||"")+'</span><div class="sub">'+dt(r.t)+'</div></span><span class="tag '+esc(r.o)+'">'+esc(r.o)+"</span></div>"}).join("")+"</div>","a");
if(P.recent&&P.recent.length)h+=card("تاریخچه معاملات کاغذی",'<div class="lst">'+P.recent.map(function(r){return'<div><span><b>'+esc(r.s)+'</b> <span class="sub">'+r.tf+" · "+esc(r.d)+'</span><div class="sub">'+dt(r.t)+'</div></span><b class="'+(r.r>=0?"up":"dn")+'">'+r.r+"R</b></div>"}).join("")+"</div>","b");var V78=S.v78e||{},WF=S.wf||{};
if(V78&&(V78.ok||V78.total!=null||V78.win_rate!=null)){h+=card("ارزیابی V78 (ثبت تصمیم)",'<div class="kp"><div class="glass"><b>'+(V78.evaluated||V78.total||0)+'</b>ارزیابی‌شده</div><div class="glass"><b>'+(V78.wins||0)+'</b>برد</div><div class="glass"><b>'+(V78.losses||0)+'</b>باخت</div><div class="glass"><b>'+(V78.win_rate!=null?Math.round(V78.win_rate*100)+"%":"—")+'</b>نرخ برد</div></div>'+(V78.notes?'<div class="sub">'+esc(String(V78.notes).slice(0,160))+"</div>":""),"up")}
if(WF&&WF.ok){var v78w=WF.v78||{},cns=v78w.consistency||{},agg=WF.aggregate||{};h+=card("Walk-Forward · "+esc(WF.symbol||"")+" · "+esc(WF.timeframe||""),'<div class="kp"><div class="glass"><b>'+(WF.windows||0)+'</b>پنجره</div><div class="glass"><b>'+(v78w.sharpe_like!=null?v78w.sharpe_like:"—")+'</b>شارپ‌مانند</div><div class="glass"><b>'+(cns.hit_rate!=null?Math.round(cns.hit_rate*100)+"%":"—")+'</b>پایداری پنجره</div><div class="glass"><b>'+(WF.abstained_windows||0)+'</b>پرهیز</div></div><div class="sub">verdict: '+esc(String(WF.verdict||"—"))+' · میانگین بازده '+(v78w.mean_return_pct!=null?v78w.mean_return_pct:"—")+"٪</div><div class="sub">معاملات تجمیعی: "+(agg.trades||agg.n||"—")+" · win " +(agg.win_rate!=null?Math.round((agg.win_rate>1?agg.win_rate:agg.win_rate*100))+"%":"—")+"</div>","b")}
else if(WF&&WF.ok===false){h+=card("Walk-Forward","<div class=sub>داده کافی یا خطا در محاسبه</div>","dn")}
return h}
function pnt(){var n=CF.nt||{},sup=("Notification" in window)&&("serviceWorker" in navigator),perm=sup?Notification.permission:"unsupported";return card("اعلان‌ها و نصب",'<div class="ctrl"><label>اعلان سیگنال قوی<button class="sw'+(n.on?" on":"")+'" data-nt="on"></button></label><label>حداقل اطمینان<input type="range" data-nk="nmin" min="50" max="95" step="5" value="'+(n.nmin||75)+'"><b>'+(n.nmin||75)+'٪</b></label><label>فاصله تکرار (ساعت)<input type="range" data-nk="cool" min="1" max="24" value="'+(n.cool||4)+'"><b>'+(n.cool||4)+'</b></label><label>LONG<button class="sw'+(n.L!==0?" on":"")+'" data-nt="L"></button></label><label>SHORT<button class="sw'+(n.S!==0?" on":"")+'" data-nt="S"></button></label></div><div class="sub" style="margin:8px 0">وضعیت مجوز: '+esc(perm)+(sup?"":" — نیاز به آدرس localhost یا HTTPS")+'</div><div class="row" style="flex-wrap:wrap"><button class="btn" data-act="ntest">اعلان آزمایشی</button>'+(IP?'<button class="btn g" data-act="install">نصب برنامه</button>':"")+"</div>","go")}
function pst0(){var cu=CF.cu||TH[CF.th]||TH["شفق نئون"];return card("تم‌ها",'<div class="themes">'+Object.keys(TH).map(function(n){var t=TH[n];return'<button class="th'+(!CF.cu&&CF.th===n?" on":"")+'" data-th="'+esc(n)+'"><i style="background:linear-gradient(90deg,'+t[2]+","+t[3]+","+t[4]+')"></i>'+esc(n)+"</button>"}).join("")+"</div>","c")+card("شخصی‌سازی",'<div class="ctrl"><label>شدت نور<input type="range" data-k="gl" min="0" max="2" step=".1" value="'+CF.gl+'"></label><label>شیشه‌ای<input type="range" data-k="bl" min="0" max="40" value="'+CF.bl+'"></label><label>گردی گوشه‌ها<input type="range" data-k="rr" min="6" max="32" value="'+CF.rr+'"></label>'+[2,3,4].map(function(i,j){return'<label>رنگ '+["اصلی","دوم","سوم"][j]+'<input type="color" data-c="'+i+'" value="'+cu[i]+'"></label>'}).join("")+'<label>پس‌زمینه متحرک<button class="sw'+(CF.fx?" on":"")+'" data-sw="fx"></button></label><label>انیمیشن‌ها<button class="sw'+(CF.an?" on":"")+'" data-sw="an"></button></label></div>',"a")+pnt()+card("سیاست لبه حرفه‌ای",'<div class="sub">SAFE MODE فقط ۴h/۱d را جهت‌دار منتشر می‌کند. Require Edge بدون EDGE_SUPPORTED → WAIT.</div><div class="row" style="flex-wrap:wrap;margin-top:8px"><button class="btn" data-act="safeon">Safe Mode روشن</button><button class="btn g" data-act="safeoff">Safe Mode خاموش</button><button class="btn" data-act="edgeon">Require Edge</button><button class="btn g" data-act="edgeoff">Edge آزاد</button><button class="btn" data-act="deepeval">ارزیابی عمیق الان</button></div>',"up")+card("ابزارها",'<div class="row" style="flex-wrap:wrap"><button class="btn" data-act="scan">اسکن مجدد</button><a class="btn g" href="/download/titan.py" download="TITAN_PRO_V75_MMM_DEEP.py" style="text-decoration:none">دانلود کد</a><a class="btn g" href="/health/page" style="text-decoration:none">صفحه سلامت</a><button class="btn g" data-act="backup">پشتیبان</button><button class="btn g" data-act="sqlite">بهینه SQLite</button><button class="btn g" data-act="reset">بازنشانی</button></div>',"go")}

function loadEdge(){get("/api/v60-edge-router").then(function(r){S.eg=r;if(S.tab==="tp")render()}).catch(function(){S.eg={ok:false};if(S.tab==="tp")render()})}
function loadCoin(){var s=S.sel;if(!s)return;if(!S.coin||!S.coin.row||S.coin.row.symbol!==s)S.coin={loading:1};S.deep={loading:1};get("/api/v59/coin?symbol="+encodeURIComponent(s)).then(function(r){S.coin=r;if(S.tab==="dt")render()}).catch(function(){S.coin={ok:false,error:"خطا"};if(S.tab==="dt")render()});get("/api/v75/deep?symbol="+encodeURIComponent(s)+"&timeframe="+(S.tf||"1h")).then(function(r){S.deep=r;if(S.tab==="dt")render()}).catch(function(){S.deep={ok:false,error:"خطا"};if(S.tab==="dt")render()})}
var TFS=["15m","1h","4h","1d"],TFN={"15m":"۱۵ دقیقه","1h":"۱ ساعت","4h":"۴ ساعت","1d":"روزانه"},CL=["a","b","c","go"];
var LB={entry:"ورود",sl:"حد ضرر",tp1:"هدف ۱",tp2:"هدف ۲",rr1:"R:R هدف ۱",rr2:"R:R هدف ۲",risk_pct:"فاصله ریسک ٪",trend:"روند",momentum:"مومنتوم",volatility:"نوسان",regime:"رژیم",support:"حمایت",resistance:"مقاومت",rsi:"RSI",volatility_pct:"نوسان ٪",pattern_bias:"سوگیری الگو",long_ratio:"نسبت لانگ",short_ratio:"نسبت شورت",top_long_ratio:"لانگ تاپ‌تریدرها",taker_buy_pct:"خرید تیکر ٪",taker_sell_pct:"فروش تیکر ٪",funding:"فاندینگ",oi:"اوپن اینترست",success:"احتمال موفقیت",quality:"کیفیت سیگنال",trust:"اعتماد",opportunity:"فرصت",neural:"نورال",neural_conf:"اطمینان نورال",meta_prob:"احتمال متا",confluence:"هم‌پوشانی",ai_agree:"توافق AI",buy_pct:"خرید ٪",sell_pct:"فروش ٪",score:"امتیاز",label:"برچسب",action:"اقدام",agreement:"توافق",majority:"اکثریت",status:"وضعیت",bias:"سوگیری",expected_move_pct:"حرکت مورد انتظار ٪",narrative:"شرح",path_strength:"قدرت مسیر",analogue_corr:"همبستگی تاریخی",upper:"بالا",middle:"وسط",lower:"پایین"};
function ago(i){var t=Date.parse(i);if(!t)return"";var m=Math.round((Date.now()-t)/6e4);if(m<1)return"هم‌اکنون";if(m<60)return m+" دقیقه پیش";var h=Math.round(m/60);return h<48?h+" ساعت پیش":Math.round(h/24)+" روز پیش"}
function clk(i){var t=typeof i==="number"?(i<1e12?i*1e3:i):Date.parse(i);return t?new Date(t).toLocaleString("fa-IR",{month:"2-digit",day:"2-digit",hour:"2-digit",minute:"2-digit"}):""}
function sigMeta(r,tf){tf=tf||r.tf||"1h";return'<div class="sub sm"><span class="pill tfp">'+esc(tf)+"</span>سیگنال برای تایم‌فریم "+esc(TFN[tf]||tf)+(r.asof?" · "+ago(r.asof)+" ("+clk(r.asof)+")":"")+(r.fresh?' · <span class="up">قیمت زنده</span>':"")+"</div>"}
function tfchips(r){return'<span class="tfs">'+TFS.map(function(t){var v=(r.tfs||{})[t]||{},d=v.dir||"WAIT";return'<span class="tfc '+d+(t===r.tf?" pri":"")+'"><b>'+t+"</b>"+(d==="LONG"?"▲":d==="SHORT"?"▼":"•")+" "+(v.conf!=null?v.conf:"—")+"</span>"}).join("")+"</span>"}
function fv(v){if(v==null||v==="")return"—";if(typeof v==="boolean")return v?"✓":"✗";if(typeof v==="number"){var a=Math.abs(v);return a>=1000?v.toLocaleString("en-US",{maximumFractionDigits:2}):String(+v.toFixed(a<1?5:3))}if(Array.isArray(v))return v.length?esc(v.map(function(x){return typeof x==="object"?JSON.stringify(x):x}).join("، ")):"—";if(typeof v==="object")return esc(JSON.stringify(v).slice(0,160));return esc(String(v))}
function flat(o,p,d,a){a=a||[];Object.keys(o||{}).forEach(function(k){var v=o[k],n=p?p+"."+k:k;if(v&&typeof v==="object"&&!Array.isArray(v)&&d<3)flat(v,n,d+1,a);else a.push([n,v])});return a}
function kvl(o){var a=flat(o,"",0);return a.length?a.map(function(x){var k=x[0],l=LB[k]||LB[k.split(".").pop()]||k;return'<div class="kv"><span class="sub">'+esc(l)+"</span><b>"+fv(x[1])+"</b></div>"}).join(""):'<div class="sub">داده‌ای نیست</div>'}
function oc(t,o,k){return card(t,kvl(o),k||"a")}
function PB(a,v,m){v=+v||0;var w=Math.max(0,Math.min(100,m?v/m*100:v));return'<div class="row sub" style="justify-content:space-between"><b>'+esc(a)+"</b><span>"+fv(v)+'</span></div><div class="bar"><i style="width:'+w+'%"></i></div>'}
function quick(r){var q=[["R:R",r.rr],["کیفیت",r.quality],["RSI",r.rsi],["هم‌راستایی",r.align],["خرید ٪",r.buy],["نوسان ٪",r.vol],["امتیاز نهنگ",r.whale_score],["فاندینگ",r.funding],["OI",r.oi],["AI اکثریت",r.ai_majority],["سوگیری",r.bias],["جهش حجم",r.vspike],["نهنگ",r.whale_label],["گرید",r.grade_fa||r.grade]];return'<div class="kp">'+q.map(function(x){return'<div class="glass"><b>'+fv(x[1])+"</b>"+x[0]+"</div>"}).join("")+"</div>"}
function hd(r){return'<section class="card glass win wide" style="--k:var(--'+(r.decision==="LONG"?"up":r.decision==="SHORT"?"dn":"go")+')"><header class="wh"><h3><span class="d"></span>'+esc(r.symbol)+" "+esc(r.name||"")+'</h3></header><div class="row"><div><div class="price">'+pf(r.price)+'</div><div class="'+(r.change>=0?"up":"dn")+'">'+(r.change>=0?"▲ ":"▼ ")+Math.abs(r.change).toFixed(2)+'٪ ۲۴ساعته</div></div><div style="margin-inline-start:auto;text-align:center"><span class="tag '+esc(r.decision)+'">'+esc(r.decision)+"</span></div></div>"+sigMeta(r)+tfchips(r)+'<div class="kp" style="margin-top:10px">'+[["conf","اطمینان"],["score","امتیاز"],["trust","اعتماد"],["prob","احتمال"]].map(function(k){return'<div class="glass"><b>'+Math.round(+r[k[0]]||0)+"</b>"+k[1]+"</div>"}).join("")+"</div></section>"}
var DT=[["ov","نمای کلی"],["dp","تحلیل عمیق"],["tf","تایم‌فریم‌ها"],["lv","سطوح"],["ix","اندیکاتورها"],["fl","جریان و نهنگ"],["ai","هوش مصنوعی"],["ed","Edge و کیفیت"],["pt","الگو و پیش‌بینی"],["ck","چک‌لیست"],["al","همه داده‌ها"]];
function pdt(){var r=cur(),C=S.coin,h=chips(S.rows.map(function(x){return[x.symbol,x.symbol.split("/")[0]]}),S.sel,"data-s");
if(!r)return h+card("جزئیات","<div class=sub>ارزی انتخاب نشده</div>");
h+=hd(r)+chips(DT,S.ctab||"ov","data-ctab");
if(!C||C.loading)return h+card("بارگذاری","<div class=sub>دریافت جزئیات ارز…</div>");
if(!C.ok)return h+card("خطا","<div class=sub>"+esc(C.error||"داده موجود نیست")+"</div>","dn");
var d=C.detail||{},row=C.row||r,T=S.ctab||"ov",P=d.prob||{},G=d.grade||{},A=d.ai||{},N=d.neural||{},F=d.forecast||{};
function L(a,b){return'<div class="kv"><span class="sub">'+a+"</span><b>"+b+"</b></div>"}
function ul(a){return a&&a.length?'<ul style="margin:4px 0;padding-inline-start:18px;font-size:12px">'+a.slice(0,10).map(function(x){return"<li>"+esc(x)+"</li>"}).join("")+"</ul>":""}
if(T==="dp"){
var D=S.deep;if(!D||D.loading){h+=card("تحلیل عمیق","<div class=sub>در حال تحلیل چندلایه و میز هوش مصنوعی… ممکن است چند ثانیه طول بکشد</div>");return h}
if(!D.ok){h+=card("خطا","<div class=sub>"+esc(D.error||"تحلیل ممکن نشد")+"</div>","dn");return h}
var desk=D.desk||{},nm=desk.next_minutes||{},crit=desk.performance_critique||{},AD=desk.ai_desk||{},CK=desk.checklist||[];
h+=card("تصمیم میز معاملاتی",'<div class="row"><span class="tag '+esc(desk.decision||"WAIT")+'">'+esc(desk.decision||"WAIT")+'</span><span class="sub">کمّی: '+esc(desk.quant_decision||"—")+' · امتیاز '+fv(desk.score)+' · HTF '+(desk.htf_confirmed?"تأیید":"رد")+'</span></div>'+PB("امتیاز",desk.score)+Object.keys(desk.tf_scores||{}).map(function(t){return PB(t,desk.tf_scores[t])}).join(""),desk.decision==="LONG"?"up":desk.decision==="SHORT"?"dn":"go");
h+=card("نقاط ورود / خروج / ریسک",L("ورود",pf(desk.entry))+L("حد ضرر",pf(desk.sl))+L("هدف ۱",pf(desk.tp1))+L("هدف ۲",pf(desk.tp2))+L("ریسک ٪",fv(desk.risk_pct))+L("R:R ۱",fv(desk.rr1))+L("R:R ۲",fv(desk.rr2))+L("ریسک پیشنهادی ٪",fv(desk.suggested_risk_pct)),"up");
h+=card("اجماع هوش مصنوعی",'<div class="row"><span class="tag '+esc(AD.consensus_side||"WAIT")+'">'+esc(AD.consensus_side||"WAIT")+'</span><span class="sub">اطمینان '+fv(AD.consensus_confidence)+'٪ · توافق '+fv(AD.agreement_pct)+'٪</span></div><div class="sub" style="margin-top:6px">ارائه‌دهندگان: '+(AD.providers_ok&&AD.providers_ok.length?AD.providers_ok.join("، "):(AD.providers_tried||[]).join("، ")||"بدون کلید AI")+'</div>'+Object.keys(AD.votes||{}).map(function(k){var v=AD.votes[k]||{};return'<div class="kv"><span class="sub">'+esc(k)+'</span><b>'+esc(v.side||"—")+' · '+fv(v.confidence)+'٪</b></div>'}).join("")+(AD.summary?'<div class="tx" style="margin-top:8px">'+esc(AD.summary)+"</div>":""),"b");
h+=card("سناریوهای محتمل",(AD.scenarios||[]).map(function(sc){return'<div class="row sub" style="justify-content:space-between;margin:4px 0"><b>'+esc(sc.name||"?")+' · '+fv(sc.prob)+'٪</b><span>هدف '+fv(sc.target_pct)+'٪</span></div><div class="bar"><i style="width:'+Math.max(0,Math.min(100,+sc.prob||0))+'%"></i></div><div class="sub sm">'+esc(sc.note||"")+"</div>"}).join("")||'<div class="sub">سناریویی نیست</div>',"a");
h+=card("انتظار ۳۰ تا ۹۰ دقیقه آینده",'<div class="tx">'+esc(desk.next_30_90_min||nm.narrative||"—")+"</div>","c");
h+=card("دلایل موافق",(desk.reasons_for||[]).map(function(x){return'<div class="sub up">✓ '+esc(x)+"</div>"}).join("")||"<div class=sub>—</div>","a");
h+=card("دلایل مخالف / ریسک",(desk.reasons_against||[]).map(function(x){return'<div class="sub dn">✗ '+esc(x)+"</div>"}).join("")||"<div class=sub>—</div>","dn");
h+=card("شرط ابطال",'<div class="tx">'+esc(desk.invalidation||"—")+"</div>","c");
var VV=desk.validity||{};
h+=card("درجه لبه تاریخی (Edge Gate)",'<div class="row"><span class="tag '+esc((desk.edge||{}).grade||"UNKNOWN")+'">'+esc((desk.edge||{}).grade||"—")+'</span><span class="sub">'+esc((desk.edge||{}).reason||"")+'</span></div><div class="kp" style="margin-top:8px"><div class="glass"><b>'+fv((desk.edge||{}).expectancy)+'</b>امید</div><div class="glass"><b>'+fv((desk.edge||{}).sharpe)+'</b>شارپ</div><div class="glass"><b>'+fv((desk.edge||{}).trades)+'</b>معامله</div><div class="glass"><b>'+fv((desk.edge||{}).win_rate)+'٪</b>برد</div></div><div class="sub">Safe Mode: '+(desk.safe_mode?"فعال":"خاموش")+' · boost آستانه: '+fv(desk.threshold_boost)+'</div>'+((desk.publish_gate&&desk.publish_gate.reasons&&desk.publish_gate.reasons.length)?'<div class="sub dn">'+desk.publish_gate.reasons.map(function(x){return esc(x)}).join(" · ")+"</div>":""),"go");
h+=card("اعتبار زمانی تصمیم",'<div class="row"><span class="pill tfp">'+esc(VV.timeframe||S.tf||"—")+'</span><span class="sub">'+esc(VV.label||"—")+'</span></div><div class="tx" style="margin-top:6px">'+esc(VV.note||"")+'</div><div class="sub">انقضا (UTC): '+esc(VV.valid_until_iso||"—")+' · '+fv(VV.valid_bars)+' کندل / '+fv(VV.valid_minutes)+' دقیقه</div>'+Object.keys(VV.per_tf_snapshot||{}).map(function(t){var x=VV.per_tf_snapshot[t]||{};return'<div class="kv"><span class="sub">'+t+" · "+esc(x.valid_label||"")+'</span><b class="tag '+(x.bias||"WAIT")+'">'+esc(x.bias||"—")+" · "+fv(x.score)+"</b></div>"}).join(""),"go");
var PS=desk.path_segments||{};
h+=card("مسیر چندافق (نزدیک / میانی / دور)",["near_1_8|کندل ۱–۸","mid_9_24|کندل ۹–۲۴","far_25_48|کندل ۲۵–۴۸"].map(function(z){var k=z.split("|")[0],l=z.split("|")[1],x=PS[k]||{};return'<div class="row sub" style="justify-content:space-between"><b>'+l+'</b><span class="tag '+(/صعود/.test(x.bias||"")?"LONG":/نزول/.test(x.bias||"")?"SHORT":"WAIT")+'">'+esc(x.bias||"—")+" · "+fv(x.move_pct)+"٪</span></div>"}).join(""),"a");
h+=card("یادداشت‌های عمق تحلیل",(desk.depth_notes||[]).map(function(x){return'<div class="sub">• '+esc(x)+"</div>"}).join("")||"<div class=sub>—</div>","b");

h+=card("چک‌لیست حرفه‌ای ("+esc(desk.checklist_score||"—")+")",CK.map(function(c){return'<div class="kv"><span>'+esc(c.name)+'<div class="sub sm">'+esc(c.detail||"")+'</div></span><span class="pill '+(c.ok?"up":"dn")+'">'+(c.ok?"✓":"✗")+"</span></div>"}).join("")||"<div class=sub>—</div>","go");
h+=card("۴۸ کندل آینده · نوسان واقعی",'<div class="row"><span class="tag '+(/صعود/.test(nm.bias||"")?"LONG":/نزول/.test(nm.bias||"")?"SHORT":"WAIT")+'">'+esc(nm.bias||"—")+'</span><span class="sub">حرکت مورد انتظار '+fv(nm.expected_move_pct)+'٪ · قدرت مسیر '+fv(nm.path_strength)+'</span></div><div class="tx" style="margin-top:6px">'+esc(nm.narrative||"")+'</div><div class="sub">'+esc(nm.vol_band_note||"")+"</div>","b");
h+=card("خودانتقادی عملکرد این نماد/تایم‌فریم",crit.has_data?('<div class="kp"><div class="glass"><b>'+fv(crit.win_rate)+'٪</b>نرخ برد</div><div class="glass"><b>'+fv(crit.expectancy)+'</b>امید</div><div class="glass"><b>'+fv(crit.sharpe)+'</b>شارپ</div><div class="glass"><b>'+esc(crit.verdict||"—")+'</b>وضعیت</div></div><div class="tx" style="margin-top:8px">'+esc(crit.lesson||"")+"</div>"):'<div class="sub">هنوز snapshot عملکرد برای این سلول ثبت نشده</div>',"go");
h+=card("یادداشت هزینه و ریسک AI",'<div class="sub">'+esc(desk.cost_note||"")+"</div>"+(AD.risk_note?'<div class="tx" style="margin-top:6px">'+esc(AD.risk_note)+"</div>":""),"c");
return h}
if(T==="ov"){
h+=card("خلاصه تصمیم",'<div class="tx">'+esc(d.summary||d.conviction||"خلاصه در دسترس نیست")+"</div>"+(d.conviction?'<div class="sub" style="margin-top:6px">قطعیت: '+esc(d.conviction)+"</div>":"")+(d.reasons_for&&d.reasons_for.length?'<div class="sub up" style="margin-top:8px">دلایل موافق</div>'+ul(d.reasons_for):"")+(d.reasons_against&&d.reasons_against.length?'<div class="sub dn">دلایل مخالف / ریسک</div>'+ul(d.reasons_against):"")+(d.invalidation?'<div class="sub" style="margin-top:6px">شرط ابطال: '+esc(d.invalidation)+"</div>":""),"a");
h+=card("وضعیت بازار",'<div class="detgrid">'+[["روند",d.trend],["مومنتوم",d.momentum],["نوسان",d.volatility],["رژیم",d.regime]].map(function(x){return'<div class="glass"><span class="sub">'+x[0]+"</span><b>"+esc(String(x[1]||"—"))+"</b></div>"}).join("")+"</div>","b");
h+=card("احتمال‌ها و کیفیت",Object.keys(P).map(function(k){return PB(LB[k]||k,P[k])}).join("")||"<div class=sub>داده‌ای نیست</div>","go");
h+=card("آمار سریع",quick(row),"c")}
else if(T==="tf"){TFS.forEach(function(t,i){var v=(row.tfs||{})[t]||{},dr=v.dir||"WAIT";h+=card("تایم‌فریم "+TFN[t]+" ("+t+")"+(t===row.tf?" ★ اصلی":""),'<div class="row"><span class="tag '+dr+'">'+dr+'</span><span class="sub">امتیاز '+fv(v.score)+" · اطمینان "+fv(v.conf)+"٪</span></div>"+PB("اطمینان",v.conf)+PB("امتیاز",v.score)+'<div class="sub sm">زمان تحلیل: '+(row.asof?ago(row.asof)+" ("+clk(row.asof)+")":"—")+"</div>",CL[i])})}
else if(T==="lv"){
h+=card("ورود / حد ضرر / اهداف",L("ورود",pf(d.entry))+L("حد ضرر",pf(d.sl))+L("هدف ۱",pf(d.tp1))+L("هدف ۲",pf(d.tp2))+L("R:R ۱",fv(d.rr1))+L("R:R ۲",fv(d.rr2))+L("فاصله ریسک ٪",fv(d.risk_pct)),"up");
h+=card("حمایت و مقاومت",L("حمایت",fv(d.support))+L("مقاومت",fv(d.resistance)),"a");
[["فیبوناچی",d.fib,"b"],["بولینگر",d.bollinger,"c"],["پیوت",d.pivots,"go"],["نردبان ورود",d.ladder,"a"],["اوردر بلاک و FVG",d.order_blocks,"b"]].forEach(function(x){if(x[1]&&Object.keys(x[1]).length)h+=oc(x[0],x[1],x[2])})}
else if(T==="ix"){
h+=card("RSI و نوسان",L("RSI",fv(d.rsi))+L("نوسان ٪",fv(d.volatility_pct))+L("نوسان (ردیف)",fv(row.vol)),"a");
[["MACD",d.macd,"b"],["Stoch RSI",d.stoch_rsi,"c"],["سشن",d.session,"go"],["همبستگی BTC",d.btc_corr,"a"],["احساسات",d.sentiment,"b"]].forEach(function(x){if(x[1]&&Object.keys(x[1]).length)h+=oc(x[0],x[1],x[2])})}
else if(T==="fl"){
h+=card("جریان سفارش",L("خرید ٪ (ردیف)",fv(row.buy))+L("خرید تیکر ٪",fv(d.taker_buy_pct))+L("فروش تیکر ٪",fv(d.taker_sell_pct))+L("نسبت لانگ",fv(d.long_ratio))+L("نسبت شورت",fv(d.short_ratio))+L("لانگ تاپ‌تریدرها",fv(d.top_long_ratio))+L("فاندینگ",fv(d.funding))+L("OI",fv(d.oi)),"c");
[["خرید/فروش",d.buy_sell,"a"],["دلتای حجم",d.volume_delta,"b"],["نهنگ",d.whale,"go"],["عمق بازار",d.depth,"c"]].forEach(function(x){if(x[1]&&Object.keys(x[1]).length)h+=oc(x[0],x[1],x[2])})}
else if(T==="ai"){
h+=card("اجماع AI",L("اکثریت",fv(A.majority))+L("توافق",fv(A.agreement))+L("توافق اکثریت",fv(A.majority_agreement))+L("وضعیت",fv(A.status))+L("اکثریت Fusion",fv(A.fusion_majority))+L("تعارض",fv(A.conflict))+(A.tally&&Object.keys(A.tally).length?kvl(A.tally):""),"b");
if(A.votes&&Object.keys(A.votes).length)h+=oc("رأی هر مدل",A.votes,"a");
if(A.details&&Object.keys(A.details).length)h+=oc("جزئیات مدل‌ها",A.details,"c");
Object.keys(A.text||{}).forEach(function(k){h+=card(esc(k),'<div class="tx">'+esc(String(A.text[k]))+"</div>","b")});
var ly=N.layers||{};h+=oc("شبکه نورال",Object.assign({},N,{layers:undefined}),"go");
if(Object.keys(ly).length)h+=card("لایه‌های نورال",Object.keys(ly).map(function(k){var q=ly[k]||{};return PB(k+" · "+fv(q.side)+" · وزن "+fv(q.weight),q.score)}).join(""),"a");
if(d.meta_v8&&Object.keys(d.meta_v8).length)h+=oc("متا V8",d.meta_v8,"c");if(d.precision&&Object.keys(d.precision).length)h+=oc("دقت (Precision)",d.precision,"b")}
else if(T==="ed"){
["regime","risk","liquidity","structure","confluence","meta","governor"].forEach(function(k,i){var e=(d.edge||{})[k];if(e&&Object.keys(e).length)h+=oc("Edge · "+k,e,CL[i%4])});
if(d.data_quality&&Object.keys(d.data_quality).length)h+=oc("کیفیت داده",d.data_quality,"up");if(d.forecast_acc&&Object.keys(d.forecast_acc).length)h+=oc("دقت پیش‌بینی",d.forecast_acc,"go");
if(G.gates&&Object.keys(G.gates).length)h+=oc("گیت‌های اطمینان",G.gates,"dn")}
else if(T==="pt"){
h+=card("الگوها",(d.patterns||[]).length?d.patterns.map(function(p){return'<div class="row" style="margin:4px 0"><span class="chip on">'+esc(p.id||"?")+'</span><span class="sub">اطمینان '+fv(p.confidence)+"</span></div>"}).join(""):'<div class="sub">الگویی نیست</div>',"b");
h+=card("پیش‌بینی شمع",L("سوگیری",fv(F.bias))+L("حرکت مورد انتظار ٪",fv(F.expected_move_pct))+L("قدرت مسیر",fv(F.path_strength))+L("همبستگی تاریخی",fv(F.analogue_corr))+(F.narrative?'<div class="tx" style="margin-top:6px">'+esc(F.narrative)+"</div>":"")+L("سوگیری الگو",fv(d.pattern_bias)),"a");
if((F.candles||[]).length)h+=card("شمع‌های پیش‌بینی‌شده",'<div class="lst">'+F.candles.map(function(c){return"<div><span><b>#"+fv(c.step)+'</b> <span class="sub">'+fv(c.direction)+" · اطمینان "+fv(c.confidence)+"</span></span><span class='sub'>O "+fv(c.open)+" H "+fv(c.high)+" L "+fv(c.low)+" C "+fv(c.close)+"</span></div>"}).join("")+"</div>","c")}
else if(T==="ck"){
h+=card("گرید و اقدام",L("گرید",fv(G.grade))+L("برچسب",fv(G.label))+L("اقدام",fv(G.action))+L("اعتماد",fv(G.trust)),"go");
h+=card("چک‌لیست",(G.checklist||[]).map(function(c){return'<div class="kv"><span>'+esc(c.name)+'<div class="sub sm">'+esc(c.detail||"")+'</div></span><span class="pill '+(c.ok?"up":"dn")+'">'+(c.ok?"✓":"✗")+"</span></div>"}).join("")||"<div class=sub>چک‌لیستی نیست</div>","up")}
else{h+=oc("ردیف سیگنال (همه فیلدها)",row,"a");Object.keys(d).forEach(function(k,i){var v=d[k];if(v&&typeof v==="object")h+=oc(k,Array.isArray(v)?{items:v}:v,CL[i%4]);else if(v!=null&&v!=="")h+=card(k,'<div class="kv"><span class="sub">'+esc(LB[k]||k)+"</span><b>"+fv(v)+"</b></div>",CL[i%4])})}
return h+'<button class="btn" data-act="fin" style="width:100%;margin:8px 0;grid-column:1/-1">تصمیم نهایی AI</button>'}
function topTf(tf,n,dir){return S.rows.map(function(r){return{r:r,v:(r.tfs||{})[tf]||{}}}).filter(function(x){var d=x.v.dir;return d&&d!=="WAIT"&&(dir==="ALL"||d===dir)}).sort(function(a,b){return(b.v.conf-a.v.conf)||(Math.abs(b.v.score-50)-Math.abs(a.v.score-50))||(b.r.conf-a.r.conf)}).slice(0,n)}
function toprows(tf,n,dir){var a=topTf(tf,n,dir);return a.length?'<div class="lst">'+a.map(function(x,i){var r=x.r,v=x.v;return'<div data-s="'+esc(r.symbol)+'"><span style="flex:1;min-width:0"><span style="display:flex;gap:8px;align-items:center"><b class="rk">'+(i+1)+"</b><b>"+esc(r.symbol)+'</b><span class="tag '+v.dir+'">'+v.dir+'</span></span><div class="sub sm">امتیاز '+fv(v.score)+" · اطمینان "+fv(v.conf)+"٪ · "+(r.asof?ago(r.asof)+" ("+clk(r.asof)+")":"")+'</div><div class="bar"><i style="width:'+v.conf+'%"></i></div></span><span style="text-align:end">'+pf(r.price)+'<div class="sm '+(r.change>=0?"up":"dn")+'">'+r.change.toFixed(1)+"٪</div></span></div>"}).join("")+"</div>":'<div class="sub">سیگنال جهت‌دار برای این تایم‌فریم نیست</div>'}
function tfmx(){return'<div class="mxw"><table class="mx"><tr><th>ارز</th>'+TFS.map(function(t){return"<th>"+t+"</th>"}).join("")+"<th>زمان سیگنال</th></tr>"+S.rows.slice().sort(function(a,b){return b.conf-a.conf}).map(function(r){return'<tr data-s="'+esc(r.symbol)+'"><td><b>'+esc(r.base||r.symbol.split("/")[0])+"</b></td>"+TFS.map(function(t){var v=(r.tfs||{})[t]||{},d=v.dir||"WAIT";return'<td class="'+d+'">'+(d==="LONG"?"▲":d==="SHORT"?"▼":"•")+" "+fv(v.conf)+"</td>"}).join("")+'<td class="sub">'+(r.asof?ago(r.asof):"")+"</td></tr>"}).join("")+"</table></div>"}
function edgeCards(){var E=S.eg;if(!E)return card("مزیت تاریخی (Edge Router)","<div class=sub>در حال دریافت…</div>","go");if(!E.ok)return card("مزیت تاریخی (Edge Router)","<div class=sub>در دسترس نیست</div>","dn");var cells=E.cells||[],sm=E.summary||{},h=card("خلاصه Edge Router",'<div class="kp">'+[["strong","قوی"],["positive","مثبت"],["neutral","خنثی"],["weak","ضعیف"],["toxic","سمی"],["sparse","کم‌نمونه"],["total_cells","کل سلول‌ها"]].map(function(k){return'<div class="glass"><b>'+fv(sm[k[0]])+"</b>"+k[1]+"</div>"}).join("")+"</div>",'go');
TFS.forEach(function(t,i){var a=cells.filter(function(c){return c.timeframe===t&&c.grade!=="SPARSE"}).sort(function(x,y){return y.edge_score-x.edge_score}).slice(0,6);h+=card("مزیت تاریخی · "+TFN[t],a.length?'<div class="lst">'+a.map(function(c){return'<div data-s="'+esc(c.symbol)+'"><span><b>'+esc(c.symbol)+'</b> <span class="tag '+esc(c.grade)+'">'+esc(c.grade)+'</span><div class="sub sm">برد '+fv(c.win_rate)+"٪ · PF "+fv(c.profit_factor)+" · امید ریاضی "+fv(c.expectancy)+" · شارپ "+fv(c.sharpe)+" · افت "+fv(c.max_drawdown)+" · "+fv(c.trades)+' معامله</div></span><b>'+fv(c.edge_score)+"</b></div>"}).join("")+"</div>":'<div class="sub">سلول معتبر (حداقل ۲۵ معامله) نیست</div>',CL[i])});return h}
function ptp(){if(!S.rows.length)return card("برترین‌ها","<div class=sub>در حال دریافت داده بازار…</div>");var d=S.bd||"ALL",n=S.bn||5,h=chips([["ALL","همه جهت‌ها"],["LONG","LONG"],["SHORT","SHORT"]],d,"data-bd")+chips([[3,"۳ برتر"],[5,"۵ برتر"],[8,"۸ برتر"],[12,"۱۲ برتر"]],n,"data-bn");
TFS.forEach(function(t,i){h+=card("بهترین ارزها · "+TFN[t]+" ("+t+")",toprows(t,n,d),CL[i])});
h+=card("ماتریس ارز × تایم‌فریم (جهت و اطمینان)",tfmx(),"c")+edgeCards();return h}
function pdx(){var U=S.ui||{},r=cur(),h="",c=U.counts||{},b=U.breadth||{},m=U.macro||{},au=U.audit||{},pp=U.paper||{},sc=U.scan||{},tot=(b.up||0)+(b.down||0)+(b.flat||0)||1;
if(r)h+=card("سیگنال "+esc(r.symbol)+" · تایم‌فریم و زمان",'<div class="row"><span class="tag '+esc(r.decision)+'">'+esc(r.decision)+"</span><span>"+esc(r.grade_fa||r.grade||"")+"</span></div>"+sigMeta(r)+tfchips(r)+quick(r),r.decision==="LONG"?"up":r.decision==="SHORT"?"dn":"go");
h+=card("نمای کلی بازار",donut([[c.LONG||0,"var(--up)"],[c.SHORT||0,"var(--dn)"],[c.WAIT||0,"var(--go)"]],S.rows.length,"ارز")+'<div class="kv"><span class="sub">LONG / SHORT / WAIT</span><b>'+(c.LONG||0)+" / "+(c.SHORT||0)+" / "+(c.WAIT||0)+"</b></div>"+'<div class="kv"><span class="sub">میانگین امتیاز</span><b>'+fv(U.avg_score)+"</b></div>"+'<div class="sub" style="margin-top:6px">پهنای بازار: ↑'+(b.up||0)+" ↓"+(b.down||0)+" →"+(b.flat||0)+'</div><div class="dv" style="display:flex;overflow:hidden"><i style="position:static;background:var(--up);width:'+(b.up||0)/tot*100+'%"></i><i style="position:static;background:var(--go);width:'+(b.flat||0)/tot*100+'%"></i><i style="position:static;background:var(--dn);width:'+(b.down||0)/tot*100+'%"></i></div>',"b");
h+=card("ترس و طمع · ماکرو",gauge(+m.fear||0)+'<div class="kv"><span class="sub">وضعیت</span><b>'+fv(m.fear_text)+'</b></div><div class="kv"><span class="sub">دامیننس BTC</span><b>'+fv(m.btc_dom)+'</b></div><div class="kv"><span class="sub">روند BTC</span><b>'+fv(m.btc_trend)+"</b></div>","go");
h+=card("سیستم و اسکن",kvl({"پیشرفت اسکن ٪":sc.percent,"وضعیت اسکن":sc.status,"فاز":sc.phase,"پیام":sc.message,"تکمیل / کل":(sc.completed!=null?sc.completed+" / "+sc.total:null),"سن کش (ثانیه)":U.cache_age,"ضریب ریسک":U.risk,"نسخه":U.version,"بیلد":U.build,"ذخیره‌سازی":U.storage,"ارزهای فعال":(U.coins||[]).length}),"c");
h+=card("ممیزی و عملکرد",'<div class="sub">ممیزی</div>'+kvl(au)+'<div class="sub" style="margin-top:8px">معاملات کاغذی</div>'+kvl(pp),"a");
var al=U.alerts||[];h+=card("هشدارها",al.length?'<div class="lst">'+al.map(function(a){return"<div><span><b>"+esc(a.symbol||"")+'</b> <span class="pill">'+esc(a.severity||"")+'</span> <span class="sub">'+esc(a.category||"")+'</span><div class="sub sm">'+esc(a.message||"")+'</div></span><span class="sub sm">'+clk(a.created_at)+"</span></div>"}).join("")+"</div>":'<div class="sub">هشداری نیست</div>',"dn");
if(U.summary)h+=card("خلاصه بازار",'<div class="tx">'+esc(U.summary)+"</div>","b");
TFS.forEach(function(t,i){h+=card("برترین‌ها · "+TFN[t],toprows(t,3,"ALL"),CL[i])});return h}
function radar4(r){var ax=[["اطمینان",r.conf],["امتیاز",r.score],["اعتماد",r.trust],["احتمال",r.prob]],pt=function(i,k){var t=i/4*6.2832-1.5708;return[100+Math.cos(t)*k,95+Math.sin(t)*k]},s='<svg viewBox="0 0 200 190" width="100%"><defs><filter id="rg" x="-50%" y="-50%" width="200%" height="200%"><feGaussianBlur stdDeviation="2" result="b"/><feMerge><feMergeNode in="b"/><feMergeNode in="SourceGraphic"/></feMerge></filter></defs>',P=[];
[.33,.66,1].forEach(function(k){s+='<polygon points="'+ax.map(function(_,i){return pt(i,66*k).join(",")}).join(" ")+'" fill="none" stroke="#ffffff22"/>'});
ax.forEach(function(x,i){var e=pt(i,66),l=pt(i,82),v=Math.max(0,Math.min(100,+x[1]||0))/100;s+='<line x1="100" y1="95" x2="'+e[0]+'" y2="'+e[1]+'" stroke="#ffffff22"/><text x="'+l[0]+'" y="'+(l[1]+3)+'" font-size="10" text-anchor="middle" fill="#8e98c9">'+x[0]+'</text>';P.push(pt(i,66*v))});
return s+'<polygon filter="url(#rg)" points="'+P.map(function(p){return p.join(",")}).join(" ")+'" fill="var(--a)" fill-opacity=".28" stroke="var(--a)" stroke-width="2"/>'+P.map(function(p){return'<circle cx="'+p[0]+'" cy="'+p[1]+'" r="3.5" fill="var(--c)"/>'}).join("")+"</svg>"}
var VW={sc:psc,ov:pvw,tp:ptp,dt:pdt,ch:pch,ai:pai,mk:pmk,pf:ppf,st:pst};
function bindPanels(){var root=$("view");if(!root)return;CF.po=CF.po||{};
root.querySelectorAll(".drag-panel").forEach(function(sec){var h=sec.querySelector(".drag-handle");if(!h||h._dragBound)return;h._dragBound=1;
h.style.cursor="grab";
h.onpointerdown=function(e){if(e.target.closest("button"))return;e.preventDefault();h.setPointerCapture(e.pointerId);h.style.cursor="grabbing";
var startY=e.clientY,el=sec,placeholder=document.createElement("div");placeholder.className="drag-ph";placeholder.style.height=el.offsetHeight+"px";
var parent=el.parentNode,kids=[].slice.call(parent.children).filter(function(n){return n.classList&&n.classList.contains("drag-panel")});
var dragging=1;
function move(ev){if(!dragging)return;var y=ev.clientY;el.style.opacity=".85";el.style.transform="scale(.98)";
var over=null,mid=0;kids.forEach(function(n){if(n===el)return;var r=n.getBoundingClientRect();if(y>r.top&&y<r.bottom){over=n;mid=r.top+r.height/2}});
if(over){if(y<mid)parent.insertBefore(el,over);else parent.insertBefore(el,over.nextSibling)}}
function up(){dragging=0;el.style.opacity="";el.style.transform="";h.style.cursor="grab";
try{h.releasePointerCapture(e.pointerId)}catch(ex){}
var order={};[].slice.call(parent.querySelectorAll(".drag-panel")).forEach(function(n,i){var id=n.getAttribute("data-pid");if(id){order[id]=i;n.style.order=i}});CF.po=order;sv()};
h.onpointermove=move;h.onpointerup=up;h.onpointercancel=up}})
}
function render(){$("nav").innerHTML=TABS.map(function(t){return'<button class="'+(S.tab===t[0]?"on":"")+'" data-t="'+t[0]+'"><b class="ic">'+t[2]+"</b>"+t[1]+"</button>"}).join("");$("view").innerHTML=VW[S.tab]();var st=$("stat");if(st)st.textContent=S.rows.length+" ارز · "+(S.sel||"");if(S.tab==="ch")setTimeout(bindChart,20);setTimeout(bindPanels,30)}
function soft(){if(["ov","ch","ai"].indexOf(S.tab)>=0)render()}
function loadV(){var t=S.tf;get("/api/v71/validate?timeframe="+t).then(function(r){S.vl=S.vl||{};S.vl[t]=r;if(S.tab==="ch")render();if(r.computing&&S.tf===t)setTimeout(loadV,8000)}).catch(function(){})}

function bindChart(){var w=document.getElementById("chwrap"),svg=document.getElementById("chsvg");if(!w||!svg)return;
var k=kk(),all=S.kl[k]||[];if(!all.length)return;
function priceAt(clientY){var r=svg.getBoundingClientRect(),h=190,vh=34,rel=(clientY-r.top)/r.height*(h+vh+8);var z=S.zoom||1,maxVis=Math.min(all.length,Math.max(20,Math.round(all.length/z))),start=Math.max(0,Math.min(all.length-maxVis,all.length-maxVis-Math.round(S.pan||0))),c=all.slice(start,start+maxVis),mx=-1e99,mn=1e99;c.forEach(function(q){mx=Math.max(mx,q.h);mn=Math.min(mn,q.l)});var F=S.fc[k]||{},fc=F.candles||[];fc.forEach(function(q){mx=Math.max(mx,q.high);mn=Math.min(mn,q.low)});var pd=(mx-mn)*.05||1;mx+=pd;mn-=pd;var y=Math.max(6,Math.min(h-6,rel));return mx-(y-6)/(h-12)*(mx-mn)}
function idxAt(clientX){var r=svg.getBoundingClientRect(),z=S.zoom||1,maxVis=Math.min(all.length,Math.max(20,Math.round(all.length/z))),start=Math.max(0,Math.min(all.length-maxVis,all.length-maxVis-Math.round(S.pan||0))),c=all.slice(start,start+maxVis),nf=(S.fc[k]&&S.fc[k].candles||[]).length,T=c.length+nf,bw=340/Math.max(T,1),x=(clientX-r.left)/r.width*340;return start+Math.max(0,Math.min(c.length-1,Math.floor(x/bw)))}
var dragging=0,lx=0,ly=0;
w.onwheel=function(e){e.preventDefault();var dy=e.deltaY>0?1.12:1/1.12;S.zoom=Math.max(1,Math.min(8,(S.zoom||1)*dy));if(S.tab==="ch"){var html=document.getElementById("view");if(html){/* soft re-render chart only */}render();setTimeout(bindChart,20)}};
w.onpointerdown=function(e){dragging=1;lx=e.clientX;ly=e.clientY;w.setPointerCapture(e.pointerId);var tool=S.tool||"pan";if(tool==="hline"){S.drawTmp={t:"hline",p:priceAt(e.clientY)}}
else if(tool==="trend"||tool==="rect"||tool==="fib"){var i=idxAt(e.clientX),p=priceAt(e.clientY);S.drawTmp={t:tool,i1:i,p1:p,i2:i,p2:p}}};
w.onpointermove=function(e){if(!dragging)return;var tool=S.tool||"pan",dx=e.clientX-lx,dy=e.clientY-ly;
if(tool==="pan"||tool==="zoom"){S.pan=(S.pan||0)+dx*0.15;lx=e.clientX;if(S.tab==="ch")render();setTimeout(bindChart,10)}
else if(S.drawTmp){if(S.drawTmp.t==="hline")S.drawTmp.p=priceAt(e.clientY);else{S.drawTmp.i2=idxAt(e.clientX);S.drawTmp.p2=priceAt(e.clientY)}if(S.tab==="ch")render();setTimeout(bindChart,10)}};
w.onpointerup=function(e){if(!dragging)return;dragging=0;var tool=S.tool||"pan";if(S.drawTmp&&tool!=="pan"&&tool!=="zoom"){var D=S.draws[k]||[];D.push(Object.assign({},S.drawTmp));S.draws[k]=D.slice(-40);S.drawTmp=null;if(S.tab==="ch")render();setTimeout(bindChart,20)}else S.drawTmp=null};
var lastPinch=0;
w.ontouchstart=function(e){if(e.touches.length===2){var d=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);lastPinch=d}};
w.ontouchmove=function(e){if(e.touches.length===2&&lastPinch){e.preventDefault();var d=Math.hypot(e.touches[0].clientX-e.touches[1].clientX,e.touches[0].clientY-e.touches[1].clientY);S.zoom=Math.max(1,Math.min(8,(S.zoom||1)*(d/lastPinch)));lastPinch=d;if(S.tab==="ch")render();setTimeout(bindChart,20)}}};
function loadK(){var s=S.sel,t=S.tf,k=kk();if(!s)return;loadV();get("/api/v69/cone-stats").then(function(r){S.cs=r;if(S.tab==="ch")render()}).catch(function(){});get("/api/klines?symbol="+encodeURIComponent(s)+"&timeframe="+t+"&limit=200").then(function(r){S.kl[k]=r.ok?r.candles:[];if(kk()===k){soft();if(S.tab==="ch")setTimeout(bindChart,40)}}).catch(function(){});get("/api/forecast24?symbol="+encodeURIComponent(s)+"&timeframe="+t).then(function(r){S.fc[k]=r;if(kk()===k)soft()}).catch(function(){})}
function loadE(){get("/api/v68/learning").then(function(r){S.lr=r;if(S.tab==="pf")render()}).catch(function(){});S.ev=null;if(S.tab==="pf")render();get("/api/v64/evaluation?days="+S.pd).then(function(r){S.ev=r;if(S.tab==="pf")render()}).catch(function(){S.ev={ok:false};if(S.tab==="pf")render()});get("/api/v75/performance-live").then(function(r){S.perfLive=r;if(S.tab==="pf")render()}).catch(function(){S.perfLive={ok:false}});
get("/api/v78/eval?days="+S.pd).then(function(r){S.v78e=r;if(S.tab==="pf")render()}).catch(function(){S.v78e=null});
var sym=encodeURIComponent(S.sel||"BTC/USDT"),tf=encodeURIComponent(S.tf||"1h");
get("/api/walk-forward?symbol="+sym+"&timeframe="+tf+"&limit=800&train=240&test=80").then(function(r){S.wf=r;if(S.tab==="pf")render()}).catch(function(){S.wf={ok:false}});
get("/api/v75/deep-eval").then(function(){return get("/api/v75/deep-stats")}).then(function(r){S.deepStats=r;if(S.tab==="pf")render()}).catch(function(){S.deepStats={ok:false}})}
function tick(){if(document.hidden||S.busy)return;S.busy=1;get("/api/v59/ui-data").then(function(d){var first=!S.rows.length;S.rows=(d&&d.rows)||[];S.ui=d||{};var ob=document.getElementById("off");if(!ob||ob.style.display!=="block")swp({t:"rows",rows:S.rows.map(function(r){return{symbol:r.symbol,decision:r.decision,conf:r.conf,score:r.score,price:r.price}})});if(!S.sel&&S.rows.length)S.sel=(S.rows.filter(function(r){return r.symbol==="BTC/USDT"})[0]||S.rows[0]).symbol;if(first){loadK();loadCoin();}if((S.tab==="ov"||S.tab==="mk"||S.tab==="tp"||S.tab==="sc")&&!(document.activeElement&&document.activeElement.id==="q"))render()}).catch(function(){}).then(function(){S.busy=0})}
document.addEventListener("pointerdown",function(e){var t=e.target.closest&&e.target.closest(".chip,.btn,.th,.nav button");if(!t)return;var r=t.getBoundingClientRect(),s=document.createElement("span"),m=Math.max(r.width,r.height)*2;s.className="rp";s.style.cssText="width:"+m+"px;height:"+m+"px;left:"+(e.clientX-r.left-m/2)+"px;top:"+(e.clientY-r.top-m/2)+"px";if(getComputedStyle(t).position==="static")t.style.position="relative";t.style.overflow="hidden";t.appendChild(s);try{navigator.vibrate&&navigator.vibrate(6)}catch(_){}setTimeout(function(){s.remove()},600)},{passive:true});
document.addEventListener("click",function(e){var g=function(a){var n=e.target.closest&&e.target.closest("["+a+"]");return n?n.getAttribute(a):null},v;
if((v=g("data-cl"))){CF.cl=CF.cl||{};CF.cl[v]=CF.cl[v]?0:1;sv();render();return}
if((v=g("data-mx"))){S.mx=S.mx===v?null:v;render();return}
if((v=g("data-wa"))){var ids=[].map.call(document.querySelectorAll("#view [data-cl]"),function(x){return x.getAttribute("data-cl")});CF.cl=CF.cl||{};if(v==="reset")CF.cl={};else ids.forEach(function(i){CF.cl[i]=v==="close"?1:0});S.mx=null;sv();render();return}
if((v=g("data-bd"))){S.bd=v;render();return}
if((v=g("data-bn"))){S.bn=+v;render();return}
if((v=g("data-mtf"))){S.mt=v;render();return}
if((v=g("data-mf"))){S.mf=v;render();return}
if((v=g("data-ms"))){S.ms=v;render();return}
if((v=g("data-t"))){S.tab=v;S.mx=null;render();if(v==="pf")loadE();if(v==="tp")loadEdge();if(v==="dt")loadCoin();if(v==="ch")setTimeout(bindChart,30);window.scrollTo(0,0);return}
if((v=g("data-s"))){S.sel=v;S.pan=0;S.drawTmp=null;if(S.tab==="mk"||S.tab==="tp")S.tab="dt";render();loadK();loadCoin();return}
if((v=g("data-tf"))){S.tf=v;S.pan=0;render();loadK();return}
if((v=g("data-ctab"))){S.ctab=v;render();return}
if((v=g("data-tool"))){if(v==="zreset"){S.zoom=1;S.pan=0}else if(v==="zclear"){S.draws[kk()]=[];S.drawTmp=null}else if(v==="erase"){var D=S.draws[kk()]||[];D.pop();S.draws[kk()]=D}else S.tool=v;if(S.tab==="ch")render();return}
if((v=g("data-pd"))){S.pd=+v;loadE();return}
if((v=g("data-evf"))){S.evf=v;render();return}
if((v=g("data-mod"))){CF.md=v;sv();ap();render();return}
if((v=g("data-lay"))){CF.layout=v;sv();ap();render();return}
if((v=g("data-navx"))){CF.nav=v;sv();ap();render();return}
if((v=g("data-dens"))){CF.density=v;sv();ap();render();return}
if((v=g("data-cardx"))){CF.card=v;sv();ap();render();return}
if((v=g("data-tabx"))){CF.tabs=v;sv();ap();render();return}
if((v=g("data-menux"))){CF.menu=v;sv();ap();render();return}
if((v=g("data-groupx"))){CF.group=v;sv();ap();render();return}

if((v=g("data-sty"))){CF.st=v;sv();ap();render();return}
if((v=g("data-sht"))){var TT=(CF.shT&&CF.shT.length?CF.shT:Object.keys(SHT)).slice(),ix=TT.indexOf(v);if(ix>=0){if(TT.length>1)TT.splice(ix,1)}else TT.push(v);CF.shT=TT;sv();ap();render();return}
if((v=g("data-acc"))){CF.cu=curTh().slice();CF.cu[2]=v;sv();ap();render();return}
if((v=g("data-pre"))){var pp=v.charAt(0)==="m"?(CF.my||[])[+v.slice(1)]:PR[+v];if(pp){var qq=Object.assign({},pp);delete qq.n;Object.assign(CF,{cu:null,sh:1,shT:null},qq);sv();ap();render()}return}
if((v=g("data-th"))){CF.th=v;CF.cu=null;sv();ap();render();return}
if((v=g("data-nt"))){var n=CF.nt=Object.assign({on:0,nmin:75,cool:4,L:1,S:1},CF.nt||{});if(v==="on"){if(n.on){n.on=0;sv();ntCfg();render()}else if("Notification" in window){Notification.requestPermission().then(function(p){n.on=p==="granted"?1:0;sv();swp({t:"reset"});ntCfg();render()})}}else{n[v]=n[v]===0?1:0;sv();ntCfg();render()}return}
if((v=g("data-sw"))){CF[v]=CF[v]?0:1;sv();ap();render();return}
if((v=g("data-act"))){if(v==="fin"){var k=kk();S.fin[k]="busy";render();get("/api/v64/final?symbol="+encodeURIComponent(S.sel)+"&timeframe="+S.tf+"&ai=1").then(function(r){S.fin[k]=r;render()}).catch(function(){S.fin[k]={ok:false,error:"خطا در ارتباط"};render()})}
else if(v==="scan"){get("/rescan").catch(function(){});e.target.textContent="درخواست شد ✓"}
else if(v==="safeon"){get("/api/v75/pro-policy?action=set&safe_mode=1").then(function(){e.target.textContent="Safe ✓"}).catch(function(){})}
else if(v==="safeoff"){get("/api/v75/pro-policy?action=set&safe_mode=0").then(function(){e.target.textContent="خاموش ✓"}).catch(function(){})}
else if(v==="edgeon"){get("/api/v75/pro-policy?action=set&require_edge=1").then(function(){e.target.textContent="Edge ✓"}).catch(function(){})}
else if(v==="edgeoff"){get("/api/v75/pro-policy?action=set&require_edge=0").then(function(){e.target.textContent="آزاد ✓"}).catch(function(){})}
else if(v==="deepeval"){get("/api/v75/deep-eval").then(function(r){e.target.textContent="ارزیابی "+(r&&r.evaluated!=null?r.evaluated:"✓")}).catch(function(){e.target.textContent="خطا"})}else if(v==="backup"){get("/api/v72/backup").then(function(r){e.target.textContent=r&&r.ok?"پشتیبان ✓":"خطا"}).catch(function(){e.target.textContent="خطا"})}else if(v==="sqlite"){get("/api/v72/sqlite?force=1").then(function(r){e.target.textContent=r&&r.ok?"SQLite ✓":"خطا"}).catch(function(){e.target.textContent="خطا"})}else if(v==="savep"){var sn={n:"نمونه من "+((CF.my||[]).length+1)};KEYS.forEach(function(k){sn[k]=CF[k]});CF.my=(CF.my||[]).concat([sn]).slice(-6);sv();render()}else if(v==="clrp"){CF.my=[];sv();render()}else if(v==="ntest"){swp({t:"test"})}else if(v==="install"&&IP){IP.prompt();IP=null;render()}else if(v==="reset"){CF=dflt();sv();ap();ntCfg();render()}}});
document.addEventListener("input",function(e){var t=e.target;var nk=t.getAttribute&&t.getAttribute("data-nk");if(nk){CF.nt=Object.assign({on:0,nmin:75,cool:4,L:1,S:1},CF.nt||{});CF.nt[nk]=+t.value;sv();ntCfg();var nb=t.nextElementSibling;if(nb)nb.textContent=t.value+(nk==="nmin"?"٪":"");return}var k=t.getAttribute&&t.getAttribute("data-k"),c=t.getAttribute&&t.getAttribute("data-c");
if(k){CF[k]=+t.value;sv();ap();var nb2=t.nextElementSibling;if(nb2&&nb2.tagName==="B")nb2.textContent=t.value}else if(c!=null&&c!==""){CF.cu=(CF.cu||TH[CF.th]).slice();CF.cu[+c]=t.value;sv();ap()}else if(t.id==="q"){S.q=t.value;var m=$("ml");if(m){m.innerHTML=ml(mlist())}}});
document.addEventListener("keydown",function(e){if(e.key==="Escape"&&S.mx){S.mx=null;render()}});
var SWR=null,IP=null;
function swp(m){if(SWR&&SWR.active)SWR.active.postMessage(m)}
function ntCfg(){var n=CF.nt||{};swp({t:"cfg",cfg:{on:!!n.on,nmin:+n.nmin||75,cool:+n.cool||4,dirs:[n.L!==0?"LONG":"",n.S!==0?"SHORT":""].filter(Boolean)}})}
if("serviceWorker" in navigator){navigator.serviceWorker.register("/sw.js").then(function(){return navigator.serviceWorker.ready}).then(function(r){SWR=r;ntCfg();try{if(r.periodicSync)r.periodicSync.register("titan-check",{minInterval:3600000}).catch(function(){})}catch(e){}}).catch(function(){});navigator.serviceWorker.addEventListener("message",function(e){var m=e.data||{};if(m.t==="open"&&m.sym){S.sel=m.sym;S.tab="ch";render();loadK()}})}
window.addEventListener("beforeinstallprompt",function(e){e.preventDefault();IP=e;if(S.tab==="st")render()});
(function(){var m=location.search.match(/[?&]sym=([^&]+)/);if(m){S.sel=decodeURIComponent(m[1]);S.tab="ch"}})();
ap();render();tick();setInterval(tick,8000);setInterval(function(){if(!document.hidden&&S.tab==="dt"&&S.sel)loadCoin()},30000);setInterval(function(){if(!document.hidden&&S.sel)loadK()},60000);
</script></body></html>
'''


# Replace the execution entry point after all V49 wrappers are defined.
