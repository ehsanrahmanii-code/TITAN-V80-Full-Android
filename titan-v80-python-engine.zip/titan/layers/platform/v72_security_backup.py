# [TITAN V77 layer] platform/v72_security_backup - V72 security headers / backup / health
# Original V76 source lines 28993-29334 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# V72 FINAL: security headers · SQLite backup/optimize · health page
# Analysis only. No order execution. Secrets never leave the process.
# ============================================================
_V72_BACKUP_DIR = DATA_DIR / "backups"
_V72_BACKUP_DIR.mkdir(parents=True, exist_ok=True)
_V72_LAST_OPTIMIZE = [0.0]
_V72_LAST_BACKUP = [0.0]
_V72_OPTIMIZE_INTERVAL = 6 * 3600
_V72_BACKUP_INTERVAL = 24 * 3600
_V72_BACKUP_KEEP = 7


@app.after_request
def _v72_security_headers(resp):
    """Hardening headers for the local dashboard (no third-party framing)."""
    try:
        resp.headers.setdefault("X-Content-Type-Options", "nosniff")
        resp.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
        resp.headers.setdefault("Referrer-Policy", "no-referrer")
        resp.headers.setdefault(
            "Permissions-Policy", "geolocation=(), microphone=(), camera=()"
        )
        resp.headers.setdefault("Cross-Origin-Opener-Policy", "same-origin")
        if "Content-Security-Policy" not in resp.headers:
            resp.headers["Content-Security-Policy"] = (
                "default-src 'self'; "
                "script-src 'self' 'unsafe-inline'; "
                "style-src 'self' 'unsafe-inline'; "
                "img-src 'self' data:; "
                "connect-src 'self'; "
                "worker-src 'self'; "
                "manifest-src 'self'; "
                "frame-ancestors 'self'; "
                "base-uri 'self'; "
                "form-action 'self'"
            )
        if request.path.startswith("/api/") or request.path in (
            "/health",
            "/download/titan.py",
        ):
            resp.headers.setdefault("Cache-Control", "no-store")
    except Exception:
        _swallow()
    return resp


def _v72_sqlite_optimize(force: bool = False) -> dict:
    """WAL checkpoint + PRAGMA optimize. Mobile-safe intervals."""
    now = time.time()
    if not force and now - _V72_LAST_OPTIMIZE[0] < _V72_OPTIMIZE_INTERVAL:
        return {
            "ok": True,
            "skipped": True,
            "next_in_sec": int(
                _V72_OPTIMIZE_INTERVAL - (now - _V72_LAST_OPTIMIZE[0])
            ),
        }
    out: dict = {"ok": False}
    try:
        with DB_LOCK, db_conn() as con:
            try:
                ck = con.execute("PRAGMA wal_checkpoint(TRUNCATE)").fetchone()
                out["wal_checkpoint"] = list(ck) if ck else None
            except Exception as exc:
                out["wal_checkpoint_error"] = str(exc)[:120]
            try:
                con.execute("PRAGMA optimize")
                out["optimize"] = True
            except Exception as exc:
                out["optimize_error"] = str(exc)[:120]
            try:
                qc = con.execute("PRAGMA quick_check").fetchone()
                out["quick_check"] = qc[0] if qc else None
            except Exception as exc:
                out["quick_check_error"] = str(exc)[:120]
            try:
                page_count = con.execute("PRAGMA page_count").fetchone()[0]
                page_size = con.execute("PRAGMA page_size").fetchone()[0]
                freelist = con.execute("PRAGMA freelist_count").fetchone()[0]
                out["size_bytes"] = int(page_count) * int(page_size)
                out["freelist_pages"] = int(freelist)
            except Exception:
                _swallow()
        _V72_LAST_OPTIMIZE[0] = now
        out["ok"] = True
        out["at"] = _now_iso()
    except Exception as exc:
        out["error"] = str(exc)[:200]
        LOGGER.warning("v72 sqlite optimize failed: %s", exc)
    return out


def _v72_backup_now(reason: str = "manual") -> dict:
    """Copy DB + settings JSON into DATA_DIR/backups with rotation."""
    import shutil

    ts = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    dest = _V72_BACKUP_DIR / f"titan_backup_{ts}"
    dest.mkdir(parents=True, exist_ok=True)
    copied = []
    errors = []
    try:
        try:
            with DB_LOCK, db_conn() as con:
                con.execute("PRAGMA wal_checkpoint(PASSIVE)")
        except Exception:
            _swallow()
        for src in (DB_PATH, USER_SETTINGS_PATH, MODEL_SETTINGS_PATH, LOG_PATH):
            try:
                p = Path(src)
                if p.is_file():
                    target = dest / p.name
                    shutil.copy2(str(p), str(target))
                    copied.append(p.name)
                    if p == DB_PATH:
                        for suffix in ("-wal", "-shm"):
                            side = Path(str(p) + suffix)
                            if side.is_file():
                                shutil.copy2(
                                    str(side), str(dest / (p.name + suffix))
                                )
                                copied.append(p.name + suffix)
            except Exception as exc:
                errors.append(f"{src}: {exc}"[:160])
        meta = {
            "created_at": _now_iso(),
            "reason": reason,
            "build": TITAN_BUILD_ID,
            "copied": copied,
            "errors": errors,
            "app_home": str(APP_HOME),
        }
        (dest / "manifest.json").write_text(
            json.dumps(meta, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        backups = sorted(
            [
                d
                for d in _V72_BACKUP_DIR.iterdir()
                if d.is_dir() and d.name.startswith("titan_backup_")
            ],
            reverse=True,
        )
        for old in backups[_V72_BACKUP_KEEP:]:
            try:
                shutil.rmtree(old, ignore_errors=True)
            except Exception:
                _swallow()
        _V72_LAST_BACKUP[0] = time.time()
        LOGGER.info("v72 backup ok reason=%s files=%s", reason, len(copied))
        return {
            "ok": True,
            "path": str(dest),
            "copied": copied,
            "errors": errors,
            "kept": _V72_BACKUP_KEEP,
        }
    except Exception as exc:
        LOGGER.warning("v72 backup failed: %s", exc)
        return {"ok": False, "error": str(exc)[:200]}


_V75_LAST_DEEP_EVAL = [0.0]

def _v72_maintenance_tick() -> None:
    """Background: optimize SQLite on interval; daily backup if due; deep-eval learning."""
    try:
        _v72_sqlite_optimize(force=False)
        if time.time() - _V72_LAST_BACKUP[0] >= _V72_BACKUP_INTERVAL:
            _v72_backup_now(reason="scheduled")
        # Auto-evaluate deep decisions for learning loop
        interval = float(globals().get("TITAN_DEEP_EVAL_INTERVAL_SEC", 900))
        if time.time() - _V75_LAST_DEEP_EVAL[0] >= interval:
            try:
                with app.test_request_context("/api/v75/deep-eval"):
                    api_v75_deep_eval()
                _V75_LAST_DEEP_EVAL[0] = time.time()
            except Exception:
                _swallow()
    except Exception:
        _swallow()


@app.get("/api/v72/backup")
def api_v72_backup():
    """Create an on-demand backup of DB + settings inside MMM/data/backups."""
    force = str(request.args.get("force", "1")) != "0"
    if not force and time.time() - _V72_LAST_BACKUP[0] < 300:
        return jsonify({"ok": False, "error": "rate_limited", "retry_sec": 300}), 429
    result = _v72_backup_now(reason="api")
    return jsonify(result), (200 if result.get("ok") else 500)


@app.get("/api/v72/sqlite")
def api_v72_sqlite():
    """Run or report SQLite optimization status."""
    force = str(request.args.get("force", "0")) == "1"
    return jsonify(_v72_sqlite_optimize(force=force))


@app.get("/api/v72/backups")
def api_v72_backups_list():
    rows = []
    try:
        for d in sorted(_V72_BACKUP_DIR.iterdir(), reverse=True):
            if not d.is_dir() or not d.name.startswith("titan_backup_"):
                continue
            man = d / "manifest.json"
            meta = {}
            if man.is_file():
                try:
                    meta = json.loads(man.read_text(encoding="utf-8"))
                except Exception:
                    _swallow()
                    meta = {}
            size = sum(f.stat().st_size for f in d.rglob("*") if f.is_file())
            rows.append(
                {"name": d.name, "path": str(d), "size_bytes": size, "manifest": meta}
            )
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)[:160]}), 500
    return jsonify({"ok": True, "backups": rows[:20], "dir": str(_V72_BACKUP_DIR)})


_V72_HEALTH_HTML = (
    "<!doctype html><html lang=\"fa\" dir=\"rtl\"><head><meta charset=\"utf-8\">"
    "<meta name=\"viewport\" content=\"width=device-width,initial-scale=1\">"
    "<meta name=\"theme-color\" content=\"#050816\"><title>TITAN Health</title>"
    "<style>"
    "body{margin:0;font-family:Vazirmatn,Tahoma,sans-serif;background:#050816;"
    "color:#e8ecff;padding:16px}"
    ".card{background:#ffffff12;border:1px solid #ffffff22;border-radius:16px;"
    "padding:14px;margin:10px 0}"
    "h1{font-size:18px;margin:0 0 8px}"
    "h2{font-size:14px;margin:0 0 8px;color:#22d3ee}"
    ".ok{color:#22e5a0}.bad{color:#ff5d7a}.mut{color:#8e98c9;font-size:12px}"
    ".kv{display:flex;justify-content:space-between;padding:6px 0;"
    "border-bottom:1px solid #ffffff10;font-size:13px}"
    "a{color:#22d3ee}"
    "html[data-layout=compact] .card{padding:8px}html[data-layout=wide] .wrap{max-width:1100px}html[data-layout=magazine] .card{border-radius:4px}html[data-density=dense] .card{margin:6px 0}html[data-density=airy] .card{margin:14px 0;padding:16px}html[data-card=solid] .glass{backdrop-filter:none}html[data-card=outline] .glass{background:transparent!important;border:1.5px solid var(--a)}html[data-card=flat] .glass{box-shadow:none}html[data-tabs=underline] .chip{border-radius:0;border-bottom:2px solid transparent}html[data-tabs=underline] .chip.on{border-bottom-color:var(--a)}html[data-tabs=square] .chip{border-radius:4px}html[data-menu=square] .nav button{border-radius:6px}html[data-menu=pill] .nav button{border-radius:999px}html[data-nav=top] .nav{order:-1}html.no-hero .tick{display:none}</style></head><body>"
    "<h1>وضعیت سلامت TITAN Pro</h1>"
    "<p class=\"mut\">تحلیل‌محور — بدون اجرای سفارش · داده فقط داخل پوشه LLL</p>"
    "<div id=\"box\" class=\"card\">در حال بررسی…</div>"
    "<div class=\"card\"><h2>لینک‌ها</h2>"
    "<div class=\"kv\"><span>داشبورد</span><a href=\"/\">باز کردن</a></div>"
    "<div class=\"kv\"><span>API سلامت</span><a href=\"/health\">/health</a></div>"
    "<div class=\"kv\"><span>سلامت یادگیری</span>"
    "<a href=\"/api/titan/health\">/api/titan/health</a></div>"
    "<div class=\"kv\"><span>دانلود کد</span>"
    "<a href=\"/download/titan.py\">TITAN_PRO_V72_PWA.py</a></div>"
    "<div class=\"kv\"><span>پشتیبان‌گیری</span>"
    "<a href=\"/api/v72/backup\">/api/v72/backup</a></div>"
    "<div class=\"kv\"><span>بهینه‌سازی SQLite</span>"
    "<a href=\"/api/v72/sqlite?force=1\">/api/v72/sqlite</a></div>"
    "</div>"
    "<script>"
    "fetch('/health',{cache:'no-store'}).then(function(r){return r.json()}).then(function(d){"
    "var ok=d.ok!==false&&d.status==='ok';"
    "var keys=['gemini','openai','grok','claude','deepseek','coinglass']"
    ".map(function(k){return k+': '+(d[k]?'\\u2713':'\\u2014')}).join(' \\u00b7 ');"
    "document.getElementById('box').innerHTML="
    "'<h2 class=\"'+(ok?'ok':'bad')+'\">'+(ok?'سالم':'ناپایدار')+'</h2>'+"
    "'<div class=\"kv\"><span>بیلد</span><b>'+(d.build||'\\u2014')+'</b></div>'+"
    "'<div class=\"kv\"><span>دارایی\\u200cهای کش</span><b>'+(d.assets!=null?d.assets:'\\u2014')+'</b></div>'+"
    "'<div class=\"kv\"><span>سن کش (ثانیه)</span><b>'+(d.cache_age_seconds!=null?d.cache_age_seconds:'\\u2014')+'</b></div>'+"
    "'<div class=\"kv\"><span>پایگاه\\u200cداده</span><b class=\"'+(d.database&&d.database.ok?'ok':'bad')+'\">'+"
    "(d.database&&d.database.quick_check||'\\u2014')+'</b></div>'+"
    "'<div class=\"kv\"><span>مسیر LLL</span><b style=\"font-size:11px;word-break:break-all\">'+"
    "(d.storage_root||d.home||'\\u2014')+'</b></div>'+"
    "'<div class=\"kv\"><span>کلیدهای API (فقط وجود)</span><b style=\"font-size:11px\">'+keys+'</b></div>'+"
    "'<div class=\"kv\"><span>سفارش واقعی</span><b class=\"ok\">غیرفعال</b></div>';"
    "}).catch(function(){"
    "document.getElementById('box').innerHTML='<b class=\"bad\">خطا در خواندن /health</b>';"
    "});"
    "</script></body></html>"
)


@app.get("/health/page")
def v72_health_page():
    return app.response_class(
        _V72_HEALTH_HTML,
        mimetype="text/html; charset=utf-8",
        headers={"Cache-Control": "no-store"},
    )


def _v72_start_maintenance() -> None:
    def loop():
        time.sleep(45)
        while True:
            try:
                _v72_maintenance_tick()
            except Exception:
                _swallow()
            time.sleep(1800)

    threading.Thread(target=loop, name="titan-v72-maint", daemon=True).start()


try:
    _v72_start_maintenance()
except Exception:
    _swallow()


def _v72_self_test() -> int:
    """V72: backup dir writable, sqlite optimize callable, DB inside MMM."""
    fails = 0
    try:
        if not _V72_BACKUP_DIR.exists():
            print("  x backup_dir_missing")
            fails += 1
        else:
            probe = _V72_BACKUP_DIR / ".probe"
            probe.write_text("ok", encoding="utf-8")
            probe.unlink(missing_ok=True)
            print("  + backup_dir_writable")
        opt = _v72_sqlite_optimize(force=True)
        if not opt.get("ok"):
            print("  x sqlite_optimize", opt)
            fails += 1
        else:
            print("  + sqlite_optimize")
        root = APP_HOME.resolve()
        DB_PATH.resolve().relative_to(root)
        print("  + db_inside_lll")
        print("  + analysis_only_flag")
    except Exception as exc:
        print("  x v72_self_test", exc)
        fails += 1
    print("V72 self-test:", "PASS" if not fails else "FAIL %d" % fails)
    return fails
