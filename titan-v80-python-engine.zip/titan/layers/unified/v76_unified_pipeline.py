# [TITAN V77 layer] unified/v76_unified_pipeline - V76 unified publish pipeline
# Original V76 source lines 29335-29538 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# V76 UNIFIED PIPELINE — single publish path for scan + deep
# Ensures SAFE_MODE, EDGE, checklist, DQ, forecast, neural align
# Analysis-only. No order execution.
# ============================================================

def v76_unified_publish_gate(item: dict[str, Any]) -> dict[str, Any]:
    """Authoritative final gate applied to every directional item.

    Order: data quality → edge → SAFE_MODE/live TF → checklist → forecast conflict
    → portfolio → meta REJECT. Mutates a shallow copy and returns it.
    """
    if not isinstance(item, dict):
        return item
    out = item
    try:
        decision = str(out.get("decision_tag") or out.get("decision") or "WAIT")
        if decision not in {"LONG", "SHORT"}:
            out["publish_gate_v76"] = {"ok": True, "reasons": ["non_directional"], "version": TITAN_PARAM_VERSION}
            return out
        reasons: list[str] = []
        symbol = _normalize_symbol(out.get("symbol") or "")
        tf = str(out.get("tf") or out.get("timeframe") or out.get("primary_tf") or "1h")
        if tf not in ("15m", "1h", "4h", "1d"):
            tf = "1h"

        # Data quality
        dq = out.get("data_quality") or (out.get("fusion") or {}).get("data_quality") or {}
        dq_score = safe_float(dq.get("score"), safe_float(out.get("quality"), 50))
        if dq.get("hard_veto") or dq_score < float(globals().get("MIN_DATA_QUALITY_SCORE", 50)):
            reasons.append(f"data_quality:{dq_score:.0f}")
            decision = "WAIT"

        # Edge
        edge = out.get("edge") or out.get("edge_live") or {}
        if not edge or edge.get("grade") in (None, "UNKNOWN", ""):
            try:
                edge = v75_edge_grade(symbol, tf)
                out["edge"] = edge
            except Exception:
                _swallow()
                edge = {"grade": "UNKNOWN", "supported": False, "reason": "edge_error"}
        checklist = out.get("grade_checklist") or (out.get("signal_grade") or {}).get("checklist") or []
        ck_pass = sum(1 for c in checklist if isinstance(c, dict) and c.get("ok"))
        if not checklist:
            ck_pass = int(safe_float(out.get("checklist_pass"), 5))
        pub = v75_publish_allowed(tf, decision, edge, ck_pass, dq_score)
        if decision in {"LONG", "SHORT"} and not pub.get("ok", True):
            reasons.extend(list(pub.get("reasons") or [])[:6])
            decision = "WAIT"

        # Forecast real conflict
        fusion = out.get("fusion") if isinstance(out.get("fusion"), dict) else {}
        if fusion.get("forecast_veto") and decision in {"LONG", "SHORT"}:
            reasons.append("forecast_veto")
            decision = "WAIT"
        fc = fusion.get("candle_forecast") or out.get("candle_forecast") or {}
        if decision in {"LONG", "SHORT"} and isinstance(fc, dict) and fc.get("ok"):
            fc_bias = str(fc.get("bias") or "")
            opposed = (decision == "LONG" and fc_bias == "نزولی") or (decision == "SHORT" and fc_bias == "صعودی")
            strength = safe_float(fc.get("path_strength"), 0)
            if opposed and strength >= 18:
                # Strong opposed path → WAIT unless grade is A/A+
                grade = str((out.get("signal_grade") or {}).get("grade") or out.get("grade") or "")
                if grade not in {"A+", "A"}:
                    reasons.append("forecast_strong_conflict")
                    decision = "WAIT"

        # Meta REJECT
        meta = out.get("meta_v8") or fusion.get("meta_v8") or {}
        if str(meta.get("label") or "") == "REJECT" and decision in {"LONG", "SHORT"}:
            reasons.append("meta_REJECT")
            decision = "WAIT"

        # Portfolio hard block only when saturated
        port = fusion.get("portfolio") or out.get("portfolio") or {}
        if decision in {"LONG", "SHORT"} and port.get("ok") is False:
            reasons.append(str(port.get("reason") or "portfolio_pressure"))
            decision = "WAIT"

        if decision == "WAIT" and str(out.get("decision_tag") or out.get("decision")) in {"LONG", "SHORT"}:
            out["decision_tag"] = "WAIT"
            out["decision"] = "WAIT"
            out["bias"] = "خنثی"
            out["decision_state"] = "V76_UNIFIED_GATE_BLOCK"
            out.setdefault("decision_reasons", [])
            if isinstance(out["decision_reasons"], list):
                out["decision_reasons"] = list(dict.fromkeys(list(out["decision_reasons"]) + reasons))[:12]
            fusion = dict(fusion)
            fusion.setdefault("explanation", [])
            if isinstance(fusion["explanation"], list):
                fusion["explanation"] = (fusion["explanation"] + [f"V76 gate: {r}" for r in reasons])[:16]
            out["fusion"] = fusion
        out["publish_gate_v76"] = {
            "ok": decision in {"LONG", "SHORT"} or not reasons,
            "final_decision": decision,
            "reasons": reasons,
            "version": TITAN_PARAM_VERSION,
            "edge_grade": (edge or {}).get("grade"),
            "checklist_pass": ck_pass,
            "dq_score": dq_score,
        }
    except Exception as exc:
        LOGGER.debug("v76_unified_publish_gate: %s", exc)
        out.setdefault("publish_gate_v76", {"ok": False, "error": str(exc)[:120]})
    return out


def v76_apply_forecast_to_levels(item: dict[str, Any]) -> dict[str, Any]:
    """Adjust SL/TP slightly using real forecast path when directional."""
    try:
        decision = str(item.get("decision_tag") or item.get("decision") or "WAIT")
        if decision not in {"LONG", "SHORT"}:
            return item
        fc = (item.get("fusion") or {}).get("candle_forecast") or item.get("candle_forecast") or {}
        if not fc.get("ok"):
            return item
        impact = safe_float(fc.get("decision_impact"), 0)
        move_pct = safe_float(fc.get("expected_move_pct"), 0)
        price = safe_float(item.get("price"), 0)
        if price <= 0 or abs(move_pct) < 0.05:
            return item
        # Only stretch TP toward forecast when aligned; never loosen SL
        aligned = (decision == "LONG" and impact > 0) or (decision == "SHORT" and impact < 0)
        if not aligned:
            return item
        tp1 = safe_float(item.get("tp1"), 0)
        tp2 = safe_float(item.get("tp2"), 0)
        stretch = float(clamp(abs(move_pct) / 100.0 * 0.25, 0, 0.012))  # max 1.2%
        if decision == "LONG":
            if tp1 > price:
                item["tp1"] = round(tp1 * (1 + stretch * 0.5), 8)
            if tp2 > price:
                item["tp2"] = round(tp2 * (1 + stretch), 8)
        else:
            if tp1 > 0 and tp1 < price:
                item["tp1"] = round(tp1 * (1 - stretch * 0.5), 8)
            if tp2 > 0 and tp2 < price:
                item["tp2"] = round(tp2 * (1 - stretch), 8)
        item["forecast_levels_adjusted"] = True
    except Exception:
        _swallow()
    return item


_V76_PREV_ANALYZE = analyze_asset


def analyze_asset(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:  # noqa: F811
    """V76 unified public gateway: prior stack + forecast levels + publish gate."""
    try:
        out = _V76_PREV_ANALYZE(symbol, btc_trend)
        if not out:
            return None
        out = v76_apply_forecast_to_levels(out)
        out = v76_unified_publish_gate(out)
        out["pipeline"] = "V76_UNIFIED"
        out["param_version"] = TITAN_PARAM_VERSION
        out["build_id"] = TITAN_BUILD_ID
        return out
    except Exception as exc:
        LOGGER.exception("V76 analyze_asset failed for %s: %s", symbol, exc)
        return None


def _v76_self_test() -> int:
    fails = 0
    def chk(name, cond):
        nonlocal fails
        print(("  + " if cond else "  x ") + name)
        if not cond:
            fails += 1
    chk("unified_pipeline_flag", bool(globals().get("TITAN_UNIFIED_PIPELINE", False)))
    chk("forecast_weight_elevated", float(TitanNeuralSynapseV9.W.get("forecast", 0)) >= 0.12)
    chk("ai_weight_capped_config", float(globals().get("TITAN_AI_MAX_WEIGHT", 1)) <= 0.12)
    # synthetic publish gate
    sample = {
        "symbol": "BTC/USDT", "decision_tag": "LONG", "decision": "LONG", "tf": "15m",
        "data_quality": {"score": 80, "hard_veto": False},
        "edge": {"grade": "NO_EDGE", "supported": False, "reason": "test"},
        "grade_checklist": [{"ok": True}] * 3,
        "fusion": {},
    }
    gated = v76_unified_publish_gate(sample)
    chk("safe_mode_blocks_15m_without_edge", gated.get("decision_tag") == "WAIT")
    # forecast function shape
    import pandas as pd
    import numpy as np
    n = 80
    rng = np.random.default_rng(42)
    px = 100 * np.cumprod(1 + rng.normal(0, 0.01, n))
    df = pd.DataFrame({
        "open": px, "high": px * 1.01, "low": px * 0.99, "close": px,
        "vol": rng.uniform(1, 5, n), "t": np.arange(n) * 3_600_000,
    })
    fc = forecast_future_candles(df, horizon=12)
    chk("forecast_ok", bool(fc.get("ok")))
    chk("forecast_has_decision_impact", "decision_impact" in fc)
    chk("forecast_has_range_position", "range_position" in fc)
    chk("forecast_has_candles", len(fc.get("candles") or []) == 12)
    print("V76 self-test:", "PASS" if not fails else f"FAIL {fails}")
    return fails
