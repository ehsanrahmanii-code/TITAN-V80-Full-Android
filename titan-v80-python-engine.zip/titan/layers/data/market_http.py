# [TITAN V77 layer] data/market_http - HTTP / market data
# Original V76 source lines 2179-2589 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# HTTP / MARKET DATA
# ============================================================


def _request_json(method: str, url: str, **kwargs) -> Optional[Any]:
    try:
        response = _http_session().request(method, url, **kwargs)
        if not response.ok:
            LOGGER.warning("HTTP %s %s -> %s", method, url, response.status_code)
            return None
        payload = response.json()
        # Binance and other APIs can legitimately return either an object or a
        # list. Keep the transport layer lossless and let callers validate shape.
        return payload
    except (requests.RequestException, ValueError) as exc:
        LOGGER.warning("HTTP request failed %s: %s", url, exc)
        return None


def _fetch_live_prices(symbols: list[str]) -> dict[str, float]:
    """Fetch spot prices with multi-host Binance + CoinGecko fallback.

    Binance is tried first (all known REST mirrors). If every host fails
    (blocked network / DNS / timeout), CoinGecko simple/price is used so the
    dashboard and emergency cards never stay permanently empty.
    """
    requested = {_normalize_symbol(s): _normalize_symbol_for_binance(s) for s in symbols if s}
    if not requested:
        return {}
    wanted_pairs = set(requested.values())
    hosts = LIVE_PRICE_URLS if "LIVE_PRICE_URLS" in globals() else [LIVE_PRICE_URL]
    last_error = None
    connect_to = float(globals().get("HTTP_CONNECT_TIMEOUT", 3.5) or 3.5)
    read_to = float(globals().get("HTTP_READ_TIMEOUT", 6.0) or 6.0)
    timeout = (connect_to, read_to)
    for url in hosts:
        try:
            response = _http_session().get(url, timeout=timeout)
            if not response.ok:
                last_error = RuntimeError(f"HTTP {response.status_code} from {url}")
                continue
            payload = response.json()
            if not isinstance(payload, list):
                last_error = RuntimeError("Invalid Binance ticker payload")
                continue
            by_pair = {}
            for row in payload:
                if not isinstance(row, dict):
                    continue
                pair = str(row.get("symbol") or "").upper()
                if pair not in wanted_pairs:
                    continue
                px = safe_float(row.get("price"), 0.0)
                if px > 0:
                    by_pair[pair] = px
            result = {}
            for sym, pair in requested.items():
                px = by_pair.get(pair)
                if px is not None and px > 0:
                    result[sym] = px
            if result:
                return result
        except Exception as exc:
            last_error = exc
            LOGGER.debug("Batch live price unavailable via %s: %s", url, exc)
    # ---- CoinGecko fallback (works when Binance is geo-blocked) ----
    try:
        cg_map = globals().get("COINGECKO_IDS") or {}
        ids = []
        base_to_sym = {}
        for sym in requested:
            base = sym.split("/")[0].upper() if "/" in sym else sym.upper().replace("USDT", "")
            cg_id = cg_map.get(base)
            if cg_id:
                ids.append(cg_id)
                base_to_sym[cg_id] = sym
        if ids:
            cg_url = globals().get("COINGECKO_SIMPLE_PRICE") or "https://api.coingecko.com/api/v3/simple/price"
            params = {"ids": ",".join(sorted(set(ids))), "vs_currencies": "usd"}
            response = _http_session().get(cg_url, params=params, timeout=timeout)
            if response.ok:
                payload = response.json()
                result = {}
                if isinstance(payload, dict):
                    for cg_id, row in payload.items():
                        if not isinstance(row, dict):
                            continue
                        px = safe_float(row.get("usd"), 0.0)
                        sym = base_to_sym.get(cg_id)
                        if sym and px > 0:
                            result[sym] = px
                if result:
                    LOGGER.info("Live prices via CoinGecko fallback: %s symbols", len(result))
                    return result
    except Exception as exc:
        LOGGER.warning("CoinGecko price fallback failed: %s", exc)
        last_error = last_error or exc
    if last_error:
        LOGGER.warning("All live price sources failed: %s", last_error)
    return {}


def fetch_24h_tickers(symbols: list[str]) -> dict[str, dict[str, float]]:
    """Batch 24h stats from Binance (real change%, high, low, volume)."""
    requested = {_normalize_symbol(s): _normalize_symbol_for_binance(s) for s in symbols if s}
    if not requested:
        return {}
    wanted = set(requested.values())
    hosts = [f"{h}/api/v3/ticker/24hr" for h in BINANCE_REST_HOSTS]
    for url in hosts:
        try:
            r = _http_session().get(url, timeout=8)
            if not r.ok:
                continue
            payload = r.json()
            if not isinstance(payload, list):
                continue
            by_pair = {}
            for row in payload:
                if not isinstance(row, dict):
                    continue
                pair = str(row.get("symbol") or "").upper()
                if pair not in wanted:
                    continue
                ch = safe_float(row.get("priceChangePercent"), float("nan"))
                last = safe_float(row.get("lastPrice"), 0)
                if last <= 0:
                    continue
                by_pair[pair] = {
                    "change_pct_24h": ch if math.isfinite(ch) else 0.0,
                    "last": last,
                    "high_24h": safe_float(row.get("highPrice"), 0),
                    "low_24h": safe_float(row.get("lowPrice"), 0),
                    "volume_24h": safe_float(row.get("volume"), 0),
                    "quote_volume_24h": safe_float(row.get("quoteVolume"), 0),
                }
            out = {}
            for sym, pair in requested.items():
                if pair in by_pair:
                    out[sym] = by_pair[pair]
            if out:
                return out
        except Exception as exc:
            LOGGER.debug("24h ticker fail %s: %s", url, exc)
    return {}


_TICKER_24H_CACHE: dict[str, Any] = {"ts": 0.0, "data": {}}
_TICKER_24H_TTL = 25.0


def get_24h_tickers_cached(symbols: Optional[list[str]] = None) -> dict[str, dict[str, float]]:
    now = time.time()
    syms = list(symbols or (USER_SETTINGS.get("active_coins") or DEFAULT_COINS))
    cached = dict(_TICKER_24H_CACHE.get("data") or {})
    fresh = bool(cached) and now - float(_TICKER_24H_CACHE.get("ts") or 0) < _TICKER_24H_TTL
    if fresh:
        # FIX: a cache filled by a single-symbol call must not hide other symbols.
        missing = [s for s in syms if s and _normalize_symbol(s) not in cached]
        if not missing:
            return cached
        extra = fetch_24h_tickers(missing)
        if extra:
            cached.update(extra)
            _TICKER_24H_CACHE["data"] = cached
        return dict(cached)
    data = fetch_24h_tickers(syms)
    if data:
        _TICKER_24H_CACHE["data"] = data
        _TICKER_24H_CACHE["ts"] = now
    return dict(_TICKER_24H_CACHE.get("data") or {})



def fetch_klines(symbol: str, tf: str, limit: int = 150, start_ms: Optional[int] = None, end_ms: Optional[int] = None) -> pd.DataFrame:
    """Fetch closed OHLCV with short TTL memory cache + fast numeric path.

    Cache key includes symbol/tf/limit/range so historical backtests stay uncached
    when start/end are set; live dashboard hits are almost free within TTL.
    """
    limit = min(max(int(limit), 1), 1000)
    cacheable = start_ms is None and end_ms is None
    ckey = _kline_cache_key(symbol, tf, limit, start_ms, end_ms) if cacheable else ""
    if cacheable:
        hit = _kline_cache_get(ckey)
        if hit is not None and len(hit) >= 10:
            return hit

    params: dict[str, Any] = {"symbol": _binance_symbol(symbol), "interval": tf, "limit": limit}
    if start_ms is not None:
        params["startTime"] = int(start_ms)
    if end_ms is not None:
        params["endTime"] = int(end_ms)
    raw = None
    last_err = None
    # Prefer data-api first; shorter timeout on failover hosts for snappy mobile UX
    hosts = KLINES_URLS if "KLINES_URLS" in globals() else ["https://data-api.binance.vision/api/v3/klines"]
    for i, kurl in enumerate(hosts):
        try:
            to = 3.5 if i == 0 else 2.2
            response = _http_session().get(kurl, params=params, timeout=to)
            if not response.ok:
                last_err = RuntimeError(f"HTTP {response.status_code} from {kurl}")
                continue
            raw = response.json()
            break
        except Exception as exc:
            last_err = exc
            LOGGER.debug("klines fail %s: %s", kurl, exc)
    if raw is None:
        raise RuntimeError(f"All kline hosts failed: {last_err}")
    if not isinstance(raw, list) or not raw:
        raise RuntimeError("Invalid Binance kline response")

    # Fast path: build from list-of-lists without per-column to_numeric loops
    # Columns: 0=t 1=o 2=h 3=l 4=c 5=v 6=T
    try:
        arr = np.asarray(raw, dtype=object)
        t = arr[:, 0].astype(np.float64)
        o = arr[:, 1].astype(np.float64)
        h = arr[:, 2].astype(np.float64)
        l = arr[:, 3].astype(np.float64)
        c = arr[:, 4].astype(np.float64)
        v = arr[:, 5].astype(np.float64)
        T = arr[:, 6].astype(np.float64)
        now_ms = time.time() * 1000.0
        mask = (
            (T < now_ms) & (t > 0) & (T >= t) & (v >= 0)
            & np.isfinite(t) & np.isfinite(T)
            & np.isfinite(o) & np.isfinite(h) & np.isfinite(l) & np.isfinite(c) & np.isfinite(v)
            & (o > 0) & (h > 0) & (l > 0) & (c > 0)
            & (h >= np.maximum(o, c)) & (l <= np.minimum(o, c)) & (h >= l)
        )
        t, o, h, l, c, v, T = t[mask], o[mask], h[mask], l[mask], c[mask], v[mask], T[mask]
        # sort + dedupe by t (keep last)
        order = np.argsort(t, kind="mergesort")
        t, o, h, l, c, v, T = t[order], o[order], h[order], l[order], c[order], v[order], T[order]
        if len(t) > 1:
            keep = np.ones(len(t), dtype=bool)
            keep[:-1] = t[:-1] != t[1:]
            t, o, h, l, c, v, T = t[keep], o[keep], h[keep], l[keep], c[keep], v[keep], T[keep]
        df = pd.DataFrame({"t": t, "open": o, "high": h, "low": l, "close": c, "vol": v, "T": T})
    except Exception:
        _swallow()
        columns = ["t", "open", "high", "low", "close", "vol", "T", "qav", "n", "tbb", "tbq", "ign"]
        df = pd.DataFrame(raw, columns=columns)
        for col in ["open", "high", "low", "close", "vol", "t", "T"]:
            df[col] = pd.to_numeric(df[col], errors="coerce")
        df = df.dropna(subset=["t", "T", "open", "high", "low", "close", "vol"])
        now_ms = int(time.time() * 1000)
        df = df[
            (df["T"] < now_ms) & (df["t"] > 0) & (df["T"] >= df["t"])
            & (df["vol"] >= 0) & (df[["open", "high", "low", "close"]] > 0).all(axis=1)
            & (df["high"] >= df[["open", "close"]].max(axis=1))
            & (df["low"] <= df[["open", "close"]].min(axis=1)) & (df["high"] >= df["low"])
        ].sort_values("t").drop_duplicates(subset=["t"], keep="last").reset_index(drop=True)

    if len(df) < 10:
        raise RuntimeError(f"Insufficient closed candles for {symbol} {tf}")
    if cacheable:
        _kline_cache_put(ckey, df)
    return df


def _binance_futures_funding(symbol: str) -> Optional[float]:
    try:
        r = _http_session().get(
            "https://fapi.binance.com/fapi/v1/premiumIndex",
            params={"symbol": _binance_symbol(symbol)}, timeout=8,
        )
        if not r.ok:
            return None
        payload = r.json()
        if not isinstance(payload, dict):
            return None
        return safe_float(payload.get("lastFundingRate")) * 100
    except Exception:
        _swallow()
        return None


def _binance_futures_oi(symbol: str) -> Optional[float]:
    try:
        r = _http_session().get(
            "https://fapi.binance.com/fapi/v1/openInterest",
            params={"symbol": _binance_symbol(symbol)}, timeout=8,
        )
        if not r.ok:
            return None
        payload = r.json()
        if not isinstance(payload, dict):
            return None
        value = safe_float(payload.get("openInterest"))
        return value if value > 0 else None
    except Exception:
        _swallow()
        return None



def fetch_ohlcv(symbol: str, timeframe: str = "1h", limit: int = 200, **kwargs):
    """Canonical OHLCV loader used by V78 forecast/evaluation.

    Wraps fetch_klines and returns a DataFrame with open/high/low/close/volume
    columns and a numeric index ordered oldest→newest. Never raises to callers
    that expect silent failure; returns empty DataFrame on total failure.
    """
    try:
        tf = str(timeframe or "1h").strip()
        if tf not in {"15m", "1h", "4h", "1d"}:
            tf = "1h"
        lim = max(20, min(int(limit or 200), 1500))
        df = fetch_klines(symbol, tf, lim)
        if df is None or getattr(df, "empty", True):
            return pd.DataFrame(columns=["open", "high", "low", "close", "volume"])
        out = df.copy()
        # normalize column names
        colmap = {}
        for c in list(out.columns):
            cl = str(c).lower()
            if cl in {"open", "high", "low", "close", "volume", "vol"}:
                colmap[c] = "volume" if cl in {"vol", "volume"} else cl
        if colmap:
            out = out.rename(columns=colmap)
        for need in ("open", "high", "low", "close"):
            if need not in out.columns:
                # try O/H/L/C
                for alt in (need[0].upper(), need.capitalize()):
                    if alt in out.columns:
                        out[need] = out[alt]
                        break
        if "volume" not in out.columns:
            out["volume"] = 0.0
        keep = [c for c in ("open", "high", "low", "close", "volume") if c in out.columns]
        out = out[keep].apply(pd.to_numeric, errors="coerce").dropna(subset=["close"])
        out = out.reset_index(drop=True)
        return out
    except Exception as exc:
        LOGGER.warning("fetch_ohlcv failed %s %s: %s", symbol, timeframe, exc)
        try:
            return pd.DataFrame(columns=["open", "high", "low", "close", "volume"])
        except Exception:
            return None


def fetch_derivatives(symbol: str) -> dict[str, Any]:
    # Short TTL cache — funding/OI rarely need sub-20s refresh during one scan
    _sym_key = _normalize_symbol(symbol)
    with KLINE_CACHE_LOCK:
        _hit = DERIV_CACHE.get(_sym_key)
        if _hit and (time.time() - _hit[0]) < DERIV_CACHE_TTL:
            return _hit[1]
    clean = _binance_symbol(symbol)
    base = clean.replace("USDT", "")
    raw_oi = 0.0
    oi_kind = "unknown"
    funding: Optional[float] = None
    cg_usd = cg_qty = cg_delta = None
    source_parts: list[str] = []

    if COINGLASS_API_KEY:
        headers = {"CG-API-KEY": COINGLASS_API_KEY}
        try:
            res = _http_session().get(
                "https://open-api-v4.coinglass.com/api/futures/open-interest/exchange-list",
                params={"symbol": base}, headers=headers, timeout=10,
            ).json()
            if str(res.get("code")) in {"0", "200"}:
                rows = res.get("data") or []
                row = next((r for r in rows if str(r.get("exchange", "")).lower() == "all"), rows[0] if rows else None)
                if row:
                    cg_qty = safe_float(row.get("open_interest_quantity"), 0)
                    cg_usd = safe_float(row.get("open_interest_usd"), 0)
                    cg_delta = safe_float(row.get("open_interest_change_percent_5m"), 0)
                    if cg_usd and cg_usd > 0:
                        raw_oi, oi_kind = cg_usd, "usd"
                    elif cg_qty and cg_qty > 0:
                        raw_oi, oi_kind = cg_qty, "base"
                    if raw_oi > 0:
                        source_parts.append("CoinGlass-OI")
        except Exception as exc:
            LOGGER.warning("CoinGlass OI failed for %s: %s", symbol, exc)
        try:
            res = _http_session().get(
                "https://open-api-v4.coinglass.com/api/futures/funding-rate/exchange-list",
                params={"symbol": base}, headers=headers, timeout=10,
            ).json()
            if str(res.get("code")) in {"0", "200"}:
                rows = res.get("data") or []
                row = next((r for r in rows if str(r.get("symbol", "")).upper() == base), rows[0] if rows else None)
                if row:
                    vals = [safe_float(x.get("funding_rate"), np.nan) for x in (row.get("stablecoin_margin_list") or [])]
                    vals = [x for x in vals if np.isfinite(x)]
                    if vals:
                        funding = float(np.mean(vals)) * 100
                        source_parts.append("CoinGlass-Funding")
        except Exception as exc:
            LOGGER.warning("CoinGlass funding failed for %s: %s", symbol, exc)

    if funding is None:
        funding = _binance_futures_funding(symbol)
        if funding is not None:
            source_parts.append("Binance-Funding")
    if raw_oi <= 0:
        fallback_oi = _binance_futures_oi(symbol)
        if fallback_oi is not None:
            raw_oi, oi_kind = fallback_oi, "base"
            source_parts.append("Binance-OI")

    now = time.time()
    delta = cg_delta if cg_delta is not None else 0.0
    with OI_LOCK:
        previous = OI_HISTORY.get(symbol)
        if cg_delta is None and previous and previous[2] == oi_kind:
            prev_oi, prev_ts, _ = previous
            if prev_oi > 0 and raw_oi > 0 and now - prev_ts <= 900:
                delta = ((raw_oi - prev_oi) / prev_oi) * 100
        if raw_oi > 0:
            OI_HISTORY[symbol] = (raw_oi, now, oi_kind)

    if cg_usd and cg_usd > 0:
        oi_disp = f"${smart_format(cg_usd)}"
    elif cg_qty and cg_qty > 0:
        oi_disp = f"{smart_format(cg_qty)} {base}"
    elif raw_oi > 0:
        oi_disp = f"{smart_format(raw_oi)} {base}"
    else:
        oi_disp = "N/A"
    ls = fetch_binance_long_short_ratio(symbol)
    taker = fetch_binance_taker_buy_sell(symbol)
    if ls.get("source") and ls.get("source") != "N/A":
        source_parts.append(str(ls.get("source")))
    if taker.get("source") and taker.get("source") != "N/A":
        source_parts.append(str(taker.get("source")))
    out = {
        "oi": oi_disp,
        "raw_oi": raw_oi,
        "oi_delta": delta,
        "funding_value": funding,
        "funding": f"{funding:+.4f}%" if funding is not None else "N/A",
        "source": " + ".join(dict.fromkeys(source_parts)) if source_parts else "N/A",
        "long_short": ls,
        "taker": taker,
        "long_ratio": ls.get("long_ratio"),
        "short_ratio": ls.get("short_ratio"),
        "long_short_ratio": ls.get("long_short_ratio"),
        "top_long_ratio": ls.get("top_long_ratio"),
        "taker_buy_pct": taker.get("buy_pct"),
        "taker_sell_pct": taker.get("sell_pct"),
        "taker_available": bool(taker.get("available")),
    }
    with KLINE_CACHE_LOCK:
        DERIV_CACHE[_normalize_symbol(symbol)] = (time.time(), out)
        if len(DERIV_CACHE) > 80:
            for k, _ in sorted(DERIV_CACHE.items(), key=lambda x: x[1][0])[:20]:
                DERIV_CACHE.pop(k, None)
    return out


def fetch_btc_trend() -> str:
    try:
        df = fetch_klines("BTC/USDT", "1h", 60)
        ema = df["close"].ewm(span=20, adjust=False).mean().iloc[-1]
        return "صعودی" if float(df["close"].iloc[-1]) >= float(ema) else "نزولی"
    except Exception as exc:
        LOGGER.warning("BTC trend failed: %s", exc)
        return "خنثی"


def fetch_macro() -> dict[str, Any]:
    fear_value = "N/A"
    fear_text = "داده نیست"
    dominance = "N/A"
    sources: list[str] = []
    try:
        payload = _http_session().get("https://api.alternative.me/fng/", params={"limit": 1}, timeout=8).json()
        data = payload.get("data") or []
        if data:
            fear_value = data[0].get("value", "N/A")
            fear_text = data[0].get("value_classification", "N/A")
            sources.append("Alternative.me")
    except Exception as exc:
        LOGGER.warning("Fear & Greed failed: %s", exc)
    try:
        payload = _http_session().get("https://api.coingecko.com/api/v3/global", timeout=8).json()
        btc_dom = safe_float((payload.get("data") or {}).get("market_cap_percentage", {}).get("btc"), np.nan)
        if np.isfinite(btc_dom):
            dominance = f"{btc_dom:.2f}%"
            sources.append("CoinGecko")
    except Exception as exc:
        LOGGER.warning("CoinGecko macro failed: %s", exc)
    return {"fear_greed_val": fear_value, "fear_greed_text": fear_text, "global_status": " / ".join(sources) or "N/A", "dominance_btc": dominance}
