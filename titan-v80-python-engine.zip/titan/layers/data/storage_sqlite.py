# [TITAN V77 layer] data/storage_sqlite - JSON / SQLite
# Original V76 source lines 1986-2178 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# JSON / SQLITE
# ============================================================


def _load_json(path: Path, default: Any) -> Any:
    with JSON_LOCK:
        try:
            path = _safe_app_path(path)
            if not path.is_file():
                return default
            text = path.read_text(encoding="utf-8")
            if not text.strip():
                return default
            return json.loads(text)
        except (OSError, json.JSONDecodeError, RuntimeError) as exc:
            LOGGER.warning("JSON read failed %s: %s", path, exc)
            return default


def _save_json(path: Path, data: Any) -> bool:
    with JSON_LOCK:
        try:
            path = _safe_app_path(path)
            path.parent.mkdir(parents=True, exist_ok=True)
            payload = json.dumps(data, ensure_ascii=False, indent=2, default=str)
            tmp = path.with_suffix(path.suffix + ".tmp")
            tmp.write_text(payload, encoding="utf-8")
            tmp.replace(path)
            return True
        except (OSError, TypeError, ValueError, RuntimeError) as exc:
            LOGGER.error("JSON write failed %s: %s", path, exc)
            return False


_DB_WAL_READY = False


def db_conn() -> sqlite3.Connection:
    """SQLite connection. WAL mode is persistent in the DB file, so it is set once per process."""
    global _DB_WAL_READY
    db_path = _safe_app_path(DB_PATH)
    con = sqlite3.connect(str(db_path), timeout=60, check_same_thread=False)
    con.row_factory = sqlite3.Row
    if not _DB_WAL_READY:
        try:
            con.execute("PRAGMA journal_mode=WAL")
            _DB_WAL_READY = True
        except sqlite3.Error:
            _swallow()
    con.execute("PRAGMA synchronous=NORMAL")
    con.execute("PRAGMA temp_store=MEMORY")
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA busy_timeout=10000")
    con.execute("PRAGMA cache_size=-8000")       # ~8 MB page cache — lighter on phone RAM
    con.execute("PRAGMA mmap_size=33554432")     # 32 MB mmap — mobile-safe
    return con


def init_db() -> None:
    with DB_LOCK, db_conn() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS forecasts(
            id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, timeframe TEXT NOT NULL,
            created_at REAL NOT NULL, direction TEXT NOT NULL, score REAL NOT NULL,
            alignment REAL NOT NULL DEFAULT 0, price REAL NOT NULL, sl REAL, tp1 REAL, tp2 REAL,
            horizon_minutes INTEGER NOT NULL, outcome TEXT DEFAULT 'PENDING', evaluated_at REAL,
            hit_type TEXT, source TEXT DEFAULT 'quant', ai_majority TEXT DEFAULT '',
            ai_agreement REAL DEFAULT 0, fused_score REAL DEFAULT 0, success_prob REAL DEFAULT 0,
            predicted_move_pct REAL DEFAULT 0)""")
        for _col, _typ in (
            ("ai_majority", "TEXT DEFAULT ''"),
            ("ai_agreement", "REAL DEFAULT 0"),
            ("fused_score", "REAL DEFAULT 0"),
            ("success_prob", "REAL DEFAULT 0"),
            ("predicted_move_pct", "REAL DEFAULT 0"),
        ):
            try:
                con.execute(f"ALTER TABLE forecasts ADD COLUMN {_col} {_typ}")
            except Exception:
                _swallow()
        con.execute("CREATE INDEX IF NOT EXISTS idx_forecasts_pending ON forecasts(outcome, created_at)")
        con.execute("""CREATE TABLE IF NOT EXISTS paper_trades(
            id INTEGER PRIMARY KEY AUTOINCREMENT, symbol TEXT NOT NULL, timeframe TEXT NOT NULL,
            created_at REAL NOT NULL, decision TEXT NOT NULL, entry REAL NOT NULL, sl REAL, tp1 REAL,
            tp2 REAL, quantity REAL DEFAULT 0, risk_pct REAL DEFAULT 0, status TEXT DEFAULT 'OPEN',
            exit_price REAL, pnl_pct REAL, r_multiple REAL, closed_at REAL, reason TEXT DEFAULT 'signal',
            success_prob REAL DEFAULT 0)""")
        try:
            con.execute("ALTER TABLE paper_trades ADD COLUMN success_prob REAL DEFAULT 0")
        except Exception:
            _swallow()
        con.execute("CREATE INDEX IF NOT EXISTS idx_paper_open ON paper_trades(status, created_at)")
        con.execute("""CREATE TABLE IF NOT EXISTS data_quality(
            id INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL NOT NULL, symbol TEXT, source TEXT,
            latency_ms REAL, candles_ok INTEGER, volume_ok INTEGER, funding_ok INTEGER, oi_ok INTEGER,
            macro_ok INTEGER, overall_ok INTEGER, details TEXT)""")
        con.execute("CREATE INDEX IF NOT EXISTS idx_quality_time ON data_quality(created_at)")
        con.execute("""CREATE TABLE IF NOT EXISTS ai_votes(
            id INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL NOT NULL, symbol TEXT NOT NULL,
            provider TEXT NOT NULL, direction TEXT, titan_direction TEXT, aligned INTEGER, latency_ms REAL)""")
        con.execute("CREATE INDEX IF NOT EXISTS idx_ai_votes_symbol ON ai_votes(symbol, created_at)")
        con.execute("""CREATE TABLE IF NOT EXISTS alerts(
            id INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL NOT NULL, severity TEXT,
            symbol TEXT, category TEXT, message TEXT, acknowledged INTEGER DEFAULT 0)""")
        con.execute("CREATE INDEX IF NOT EXISTS idx_alerts_time ON alerts(created_at)")
        con.execute("""CREATE TABLE IF NOT EXISTS performance_snapshots(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            symbol TEXT NOT NULL,
            timeframe TEXT NOT NULL,
            created_at REAL NOT NULL,
            trades INTEGER DEFAULT 0,
            wins INTEGER DEFAULT 0,
            losses INTEGER DEFAULT 0,
            win_rate REAL DEFAULT 0,
            expectancy REAL DEFAULT 0,
            profit_factor REAL,
            max_drawdown REAL DEFAULT 0,
            sharpe REAL DEFAULT 0,
            sortino REAL DEFAULT 0,
            oos_status TEXT DEFAULT '',
            metrics_json TEXT DEFAULT ''
        )""")
        con.execute("CREATE INDEX IF NOT EXISTS idx_perf_snap ON performance_snapshots(symbol,timeframe,created_at)")
        con.execute("""CREATE TABLE IF NOT EXISTS setup_stats(
            setup_key TEXT PRIMARY KEY, trades INTEGER DEFAULT 0, wins INTEGER DEFAULT 0,
            losses INTEGER DEFAULT 0, pnl_r REAL DEFAULT 0, updated_at REAL DEFAULT 0)""")
        con.execute("""CREATE TABLE IF NOT EXISTS v75_deep_ledger(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at REAL NOT NULL,
            symbol TEXT NOT NULL,
            timeframe TEXT NOT NULL,
            decision TEXT NOT NULL,
            quant_decision TEXT,
            consensus_side TEXT,
            score REAL,
            confidence REAL,
            entry REAL,
            sl REAL,
            tp1 REAL,
            tp2 REAL,
            valid_from REAL,
            valid_until REAL,
            valid_bars INTEGER,
            valid_minutes INTEGER,
            price_at REAL,
            outcome TEXT DEFAULT 'PENDING',
            exit_price REAL,
            return_pct REAL,
            hit_type TEXT,
            evaluated_at REAL,
            reasons_json TEXT DEFAULT '[]',
            checklist_score TEXT,
            ai_agreement REAL,
            notes TEXT DEFAULT '',
            build_id TEXT
        )""")
        con.execute("CREATE INDEX IF NOT EXISTS idx_v75_deep_pending ON v75_deep_ledger(outcome, created_at)")
        con.execute("CREATE INDEX IF NOT EXISTS idx_v75_deep_sym ON v75_deep_ledger(symbol, timeframe, created_at)")

init_db()


def load_settings() -> None:
    global USER_SETTINGS, TITAN_SAFE_MODE, TITAN_REQUIRE_EDGE_SUPPORTED
    data = _load_json(USER_SETTINGS_PATH, {})
    if not isinstance(data, dict):
        return
    risk = clamp(safe_float(data.get("risk_multiplier"), 1.0), 0.2, 5.0)
    normalized: list[str] = []
    for coin in data.get("active_coins", []) if isinstance(data.get("active_coins"), list) else []:
        symbol = _normalize_symbol(coin)
        if symbol and symbol not in normalized:
            normalized.append(symbol)
    safe_mode = bool(data.get("safe_mode", True))
    require_edge = bool(data.get("require_edge", True))
    live_tfs = data.get("live_timeframes") if isinstance(data.get("live_timeframes"), list) else ["4h", "1d"]
    live_tfs = [str(t) for t in live_tfs if str(t) in ("15m", "1h", "4h", "1d")] or ["4h", "1d"]
    TITAN_SAFE_MODE = safe_mode
    TITAN_REQUIRE_EDGE_SUPPORTED = require_edge
    USER_SETTINGS = {
        "risk_multiplier": risk,
        "active_coins": normalized or DEFAULT_COINS.copy(),
        "safe_mode": safe_mode,
        "require_edge": require_edge,
        "live_timeframes": live_tfs,
    }


def save_settings() -> bool:
    return _save_json(USER_SETTINGS_PATH, USER_SETTINGS)

load_settings()
