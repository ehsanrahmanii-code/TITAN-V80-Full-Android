# [TITAN V77 layer] intel/v31_canonical_decision - V31 canonical decision governor
# Original V76 source lines 11018-11212 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# V31 — CANONICAL DECISION GOVERNOR
# One brain / many evidence channels. All upstream modules are evidence only;
# none of them is allowed to publish an independent final decision.
# ============================================================
V31_VERSION = "TITAN-V31-CANONICAL-DECISION-GOVERNOR"
V31_MIN_MARGIN = 0.065
V31_READY_MARGIN = 0.145
V31_STRONG_MARGIN = 0.24
V31_MIN_DATA = 54.0
V31_MIN_QUALITY = 50.0
V31_MIN_RR = 1.02
V31_MAX_CONTRADICTION = 0.70
V31_PRIOR_MAX = 0.08

class TitanCanonicalDecisionV31:
    """Single final decision brain.

    Upstream engines may disagree internally. Their outputs are compressed into
    common evidence and evaluated together. Only this governor is authoritative
    for the final LONG/SHORT/WAIT decision exposed to the dashboard/API.
    """
    def _side(self, debate, side):
        return (debate or {}).get(side.lower()) or {}

    def _score(self, debate, side):
        return float(self._side(debate, side).get("score", 0.0) or 0.0)

    def decide(self, item, debate):
        long = self._side(debate, "LONG")
        short = self._side(debate, "SHORT")
        ls = self._score(debate, "LONG")
        ss = self._score(debate, "SHORT")
        margin = ls - ss
        abs_margin = abs(margin)
        candidate = "LONG" if margin >= V31_MIN_MARGIN else "SHORT" if margin <= -V31_MIN_MARGIN else "WAIT"
        chosen = long if candidate == "LONG" else short if candidate == "SHORT" else (long if ls >= ss else short)
        opposite = short if candidate == "LONG" else long if candidate == "SHORT" else {}

        dq = float(chosen.get("data_quality", 0) or 0)
        quality = float(chosen.get("quality", 0) or 0)
        rr = float(chosen.get("rr", 0) or 0)
        contradiction = float(chosen.get("contradiction", 0) or 0)
        support = int(chosen.get("support", 0) or 0)
        oppose = int(chosen.get("oppose", 0) or 0)
        hard = list(chosen.get("hard_blocks") or [])

        # Confidence is an evidence-confidence score, not a probability of profit.
        base = 50.0 + abs_margin * 105.0
        base += min(18.0, support * 4.5)
        base -= min(18.0, oppose * 4.0)
        base -= contradiction * 24.0
        base += max(-10.0, min(10.0, (dq - 60.0) * 0.18))
        base += max(-7.0, min(7.0, (quality - 60.0) * 0.14))
        if rr >= V31_MIN_RR: base += min(5.0, (rr - V31_MIN_RR) * 5.0)
        confidence = clamp(base, 0.0, 96.0)

        reasons=[]
        if candidate == "WAIT": reasons.append("اختلاف LONG و SHORT برای تصمیم جهت‌دار کافی نیست.")
        if dq < V31_MIN_DATA: reasons.append("کیفیت/اعتبار داده برای تصمیم جهت‌دار کافی نیست.")
        if quality < V31_MIN_QUALITY: reasons.append("کیفیت سیگنال ترکیبی پایین‌تر از حد لازم است.")
        if rr and rr < V31_MIN_RR: reasons.append("نسبت ریسک به بازده مؤثر کافی نیست.")
        if contradiction >= V31_MAX_CONTRADICTION: reasons.append("بین خانواده‌های مستقل شواهد تضاد معنادار وجود دارد.")
        if hard: reasons.append("یک یا چند کنترل سخت کیفیت/ریسک فعال است.")
        if support < 2 and candidate != "WAIT": reasons.append("پشتیبانی مستقل برای جهت انتخابی محدود است.")

        # A direction becomes authoritative only when the combined evidence is
        # coherent. No individual model, indicator, or AI provider can promote it.
        directional_ok = (
            candidate in {"LONG","SHORT"}
            and abs_margin >= V31_MIN_MARGIN
            and dq >= V31_MIN_DATA
            and quality >= V31_MIN_QUALITY
            and rr >= V31_MIN_RR
            and support >= 1
            and contradiction < V31_MAX_CONTRADICTION
            and not hard
        )

        if not directional_ok:
            final = "WAIT"
            state = "WAIT"
        elif abs_margin >= V31_STRONG_MARGIN and support >= 3 and quality >= 60 and dq >= 62:
            final = candidate
            state = "STRONG"
        elif abs_margin >= V31_READY_MARGIN and support >= 2:
            final = candidate
            state = "READY"
        else:
            final = candidate
            state = "EARLY"

        # Hysteresis: an existing valid direction may survive a small temporary
        # margin loss, but it cannot survive a clear opposite consensus.
        prior = str(item.get("decision_tag") or "WAIT").upper()
        if final == "WAIT" and prior in {"LONG","SHORT"}:
            prior_side = self._side(debate, prior)
            prior_score = float(prior_side.get("score",0) or 0)
            opp_score = float((short if prior=="LONG" else long).get("score",0) or 0)
            prior_valid = (
                prior_score >= 0.16 and dq >= V31_MIN_DATA and quality >= V31_MIN_QUALITY
                and rr >= V31_MIN_RR and int(prior_side.get("support",0) or 0) >= 1
                and float(prior_side.get("contradiction",0) or 0) < V31_MAX_CONTRADICTION
                and not (prior_side.get("hard_blocks") or [])
            )
            clear_opposite = (opp_score - prior_score) >= V31_READY_MARGIN and int((short if prior=="LONG" else long).get("support",0) or 0) >= 3
            if prior_valid and not clear_opposite:
                final = prior
                state = "HOLDING"
                reasons.append("تصمیم قبلی فقط به‌عنوان hysteresis معتبر حفظ شد؛ هیچ موتور مستقلی تصمیم را تحمیل نکرد.")

        if not reasons:
            reasons.append("تصمیم از ادغام واحد همه خانواده‌های شواهد حاصل شد.")

        return {
            "version": V31_VERSION,
            "decision": final,
            "state": state,
            "candidate": candidate,
            "confidence": round(confidence,1),
            "margin": round(margin,4),
            "long_score": round(ls,4),
            "short_score": round(ss,4),
            "support": support,
            "opposition": oppose,
            "data_quality": round(dq,1),
            "signal_quality": round(quality,1),
            "rr": round(rr,2),
            "contradiction": round(contradiction,3),
            "authoritative": True,
            "reason": reasons,
            "architecture": "ONE_BRAIN_MANY_EVIDENCE_CHANNELS",
        }

TITAN_CANONICAL_V31 = TitanCanonicalDecisionV31()
_analyze_asset_v30 = _analyze_asset_v30_impl

def _analyze_asset_v31_impl(symbol: str, btc_trend: str) -> Optional[dict[str, Any]]:
    """Public analyzer: exactly one authoritative final decision."""
    item = _analyze_asset_v30(symbol, btc_trend)
    if not item:
        return None
    try:
        debate = item.get("deep_consensus_v30") or TITAN_DEEP_V30.evaluate(item)
        canonical = TITAN_CANONICAL_V31.decide(item, debate)

        # Preserve every upstream analysis as evidence/audit, but overwrite the
        # public decision fields from ONE canonical governor only.
        decision = canonical["decision"]
        item["decision_tag"] = decision
        item["bias"] = "صعودی" if decision == "LONG" else "نزولی" if decision == "SHORT" else "خنثی"
        item["entry_mode"] = "EARLY" if decision in {"LONG","SHORT"} else "WAIT"
        item["decision_confidence"] = canonical["confidence"]
        item["decision_state"] = canonical["state"]
        item["signal_tag"] = f"V31 CANONICAL — {decision}"
        item["canonical_decision"] = {
            **(item.get("canonical_decision") or {}),
            "decision": decision,
            "bias": item["bias"],
            "confidence": canonical["confidence"],
            "state": canonical["state"],
            "version": V31_VERSION,
            "authoritative": True,
        }
        item["decision_audit_v31"] = canonical
        item.setdefault("fusion", {})["canonical_decision_v31"] = canonical

        # Explicitly mark upstream outputs as evidence, preventing downstream UI
        # code from treating them as separate final decisions.
        item["decision_architecture"] = {
            "type": "ONE_BRAIN_MANY_EVIDENCE_CHANNELS",
            "authoritative_source": V31_VERSION,
            "upstream_are_evidence_only": True,
            "final_decision": decision,
        }
        return item
    except Exception as exc:
        LOGGER.exception("V31 canonical governor failed for %s: %s", symbol, exc)
        # Fail closed: never invent a directional signal when the single
        # authoritative governor cannot complete.
        item["decision_tag"] = "WAIT"
        item["bias"] = "خنثی"
        item["entry_mode"] = "WAIT"
        item["decision_confidence"] = 0.0
        item["decision_state"] = "ERROR_SAFE_WAIT"
        item["signal_tag"] = "V31 CANONICAL — WAIT"
        item["canonical_decision"] = {
            "decision":"WAIT","state":"ERROR_SAFE_WAIT","confidence":0.0,
            "version":V31_VERSION,"authoritative":True,
            "reason":["موتور تصمیم واحد با خطای داخلی متوقف شد؛ fail-closed به WAIT انجام شد."]
        }
        return item
