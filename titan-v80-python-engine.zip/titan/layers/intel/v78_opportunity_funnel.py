# [TITAN V78 layer] intel/v78_opportunity_funnel
# ============================================================
# TITAN V78 — REAL OPPORTUNITY FUNNEL (NO WASTEFUL WAITS)
# Strict, multi-stage filter that only surfaces high-quality,
# time-sensitive trading opportunities. Every stage is auditable.
# Integrates neural, AI, consensus, edge, regime, forecast path.
# ============================================================
V78_FUNNEL_VERSION = "TITAN-V78.2-OPPORTUNITY-FUNNEL"

def _v78_funnel_score(item: dict, adaptive: dict | None = None) -> dict:
    """
    Multi-stage opportunity funnel.
    Returns:
      stage: which stage passed/failed
      score: 0..1
      action: LONG / SHORT / WAIT / WATCH
      reasons: list of pass/fail reasons
      urgency: 0..1 (time sensitivity)
      quality: letter grade
    """
    adaptive = adaptive or {}
    min_conf = safe_float(adaptive.get("min_confidence"), 0.52)
    min_edge = safe_float(adaptive.get("min_edge_long"), 0.14)
    min_cons = safe_float(adaptive.get("min_consensus"), 0.55)
    opp_th = safe_float(adaptive.get("opportunity_threshold"), 0.62)

    result = {
        "version": V78_FUNNEL_VERSION,
        "stage": "entry",
        "score": 0.0,
        "action": "WAIT",
        "reasons": [],
        "urgency": 0.0,
        "quality": "F",
        "filters": {},
        "stages": [],  # ordered audit trail for schematic UI
    }

    def _stage(sid, label_fa, ok, detail=""):
        result["stages"].append({
            "id": sid,
            "label": label_fa,
            "ok": bool(ok),
            "state": "pass" if ok else "fail",
            "detail": str(detail or "")[:80],
        })
    try:
        decision = str(item.get("decision") or item.get("final_decision") or "WAIT").upper()
        conf = safe_float(item.get("confidence") or item.get("final_confidence"), 0.0)
        edge = safe_float(item.get("edge") or (item.get("edge_pack") or {}).get("edge"), 0.0)
        if edge < 0.01:
            edge = safe_float((item.get("edge_pack") or {}).get("score"), 0.0)
        cons = safe_float(item.get("consensus_score") or item.get("v30_score") or item.get("deep_consensus"), 0.0)
        neural = safe_float((item.get("neural") or {}).get("score") or item.get("neural_score"), 0.5)
        ai = safe_float((item.get("ai") or {}).get("score") or item.get("ai_score"), 0.5)
        opp_raw = safe_float(item.get("opportunity_score") or (item.get("opportunity") or {}).get("score"), 0.0)
        _reg = item.get("regime") or item.get("market_regime") or ""
        if isinstance(_reg, dict):
            regime = str(_reg.get("label") or _reg.get("name") or "")
        else:
            regime = str(_reg or "")
        dq = safe_float(item.get("data_quality") or item.get("dq_score"), 70.0)
        fc = item.get("v78_forecast") or item.get("candle_forecast") or item.get("forecast") or {}
        path_score = safe_float(fc.get("path_score"), 0.5)
        fc_conf = safe_float(fc.get("confidence"), 0.4)

        # Stage 1: Data quality gate
        result["stage"] = "data_quality"
        if dq < 55:
            result["reasons"].append(f"data_quality_low:{dq:.0f}")
            result["filters"]["data_quality"] = False
            _stage("data", "داده", False, f"dq={dq:.0f}")
            return result
        result["filters"]["data_quality"] = True
        result["reasons"].append("data_ok")
        _stage("data", "داده", True, f"dq={dq:.0f}")

        # Stage 2: Hard safety (stale / invalid levels already handled upstream)
        result["stage"] = "safety"
        levels = item.get("levels") or item.get("price_levels") or {}
        if decision in {"LONG", "SHORT"}:
            sl = safe_float(levels.get("sl") or levels.get("stop"), 0)
            tp = safe_float(levels.get("tp1") or levels.get("target1"), 0)
            price = safe_float(item.get("price") or item.get("last"), 0)
            if price > 0 and sl > 0 and tp > 0:
                if decision == "LONG" and not (sl < price < tp):
                    result["reasons"].append("levels_invalid_long")
                    result["filters"]["levels"] = False
                    _stage("safety", "ایمنی", False, "levels_long")
                    return result
                if decision == "SHORT" and not (tp < price < sl):
                    result["reasons"].append("levels_invalid_short")
                    result["filters"]["levels"] = False
                    _stage("safety", "ایمنی", False, "levels_short")
                    return result
            result["filters"]["levels"] = True
            _stage("safety", "ایمنی", True, "levels_ok")
        else:
            result["filters"]["levels"] = True
            _stage("safety", "ایمنی", True, "n/a")

        # Stage 3: Regime filter (hostile regimes need higher bar)
        result["stage"] = "regime"
        regime_penalty = 0.0
        if any(x in regime.lower() for x in ("chaotic", "high_vol", "spike", "news")):
            regime_penalty = 0.12
            result["reasons"].append("regime_hostile_penalty")
        result["filters"]["regime"] = True
        _stage("regime", "رژیم", True, regime[:24] or "unknown")

        # Stage 4: Multi-factor confluence score
        result["stage"] = "confluence"
        # normalize components to 0..1
        c_conf = float(clamp(conf, 0, 1))
        c_edge = float(clamp(edge / 0.35, 0, 1))  # edge 0.35 ~ full
        c_cons = float(clamp(cons, 0, 1))
        c_neural = float(clamp(neural if neural <= 1 else neural / 100, 0, 1))
        c_ai = float(clamp(ai if ai <= 1 else ai / 100, 0, 1))
        c_path = float(clamp(path_score, 0, 1))
        c_fc = float(clamp(fc_conf, 0, 1))
        c_opp = float(clamp(opp_raw if opp_raw <= 1 else opp_raw / 100, 0, 1))

        # weighted confluence (neural + AI + consensus + edge + path are core)
        weights = {
            "conf": 0.14,
            "edge": 0.18,
            "cons": 0.18,
            "neural": 0.14,
            "ai": 0.08,
            "path": 0.16,
            "fc": 0.07,
            "opp": 0.05,
        }
        score = (
            weights["conf"] * c_conf +
            weights["edge"] * c_edge +
            weights["cons"] * c_cons +
            weights["neural"] * c_neural +
            weights["ai"] * c_ai +
            weights["path"] * c_path +
            weights["fc"] * c_fc +
            weights["opp"] * c_opp
        )
        score = float(clamp(score - regime_penalty, 0, 1))
        result["score"] = round(score, 4)
        result["filters"]["confluence"] = score >= 0.42
        result["reasons"].append(f"confluence:{score:.3f}")
        _stage("confluence", "هم‌گرایی", score >= 0.42, f"{score:.2f}")

        # Stage 5: Decision alignment + minimum thresholds
        result["stage"] = "thresholds"
        action = "WAIT"
        if decision in {"LONG", "SHORT"}:
            pass_conf = conf >= min_conf
            pass_edge = edge >= (min_edge - 0.02 if score > 0.70 else min_edge)
            pass_cons = cons >= min_cons or score >= 0.68
            result["filters"]["min_conf"] = pass_conf
            result["filters"]["min_edge"] = pass_edge
            result["filters"]["min_cons"] = pass_cons
            if pass_conf and pass_edge and pass_cons and score >= 0.48:
                action = decision
                result["reasons"].append("thresholds_passed")
            else:
                fails = []
                if not pass_conf:
                    fails.append(f"conf<{min_conf:.2f}")
                if not pass_edge:
                    fails.append(f"edge<{min_edge:.2f}")
                if not pass_cons:
                    fails.append(f"cons<{min_cons:.2f}")
                result["reasons"].append("threshold_fail:" + ",".join(fails))
                # high confluence but missing one threshold → WATCH instead of hard WAIT
                if score >= 0.58:
                    action = "WATCH"
                    result["reasons"].append("elevated_to_WATCH")
        else:
            # original WAIT — check if we should upgrade to WATCH because confluence is high
            if score >= 0.62 and path_score >= 0.58:
                action = "WATCH"
                result["reasons"].append("WAIT_upgraded_to_WATCH_by_path")
            else:
                result["reasons"].append("clean_WAIT")

        result["action"] = action
        thr_ok = action in {"LONG", "SHORT", "WATCH"}
        if not any(s.get("id") == "thresholds" for s in result["stages"]):
            _stage("thresholds", "آستانه", thr_ok, action)

        # Stage 6: Urgency (time sensitivity)
        result["stage"] = "urgency"
        urgency = 0.0
        if action in {"LONG", "SHORT"}:
            urgency = 0.35 + 0.25 * c_edge + 0.20 * c_path + 0.15 * (1.0 if score > 0.7 else 0.0)
            # boost if forecast path is strongly aligned
            if (action == "LONG" and path_score > 0.62) or (action == "SHORT" and path_score < 0.38):
                urgency += 0.12
            urgency = float(clamp(urgency, 0, 1))
        elif action == "WATCH":
            urgency = 0.25 + 0.2 * score
        result["urgency"] = round(urgency, 3)
        _stage("urgency", "فوریت", (urgency >= 0.3) if action in {"LONG", "SHORT"} else True, f"{urgency:.2f}")

        # Quality grade
        if score >= 0.78 and action in {"LONG", "SHORT"}:
            result["quality"] = "A"
        elif score >= 0.68 and action in {"LONG", "SHORT"}:
            result["quality"] = "B"
        elif score >= 0.58:
            result["quality"] = "C"
        elif score >= 0.45:
            result["quality"] = "D"
        else:
            result["quality"] = "F"

        result["stage"] = "complete"
        result["reasons"].append(f"final:{action}:{result['quality']}")
    except Exception as exp:
        result["reasons"].append(f"error:{exp}")
        _swallow()
    try:
        known = {s["id"] for s in (result.get("stages") or [])}
        for sid, lab in (("data","داده"),("safety","ایمنی"),("regime","رژیم"),("confluence","هم‌گرایی"),("thresholds","آستانه"),("urgency","فوریت")):
            if sid not in known:
                result.setdefault("stages", []).append({"id": sid, "label": lab, "ok": False, "state": "skip", "detail": ""})
    except Exception:
        pass
    return result

def _v78_apply_funnel(item: dict) -> dict:
    """Apply funnel to analysis item and override weak WAIT/decision when justified."""
    try:
        if not isinstance(item, dict):
            return item
        adaptive = item.get("v78_adaptive") or {}
        if not adaptive and "_v78_get_adaptive_params" in globals():
            try:
                adaptive = _v78_get_adaptive_params()
            except Exception:
                _swallow()
        funnel = _v78_funnel_score(item, adaptive)
        item["v78_funnel"] = funnel
        item["opportunity_funnel"] = funnel
        # practical override: only upgrade WAIT → WATCH or keep directional if funnel agrees
        original = str(item.get("decision") or "WAIT").upper()
        new_action = funnel.get("action", "WAIT")
        if new_action in {"LONG", "SHORT"} and original in {"LONG", "SHORT", "WAIT"}:
            # only change if funnel is confident
            if funnel.get("score", 0) >= 0.55 and funnel.get("quality") in {"A", "B", "C"}:
                item["decision"] = new_action
                item["final_decision"] = new_action
                item["funnel_override"] = True
                item["funnel_reason"] = funnel.get("reasons", [])[-1] if funnel.get("reasons") else ""
        elif new_action == "WATCH" and original == "WAIT":
            item["decision"] = "WATCH"
            item["final_decision"] = "WATCH"
            item["funnel_override"] = True
        item["opportunity_score"] = funnel.get("score", 0)
        item["opportunity_quality"] = funnel.get("quality", "F")
        item["opportunity_urgency"] = funnel.get("urgency", 0)
    except Exception:
        _swallow()
    return item

def _v78_funnel_self_test() -> int:
    print("  + v78_funnel_basic")
    item = {
        "decision": "LONG",
        "confidence": 0.68,
        "edge": 0.19,
        "consensus_score": 0.71,
        "neural": {"score": 0.65},
        "ai": {"score": 0.55},
        "opportunity_score": 0.6,
        "data_quality": 82,
        "levels": {"sl": 100, "tp1": 110},
        "price": 105,
        "regime": "trend",
        "v78_forecast": {"path_score": 0.66, "confidence": 0.7},
    }
    f = _v78_funnel_score(item)
    assert f["action"] in {"LONG", "WATCH", "WAIT"}
    assert "score" in f
    print("  + v78_funnel_rejects_bad_data")
    bad = dict(item)
    bad["data_quality"] = 40
    f2 = _v78_funnel_score(bad)
    assert f2["action"] == "WAIT"
    print("V78 Opportunity Funnel self-test: PASS")
    return 0
