# [TITAN V77 layer] engine/backtest_walkforward - Backtest / walk-forward
# Original V76 source lines 7207-7235 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# BACKTEST / WALK FORWARD - FIXED HORIZON LOGIC
# ============================================================





def _probability_calibration(symbol: str = "", direction: str = "", raw_prob: float = 50.0) -> dict[str, Any]:
    """Delegate to Platt+Isotonic calibrator (forecasts + paper trades)."""
    return calibrate_success_probability(symbol=symbol, direction=direction, raw_prob=raw_prob)


def _proxy_trade_candidates(df: pd.DataFrame, long_threshold: float, short_threshold: float,
                            min_gap_long: float, min_gap_short: float, max_momentum_short: float,
                            start: int, end: int, friction: float) -> list[float]:
    out=[]
    for i in range(max(60,start), min(end, len(df)-1)):
        sample=df.iloc[:i+1]
        direction, score, meta=_tf_forecast(sample)
        entry=float(df['close'].iloc[i]); future=float(df['close'].iloc[i+1])
        rsi=safe_float(meta.get('rsi'),50); gap=safe_float(meta.get('ema_gap'),0); mom=safe_float(meta.get('momentum'),0)
        if direction=='صعودی' and score>=long_threshold and gap>=min_gap_long:
            out.append(((future-entry)/entry)*100-friction)
        elif direction=='نزولی' and score<=short_threshold and gap<=min_gap_short and mom<=max_momentum_short and not(rsi<22 and mom>-0.5):
            out.append(((entry-future)/entry)*100-friction)
    return out
