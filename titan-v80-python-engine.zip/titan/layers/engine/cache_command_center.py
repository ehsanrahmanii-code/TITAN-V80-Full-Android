# [TITAN V77 layer] engine/cache_command_center - Market cache / command center
# Original V76 source lines 7326-7954 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# MARKET CACHE / COMMAND CENTER
# ============================================================


def _load_market_cache() -> tuple[list[dict[str, Any]], str, dict[str, Any]]:
    data = _load_json(MARKET_CACHE_PATH, {})
    if not isinstance(data, dict): return [], "", {}
    return data.get("data", []) if isinstance(data.get("data"), list) else [], str(data.get("gemini_summary", "") or ""), data.get("macro", {}) if isinstance(data.get("macro"), dict) else {}


def _global_ai_summary(market_data: list[dict[str, Any]], macro: dict[str, Any]) -> str:
    payload = {"macro": macro, "coins": [{"symbol": x.get("symbol"), "bias": x.get("bias"), "score": x.get("score"), "alignment": x.get("alignment")} for x in market_data[:8]]}
    return _call_gemini(payload, global_summary=True) or ""


def _market_pulse_snapshot(market_data: list[dict[str, Any]], macro: dict[str, Any]) -> dict[str, Any]:
    items = market_data or []
    scores = [safe_float(x.get("score"), 50) for x in items]
    alignments = [safe_float(x.get("alignment"), 50) for x in items]
    # Prefer unified stance family so breadth matches cards / signals
    bullish = sum(1 for x in items if str(x.get("stance_family") or "") == "LONG" or x.get("bias") == "صعودی")
    bearish = sum(1 for x in items if str(x.get("stance_family") or "") == "SHORT" or x.get("bias") == "نزولی")
    # Avoid double-count if both set; recompute cleanly
    bullish = sum(1 for x in items if str(x.get("stance_family") or ("LONG" if x.get("bias")=="صعودی" else "")) == "LONG")
    bearish = sum(1 for x in items if str(x.get("stance_family") or ("SHORT" if x.get("bias")=="نزولی" else "")) == "SHORT")
    neutral = max(0, len(items) - bullish - bearish)
    published_long = sum(1 for x in items if str(x.get("stance") or "") == "LONG")
    published_short = sum(1 for x in items if str(x.get("stance") or "") == "SHORT")
    lean_long = sum(1 for x in items if str(x.get("stance") or "") == "LEAN_LONG")
    lean_short = sum(1 for x in items if str(x.get("stance") or "") == "LEAN_SHORT")
    avg_score = float(np.mean(scores)) if scores else 50.0
    avg_alignment = float(np.mean(alignments)) if alignments else 0.0
    leader = max(items, key=lambda x: safe_float(x.get("signal_quality"), 0), default=None)
    if avg_score >= 62: regime = "متمایل به صعود"
    elif avg_score <= 38: regime = "متمایل به نزول"
    else: regime = "خنثی / دوطرفه"
    return {
        "timestamp": datetime.now(timezone.utc).isoformat(timespec="seconds"), "regime": regime,
        "avg_score": round(avg_score, 1), "avg_alignment": round(avg_alignment, 1),
        "breadth": {
            "bullish": bullish, "bearish": bearish, "neutral": neutral, "total": len(items),
            "published_long": published_long, "published_short": published_short,
            "lean_long": lean_long, "lean_short": lean_short,
            "actionable": published_long + published_short,
        },
        "leader": {"symbol": leader.get("symbol"), "score": leader.get("score"), "quality": leader.get("signal_quality"), "tag": leader.get("signal_tag")} if leader else None,
        "btc_trend": macro.get("btc_trend", "N/A"), "fear_greed": macro.get("fear_greed_val", "N/A"),
        "confluence_avg": round(float(np.mean([safe_float(x.get("edge",{}).get("confluence",{}).get("score"),50) for x in items])) if items else 0,1),
        "meta_accept": sum(1 for x in items if x.get("edge",{}).get("meta",{}).get("label") == "ACCEPT"),
        "defensive_count": sum(1 for x in items if x.get("edge",{}).get("governor",{}).get("state") in {"DEFENSIVE","REDUCED"}),
    }


_BACKGROUND_REFRESH_LOCK = threading.Lock()
_BACKGROUND_REFRESH_RUNNING = False
_SCAN_PROGRESS_LOCK = threading.Lock()
_SCAN_PROGRESS = {
    "status":"idle", "phase":"آماده", "started_at":0.0, "finished_at":0.0,
    "completed":0, "total":0, "percent":0, "message":"هنوز اسکن جدیدی اجرا نشده است",
    "last_success_at":0.0, "elapsed_sec":0.0, "fresh":False
}

def _scan_progress_update(**kwargs):
    with _SCAN_PROGRESS_LOCK:
        _SCAN_PROGRESS.update(kwargs)
        if _SCAN_PROGRESS.get("started_at"):
            _SCAN_PROGRESS["elapsed_sec"] = round(max(0.0, time.time()-float(_SCAN_PROGRESS["started_at"])),1)
        return dict(_SCAN_PROGRESS)

def _scan_progress_snapshot():
    with _SCAN_PROGRESS_LOCK:
        out=dict(_SCAN_PROGRESS)
        if out.get("started_at"):
            out["elapsed_sec"]=round(max(0.0,time.time()-float(out["started_at"])),1)
        return out

def _scan_supervisor_tick() -> None:
    """Recover the refresh gate if a worker is stuck, so later scans can retry."""
    global _BACKGROUND_REFRESH_RUNNING
    try:
        p = _scan_progress_snapshot()
        status = str(p.get("status") or "")
        if status in {"running", "queued"}:
            started = float(p.get("started_at") or 0.0)
            stall_limit = float(globals().get("SCAN_STALL_TIMEOUT_SEC", 90.0) or 90.0)
            stall_limit = max(60.0, min(stall_limit, max(90.0, float(globals().get("AUTO_SCAN_INTERVAL_SECONDS", 45) or 45) * 3)))
            # Network/API stalls must not permanently disable every future scan.
            if started and time.time() - started > stall_limit:
                LOGGER.error("Android scan watchdog: stale scan (%.0fs); releasing refresh gate", time.time() - started)
                with _BACKGROUND_REFRESH_LOCK:
                    _BACKGROUND_REFRESH_RUNNING = False
                _scan_progress_update(
                    status="stalled", phase="watchdog",
                    finished_at=time.time(),
                    message="اسکن از مهلت مجاز گذشت؛ قفل آزاد شد. در حال تلاش مجدد… (اگر Binance مسدود است، از VPN یا فیلترشکن استفاده کنید)",
                    fresh=False,
                )
        # Extra safety: if flag says running but status is idle/complete/error/stalled, clear flag
        elif status in {"idle", "complete", "error", "stalled", "failed", "no-data"} or not status:
            with _BACKGROUND_REFRESH_LOCK:
                if _BACKGROUND_REFRESH_RUNNING and status != "running":
                    _BACKGROUND_REFRESH_RUNNING = False
    except Exception as exc:
        LOGGER.exception("scan watchdog failed: %s", exc)


def _background_market_refresh(force: bool = False) -> bool:
    """Refresh market data off-request, with truthful progress and guaranteed lock cleanup."""
    global _BACKGROUND_REFRESH_RUNNING
    now = time.time()
    # Opportunistic recovery before attempting a new scan
    try:
        _scan_supervisor_tick()
    except Exception:
        pass
    with _BACKGROUND_REFRESH_LOCK:
        if _BACKGROUND_REFRESH_RUNNING:
            # If the previous worker has been stuck longer than stall limit, steal the lock
            p = _scan_progress_snapshot()
            started = float(p.get("started_at") or 0.0)
            stall_limit = float(globals().get("SCAN_STALL_TIMEOUT_SEC", 90.0) or 90.0)
            if force and started and (now - started) > stall_limit:
                LOGGER.warning("Force-stealing stuck refresh lock (age=%.0fs)", now - started)
                _BACKGROUND_REFRESH_RUNNING = False
            elif _BACKGROUND_REFRESH_RUNNING:
                # Do not silently lose a manual refresh request: keep existing progress fields.
                cur = _scan_progress_snapshot()
                if str(cur.get("status") or "") not in {"running", "queued"}:
                    _scan_progress_update(
                        status="running", phase=cur.get("phase") or "اسکن در حال اجرا",
                        message="اسکن در حال اجراست",
                        fresh=False,
                    )
                return False
        _BACKGROUND_REFRESH_RUNNING = True

    _scan_progress_update(
        status="running", phase="آماده‌سازی داده‌ها", started_at=now,
        finished_at=0.0, completed=0,
        total=max(1, len(USER_SETTINGS.get("active_coins") or DEFAULT_COINS)),
        percent=1, message="اتصال به بازار و دریافت داده‌ها…", fresh=False,
    )

    def _runner():
        global _BACKGROUND_REFRESH_RUNNING
        started = time.time()
        try:
            result = update_cache(force)
            with CACHE_LOCK:
                rows = list(CACHE.get("data") or [])
                cache_ts = float(CACHE.get("timestamp") or 0.0)
            # Some historical wrappers return data without updating progress.
            if isinstance(result, tuple) and result and isinstance(result[0], list):
                rows = result[0] or rows
            finished = time.time()
            if rows:
                _scan_progress_update(
                    status="complete", phase="تکمیل شد", finished_at=finished,
                    completed=len(rows), total=max(len(rows), int(_scan_progress_snapshot().get("total") or 0)),
                    percent=100, message=f"اسکن کامل شد؛ {len(rows)} دارایی تحلیل شد",
                    last_success_at=cache_ts or finished, elapsed_sec=round(finished-started, 1),
                    fresh=True,
                )
            else:
                _scan_progress_update(
                    status="error", phase="بدون داده", finished_at=finished,
                    percent=0, message="اسکن تمام شد اما داده‌ای برنگشت؛ اتصال اینترنت/API و لاگ را بررسی کنید",
                    elapsed_sec=round(finished-started, 1), fresh=False,
                )
        except Exception as exc:
            LOGGER.exception("Background market refresh failed: %s", exc)
            _scan_progress_update(
                status="error", phase="خطای اسکن", finished_at=time.time(),
                percent=0, message=f"اسکن ناموفق بود: {type(exc).__name__}: {str(exc)[:180]}",
                fresh=False,
            )
        finally:
            with _BACKGROUND_REFRESH_LOCK:
                _BACKGROUND_REFRESH_RUNNING = False
    try:
        threading.Thread(target=_runner, name="titan-market-refresh", daemon=True).start()
    except Exception:
        with _BACKGROUND_REFRESH_LOCK:
            _BACKGROUND_REFRESH_RUNNING = False
        _scan_progress_update(
            status="error", phase="راه‌اندازی ناموفق", finished_at=time.time(),
            percent=0, message="ساخت نخ اسکن ناموفق بود", fresh=False,
        )
        LOGGER.exception("Could not start market refresh thread")
        return False
    return True

def _fast_market_snapshot() -> tuple[list[dict[str, Any]], str, dict[str, Any]]:
    """Return memory cache first, then disk cache, without network calls."""
    with CACHE_LOCK:
        cached_data = list(CACHE.get("data") or [])
        cached_summary = CACHE.get("gemini_summary") or ""
        cached_macro = CACHE.get("macro") or {}
    if cached_data:
        # Single-source price rule: even RAM-cache hits must pass through the
        # same LIVE_PRICES rebase before any API/dashboard consumer receives them.
        try:
            live_data = _v29_sync_snapshot_to_live(cached_data)
            with CACHE_LOCK:
                CACHE["data"] = live_data
            return live_data, cached_summary, cached_macro
        except Exception as exc:
            LOGGER.debug("Live RAM snapshot sync failed: %s", exc)
            return cached_data, cached_summary, cached_macro
    data, summary, macro = _load_market_cache()
    if data:
        # Preserve the timestamp written by the scan instead of replacing it
        # with application restart time. This is critical for truthful freshness.
        raw=_load_json(MARKET_CACHE_PATH,{})
        stored_ts=safe_float(raw.get("timestamp"),0.0) if isinstance(raw,dict) else 0.0
        with CACHE_LOCK:
            CACHE.update(timestamp=stored_ts or time.time(), data=data, gemini_summary=summary, macro=macro)
    # Critical consistency rule: cached analytical state may be 40s old, but the
    # displayed market price must always come from the freshest live ticker.
    if data:
        try:
            data = _v29_sync_snapshot_to_live(list(data))
            with CACHE_LOCK:
                CACHE["data"] = data
        except Exception as exc:
            LOGGER.debug("Live snapshot sync failed: %s", exc)
    return data or [], summary or "", macro or {}


def _v29_num_price(value: Any) -> float:
    """Parse TITAN display prices safely."""
    try:
        s = str(value or "").replace(",", "").replace("$", "").replace("USDT", "").strip()
        return float(s)
    except Exception:
        _swallow()
        return 0.0


def _v29_shift_price_field(value: Any, ratio: float) -> Any:
    p = _v29_num_price(value)
    if p <= 0 or not math.isfinite(ratio):
        return value
    return smart_format(p * ratio)


def _v29_sync_snapshot_to_live(data: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """
    Rebase only price-dependent dashboard outputs to the newest Binance spot
    price. Closed-candle indicators remain untouched; entry/SL/TP and the
    scenario path move with the live reference price.
    """
    if not data:
        return data
    now = time.time()
    with LIVE_LOCK:
        live_map = {
            k: dict(v) for k, v in LIVE_PRICES.items()
            if safe_float(v.get("price"), 0) > 0
        }
    for item in data:
        sym = _normalize_symbol(item.get("symbol", ""))
        lp = live_map.get(sym)
        if not lp:
            continue
        live = safe_float(lp.get("price"), 0)
        if live <= 0:
            continue
        old = _v29_num_price(item.get("price"))
        if old <= 0:
            item["price"] = smart_format(live)
            item["entry_valid"] = smart_format(live)
            continue

        ratio = live / old
        # Keep the canonical signal timestamp/price for audit, but expose a
        # second, authoritative live price for the current UI.
        item.setdefault("signal_snapshot", {})
        item["signal_snapshot"].setdefault("price", old)
        item["signal_snapshot"].setdefault("timestamp", item.get("scan_timestamp", now))
        item["price"] = smart_format(live)
        item["price_raw"] = float(live)
        item["live_price"] = float(live)
        item["entry_valid"] = smart_format(live)
        item["entry_raw"] = float(live)
        for key in ("stop_loss", "tp1", "tp2"):
            if key in item:
                item[key] = _v29_shift_price_field(item.get(key), ratio)

        # Recompute price-relative risk metrics from the live price.
        sl = _v29_num_price(item.get("stop_loss"))
        tp1 = _v29_num_price(item.get("tp1"))
        tp2 = _v29_num_price(item.get("tp2"))
        if sl > 0:
            item["stop_loss_raw"] = float(sl)
            if tp1 > 0: item["tp1_raw"] = float(tp1)
            if tp2 > 0: item["tp2_raw"] = float(tp2)
            item["risk_distance_pct"] = round(abs(live - sl) / live * 100.0, 3)
            item["rr_tp1"] = round(abs(tp1 - live) / max(abs(live - sl), 1e-12), 2) if tp1 > 0 else item.get("rr_tp1", 0)
            item["rr_tp2"] = round(abs(tp2 - live) / max(abs(live - sl), 1e-12), 2) if tp2 > 0 else item.get("rr_tp2", 0)
            item["effective_rr_tp1"] = item["rr_tp1"]
            item["effective_rr_tp2"] = item["rr_tp2"]

        scan_ts = safe_float(item.get("scan_timestamp"), now)
        item["live_price"] = live
        item["live_price_source"] = lp.get("source", "Binance")
        item["live_price_ts"] = safe_float(lp.get("ts"), now)
        item["live_price_age_sec"] = round(max(0.0, now - safe_float(lp.get("ts"), now)), 2)
        item["live_sync"] = True
        item["price_delta_from_scan_pct"] = round((live / old - 1.0) * 100.0, 4)
        item["signal_age_sec"] = round(max(0.0, now - scan_ts), 1)

        # Re-anchor future candle scenario to the same live price while keeping
        # its modeled percentage geometry unchanged.
        fc = item.get("candle_forecast")
        if isinstance(fc, dict):
            fc["last_price"] = round(live, 8)
            for candle in fc.get("candles", []) or []:
                if isinstance(candle, dict):
                    for k in ("open", "high", "low", "close", "mid", "band_low", "band_high"):
                        if k in candle:
                            try:
                                candle[k] = round(float(candle[k]) * ratio, 8)
                            except Exception:
                                _swallow()
    return data


def _v29_async_gemini_enrichment(snapshot: list[dict[str, Any]], macro: dict[str, Any]) -> None:
    """Low-latency asynchronous Gemini evidence pass; never blocks market scan.

    V58 optimization: never launch overlapping enrichment jobs and never re-query
    a symbol whose Gemini evidence is still inside AUTO_AI_REFRESH_SECONDS.
    """
    if not GEMINI_API_KEY or not snapshot:
        return
    if not _AI_ENRICH_LOCK.acquire(blocking=False):
        return
    try:
        ordered = sorted(
            snapshot,
            key=lambda x: (
                -safe_float(x.get("signal_quality"), 0),
                -safe_float(x.get("success_probability"), 0),
            ),
        )[:AUTO_AI_TOP_N]
        raw = _load_json(AI_SYMBOL_CACHE_PATH, {})
        cache = raw if isinstance(raw, dict) else {}
        jobs = []
        now_ts = time.time()
        for item in ordered:
            sym = _normalize_symbol(item.get("symbol", ""))
            cached_row = cache.get(sym) if isinstance(cache, dict) else None
            if isinstance(cached_row, dict) and (now_ts - safe_float(cached_row.get("ts"), 0)) <= AUTO_AI_REFRESH_SECONDS and cached_row.get("text"):
                continue
            payload = {
                "task": "TITAN evidence review only; do not invent prices; use supplied live price.",
                "symbol": sym,
                "live_price": _v29_num_price(item.get("price")),
                "decision": item.get("decision_tag", "WAIT"),
                "score": item.get("score", 50),
                "signal_quality": item.get("signal_quality", 0),
                "success_probability": item.get("success_probability", 50),
                "timeframes": item.get("tf_scores", {}),
                "bias": item.get("bias"),
                "entry": item.get("entry_valid"),
                "stop_loss": item.get("stop_loss"),
                "tp1": item.get("tp1"),
                "tp2": item.get("tp2"),
                "rsi": item.get("rsi"),
                "macd": item.get("macd"),
                "derivatives": {
                    "oi": item.get("coinglass_oi"),
                    "funding": item.get("coinglass_funding"),
                    "taker_buy_pct": item.get("taker_buy_pct"),
                    "long_short_ratio": item.get("long_short_ratio"),
                },
                "macro": {
                    "btc_trend": macro.get("btc_trend"),
                    "fear_greed": macro.get("fear_greed_val"),
                },
            }
            jobs.append((sym, payload))

        def one(sym_payload):
            sym, payload = sym_payload
            try:
                result = _call_gemini(payload)
                if result:
                    return sym, {"ts": time.time(), "text": result, "source": "Gemini", "price": payload["live_price"]}
            except Exception as exc:
                LOGGER.debug("V29 async Gemini %s failed: %s", sym, exc)
            return sym, None

        if not jobs:
            return

        pool = _get_ai_pool(min(2, max(1, len(jobs))))
        futures = [pool.submit(one, j) for j in jobs]
        for fut in as_completed(futures):
            sym, row = fut.result()
            if row:
                cache[sym] = row

        _save_json(AI_SYMBOL_CACHE_PATH, cache)

        # Feed fresh Gemini evidence into the in-memory dashboard without
        # forcing a page reload. The next automatic scan also consumes it.
        with CACHE_LOCK:
            current = CACHE.get("data") or []
            by = {_normalize_symbol(x.get("symbol", "")): x for x in current}
            for sym, row in cache.items():
                if sym in by and isinstance(by[sym], dict) and row.get("text"):
                    ai = by[sym].get("ai_opinions") if isinstance(by[sym].get("ai_opinions"), dict) else {}
                    ai = dict(ai)
                    ai["gemini"] = row["text"]
                    ai["providers"] = list(dict.fromkeys((ai.get("providers") or []) + ["gemini"]))
                    ai["ai_status"] = dict(ai.get("ai_status") or {})
                    ai["ai_status"]["gemini"] = "تحلیل Gemini زنده"
                    ai["cached_at"] = row.get("ts")
                    by[sym]["ai_opinions"] = ai
            CACHE["data"] = _v29_sync_snapshot_to_live(list(by.values()))
            CACHE["timestamp"] = time.time()
            snap = CACHE["data"]
            summary = CACHE.get("gemini_summary") or ""
            macro_now = CACHE.get("macro") or macro
        _save_json(MARKET_CACHE_PATH, {
            "timestamp": time.time(), "data": snap,
            "gemini_summary": summary, "macro": macro_now
        })
    except Exception as exc:
        LOGGER.warning("V29 Gemini enrichment failed: %s", exc)
    finally:
        try:
            _AI_ENRICH_LOCK.release()
        except RuntimeError:
            pass


def _v29_auto_loop() -> None:
    """Permanent autonomous maintenance loop independent of browser requests.

    Three independent maintenance lanes are kept alive:
      1) live multi-asset market scans;
      2) forecast/outcome resolution and learning calibration;
      3) throttled historical-performance/backtest snapshots.

    The performance lane is dispatched in its own daemon thread so an Android
    backtest cannot block the live dashboard or the 45-second market scanner.
    """
    last_scan = 0.0
    while True:
        try:
            now = time.time()
            if now - last_scan >= AUTO_SCAN_INTERVAL_SECONDS:
                started = time.perf_counter()
                queued = _background_market_refresh(False)
                last_scan = now
                LOGGER.info(
                    "V29 autonomous scan %s in %.1fms",
                    "queued" if queued else "already-running",
                    (time.perf_counter() - started) * 1000,
                )

            # Resolve matured forecasts and rebuild the conservative learning
            # profile from actual outcomes. This never invents a result.
            _scan_supervisor_tick()
            _safe_background_forecast_maintenance()

            # Historical performance is throttled internally (currently every
            # 5 minutes) and rotates through symbols. Dispatching it separately
            # prevents a slow backtest/API call from freezing live updates.
            try:
                if now - _PERFORMANCE_LAST_RUN >= PERFORMANCE_AUTO_INTERVAL_SECONDS:
                    threading.Thread(
                        target=autonomous_performance_maintenance,
                        kwargs={"force": False},
                        name="titan-performance-maintenance",
                        daemon=True,
                    ).start()
            except Exception as perf_exc:
                LOGGER.debug("Performance maintenance dispatch failed: %s", perf_exc)
        except Exception as exc:
            LOGGER.warning("V29 autonomous loop error: %s", exc)
        LIVE_STOP.wait(AUTO_MAINTENANCE_INTERVAL_SECONDS)


def _update_cache_base(force: bool = False) -> tuple[list[dict[str, Any]], str, dict[str, Any]]:
    global CACHE
    reload_keys()
    now = time.time()
    with CACHE_LOCK:
        if CACHE["data"] and not force and now - CACHE["timestamp"] < MARKET_CACHE_TTL:
            return CACHE["data"], CACHE["gemini_summary"], CACHE["macro"]
    with UPDATE_LOCK:
        with CACHE_LOCK:
            if CACHE["data"] and not force and time.time() - CACHE["timestamp"] < MARKET_CACHE_TTL:
                return CACHE["data"], CACHE["gemini_summary"], CACHE["macro"]
        coins = list(USER_SETTINGS.get("active_coins") or DEFAULT_COINS)
        _prio = {"BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT", "XRP/USDT"}
        coins = [c for c in coins if _normalize_symbol(c) in _prio] + [c for c in coins if _normalize_symbol(c) not in _prio]
        scan_started=time.time()
        total_coins = max(1, len(coins))
        _scan_progress_update(
            status="running", phase="دریافت داده‌های زنده و کلان",
            started_at=scan_started, finished_at=0.0, completed=0, total=total_coins,
            percent=6, message="در حال دریافت قیمت، BTC و داده‌های کلان…", fresh=False,
        )
        # Bootstrap: macro + BTC + batch live prices in parallel (one REST round-trip for all coins)
        def _batch_live():
            try:
                prices = _fetch_live_prices(list(coins))
                for sym, px in prices.items():
                    _register_live_price(sym, px, "REST-batch")
                return len(prices)
            except Exception as exc:
                LOGGER.debug("batch live prices: %s", exc)
                return 0
        with ThreadPoolExecutor(max_workers=3) as meta_ex:
            btc_future = meta_ex.submit(fetch_btc_trend)
            macro_future = meta_ex.submit(fetch_macro)
            live_future = meta_ex.submit(_batch_live)
            btc_trend = btc_future.result()
            macro = macro_future.result()
            try:
                live_future.result(timeout=6)
            except Exception:
                _swallow()
        macro["btc_trend"] = btc_trend
        _scan_progress_update(
            phase="تحلیل موازی ارزها", percent=14, completed=0, total=total_coins,
            message=f"داده اولیه آماده · شروع تحلیل {total_coins} ارز…",
        )
        results: list[dict[str, Any]] = []
        scan_t0 = time.perf_counter()
        # Parallelism scales with coin count; hard-capped inside pool helper for phone RAM.
        pool = _get_analysis_pool(min(8, max(4, len(coins))))
        futures = {pool.submit(analyze_asset, symbol, btc_trend): symbol for symbol in coins}
        _partial_every = max(1, int(globals().get("SCAN_PARTIAL_PUBLISH_EVERY", 2) or 2))
        _finished_count = 0  # includes failures so the bar always advances

        def _publish_partial(partial: list[dict[str, Any]]) -> None:
            """Push partial analysis into CACHE so the dashboard paints early."""
            if not partial:
                return
            try:
                order_map = {coin: i for i, coin in enumerate(coins)}
                snapshot = list(partial)
                snapshot.sort(key=lambda x: order_map.get(x.get("symbol"), 999))
                # Rebase prices to live tickers without blocking the scan.
                try:
                    snapshot = _v29_sync_snapshot_to_live(snapshot)
                except Exception:
                    _swallow()
                with CACHE_LOCK:
                    # Merge: keep already-analyzed symbols, never wipe on partial.
                    prev = {str(x.get("symbol")): x for x in (CACHE.get("data") or []) if isinstance(x, dict)}
                    for it in snapshot:
                        if isinstance(it, dict) and it.get("symbol"):
                            prev[str(it["symbol"])] = it
                    merged = list(prev.values())
                    CACHE["data"] = merged
                    # Soft timestamp so progressive rows appear without claiming a full scan.
                    if not CACHE.get("timestamp"):
                        CACHE["timestamp"] = time.time()
                    CACHE["macro"] = macro
                # Bust short UI cache so /api/v59/ui-data reflects partial results immediately.
                try:
                    with _V59_UI_LOCK:
                        _V59_UI_CACHE["ts"] = 0.0
                        _V59_UI_CACHE["payload"] = None
                except Exception:
                    _swallow()
            except Exception as exc:
                LOGGER.debug("partial publish failed: %s", exc)

        for future in as_completed(futures):
            symbol = futures[future]
            try:
                result = future.result()
                if result:
                    results.append(result)
            except Exception as exc:
                LOGGER.exception("Asset analysis failed for %s: %s", symbol, exc)
            finally:
                _finished_count += 1
                done = len(results)
                # Honest progress: 14% bootstrap + up to 78% from finished futures
                pct = 14 + int(78 * min(1.0, _finished_count / total_coins))
                _scan_progress_update(
                    completed=done, total=total_coins, percent=min(92, pct),
                    phase="تحلیل موازی ارزها",
                    message=f"تحلیل {done}/{total_coins} ارز · {_finished_count} پردازش‌شده…",
                )
                # Progressive UI: every N completions, publish partial results.
                if done > 0 and (done == 1 or done % _partial_every == 0 or _finished_count >= total_coins):
                    _publish_partial(results)
        if not results:
            stale_data, stale_summary, stale_macro = _load_market_cache()
            with CACHE_LOCK: CACHE.update(timestamp=time.time(), data=stale_data, gemini_summary=stale_summary, macro=stale_macro)
            return stale_data, stale_summary, stale_macro
        order = {coin: i for i, coin in enumerate(coins)}
        # V28.4: directional first (LONG/SHORT), then grade, quality, original order
        def _result_rank(x: dict) -> tuple:
            dec = str(x.get("decision_tag") or "WAIT").upper()
            dir_pri = 0 if dec in {"LONG", "SHORT"} else 1
            side_pri = 0 if dec == "LONG" else 1 if dec == "SHORT" else 2
            g = str(x.get("grade") or ((x.get("signal_grade") or {}).get("grade")) or "—")
            return (
                dir_pri,
                side_pri,
                -GRADE_RANK.get(g, 0),
                -safe_float(x.get("opportunity_score"), 0),
                -safe_float(x.get("trust_index"), 0),
                -safe_float(x.get("signal_quality"), 0),
                order.get(x.get("symbol"), 999),
            )
        results.sort(key=_result_rank)
        scan_timestamp=time.time()
        finalized=[]
        for _item in results:
            if not isinstance(_item, dict):
                continue
            _item = _dashboard_finalize_item(_item) or _item
            _item["scan_timestamp"]=scan_timestamp
            _item["scan_time_utc"]=datetime.fromtimestamp(scan_timestamp,timezone.utc).isoformat(timespec="seconds")
            finalized.append(_item)
        results = finalized
        try:
            signal_board = rank_market_signals(results)
            macro["signal_board"] = signal_board
            macro["actionable_count"] = signal_board.get("counts", {}).get("actionable", 0)
            macro["grade_summary"] = {
                g: sum(1 for r in results if (r.get("grade") or (r.get("signal_grade") or {}).get("grade")) == g)
                for g in ("A+", "A", "B", "C", "D", "F")
            }
        except Exception as _sb:
            LOGGER.debug("signal board failed: %s", _sb)
            macro["signal_board"] = {"actionable": [], "watchlist": [], "counts": {}}
        if not TITAN_V51_AUTHORITATIVE:
            try:
                # Legacy V32 forecast/paper telemetry is kept for audit only.
                v32_record_scan_predictions(results)
                v32_evaluate_pending()
                store_forecasts(results)
                for item in results:
                    _g = str(item.get("grade") or (item.get("signal_grade") or {}).get("grade") or "")
                    if (item.get("decision_tag") in {"LONG", "SHORT"}
                        and item.get("alignment", 0) >= 65
                        and item.get("signal_quality", 0) >= MIN_DIRECTIONAL_QUALITY
                        and item.get("bias") in {"صعودی", "نزولی"}
                        and _g in {"A+", "A", "B"}):
                        paper_open_signal(item)
                evaluate_paper_trades(); evaluate_pending_forecasts()
            except Exception as exc: LOGGER.warning("Forecast/paper batch failed: %s", exc)
        # Do NOT block first dashboard paint on Gemini. The market result is complete and
        # usable at this point; keep the previous summary until the fresh AI summary arrives.
        with CACHE_LOCK:
            previous_summary = CACHE.get("gemini_summary") or ""
        if not previous_summary:
            _, previous_summary, _ = _load_market_cache()
        payload = {"timestamp": time.time(), "data": results, "gemini_summary": previous_summary, "macro": macro}
        finished=time.time()
        _scan_progress_update(status="complete",phase="اسکن کامل شد",completed=len(results),total=len(coins),percent=100,finished_at=finished,last_success_at=finished,elapsed_sec=round(finished-scan_started,1),message=f"اسکن جدید کامل شد · {len(results)}/{len(coins)} ارز · داده تازه",fresh=True)
        LOGGER.info("update_cache analyze done in %.1fs coins=%s", time.perf_counter()-scan_t0, len(results))
        results = _v29_sync_snapshot_to_live(results)
        payload["data"] = results
        _save_json(MARKET_CACHE_PATH, payload)
        with CACHE_LOCK:
            CACHE.update(timestamp=time.time(), data=results, gemini_summary=previous_summary, macro=macro)
        # Gemini is deliberately asynchronous: it enriches the live snapshot and
        # is consumed by the next scan, while the current dashboard stays fast.
        threading.Thread(
            target=_v29_async_gemini_enrichment,
            args=(list(results), dict(macro)),
            name="titan-gemini-enrichment",
            daemon=True,
        ).start()
        # Gemini global summary is also non-blocking.
        def _ai_summary_refresh(snapshot, macro_snapshot):
            global _AI_SUMMARY_LAST_RUN
            if not GEMINI_API_KEY or not _AI_SUMMARY_LOCK.acquire(blocking=False):
                return
            try:
                now = time.time()
                if now - _AI_SUMMARY_LAST_RUN < AUTO_AI_REFRESH_SECONDS:
                    return
                _AI_SUMMARY_LAST_RUN = now
                fresh = _global_ai_summary(snapshot, macro_snapshot)
                if fresh:
                    with CACHE_LOCK:
                        CACHE["gemini_summary"] = fresh
                    current = _load_market_cache()
                    _save_json(MARKET_CACHE_PATH, {
                        "timestamp": time.time(),
                        "data": current[0] or snapshot,
                        "gemini_summary": fresh,
                        "macro": macro_snapshot,
                    })
            except Exception as exc:
                LOGGER.warning("Async Gemini dashboard summary failed: %s", exc)
            finally:
                try:
                    _AI_SUMMARY_LOCK.release()
                except RuntimeError:
                    pass
        threading.Thread(target=_ai_summary_refresh, args=(results, macro), name="titan-gemini-summary", daemon=True).start()
        return results, previous_summary, macro
