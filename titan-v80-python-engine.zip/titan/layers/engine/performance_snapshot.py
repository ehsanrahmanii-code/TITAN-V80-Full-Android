# [TITAN V77 layer] engine/performance_snapshot - Autonomous performance snapshot
# Original V76 source lines 7975-8089 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# AUTONOMOUS PERFORMANCE SNAPSHOT ENGINE
# ============================================================

PERFORMANCE_AUTO_INTERVAL_SECONDS = 300
PERFORMANCE_SYMBOLS_PER_RUN = 3
_PERFORMANCE_LOCK = threading.Lock()
_PERFORMANCE_LAST_RUN = 0.0
_PERFORMANCE_CURSOR = 0
_PERFORMANCE_LAST_RESULT: dict[str, Any] = {"ok": True, "status": "never_run", "completed": 0, "failed": 0}


def _store_performance_snapshot(symbol: str, tf: str, result: dict[str, Any]) -> None:
    if not isinstance(result, dict) or not result.get("ok"):
        return
    m = result.get("metrics") or {}
    oos = (((result.get("professional") or {}).get("oos") or {}).get("status")
           or ((result.get("professional") or {}).get("out_of_sample") or {}).get("status") or "")
    payload = json.dumps(result, ensure_ascii=False, default=str)
    with DB_LOCK, db_conn() as con:
        con.execute(
            """INSERT INTO performance_snapshots(
                symbol,timeframe,created_at,trades,wins,losses,win_rate,expectancy,
                profit_factor,max_drawdown,sharpe,sortino,oos_status,metrics_json
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (
                _normalize_symbol(symbol), str(tf), time.time(),
                int(safe_float(m.get("trades"), 0)),
                int(safe_float(m.get("wins"), 0)),
                int(safe_float(m.get("losses"), 0)),
                safe_float(m.get("win_rate"), 0),
                safe_float(m.get("expectancy"), 0),
                safe_float(m.get("profit_factor"), 0) if m.get("profit_factor") is not None else None,
                safe_float(m.get("max_drawdown"), 0),
                safe_float(m.get("sharpe"), 0),
                safe_float(m.get("sortino"), 0),
                str(oos),
                payload[-120000:],
            ),
        )


def autonomous_performance_maintenance(force: bool = False) -> dict[str, Any]:
    """Continuously build auditable backtest history without browser interaction.

    This is deliberately throttled for Android: a small rotating subset of coins
    is evaluated each cycle, while all timeframes are covered for those coins.
    """
    global _PERFORMANCE_LAST_RUN, _PERFORMANCE_CURSOR, _PERFORMANCE_LAST_RESULT
    now = time.time()
    if not force and now - _PERFORMANCE_LAST_RUN < PERFORMANCE_AUTO_INTERVAL_SECONDS:
        return {"ok": True, "skipped": True, "reason": "interval"}
    if not _PERFORMANCE_LOCK.acquire(blocking=False):
        return {"ok": True, "skipped": True, "reason": "already_running"}
    try:
        _PERFORMANCE_LAST_RUN = now
        coins = list(USER_SETTINGS.get("active_coins") or DEFAULT_COINS)
        if not coins:
            return {"ok": False, "error": "no active coins"}
        start = _PERFORMANCE_CURSOR % len(coins)
        selected = [coins[(start + i) % len(coins)] for i in range(min(PERFORMANCE_SYMBOLS_PER_RUN, len(coins)))]
        _PERFORMANCE_CURSOR = (start + len(selected)) % len(coins)
        summary = {"ok": True, "symbols": selected, "timeframes": list(TF_CFG), "completed": 0, "failed": 0, "started_at": now}
        for sym in selected:
            for tf in TF_CFG:
                try:
                    result = backtest_signal_logic(_normalize_symbol(sym), tf, 800)
                    if result.get("ok"):
                        _store_performance_snapshot(sym, tf, result)
                        summary["completed"] += 1
                    else:
                        summary["failed"] += 1
                except Exception as exc:
                    summary["failed"] += 1
                    LOGGER.debug("Autonomous performance %s %s failed: %s", sym, tf, exc)
        # Retain bounded history; raw metrics are also available in the latest rows.
        with DB_LOCK, db_conn() as con:
            con.execute(
                "DELETE FROM performance_snapshots WHERE id NOT IN "
                "(SELECT id FROM performance_snapshots ORDER BY created_at DESC LIMIT 5000)"
            )
        summary["finished_at"] = time.time()
        summary["elapsed_sec"] = round(summary["finished_at"] - now, 2)
        summary["status"] = "complete" if summary["failed"] == 0 else "partial"
        _PERFORMANCE_LAST_RESULT = dict(summary)
        return summary
    finally:
        _PERFORMANCE_LOCK.release()


def get_performance_history(symbol: str = "", tf: str = "", limit: int = 120) -> dict[str, Any]:
    symbol = _normalize_symbol(symbol) if symbol else ""
    limit = max(1, min(int(limit), 500))
    where, args = [], []
    if symbol:
        where.append("symbol=?"); args.append(symbol)
    if tf in TF_CFG:
        where.append("timeframe=?"); args.append(tf)
    clause = (" WHERE " + " AND ".join(where)) if where else ""
    with DB_LOCK, db_conn() as con:
        rows = con.execute(
            f"SELECT symbol,timeframe,created_at,trades,wins,losses,win_rate,expectancy,"
            f"profit_factor,max_drawdown,sharpe,sortino,oos_status "
            f"FROM performance_snapshots{clause} ORDER BY created_at DESC LIMIT ?",
            (*args, limit),
        ).fetchall()
    return {
        "ok": True,
        "items": [dict(r) for r in rows],
        "count": len(rows),
        "source": "AUTONOMOUS_BACKTEST_HISTORY",
        "autonomous_status": dict(_PERFORMANCE_LAST_RESULT),
    }
