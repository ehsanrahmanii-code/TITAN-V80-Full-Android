# [TITAN V77 layer] analytics/v64_forecast_patterns - V64 24-candle forecast + pattern engine
# Original V76 source lines 27423-27839 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# V64: 24-candle forecast for every timeframe + candlestick pattern engine.
# Analysis only. No disk writes (all persistence stays in the LLL folder).
# ============================================================
def _v64_candle_patterns(df, lookahead: int = 5, scan: int = 200, _raw: Optional[list] = None) -> dict[str, Any]:
    out: dict[str, Any] = {"recent": [], "stats": [], "history": []}
    try:
        d = df.tail(scan + 3).reset_index(drop=True)
        o = d["open"].astype(float).to_numpy(); h = d["high"].astype(float).to_numpy()
        l = d["low"].astype(float).to_numpy(); c = d["close"].astype(float).to_numpy()
        ts = d["t"].to_numpy() if "t" in d.columns else None
        n = len(d)
        if n < 12:
            return out
        body = np.abs(c - o); rng = np.maximum(h - l, 1e-12)
        upw = h - np.maximum(o, c); low_w = np.minimum(o, c) - l
        avgb = pd.Series(body).rolling(10, min_periods=3).mean().bfill().to_numpy()
        BU, BE, NE = "صعودی", "نزولی", "خنثی"
        found = []
        for i in range(3, n):
            b, r = body[i], rng[i]
            prior = c[i - 1] - c[max(0, i - 6)]
            dn, upt = prior < 0, prior > 0
            bull, bear = c[i] > o[i], c[i] < o[i]
            pb, pbull, pbear = body[i - 1], c[i - 1] > o[i - 1], c[i - 1] < o[i - 1]
            if b <= r * .1: found.append((i, "دوجی", NE))
            elif b > 0 and low_w[i] >= 2 * b and upw[i] <= b * .6: found.append((i, "چکش" if dn else "مرد آویزان", BU if dn else BE))
            elif b > 0 and upw[i] >= 2 * b and low_w[i] <= b * .6: found.append((i, "چکش وارونه" if dn else "ستاره دنباله‌دار", BU if dn else BE))
            elif b >= r * .9 and b > avgb[i]: found.append((i, "ماروبوزو صعودی" if bull else "ماروبوزو نزولی", BU if bull else BE))
            elif r * .1 < b <= r * .3 and upw[i] > b and low_w[i] > b: found.append((i, "فرفره", NE))
            if bull and pbear and o[i] <= c[i - 1] and c[i] >= o[i - 1] and b > pb: found.append((i, "پوشا صعودی", BU))
            if bear and pbull and o[i] >= c[i - 1] and c[i] <= o[i - 1] and b > pb: found.append((i, "پوشا نزولی", BE))
            inside = max(o[i], c[i]) < max(o[i - 1], c[i - 1]) and min(o[i], c[i]) > min(o[i - 1], c[i - 1]) and b < pb * .6
            if inside and pbear and dn: found.append((i, "هارامی صعودی", BU))
            if inside and pbull and upt: found.append((i, "هارامی نزولی", BE))
            if bull and pbear and dn and o[i] < l[i - 1] and c[i] > (o[i - 1] + c[i - 1]) / 2 and c[i] < o[i - 1]: found.append((i, "نفوذی", BU))
            if bear and pbull and upt and o[i] > h[i - 1] and c[i] < (o[i - 1] + c[i - 1]) / 2 and c[i] > o[i - 1]: found.append((i, "ابر سیاه", BE))
            if upt and abs(h[i] - h[i - 1]) <= r * .05 and bear and pbull: found.append((i, "سرِ موچین", BE))
            if dn and abs(l[i] - l[i - 1]) <= r * .05 and bull and pbear: found.append((i, "ته موچین", BU))
            a = i - 2
            if c[a] < o[a] and body[a] > avgb[a] and pb < body[a] * .4 and bull and c[i] > (o[a] + c[a]) / 2: found.append((i, "ستاره صبحگاهی", BU))
            if c[a] > o[a] and body[a] > avgb[a] and pb < body[a] * .4 and bear and c[i] < (o[a] + c[a]) / 2: found.append((i, "ستاره عصرگاهی", BE))
            if c[a] > o[a] and pbull and bull and c[a] < c[i - 1] < c[i] and o[i - 1] > o[a] and o[i] > o[i - 1]: found.append((i, "سه سرباز سفید", BU))
            if c[a] < o[a] and pbear and bear and c[a] > c[i - 1] > c[i] and o[i - 1] < o[a] and o[i] < o[i - 1]: found.append((i, "سه کلاغ سیاه", BE))
        if _raw is not None:
            _raw.extend([found, c, n])
            return out
        agg: dict[str, dict[str, Any]] = {}
        hist = []
        for i, name, bias in found:
            mv = None
            if i + lookahead < n:
                mv = (c[i + lookahead] / c[i] - 1) * 100
                if bias == BE: mv = -mv
            s = agg.setdefault(name, {"name": name, "bias": bias, "count": 0, "n": 0, "hits": 0, "sum": 0.0})
            s["count"] += 1
            if mv is not None and bias != NE:
                s["n"] += 1; s["hits"] += 1 if mv > 0 else 0; s["sum"] += mv
            hist.append({"name": name, "bias": bias, "ago": int(n - 1 - i), "t": int(ts[i]) if ts is not None else None,
                         "move": None if mv is None else round(float(mv), 2)})
        out["recent"] = [{"name": nm, "bias": bs, "ago": int(n - 1 - i)} for i, nm, bs in found if i >= n - 6][-8:]
        out["stats"] = [{"name": s["name"], "bias": s["bias"], "count": s["count"],
                         "hit": int(round(100 * s["hits"] / s["n"])) if s["n"] else 0,
                         "avg": round(s["sum"] / s["n"], 2) if s["n"] else 0.0}
                        for s in sorted(agg.values(), key=lambda z: -z["count"])[:10]]
        out["history"] = hist[-25:]
        out["lookahead"] = lookahead
    except Exception as exc:
        LOGGER.debug("v64 candle patterns failed: %s", exc)
    return out


_V64_MEM: dict[str, Any] = {}
_V64_DIR = CACHE_DIR / "v64"


def _v64_save(name: str, obj: Any) -> None:
    """Persist small JSON caches ONLY inside the LLL cache folder."""
    try:
        _V64_DIR.mkdir(parents=True, exist_ok=True)
        tmp = _V64_DIR / (name + ".tmp")
        tmp.write_text(json.dumps(obj, ensure_ascii=False, default=str), encoding="utf-8")
        os.replace(tmp, _V64_DIR / (name + ".json"))
    except Exception:
        _swallow()


def _v64_pivots(a, w: int = 3, hi: bool = True) -> list:
    out = []
    for i in range(w, len(a) - w):
        seg = a[i - w:i + w + 1]
        if (hi and a[i] == seg.max()) or ((not hi) and a[i] == seg.min()):
            out.append(i)
    return out


def _v64_chart_patterns(df) -> list:
    """Wedges, triangles, channels, flags, cup-and-handle from pivots/regression."""
    out: list = []
    try:
        d = df.tail(140).reset_index(drop=True)
        h = d["high"].astype(float).to_numpy(); l = d["low"].astype(float).to_numpy(); c = d["close"].astype(float).to_numpy()
        n = len(d)
        if n < 60:
            return out
        last = float(c[-1])
        ph = [i for i in _v64_pivots(h, 3, True) if i >= n - 100][-5:]
        pl = [i for i in _v64_pivots(l, 3, False) if i >= n - 100][-5:]

        def fit(idx, arr):
            x = np.array(idx, float); y = arr[idx]
            m, b0 = np.polyfit(x, y, 1)
            ss = float(((y - y.mean()) ** 2).sum()) + 1e-12
            return float(m), float(b0), 1 - float(((y - (m * x + b0)) ** 2).sum()) / ss
        if len(ph) >= 3 and len(pl) >= 3:
            mh, bh, rh = fit(ph, h); ml, bl, rl = fit(pl, l)
            sh, sl, flat = mh / last * 100, ml / last * 100, 0.03
            x0 = min(ph[0], pl[0]); w0 = (mh * x0 + bh) - (ml * x0 + bl); w1 = (mh * (n - 1) + bh) - (ml * (n - 1) + bl)
            conv = 0 < w1 < w0 * 0.8
            conf = int(clamp(50 + 30 * max(0.0, min(rh, rl)) + (10 if conv else 0), 40, 92))
            lv = {"upper": [x0, round(mh * x0 + bh, 8), n - 1, round(mh * (n - 1) + bh, 8)],
                  "lower": [x0, round(ml * x0 + bl, 8), n - 1, round(ml * (n - 1) + bl, 8)]}

            def add(pid, bias, desc):
                out.append({"id": pid, "bias": bias, "confidence": conf, "desc": desc, "levels": lv})
            if conv and sh > flat and sl > flat and sl > sh: add("گوه صعودی", "نزولی", "هر دو خط بالا می‌روند و به هم نزدیک می‌شوند؛ معمولاً شکست رو به پایین")
            elif conv and sh < -flat and sl < -flat and sh < sl: add("گوه نزولی", "صعودی", "هر دو خط پایین می‌آیند و جمع می‌شوند؛ معمولاً شکست رو به بالا")
            elif conv and sh < -flat and sl > flat: add("مثلث متقارن", "خنثی", "فشردگی نوسان؛ جهت شکست را حجم تأیید می‌کند")
            elif abs(sh) <= flat and sl > flat: add("مثلث صعودی", "صعودی", "سقف تقریباً افقی با کف‌های بالاتر")
            elif abs(sl) <= flat and sh < -flat: add("مثلث نزولی", "نزولی", "کف تقریباً افقی با سقف‌های پایین‌تر")
            elif (not conv) and abs(sh - sl) < flat * 1.5 and sh > flat: add("کانال صعودی", "صعودی", "روند صعودی با خطوط موازی")
            elif (not conv) and abs(sh - sl) < flat * 1.5 and sh < -flat: add("کانال نزولی", "نزولی", "روند نزولی با خطوط موازی")
            elif abs(sh) <= flat and abs(sl) <= flat: add("رنج افقی", "خنثی", "نوسان بین حمایت و مقاومت افقی")
        best = None
        for f in range(6, 19):
            for p in range(8, 26):
                s0 = n - f - p
                if s0 < 0:
                    continue
                pole = c[n - f - 1] / c[s0] - 1
                seg = c[-f:]
                slope = float(np.polyfit(np.arange(f), seg, 1)[0]) / last * 100
                if pole >= 0.08 and slope <= 0.05 and (c[n - f - 1] - float(l[-f:].min())) < 0.5 * (c[n - f - 1] - c[s0]):
                    if best is None or abs(pole) > abs(best[1]): best = ("پرچم صعودی", pole, "صعودی")
                if pole <= -0.08 and slope >= -0.05 and (float(h[-f:].max()) - c[n - f - 1]) < 0.5 * (c[s0] - c[n - f - 1]):
                    if best is None or abs(pole) > abs(best[1]): best = ("پرچم نزولی", pole, "نزولی")
        if best:
            out.append({"id": best[0], "bias": best[2], "confidence": int(clamp(55 + abs(best[1]) * 200, 55, 88)),
                        "desc": "حرکت تند (دکل) و سپس اصلاح کم‌عمق؛ ادامه روند اصلی محتمل است", "levels": {}})
        cl = c[-90:]; L = len(cl)
        for hl in range(5, 16):
            cup = cl[:L - hl]
            if len(cup) < 40:
                continue
            x = np.arange(len(cup)); qa, qb, _ = np.polyfit(x, cup, 2)
            if qa <= 0:
                continue
            vx = -qb / (2 * qa) / len(cup); q = len(cup) // 4
            lrim, rrim, bot = float(cup[:q].max()), float(cup[-q:].max()), float(cup.min())
            depth = (min(lrim, rrim) - bot) / min(lrim, rrim)
            pull = (rrim - float(cl[-hl:].min())) / rrim
            if 0.3 <= vx <= 0.7 and 0.12 <= depth <= 0.5 and abs(lrim - rrim) / lrim < 0.06 and 0.02 <= pull <= 0.15 and cl[-1] > bot + 0.6 * (min(lrim, rrim) - bot):
                out.append({"id": "فنجان و دسته", "bias": "صعودی", "confidence": int(clamp(60 + depth * 40, 60, 88)),
                            "desc": "کف گرد، بازگشت به لبه راست و اصلاح کوتاه (دسته)", "levels": {"rim": round(rrim, 8)}})
                break
        out.sort(key=lambda z: -z["confidence"])
    except Exception as exc:
        LOGGER.debug("v64 chart patterns failed: %s", exc)
    return out


def _v64_build(symbol: str, tf: str) -> dict[str, Any]:
    df = fetch_klines(symbol, tf, 300 if tf in ("15m", "1h") else 200)
    pats = detect_chart_patterns(df, wilder_rsi(df["close"]))
    fc = forecast_future_candles(df, horizon=48, patterns=pats)
    flow: dict[str, Any] = {}
    try:
        flow = {"liq": fetch_coinglass_liquidations(symbol), "taker": fetch_coinglass_taker(symbol)}
    except Exception:
        _swallow()
        flow = {}
    regime = _v70_regime(df)
    cone = _v69_cone(df, [float(x["close"]) for x in (fc.get("candles") or [])], horizon=48)
    res = {"ok": bool(fc.get("ok")), "symbol": symbol, "timeframe": tf, "candles": fc.get("candles", []),
           "bias": fc.get("overall_bias") or fc.get("bias"), "expected_move_pct": fc.get("expected_move_pct"), "narrative": fc.get("narrative"),
           "chart_patterns": pats, "adv": _v70_adjust(_v64_chart_patterns(df), regime, _v71_status_map(tf, "chart")), "cp": _v71_annotate(_v64_candle_patterns(df), tf), "flow": flow,
           "cone": cone, "regime": regime, "ts": time.time(), "note": "تخمین آماری است، تضمین قیمت نیست"}
    _V64_MEM[symbol + "|" + tf] = res
    _v69_record(symbol, tf, cone, float(df["close"].iloc[-1]))
    _v68_kick()
    _v71_kick(tf)
    _v64_save("fc_" + symbol.replace("/", "_") + "_" + tf, res)
    return res


@app.get("/api/forecast24")
def api_forecast24():
    symbol = _normalize_symbol(request.args.get("symbol", "BTC/USDT"))
    tf = str(request.args.get("timeframe", "1h") or "1h")
    if tf not in {"15m", "1h", "4h", "1d"}:
        tf = "1h"
    try:
        res = _v64_build(symbol, tf)
        # normalize candle keys for dashboard chart (o/h/l/c + open/high/low/close)
        out_c = []
        for q in (res.get("candles") or []):
            if not isinstance(q, dict):
                continue
            o = q.get("o", q.get("open"))
            h = q.get("h", q.get("high"))
            l = q.get("l", q.get("low"))
            c = q.get("c", q.get("close"))
            if c is None:
                continue
            out_c.append({
                "o": float(o if o is not None else c),
                "h": float(h if h is not None else c),
                "l": float(l if l is not None else c),
                "c": float(c),
                "open": float(o if o is not None else c),
                "high": float(h if h is not None else c),
                "low": float(l if l is not None else c),
                "close": float(c),
                "direction": q.get("direction"),
                "confidence": q.get("confidence"),
                "step": q.get("step"),
            })
        res["candles"] = out_c
        if not res.get("bias"):
            res["bias"] = res.get("overall_bias") or ""
        res["ok"] = bool(res.get("ok")) and bool(out_c)
        return jsonify(res)
    except Exception as exc:
        LOGGER.warning("forecast24 failed %s: %s", symbol, exc)
        return jsonify({"ok": False, "error": str(exc)[:300], "symbol": symbol, "candles": []}), 200


@app.get("/api/v64/gemini")
def api_v64_gemini():
    """Gemini verdict that sees candle patterns, chart patterns, the 24-candle path and CoinGlass flow."""
    symbol = _normalize_symbol(request.args.get("symbol", "BTC/USDT"))
    tf = str(request.args.get("timeframe", "1h") or "1h")
    if tf not in {"15m", "1h", "4h", "1d"}:
        tf = "1h"
    try:
        reload_keys()
        if not GEMINI_API_KEY:
            return jsonify({"ok": False, "error": "کلید Gemini موجود نیست", "analysis": ""})
        b = _V64_MEM.get(symbol + "|" + tf)
        if not b or time.time() - float(b.get("ts", 0)) > 300:
            b = _v64_build(symbol, tf)
        cp = b.get("cp") or {}
        payload = {"symbol": symbol, "timeframe": tf,
                   "task": "با الگوهای شمعی، الگوهای نموداری، مسیر پیش‌بینی ۴۸ شمع و جریان CoinGlass تصمیم نهایی بده: سناریوی صعودی و نزولی، سطح ابطال و درجه اطمینان، کوتاه و فارسی",
                   "forecast": {"bias": b.get("bias"), "expected_move_pct": b.get("expected_move_pct"), "narrative": b.get("narrative")},
                   "candle_patterns": {"recent": cp.get("recent"), "stats": (cp.get("stats") or [])[:5]},
                   "chart_patterns": [{"id": p.get("id"), "bias": p.get("bias"), "confidence": p.get("confidence")} for p in (b.get("adv") or []) + ((b.get("chart_patterns") or {}).get("patterns") or [])],
                   "coinglass": b.get("flow")}
        txt = _call_gemini(payload)
        if txt:
            _v64_save("gem_" + symbol.replace("/", "_") + "_" + tf, {"t": time.time(), "text": txt})
        return jsonify({"ok": bool(txt), "analysis": txt or "", "error": "" if txt else str(GEMINI_LAST_ERROR)[:200]})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)[:200], "analysis": ""})


def _v64_grp(rows, keyfn) -> list:
    acc: dict = {}
    for r in rows:
        k = str(keyfn(r) or "—"); a = acc.setdefault(k, [0, 0, 0])
        a[0] += 1
        if r["outcome"] == "WIN": a[1] += 1
        elif r["outcome"] == "LOSS": a[2] += 1
    out = []
    for k, (t, w, lo) in acc.items():
        dn = w + lo
        out.append({"k": k, "n": t, "wins": w, "losses": lo, "wr": round(w / dn * 100, 1) if dn else None})
    return sorted(out, key=lambda z: -z["n"])


@app.get("/api/v64/evaluation")
def api_v64_evaluation():
    """Full evaluation: forecasts, paper trades, audit, calibration and history."""
    try:
        days = int(request.args.get("days", 30) or 30)
    except Exception:
        _swallow()
        days = 30
    since = 0.0 if days <= 0 else time.time() - days * 86400.0
    out: dict[str, Any] = {"ok": True, "days": days}
    try:
        with DB_LOCK, db_conn() as con:
            try:
                fr = con.execute("SELECT symbol,timeframe,created_at,direction,price,outcome,hit_type,source,success_prob,predicted_move_pct FROM forecasts WHERE created_at>=? ORDER BY created_at ASC", (since,)).fetchall()
                res = [r for r in fr if r["outcome"] in ("WIN", "LOSS")]
                w = sum(1 for r in res if r["outcome"] == "WIN")
                cal = []
                for lo, hi in ((0, 40), (40, 50), (50, 60), (60, 70), (70, 80), (80, 101)):
                    bk = [r for r in res if lo <= (float(r["success_prob"] or 0) * (100 if float(r["success_prob"] or 0) <= 1 else 1)) < hi]
                    if bk:
                        cal.append({"b": "%d-%d" % (lo, min(hi, 100)), "n": len(bk), "actual": round(sum(1 for r in bk if r["outcome"] == "WIN") / len(bk) * 100, 1),
                                    "pred": round(sum(float(r["success_prob"] or 0) * (100 if float(r["success_prob"] or 0) <= 1 else 1) for r in bk) / len(bk), 1)})
                out["forecasts"] = {"total": len(fr), "resolved": len(res), "wins": w, "losses": len(res) - w,
                                    "pending": sum(1 for r in fr if r["outcome"] == "PENDING"),
                                    "win_rate": round(w / len(res) * 100, 1) if res else None,
                                    "by_tf": _v64_grp(fr, lambda r: r["timeframe"]), "by_dir": _v64_grp(fr, lambda r: r["direction"]),
                                    "by_source": _v64_grp(fr, lambda r: r["source"]), "by_hit": _v64_grp(res, lambda r: r["hit_type"]),
                                    "by_symbol": _v64_grp(fr, lambda r: r["symbol"])[:8], "calib": cal,
                                    "history": [{"s": r["symbol"], "tf": r["timeframe"], "t": float(r["created_at"]), "d": r["direction"], "o": r["outcome"], "hit": r["hit_type"], "p": r["price"]} for r in reversed(fr[-60:])]}
            except Exception as exc:
                out["forecasts"] = {"err": str(exc)[:120]}
            try:
                pr = con.execute("SELECT symbol,timeframe,created_at,decision,entry,exit_price,pnl_pct,r_multiple,reason FROM paper_trades WHERE status='CLOSED' AND r_multiple IS NOT NULL AND created_at>=? ORDER BY created_at ASC", (since,)).fetchall()
                rs = [float(r["r_multiple"]) for r in pr]
                gp = sum(x for x in rs if x > 0); gl = -sum(x for x in rs if x < 0)
                eq, run, pk, dd = [], 0.0, 0.0, 0.0
                for x in rs:
                    run += x; pk = max(pk, run); dd = max(dd, pk - run); eq.append(round(run, 2))
                st = max(1, len(eq) // 60)
                out["paper"] = {"closed": len(rs), "wins": sum(1 for x in rs if x > 0), "win_rate": round(sum(1 for x in rs if x > 0) / len(rs) * 100, 1) if rs else None,
                                "avg_r": round(sum(rs) / len(rs), 2) if rs else None, "profit_factor": round(gp / gl, 2) if gl > 0 else None,
                                "max_dd_r": round(dd, 2), "best": round(max(rs), 2) if rs else None, "worst": round(min(rs), 2) if rs else None,
                                "equity": eq[::st], "recent": [{"s": r["symbol"], "tf": r["timeframe"], "t": float(r["created_at"]), "d": r["decision"], "r": round(float(r["r_multiple"]), 2), "why": r["reason"]} for r in reversed(pr[-25:])]}
            except Exception as exc:
                out["paper"] = {"err": str(exc)[:120]}
            try:
                au = con.execute("SELECT outcome,return_pct,max_favorable_pct,max_adverse_pct FROM v32_forecast_audit WHERE created_at>=?", (since,)).fetchall()
                def _avg(k):
                    v = [float(r[k]) for r in au if r[k] is not None]
                    return round(sum(v) / len(v), 2) if v else None
                out["audit"] = {"n": len(au), "by_outcome": _v64_grp(au, lambda r: r["outcome"]), "avg_return": _avg("return_pct"), "avg_mfe": _avg("max_favorable_pct"), "avg_mae": _avg("max_adverse_pct")}
            except Exception as exc:
                out["audit"] = {"err": str(exc)[:120]}
        return jsonify(out)
    except Exception as exc:
        LOGGER.warning("v64 evaluation failed: %s", exc)
        return jsonify({"ok": False, "error": str(exc)[:200]}), 500


import re as _v65_re


def _v64_vote(txt: Optional[str]) -> tuple:
    t = txt or ""
    m = _v65_re.search(r"VERDICT\s*:\s*(LONG|SHORT|WAIT)", t, _v65_re.I)
    c = _v65_re.search(r"CONF\s*:\s*(\d{1,3})", t, _v65_re.I)
    if m:
        return m.group(1).upper(), min(100, int(c.group(1))) if c else 60
    up = len(_v65_re.findall("صعود|LONG|خرید", t)); dn = len(_v65_re.findall("نزول|SHORT|فروش", t))
    return ("LONG", 55) if up > dn else ("SHORT", 55) if dn > up else ("WAIT", 50)


@app.get("/api/v64/final")
def api_v64_final():
    """Transparent final verdict: engine + candle/chart patterns + 24-candle path + CoinGlass + Gemini.

    Display/analysis layer only: it never rewrites the engine's published signals or its learning ledger.
    Gemini weight is capped at 25% and is dropped (weights renormalised) when unavailable.
    """
    symbol = _normalize_symbol(request.args.get("symbol", "BTC/USDT"))
    tf = str(request.args.get("timeframe", "1h") or "1h")
    if tf not in {"15m", "1h", "4h", "1d"}:
        tf = "1h"
    use_ai = str(request.args.get("ai", "1")) != "0"
    try:
        key = symbol + "|" + tf
        b = _V64_MEM.get(key)
        if not b or time.time() - float(b.get("ts", 0)) > 120:
            b = _v64_build(symbol, tf)
        item = None
        with CACHE_LOCK:
            for r in list(CACHE.get("data") or []):
                if isinstance(r, dict) and str(r.get("symbol") or "") == symbol:
                    item = r
                    break
        parts: list = []
        rg68 = (b.get("regime") or {}).get("key")
        W68, mode68 = _v68_weights(rg68)

        def add(name, val, w, note):
            parts.append({"name": name, "val": round(float(clamp(val, -1, 1)), 3), "w": W68.get(name, w), "note": note})
        if item is not None:
            sc = safe_float(item.get("score"))
            if sc:
                add("موتور TITAN", (sc - 50) / 50, 0.40, "امتیاز %d" % round(sc))
        sg = lambda s: 1 if s == "صعودی" else -1 if s == "نزولی" else 0
        rec = (b.get("cp") or {}).get("recent") or []
        if rec:
            add("الگوی شمعی", sum(sg(r.get("bias")) for r in rec) / 3.0, 0.10, "%d الگو" % len(rec))
        adv = b.get("adv") or []
        if adv:
            add("الگوی نموداری", sum(sg(p.get("bias")) * p.get("confidence", 50) / 100.0 for p in adv), 0.10, adv[0].get("id", ""))
        cand = b.get("candles") or []
        if cand:
            em = (float(cand[-1]["close"]) / float(cand[0]["open"]) - 1) * 100
            add("پیش‌بینی ۴۸ شمع", em / 3.0, 0.15, "%+.2f%%" % em)
        tk = (b.get("flow") or {}).get("taker") or {}
        if tk.get("available") and tk.get("buy_pct") is not None:
            add("جریان CoinGlass", (float(tk["buy_pct"]) - 50) / 10.0, 0.15, "خرید %s٪" % tk["buy_pct"])
        gem_txt = ""
        if use_ai:
            reload_keys()
            if GEMINI_API_KEY:
                gk = "g|" + key
                cached = _V64_MEM.get(gk)
                if cached and time.time() - cached["t"] < 180:
                    gem_txt = cached["txt"]
                else:
                    cp = b.get("cp") or {}
                    payload = {"symbol": symbol, "timeframe": tf,
                               "task": "با موتور TITAN، الگوهای شمعی و نموداری، مسیر ۴۸ شمع آینده و جریان CoinGlass تصمیم نهایی بده؛ کوتاه و فارسی. خط آخر دقیقاً: VERDICT: LONG یا SHORT یا WAIT و CONF: عدد صفر تا صد",
                               "engine": {"decision": (item or {}).get("decision"), "score": (item or {}).get("score"), "conf": (item or {}).get("conf")},
                               "forecast": {"bias": b.get("bias"), "narrative": b.get("narrative")},
                               "candle_patterns": {"recent": cp.get("recent"), "stats": (cp.get("stats") or [])[:5]},
                               "chart_patterns": [{"id": p.get("id"), "bias": p.get("bias"), "confidence": p.get("confidence")} for p in adv],
                               "coinglass": b.get("flow")}
                    gem_txt = _call_gemini(payload) or ""
                    if gem_txt:
                        _V64_MEM[gk] = {"t": time.time(), "txt": gem_txt}
                        _v64_save("gem_" + symbol.replace("/", "_") + "_" + tf, {"t": time.time(), "text": gem_txt})
                if gem_txt:
                    v, cf = _v64_vote(gem_txt)
                    add("Gemini", (1 if v == "LONG" else -1 if v == "SHORT" else 0) * cf / 100.0, 0.25, "%s %d٪" % (v, cf))
        if not parts:
            return jsonify({"ok": False, "error": "داده کافی برای تصمیم نیست"})
        tw = sum(p["w"] for p in parts)
        for p in parts:
            p["w"] = round(p["w"] / tw, 3)
        final = sum(p["val"] * p["w"] for p in parts)
        agree = sum(1 for p in parts if p["val"] * final > 0) / len(parts)
        out = {"ok": True, "symbol": symbol, "timeframe": tf, "score": round(50 + 50 * final, 1),
               "decision": "LONG" if final > 0.18 else "SHORT" if final < -0.18 else "WAIT",
               "conf": int(clamp(abs(final) * 60 + agree * 40, 0, 99)), "parts": parts, "gemini": gem_txt,
               "note": "تحلیل کمکی است، تضمین قیمت نیست"}
        out["weights_mode"] = mode68
        out["regime"] = rg68
        out["regime_fa"] = (b.get("regime") or {}).get("fa")
        px68 = safe_float((item or {}).get("price")) or (float(cand[0]["open"]) if cand else 0.0)
        if px68 and px68 > 0:
            out["ledger_id"] = _v68_record(symbol, tf, out, float(px68))
        _v68_kick()
        _v64_save("final_" + symbol.replace("/", "_") + "_" + tf, out)
        return jsonify(out)
    except Exception as exc:
        LOGGER.warning("v64 final failed %s: %s", symbol, exc)
        return jsonify({"ok": False, "error": str(exc)[:200]}), 500
