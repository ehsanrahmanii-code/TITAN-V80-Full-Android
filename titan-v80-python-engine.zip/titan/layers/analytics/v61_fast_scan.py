# [TITAN V77 layer] analytics/v61_fast_scan - V61 fast scan / live flow
# Original V76 source lines 25568-26207 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# TITAN V61 — FAST SCAN / LIVE FLOW / MOBILE FIT
# Parallel Binance+CoinGlass market flow, REST depth for every coin,
# labelled LIVE vs proxy, tighter mobile layout. Analysis only.
# ============================================================
V61_VERSION = "TITAN-V61-FAST-LIVE-FLOW"

def _v61_attach_flow(x: dict) -> dict:
    """Backfill buy_sell + whale from live scalars so feature_only / partial cards show real flow."""
    if not isinstance(x, dict):
        return x
    try:
        tb = x.get("taker_buy_pct")
        if tb is None and isinstance(x.get("buy_sell"), dict):
            tb = x["buy_sell"].get("taker_buy_pct") or x["buy_sell"].get("buy_pct")
        ts = x.get("taker_sell_pct")
        if tb is not None:
            try:
                bp = float(clamp(safe_float(tb), 5.0, 95.0))
            except Exception:
                _swallow()
                bp = 50.0
            live = True
            src = "Binance-Taker LIVE"
            note = "Taker buy/sell is live Binance Futures data"
        else:
            # labelled proxy from volume_delta / rsi / score
            vd = 0.0
            try:
                vobj = x.get("volume_delta") or {}
                if isinstance(vobj, dict):
                    vd = safe_float(vobj.get("delta_pct"), 0.0)
                else:
                    vd = safe_float(vobj, 0.0)
            except Exception:
                _swallow()
                vd = 0.0
            rsi = safe_float(x.get("rsi_value"), safe_float(str(x.get("rsi") or "50").replace("%",""), 50))
            sc = safe_float(x.get("score"), 50)
            if abs(vd) > 0.01:
                bp = float(clamp(50.0 + vd * 0.35, 12.0, 88.0))
                src = "volume_body_proxy"
                note = "Taker feed not ready — labelled candle-body volume proxy"
            else:
                bp = float(clamp(0.55 * rsi + 0.45 * sc, 15.0, 85.0))
                src = "rsi_score_proxy"
                note = "Taker feed not ready — RSI/score labelled proxy"
            live = False
            ts = 100.0 - bp
        if ts is None:
            ts = 100.0 - bp
        bs = x.get("buy_sell") if isinstance(x.get("buy_sell"), dict) else {}
        bs.update({
            "buy_pct": int(round(bp)),
            "sell_pct": int(round(float(ts) if ts is not None else (100.0 - bp))),
            "taker_buy_pct": float(tb) if tb is not None else None,
            "taker_sell_pct": float(ts) if ts is not None else None,
            "taker_available": tb is not None,
            "bias": "buy" if bp >= 55 else "sell" if bp <= 45 else "neutral",
            "state": "buy_pressure" if bp >= 58 else "sell_pressure" if bp <= 42 else "balanced",
            "source": src if not bs.get("source") else bs.get("source"),
            "live": live if "live" not in bs else bool(bs.get("live")),
            "note": note if not bs.get("note") else bs.get("note"),
            "volume_delta_pct": safe_float((x.get("volume_delta") or {}).get("delta_pct") if isinstance(x.get("volume_delta"), dict) else x.get("volume_delta"), 0.0),
        })
        x["buy_sell"] = bs
        x["taker_buy_pct"] = bs.get("taker_buy_pct") if bs.get("taker_buy_pct") is not None else bp
        x["taker_sell_pct"] = bs.get("taker_sell_pct") if bs.get("taker_sell_pct") is not None else (100.0 - bp)

        # Whale pack
        od = safe_float(x.get("oi_delta"), 0.0)
        if not math.isfinite(od):
            od = 0.0
        fund = x.get("funding_value")
        if fund is None:
            # try parse funding string
            fs = str(x.get("funding") or "")
            try:
                fund = float(fs.replace("%", "").replace("+", "").strip()) if fs and fs != "N/A" else None
            except Exception:
                _swallow()
                fund = None
        src_w = str(x.get("source") or "")
        liq = x.get("liquidations") if isinstance(x.get("liquidations"), dict) else {}
        prints = x.get("large_prints") if isinstance(x.get("large_prints"), dict) else {}
        live_w = ("Binance" in src_w) or ("CoinGlass" in src_w) or bool(x.get("taker_available")) or (tb is not None)
        if od > 1.5 and live_w:
            label = "Whale inflow / OI rising"
        elif od < -1.5 and live_w:
            label = "Liquidity exit / OI falling"
        elif bp >= 58:
            label = "Taker buy dominant"
        elif bp <= 42:
            label = "Taker sell dominant"
        else:
            label = "Neutral / limited OI evidence"
        w = x.get("whale") if isinstance(x.get("whale"), dict) else {}
        w.update({
            "oi": x.get("oi") or w.get("oi") or "N/A",
            "oi_delta": round(od, 3),
            "oi_change_1h": x.get("oi_change_1h") if x.get("oi_change_1h") is not None else w.get("oi_change_1h"),
            "funding": x.get("funding") or w.get("funding") or "N/A",
            "funding_value": fund,
            "taker_buy_pct": float(tb) if tb is not None else bp,
            "source": src_w or w.get("source") or ("Binance LIVE" if live_w else "limited / proxy"),
            "live": live_w,
            "is_proxy": not live_w,
            "liquidations": liq or w.get("liquidations") or {},
            "large_prints": prints or w.get("large_prints") or {},
            "liq_long_usd": liq.get("long_usd") if liq else w.get("liq_long_usd"),
            "liq_short_usd": liq.get("short_usd") if liq else w.get("liq_short_usd"),
            "large_buy": prints.get("buy_large") if prints else w.get("large_buy"),
            "large_sell": prints.get("sell_large") if prints else w.get("large_sell"),
            "label": label,
            "score": int(round(clamp(
                50
                + (float(max(-10, min(10, od))) * 3)
                + ((bp - 50) * 0.4)
                + ((float(fund) * 80) if fund is not None and math.isfinite(float(fund)) else 0),
                0, 100
            ))),
            "note": w.get("note") or ("LIVE derivatives" if live_w else "Proxy / limited feed"),
        })
        x["whale"] = w
    except Exception:
        _swallow()
    return x


V61_BUILD_ID = TITAN_BUILD_ID
_V61_DEPTH_TTL = 8.0
_V61_FLOW_TTL = 18.0
_V61_FLOW_LOCK = threading.RLock()
_V61_FLOW: dict[str, tuple[float, dict]] = {}


def _v61_get(url: str, params: Optional[dict] = None, headers: Optional[dict] = None, timeout: float = 3.2) -> Optional[Any]:
    try:
        r = _http_session().get(url, params=params or {}, headers=headers or {}, timeout=timeout)
        if not r.ok:
            return None
        return r.json()
    except Exception:
        _swallow()
        return None


def _v61_cg_headers() -> dict[str, str]:
    key = (COINGLASS_API_KEY or "").strip()
    return {"CG-API-KEY": key} if key else {}


def fetch_rest_depth(symbol: str, limit: int = 20) -> dict[str, Any]:
    """Live Binance spot order book (REST). Used for every coin, not just the WS watchlist."""
    pair = _binance_symbol(symbol)
    with DEPTH_LOCK:
        cached = DEPTH_STATE.get(pair) or {}
    if cached and time.time() - safe_float(cached.get("ts"), 0) < _V61_DEPTH_TTL:
        out = dict(cached)
        out.update({"available": True, "symbol": pair, "live": True})
        return out
    raw = _v61_get(
        "https://data-api.binance.vision/api/v3/depth",
        {"symbol": pair, "limit": int(limit)},
        timeout=2.4,
    )
    if not isinstance(raw, dict):
        raw = _v61_get("https://api.binance.com/api/v3/depth", {"symbol": pair, "limit": int(limit)}, timeout=2.4)
    if not isinstance(raw, dict):
        return {"available": False, "symbol": pair, "source": "depth-miss"}
    bids = raw.get("bids") or []
    asks = raw.get("asks") or []
    if not bids or not asks:
        return {"available": False, "symbol": pair, "source": "depth-empty"}
    best_bid = safe_float(bids[0][0])
    best_ask = safe_float(asks[0][0])
    bid_vol = sum(safe_float(x[1]) for x in bids[:10])
    ask_vol = sum(safe_float(x[1]) for x in asks[:10])
    mid = (best_bid + best_ask) / 2 if best_bid and best_ask else 0
    spread_bps = ((best_ask - best_bid) / mid * 10000) if mid else 0
    imb = (bid_vol - ask_vol) / max(bid_vol + ask_vol, 1e-12)
    row = {
        "bid": best_bid,
        "ask": best_ask,
        "bid_vol": round(bid_vol, 4),
        "ask_vol": round(ask_vol, 4),
        "spread_bps": round(spread_bps, 2),
        "imbalance": round(imb, 4),
        "ts": time.time(),
        "source": "Binance-Depth REST LIVE",
        "available": True,
        "symbol": pair,
        "live": True,
    }
    with DEPTH_LOCK:
        DEPTH_STATE[pair] = dict(row)
    return row


_ORIG_GET_DEPTH = get_depth_snapshot


def get_depth_snapshot(symbol: str) -> dict[str, Any]:  # noqa: F811
    """WS cache first (watchlist), then live REST book for every other coin."""
    snap = _ORIG_GET_DEPTH(symbol)
    if snap.get("available"):
        snap["live"] = True
        return snap
    try:
        rest = fetch_rest_depth(symbol)
        if rest.get("available"):
            return rest
    except Exception:
        _swallow()
    return snap


def fetch_binance_oi_history(symbol: str) -> dict[str, Any]:
    """Public Binance futures OI history — real 1h OI change without CoinGlass."""
    pair = _binance_symbol(symbol)
    raw = _v61_get(
        "https://fapi.binance.com/futures/data/openInterestHist",
        {"symbol": pair, "period": "5m", "limit": 12},
        timeout=3.0,
    )
    if not isinstance(raw, list) or len(raw) < 2:
        return {"available": False, "source": "N/A"}
    def _oi(row):
        return safe_float(row.get("sumOpenInterestValue"), safe_float(row.get("sumOpenInterest")))
    first, last = _oi(raw[0]), _oi(raw[-1])
    chg = ((last - first) / first * 100.0) if first > 0 else 0.0
    return {
        "available": True,
        "oi_now": last,
        "oi_change_1h": round(chg, 3),
        "samples": len(raw),
        "source": "Binance-OI-Hist LIVE",
        "live": True,
    }


def fetch_binance_large_prints(symbol: str) -> dict[str, Any]:
    """Live aggTrades: count large prints as a whale-activity proxy (real trades, not invented)."""
    pair = _binance_symbol(symbol)
    raw = _v61_get(
        "https://data-api.binance.vision/api/v3/aggTrades",
        {"symbol": pair, "limit": 80},
        timeout=2.6,
    )
    if not isinstance(raw, list) or not raw:
        raw = _v61_get("https://api.binance.com/api/v3/aggTrades", {"symbol": pair, "limit": 80}, timeout=2.6)
    if not isinstance(raw, list) or not raw:
        return {"available": False, "buy_large": 0, "sell_large": 0, "source": "N/A"}
    qtys = [safe_float(t.get("q")) for t in raw if isinstance(t, dict)]
    qtys = [q for q in qtys if q > 0]
    if not qtys:
        return {"available": False, "buy_large": 0, "sell_large": 0, "source": "N/A"}
    thresh = max(float(np.percentile(qtys, 85)), 1e-12)
    buy_n = sell_n = 0
    buy_q = sell_q = 0.0
    for t in raw:
        if not isinstance(t, dict):
            continue
        q = safe_float(t.get("q"))
        if q < thresh:
            continue
        # m=true means buyer is maker → aggressive sell
        if t.get("m"):
            sell_n += 1
            sell_q += q
        else:
            buy_n += 1
            buy_q += q
    tot = buy_q + sell_q
    return {
        "available": True,
        "buy_large": buy_n,
        "sell_large": sell_n,
        "buy_qty": round(buy_q, 4),
        "sell_qty": round(sell_q, 4),
        "buy_share_pct": round(buy_q / tot * 100.0, 1) if tot > 0 else 50.0,
        "threshold": round(thresh, 6),
        "source": "Binance-aggTrades LIVE",
        "live": True,
        "note": "Prints above the 85th percentile of the last 80 trades",
    }


def fetch_coinglass_liquidations(symbol: str) -> dict[str, Any]:
    """CoinGlass aggregated liquidations when a key is present in LLL/secrets."""
    if not COINGLASS_API_KEY:
        return {"available": False, "source": "no_coinglass_key"}
    base = _binance_symbol(symbol).replace("USDT", "")
    raw = _v61_get(
        "https://open-api-v4.coinglass.com/api/futures/liquidation/aggregated-history",
        {"symbol": base, "interval": "1h", "limit": 2, "exchange_list": "Binance"},
        headers=_v61_cg_headers(),
        timeout=3.4,
    )
    if not isinstance(raw, dict) or str(raw.get("code")) not in {"0", "200"}:
        return {"available": False, "source": "coinglass_liq_unavailable"}
    rows = raw.get("data") or []
    if not isinstance(rows, list) or not rows:
        return {"available": False, "source": "coinglass_liq_empty"}
    row = rows[-1] if isinstance(rows[-1], dict) else {}
    long_usd = safe_float(row.get("aggregated_long_liquidation_usd") or row.get("long_liquidation_usd"))
    short_usd = safe_float(row.get("aggregated_short_liquidation_usd") or row.get("short_liquidation_usd"))
    return {
        "available": True,
        "long_usd": long_usd,
        "short_usd": short_usd,
        "bias": "shorts_squeezed" if short_usd > long_usd * 1.25 else "longs_flushed" if long_usd > short_usd * 1.25 else "balanced",
        "source": "CoinGlass-Liq LIVE",
        "live": True,
    }


def fetch_coinglass_taker(symbol: str) -> dict[str, Any]:
    if not COINGLASS_API_KEY:
        return {"available": False}
    base = _binance_symbol(symbol).replace("USDT", "")
    raw = _v61_get(
        "https://open-api-v4.coinglass.com/api/futures/taker-buy-sell-volume/exchange-list",
        {"symbol": base},
        headers=_v61_cg_headers(),
        timeout=3.4,
    )
    if not isinstance(raw, dict) or str(raw.get("code")) not in {"0", "200"}:
        return {"available": False}
    rows = raw.get("data") or []
    row = next((r for r in rows if str(r.get("exchange", "")).lower() in {"all", "binance"}), rows[0] if rows else None)
    if not isinstance(row, dict):
        return {"available": False}
    buy = safe_float(row.get("buy_vol_usd") or row.get("buyVolUsd") or row.get("buy_vol"))
    sell = safe_float(row.get("sell_vol_usd") or row.get("sellVolUsd") or row.get("sell_vol"))
    tot = buy + sell
    return {
        "available": tot > 0,
        "buy_pct": round(buy / tot * 100.0, 1) if tot > 0 else None,
        "sell_pct": round(sell / tot * 100.0, 1) if tot > 0 else None,
        "source": "CoinGlass-Taker LIVE",
        "live": True,
    }


_ORIG_FETCH_DERIV = fetch_derivatives


def fetch_derivatives(symbol: str) -> dict[str, Any]:  # noqa: F811
    """V61: all derivative HTTP calls run in parallel; CoinGlass extras if key exists."""
    _sym_key = _normalize_symbol(symbol)
    with KLINE_CACHE_LOCK:
        _hit = DERIV_CACHE.get(_sym_key)
        if _hit and (time.time() - _hit[0]) < DERIV_CACHE_TTL:
            return _hit[1]
    pair = _binance_symbol(symbol)
    base = pair.replace("USDT", "")
    source_parts: list[str] = []
    raw_oi = 0.0
    oi_kind = "unknown"
    funding: Optional[float] = None
    cg_usd = cg_qty = cg_delta = None

    def cg_oi():
        if not COINGLASS_API_KEY:
            return None
        return _v61_get(
            "https://open-api-v4.coinglass.com/api/futures/open-interest/exchange-list",
            {"symbol": base}, headers=_v61_cg_headers(), timeout=3.4,
        )

    def cg_fund():
        if not COINGLASS_API_KEY:
            return None
        return _v61_get(
            "https://open-api-v4.coinglass.com/api/futures/funding-rate/exchange-list",
            {"symbol": base}, headers=_v61_cg_headers(), timeout=3.4,
        )

    pack: dict[str, Any] = {}
    with ThreadPoolExecutor(max_workers=8, thread_name_prefix="titan-fl") as ex:
        futs = {
            ex.submit(cg_oi): "cg_oi",
            ex.submit(cg_fund): "cg_fund",
            ex.submit(_binance_futures_funding, symbol): "bn_fund",
            ex.submit(_binance_futures_oi, symbol): "bn_oi",
            ex.submit(fetch_binance_long_short_ratio, symbol): "ls",
            ex.submit(fetch_binance_taker_buy_sell, symbol): "taker",
            ex.submit(fetch_binance_oi_history, symbol): "oih",
            ex.submit(fetch_binance_large_prints, symbol): "prints",
            ex.submit(fetch_rest_depth, symbol): "depth",
            ex.submit(fetch_coinglass_liquidations, symbol): "liq",
            ex.submit(fetch_coinglass_taker, symbol): "cgtaker",
        }
        for fut in as_completed(futs):
            key = futs[fut]
            try:
                pack[key] = fut.result()
            except Exception:
                _swallow()
                pack[key] = None

    res = pack.get("cg_oi")
    if isinstance(res, dict) and str(res.get("code")) in {"0", "200"}:
        rows = res.get("data") or []
        row = next((r for r in rows if str(r.get("exchange", "")).lower() == "all"), rows[0] if rows else None)
        if row:
            cg_qty = safe_float(row.get("open_interest_quantity"), 0)
            cg_usd = safe_float(row.get("open_interest_usd"), 0)
            cg_delta = safe_float(row.get("open_interest_change_percent_5m"), 0)
            if cg_usd and cg_usd > 0:
                raw_oi, oi_kind = cg_usd, "usd"
            elif cg_qty and cg_qty > 0:
                raw_oi, oi_kind = cg_qty, "base"
            if raw_oi > 0:
                source_parts.append("CoinGlass-OI LIVE")

    res = pack.get("cg_fund")
    if isinstance(res, dict) and str(res.get("code")) in {"0", "200"}:
        rows = res.get("data") or []
        row = next((r for r in rows if str(r.get("symbol", "")).upper() == base), rows[0] if rows else None)
        if row:
            vals = [safe_float(x.get("funding_rate"), np.nan) for x in (row.get("stablecoin_margin_list") or [])]
            vals = [x for x in vals if np.isfinite(x)]
            if vals:
                funding = float(np.mean(vals)) * 100
                source_parts.append("CoinGlass-Funding LIVE")

    if funding is None:
        funding = pack.get("bn_fund") if pack.get("bn_fund") is not None else _binance_futures_funding(symbol)
        if funding is not None:
            source_parts.append("Binance-Funding LIVE")
    if raw_oi <= 0:
        fallback_oi = pack.get("bn_oi")
        if fallback_oi is not None and safe_float(fallback_oi) > 0:
            raw_oi, oi_kind = float(fallback_oi), "base"
            source_parts.append("Binance-OI LIVE")

    oih = pack.get("oih") if isinstance(pack.get("oih"), dict) else {}
    now = time.time()
    delta = cg_delta if cg_delta is not None else safe_float(oih.get("oi_change_1h"), 0.0)
    with OI_LOCK:
        previous = OI_HISTORY.get(symbol)
        if cg_delta is None and previous and previous[2] == oi_kind:
            prev_oi, prev_ts, _ = previous
            if prev_oi > 0 and raw_oi > 0 and now - prev_ts <= 900:
                delta = ((raw_oi - prev_oi) / prev_oi) * 100
        if raw_oi > 0:
            OI_HISTORY[symbol] = (raw_oi, now, oi_kind)

    if cg_usd and cg_usd > 0:
        oi_disp = f"${smart_format(cg_usd)}"
    elif cg_qty and cg_qty > 0:
        oi_disp = f"{smart_format(cg_qty)} {base}"
    elif raw_oi > 0:
        oi_disp = f"{smart_format(raw_oi)} {base}"
    else:
        oi_disp = "N/A"

    ls = pack.get("ls") if isinstance(pack.get("ls"), dict) else {"source": "N/A"}
    taker = pack.get("taker") if isinstance(pack.get("taker"), dict) else {"available": False, "source": "N/A"}
    cgtaker = pack.get("cgtaker") if isinstance(pack.get("cgtaker"), dict) else {}
    if not taker.get("available") and cgtaker.get("available"):
        taker = {
            "buy_pct": cgtaker.get("buy_pct"),
            "sell_pct": cgtaker.get("sell_pct"),
            "source": cgtaker.get("source"),
            "available": True,
        }
    if ls.get("source") and ls.get("source") != "N/A":
        source_parts.append(str(ls.get("source")) + " LIVE")
    if taker.get("source") and taker.get("source") != "N/A":
        source_parts.append(str(taker.get("source")) + (" LIVE" if "LIVE" not in str(taker.get("source")) else ""))
    if oih.get("available"):
        source_parts.append("Binance-OI-Hist LIVE")
    liq = pack.get("liq") if isinstance(pack.get("liq"), dict) else {}
    if liq.get("available"):
        source_parts.append("CoinGlass-Liq LIVE")
    prints = pack.get("prints") if isinstance(pack.get("prints"), dict) else {}
    if prints.get("available"):
        source_parts.append("Binance-aggTrades LIVE")
    depth = pack.get("depth") if isinstance(pack.get("depth"), dict) else {}

    out = {
        "oi": oi_disp,
        "raw_oi": raw_oi,
        "oi_delta": delta,
        "oi_change_1h": safe_float(oih.get("oi_change_1h"), delta),
        "funding_value": funding,
        "funding": f"{funding:+.4f}%" if funding is not None else "N/A",
        "source": " + ".join(dict.fromkeys(source_parts)) if source_parts else "N/A",
        "long_short": ls,
        "taker": taker,
        "long_ratio": ls.get("long_ratio"),
        "short_ratio": ls.get("short_ratio"),
        "long_short_ratio": ls.get("long_short_ratio"),
        "top_long_ratio": ls.get("top_long_ratio"),
        "taker_buy_pct": taker.get("buy_pct"),
        "taker_sell_pct": taker.get("sell_pct"),
        "taker_available": bool(taker.get("available")),
        "liquidations": liq,
        "large_prints": prints,
        "depth": depth,
        "live_flow": True,
        "v61": True,
    }
    with KLINE_CACHE_LOCK:
        DERIV_CACHE[_normalize_symbol(symbol)] = (time.time(), out)
        if len(DERIV_CACHE) > 80:
            for k, _ in sorted(DERIV_CACHE.items(), key=lambda x: x[1][0])[:20]:
                DERIV_CACHE.pop(k, None)
    return out


def _v61_keys_status() -> dict[str, Any]:
    reload_keys()
    return {
        "gemini": bool(GEMINI_API_KEY),
        "coinglass": bool(COINGLASS_API_KEY),
        "openai": bool(OPENAI_API_KEY),
        "grok": bool(GROK_API_KEY),
        "claude": bool(CLAUDE_API_KEY),
        "deepseek": bool(DEEPSEEK_API_KEY),
        "secrets_dir": str(SECRETS_DIR),
        "folder": TITAN_FOLDER_NAME,
    }


try:
    @app.get("/api/v61/status")
    def api_v61_status():
        return jsonify({
            "ok": True,
            "version": V61_VERSION,
            "build": V61_BUILD_ID,
            "keys": _v61_keys_status(),
            "scan_workers": int(os.environ.get("TITAN_SCAN_WORKERS", "8") or 8),
            "live_flow": {
                "buy_sell": "Binance futures taker (LIVE) else labelled candle-body proxy",
                "whales": "CoinGlass OI/liq if key + Binance OI history + large aggTrades (LIVE)",
                "depth": "WebSocket watchlist + REST book for every coin (LIVE)",
                "funding_oi": "CoinGlass if key, else Binance premiumIndex/openInterest (LIVE)",
            },
            "storage": str(APP_HOME),
        })
except Exception:
    _swallow()


try:
    @app.get("/download/titan.py")
    def api_v61_download():
        """Serve the TITAN package (zip) for backup / transfer.

        V77: access is gated by titan.layers.hardening.v77_security (token, or loopback
        when no token is configured). Secrets, data folders and caches are never included.
        """
        import io as _io
        import zipfile as _zipfile
        root = Path(__file__).resolve().parent
        buf = _io.BytesIO()
        skip_dirs = {"__pycache__", "MMM", "secrets", "data", "cache", "memory", ".git"}
        with _zipfile.ZipFile(buf, "w", _zipfile.ZIP_DEFLATED) as zf:
            for p in sorted(root.rglob("*")):
                rel = p.relative_to(root)
                if p.is_file() and not (set(rel.parts) & skip_dirs) and p.suffix not in {".pyc", ".db", ".sqlite"}:
                    zf.write(p, str(rel))
        data = buf.getvalue()
        return app.response_class(
            data,
            mimetype="application/zip",
            headers={
                "Content-Disposition": 'attachment; filename="titan_pro_v77.zip"',
                "Content-Length": str(len(data)),
                "X-Content-Type-Options": "nosniff",
                "Cache-Control": "no-store",
            },
        )
except Exception:
    _swallow()


# ---- mobile overflow + live-source chips (appended CSS/JS, original skin kept)
_V61_CSS = r'''
<style id="v61-css">
#v59,#v59 *{box-sizing:border-box}
#v59{overflow:hidden;max-width:100vw}
#v59 .v59-view,#v59 .v59-sheet,#v59 .v59-sheet-b{overflow-x:hidden;max-width:100%}
#v59 .v59-wrap{width:100%;max-width:min(640px,100%);padding-left:max(2px,env(safe-area-inset-left));padding-right:max(2px,env(safe-area-inset-right))}
#v59 .v59-card,#v59 .v59-tile,#v59 .v59-kpi,#v59 .v59-row{max-width:100%;min-width:0}
#v59 .v59-hero{grid-template-columns:minmax(0,86px) minmax(0,1fr);gap:10px}
#v59 .v59-hero .sig{font-size:clamp(18px,6vw,26px);word-break:break-word}
#v59 .v59-lv{grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:6px}
#v59 .v59-lv b{float:none;display:block;text-align:right;overflow-wrap:anywhere}
#v59 .v59-kv{grid-template-columns:minmax(0,1fr) minmax(0,1.1fr);gap:6px 8px}
#v59 .v59-kv span,#v59 .v59-kv b{min-width:0;overflow-wrap:anywhere;word-break:break-word}
#v59 .v59-kv b{text-align:right}
#v59 .v59-sym{min-width:0;max-width:38%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
#v59 .v59-cprice,.v59-bigprice{font-size:clamp(22px,8vw,34px);overflow-wrap:anywhere}
#v59 .v59-fib{grid-template-columns:repeat(auto-fit,minmax(56px,1fr))}
#v59 .v59-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}
#v59 .v59-quick{grid-template-columns:repeat(5,minmax(0,1fr));gap:6px}
#v59 .v59-q{padding:8px 0 6px;font-size:9px}
#v59 .v59-g3{grid-template-columns:repeat(3,minmax(0,1fr))}
#v59 .v59-mtf{grid-template-columns:40px minmax(0,1fr) 44px}
#v59 .v59-itabs .v59-it{width:58px}
#v59 .v60-t{min-width:0!important;width:100%}
#v59 .v60-t td,#v59 .v60-t th{white-space:normal;word-break:break-word}
#v59 .v60-scroll{max-width:100%;overflow-x:auto}
#v59 .v59-ladder{height:220px;margin:6px 0}
#v59 .v59-ladder .lv span{margin-left:calc(42% + 16px)!important;max-width:54%;overflow:hidden;text-overflow:ellipsis}
#v59 .v59-gate{flex:1 1 calc(50% - 8px);min-width:0}
#v59 .v59-sum{overflow-wrap:anywhere}
#v59 .v59-prov .fa{overflow-wrap:anywhere}
#v59 .src-live{display:inline-block;font-size:10px;font-weight:800;letter-spacing:.04em;padding:2px 7px;border-radius:999px;border:1px solid rgba(52,211,153,.7);color:#86efac;background:rgba(6,78,59,.45);margin-inline:4px}
#v59 .src-proxy{display:inline-block;font-size:10px;font-weight:800;letter-spacing:.04em;padding:2px 7px;border-radius:999px;border:1px solid rgba(251,191,36,.7);color:#fde68a;background:rgba(69,40,8,.5);margin-inline:4px}
#v59 .v59-sheet{top:max(4%,env(safe-area-inset-top));max-height:96%}
#v59 .v59-sheet-b{padding:4px 12px calc(24px + env(safe-area-inset-bottom))}
@media(max-width:420px){
  #v59 .v59-view{padding-left:8px;padding-right:8px}
  #v59 .v59-card{padding:10px;border-radius:14px}
  #v59 .v59-g3{grid-template-columns:repeat(2,minmax(0,1fr))!important}
  #v59 .v59-hero{grid-template-columns:1fr}
  #v59 .v59-pulse{grid-template-columns:1fr}
  #v59 .v59-nav{left:4px;right:4px}
  #v59 .v59-fib{grid-template-columns:repeat(3,minmax(0,1fr))}
  #v59 .v59-hub{gap:8px}
  #v59 .v59-tile{min-height:92px;padding:12px 10px}
}
@media(min-width:700px){
  #v59 .v59-kpis{grid-template-columns:repeat(4,minmax(0,1fr))}
}
</style>
'''

_V59_UI_MARKUP = _V59_UI_MARKUP.replace("</style>", "</style>" + _V61_CSS, 1) if "</style>" in _V59_UI_MARKUP else (_V59_UI_MARKUP + _V61_CSS)

# Flow tab: show live vs proxy clearly + liquidations / large prints
_V59_UI_MARKUP = _V59_UI_MARKUP.replace(
    "kv([['Volume delta %',bs.volume_delta_pct!=null?bs.volume_delta_pct:(D.volume_delta||{}).delta_pct],['Bias',bs.bias],['Taker buy %',D.taker_buy_pct],['Taker sell %',D.taker_sell_pct]])",
    "kv([['Feed',(bs.live||bs.taker_available)?'LIVE Binance taker':'labelled proxy'],['Source',bs.source||'—'],['Volume delta %',bs.volume_delta_pct!=null?bs.volume_delta_pct:(D.volume_delta||{}).delta_pct],['Bias',bs.bias],['Taker buy %',D.taker_buy_pct],['Taker sell %',D.taker_sell_pct],['Note',bs.note]])",
)

_V59_UI_MARKUP = _V59_UI_MARKUP.replace(
    "kv([['OI Δ',pct(d,2)],['Funding',w.funding],['Open interest',w.oi],['Buy pressure',b+'%'],['Book imbalance',dp.imbalance!=null?pct(im*100,1):null]])",
    "kv([['Feed',w.live?'LIVE OI / taker / prints':'limited / proxy'],['Source',w.source||'—'],['OI Δ',pct(d,2)],['OI 1h',w.oi_change_1h!=null?pct(w.oi_change_1h,2):null],['Funding',w.funding],['Open interest',w.oi],['Buy pressure',b+'%'],['Book imbalance',dp.imbalance!=null?pct(im*100,1):null],['Liq longs USD',w.liq_long_usd],['Liq shorts USD',w.liq_short_usd],['Large buy prints',w.large_buy],['Large sell prints',w.large_sell]])",
)

# Keep tables from blowing past the phone width in windows
_V59_UI_MARKUP = _V59_UI_MARKUP.replace(
    "#v59 .v60-t{width:100%;border-collapse:collapse;font-size:11.5px;min-width:560px}",
    "#v59 .v60-t{width:100%;border-collapse:collapse;font-size:11.5px;min-width:0}",
)

LOGGER.info("V61 fast-live layer armed · keys gemini=%s coinglass=%s", bool(GEMINI_API_KEY), bool(COINGLASS_API_KEY))
