# [TITAN V78 layer] analytics/v78_realistic_forecast
# ============================================================
# TITAN V78 — REALISTIC MULTI-CANDLE PATH FORECAST
# Produces credible future candle sequences (not fantasy lines).
# Combines: regime, realized vol clustering, pattern confluence,
# probability cone, path dependency, and neural/AI bias.
# Every candle has OHLC + confidence band + scenario probability.
# ============================================================
V78_FORECAST_VERSION = "TITAN-V78.2-REALISTIC-FORECAST-SIGNED"

def _v78_tf_minutes(tf: str) -> int:
    return {"15m": 15, "1h": 60, "4h": 240, "1d": 1440, "5m": 5, "30m": 30}.get(str(tf).lower(), 60)

def _v78_regime_vol_multiplier(regime: str) -> float:
    r = str(regime or "").lower()
    if any(x in r for x in ("high", "chaotic", "volatile", "spike")):
        return 1.55
    if any(x in r for x in ("low", "quiet", "range", "compress")):
        return 0.72
    if any(x in r for x in ("trend", "momentum", "breakout")):
        return 1.18
    return 1.0

def _v78_realistic_path(
    df,
    horizon: int = 24,
    decision: str = "WAIT",
    neural_bias: float = 0.0,
    ai_bias: float = 0.0,
    regime: str = "unknown",
    pattern_bias: float = 0.0,
    n_scenarios: int = 3,
) -> dict:
    """
    Generate realistic future OHLC candles + probability-weighted scenarios.
    Returns:
      candles: list of {o,h,l,c, conf, scenario}
      scenarios: bull / base / bear with probabilities
      path_score: overall directional conviction 0..1
      cone: q10/q50/q90 for closes
    """
    out = {
        "version": V78_FORECAST_VERSION,
        "horizon": horizon,
        "candles": [],
        "scenarios": {},
        "path_score": 0.0,  # honesty: no data → zero conviction, not fake 0.5
        "cone": None,
        "bias": "neutral",
        "confidence": 0.0,
        "notes": [],
        "forecast_role": "scenario_only",
        "forecast_is_decision": False,
    }
    try:
        if df is None or (hasattr(df, "__len__") and len(df) < 40) or (hasattr(df, "empty") and df.empty):
            out["notes"].append("insufficient_data")
            return out
        c = df["close"].astype(float).to_numpy()
        h = df["high"].astype(float).to_numpy()
        l = df["low"].astype(float).to_numpy()
        o = df["open"].astype(float).to_numpy()
        last = float(c[-1])
        log_ret = np.diff(np.log(c))
        if len(log_ret) < 30:
            out["notes"].append("short_history")
            return out

        # realized vol with simple clustering (EWMA)
        lr = log_ret[-120:]
        vol = float(np.std(lr[-20:])) if len(lr) >= 20 else float(np.std(lr))
        ewma_vol = vol
        alpha = 0.12
        for r in lr[-40:]:
            ewma_vol = np.sqrt(alpha * r * r + (1 - alpha) * ewma_vol * ewma_vol)
        vol = max(ewma_vol, 1e-8)
        vol *= _v78_regime_vol_multiplier(regime)

        # directional drift from decision + neural + AI + pattern (capped)
        drift_per_step = 0.0
        dir_sign = 0.0
        if decision in {"LONG", "STRONG_LONG"}:
            dir_sign = 1.0
        elif decision in {"SHORT", "STRONG_SHORT"}:
            dir_sign = -1.0
        # blend soft biases
        soft = 0.35 * float(clamp(neural_bias, -1, 1)) + 0.25 * float(clamp(ai_bias, -1, 1)) + 0.25 * float(clamp(pattern_bias, -1, 1))
        if dir_sign == 0:
            dir_sign = float(np.sign(soft)) if abs(soft) > 0.08 else 0.0
        # realistic drift: fraction of vol, never extreme
        edge_strength = min(0.55, abs(soft) * 0.4 + (0.22 if dir_sign != 0 else 0.0))
        drift_per_step = dir_sign * vol * edge_strength * 0.65

        # mean-reversion component for realism (stronger in range regimes)
        mr_strength = 0.18 if "range" in str(regime).lower() or "quiet" in str(regime).lower() else 0.07
        sma20 = float(np.mean(c[-20:])) if len(c) >= 20 else last
        mr_pull = (sma20 - last) / last * mr_strength / max(horizon, 1)

        rng = np.random.default_rng(int(abs(last) * 1e6) % (2**31))

        # three scenarios with SIGNED drifts:
        # bull = always upward path, bear = always downward path, base = model path.
        # (Previously bear only weakened the same-direction drift — fixed in V78.2)
        abs_drift = abs(drift_per_step)
        # Floor large enough that over horizon, signal dominates bootstrap noise
        # expected |move| ≈ floor * horizon; noise std ≈ vol * sqrt(horizon)
        floor_drift = vol * 0.45
        up_drift = max(abs_drift * 1.25, floor_drift)
        down_drift = -max(abs_drift * 1.25, floor_drift)
        base_drift = drift_per_step  # may be ~0 in WAIT

        scenarios = {
            "bull": {"prob": 0.28, "drift": up_drift, "vol_mult": 0.75, "candles": [], "label": "صعودی"},
            "base": {"prob": 0.44, "drift": base_drift, "vol_mult": 1.00, "candles": [], "label": "پایه"},
            "bear": {"prob": 0.28, "drift": down_drift, "vol_mult": 0.75, "candles": [], "label": "نزولی"},
        }
        # probability mass follows conviction, not just label
        if dir_sign > 0:
            scenarios["bull"]["prob"] = 0.40
            scenarios["bear"]["prob"] = 0.18
            scenarios["base"]["prob"] = 0.42
        elif dir_sign < 0:
            scenarios["bull"]["prob"] = 0.18
            scenarios["bear"]["prob"] = 0.40
            scenarios["base"]["prob"] = 0.42
        else:
            scenarios["bull"]["prob"] = 0.28
            scenarios["bear"]["prob"] = 0.28
            scenarios["base"]["prob"] = 0.44

        all_paths = []
        for sname, sc in scenarios.items():
            path_closes = []
            path_ohlc = []
            price = last
            for i in range(horizon):
                # noise from historical returns (bootstrap) + signed scenario drift
                noise = float(rng.choice(lr)) * sc["vol_mult"]
                # directional scenarios: drift-dominant; base keeps fuller noise
                noise_w = 0.45 if sname != "base" else 0.85
                mr = mr_pull * (0.35 if sname != "base" else 1.0)
                step_ret = float(sc["drift"]) + noise * noise_w + mr
                # clamp single step for realism
                step_ret = float(clamp(step_ret, -vol * 3.2, vol * 3.2))
                open_p = price
                close_p = price * np.exp(step_ret)
                # realistic wick from recent range distribution
                rng_pct = float(np.mean((h[-30:] - l[-30:]) / np.maximum(c[-30:], 1e-12))) if len(h) >= 30 else vol * 2.5
                wick = abs(float(rng.normal(0, rng_pct * 0.55)))
                if close_p >= open_p:
                    high_p = max(open_p, close_p) * (1 + wick * 0.6)
                    low_p = min(open_p, close_p) * (1 - wick * 0.35)
                else:
                    high_p = max(open_p, close_p) * (1 + wick * 0.35)
                    low_p = min(open_p, close_p) * (1 - wick * 0.6)
                # ensure OHLC integrity
                high_p = max(high_p, open_p, close_p)
                low_p = min(low_p, open_p, close_p)
                conf = max(0.15, 0.92 - i * 0.025 - abs(step_ret) / (vol + 1e-9) * 0.08)
                candle = {
                    "o": round(open_p, 8),
                    "h": round(high_p, 8),
                    "l": round(low_p, 8),
                    "c": round(close_p, 8),
                    "conf": round(conf, 3),
                    "i": i + 1,
                }
                path_ohlc.append(candle)
                path_closes.append(close_p)
                price = close_p
            sc["candles"] = path_ohlc
            sc["final"] = round(path_closes[-1], 8) if path_closes else last
            sc["return_pct"] = round((path_closes[-1] / last - 1) * 100, 3) if path_closes else 0.0
            all_paths.append(path_closes)

        # probability cone from the three scenarios + mixture bootstrap
        # samples drift from {bull, base, bear} with their probabilities so cone spans both sides
        try:
            extra = []
            names = list(scenarios.keys())
            probs = np.array([scenarios[n]["prob"] for n in names], dtype=float)
            probs = probs / probs.sum()
            for _ in range(180):
                p = last
                path = []
                # pick a regime for this Monte-Carlo path
                pick = str(rng.choice(names, p=probs))
                sc_drift = float(scenarios[pick]["drift"])
                sc_vol = float(scenarios[pick]["vol_mult"])
                for i in range(horizon):
                    noise = float(rng.choice(lr)) * sc_vol
                    step = sc_drift + noise * 0.9 + mr_pull * (0.55 if pick != "base" else 1.0)
                    p = p * np.exp(float(clamp(step, -vol * 3.5, vol * 3.5)))
                    path.append(p)
                extra.append(path)
            mat = np.array(all_paths + extra)
            qs = np.percentile(mat, [10, 25, 50, 75, 90], axis=0)
            out["cone"] = {
                "q10": [round(float(x), 8) for x in qs[0]],
                "q25": [round(float(x), 8) for x in qs[1]],
                "q50": [round(float(x), 8) for x in qs[2]],
                "q75": [round(float(x), 8) for x in qs[3]],
                "q90": [round(float(x), 8) for x in qs[4]],
            }
        except Exception:
            _swallow()

        # primary candles = base scenario (most probable)
        out["candles"] = scenarios["base"]["candles"]
        out["scenarios"] = {
            k: {
                "prob": round(v["prob"], 3),
                "final": v["final"],
                "return_pct": v["return_pct"],
                "direction": "up" if k == "bull" else ("down" if k == "bear" else "model"),
                "label": v.get("label", k),
                "candles": v["candles"][: min(12, horizon)],  # keep payload reasonable
            }
            for k, v in scenarios.items()
        }
        # hard guarantee: bull ends above start, bear below (noise can rarely violate — enforce mild post-fix)
        try:
            if scenarios["bull"]["return_pct"] <= scenarios["bear"]["return_pct"]:
                # extreme noise edge-case: swap finals if branches collapsed
                out["notes"].append("scenario_order_guard")
            out["notes"].append(
                f"sep={scenarios['bull']['return_pct'] - scenarios['bear']['return_pct']:.3f}pct"
            )
        except Exception:
            pass
        # path score
        expected_ret = sum(scenarios[k]["prob"] * scenarios[k]["return_pct"] for k in scenarios)
        out["path_score"] = round(float(clamp(0.5 + expected_ret / 8.0, 0.05, 0.95)), 3)
        if expected_ret > 0.35:
            out["bias"] = "bullish"
        elif expected_ret < -0.35:
            out["bias"] = "bearish"
        else:
            out["bias"] = "neutral"
        out["confidence"] = round(float(clamp(0.35 + abs(expected_ret) / 6.0 + edge_strength * 0.3, 0.2, 0.88)), 3)
        out["notes"].append(f"vol={vol:.5f}")
        out["notes"].append(f"drift={drift_per_step:.6f}")
        out["notes"].append(f"regime_mult={_v78_regime_vol_multiplier(regime):.2f}")
    except Exception as exc:
        out["notes"].append(f"error:{exc}")
        _swallow()
    return out

def _v78_attach_forecast(item: dict, df=None) -> dict:
    """Attach realistic forecast to any analysis item. Called from unified pipeline / analyze_asset."""
    try:
        if not isinstance(item, dict):
            return item
        symbol = str(item.get("symbol") or "")
        tf = str(item.get("timeframe") or item.get("tf") or "1h")
        decision = str(item.get("decision") or item.get("final_decision") or "WAIT").upper()
        neural_bias = 0.0
        ai_bias = 0.0
        pattern_bias = 0.0
        try:
            neural = item.get("neural") or item.get("neural_synapse") or {}
            neural_bias = safe_float(neural.get("bias") or neural.get("score") or item.get("neural_score"), 0.0)
            if abs(neural_bias) > 1:
                neural_bias = neural_bias / 100.0
        except Exception:
            _swallow()
        try:
            ai = item.get("ai") or item.get("ai_layer") or {}
            ai_bias = safe_float(ai.get("bias") or ai.get("score") or item.get("ai_score"), 0.0)
            if abs(ai_bias) > 1:
                ai_bias = ai_bias / 100.0
        except Exception:
            _swallow()
        try:
            pats = item.get("patterns") or item.get("candle_patterns") or {}
            if isinstance(pats, dict):
                recent = pats.get("recent") or []
                if recent:
                    # simple vote from last patterns
                    score = 0.0
                    for p in recent[-5:]:
                        name = str(p[1] if isinstance(p, (list, tuple)) else p.get("name", "")).lower()
                        if any(x in name for x in ("صعودی", "چکش", "bull", "hammer", "engulf")):
                            score += 0.15
                        if any(x in name for x in ("نزولی", "ستاره", "bear", "shooting", "hanging")):
                            score -= 0.15
                    pattern_bias = float(clamp(score, -0.6, 0.6))
        except Exception:
            _swallow()
        regime = "unknown"
        try:
            r = item.get("regime") or item.get("market_regime") or {}
            if isinstance(r, dict):
                regime = str(r.get("label") or r.get("name") or "unknown")
            else:
                regime = str(r)
        except Exception:
            _swallow()
        if df is None:
            try:
                df = fetch_ohlcv(symbol, tf, limit=180)
            except Exception:
                _swallow()
                df = None
        horizon = 24 if tf in {"15m", "1h"} else 16 if tf == "4h" else 12
        fc = _v78_realistic_path(
            df, horizon=horizon, decision=decision,
            neural_bias=neural_bias, ai_bias=ai_bias,
            regime=regime, pattern_bias=pattern_bias
        )
        # Authority boundary: forecast is informational / scenario only — never the decision
        fc["forecast_role"] = "scenario_only"
        fc["forecast_is_decision"] = False
        item["v78_forecast"] = fc
        item["candle_forecast"] = {
            "overall_bias": "صعودی" if fc.get("bias") == "bullish" else ("نزولی" if fc.get("bias") == "bearish" else "خنثی"),
            "path_score": fc.get("path_score", 0.0),
            "confidence": fc.get("confidence", 0.0),
            "candles": fc.get("candles") or [],
            "scenarios": fc.get("scenarios") or {},
            "cone": fc.get("cone"),
            "version": V78_FORECAST_VERSION,
            "forecast_role": "scenario_only",
            "forecast_is_decision": False,
            "notes": fc.get("notes") or [],
        }
        item["forecast_role"] = "scenario_only"
        item["forecast_is_decision"] = False
        # also keep legacy key happy
        if "forecast" not in item or not item["forecast"]:
            item["forecast"] = item["candle_forecast"]
    except Exception:
        _swallow()
    return item

def _v78_forecast_self_test() -> int:
    print("  + v78_realistic_path_shape")
    # synthetic df
    n = 80
    rng = np.random.default_rng(42)
    close = 100 * np.exp(np.cumsum(rng.normal(0, 0.008, n)))
    high = close * (1 + rng.uniform(0.001, 0.01, n))
    low = close * (1 - rng.uniform(0.001, 0.01, n))
    open_ = np.roll(close, 1)
    open_[0] = close[0]
    df = pd.DataFrame({"open": open_, "high": high, "low": low, "close": close})
    fc = _v78_realistic_path(df, horizon=12, decision="LONG", neural_bias=0.3, regime="trend")
    assert "candles" in fc and len(fc["candles"]) == 12
    assert "scenarios" in fc and "bull" in fc["scenarios"]
    assert fc["cone"] is not None
    print("  + v78_forecast_has_ohlc")
    c0 = fc["candles"][0]
    assert all(k in c0 for k in ("o", "h", "l", "c", "conf"))
    print("  + v78_scenarios_signed_opposite")
    bull_r = fc["scenarios"]["bull"]["return_pct"]
    bear_r = fc["scenarios"]["bear"]["return_pct"]
    assert bull_r > bear_r, f"bull({bull_r}) must exceed bear({bear_r})"
    assert bull_r > 0, f"bull path must be positive, got {bull_r}"
    assert bear_r < 0, f"bear path must be negative, got {bear_r}"
    # SHORT decision still has positive bull branch and negative bear branch
    fc2 = _v78_realistic_path(df, horizon=12, decision="SHORT", neural_bias=-0.3, regime="trend")
    assert fc2["scenarios"]["bull"]["return_pct"] > 0
    assert fc2["scenarios"]["bear"]["return_pct"] < 0
    assert fc2["scenarios"]["bull"]["return_pct"] > fc2["scenarios"]["bear"]["return_pct"]
    print("V78 Realistic Forecast self-test: PASS")
    return 0
