# [TITAN V77 layer] analytics/v62_1_quality_patch - V62.1 quality / learning patch
# Original V76 source lines 27299-27422 (kept verbatim unless listed in CHANGELOG.md).
# =============================================================================
# V62.1 QUALITY / LEARNING PATCH
# - missing feed values stay NULL (not synthetic zero)
# - calibration excludes WAIT and FLAT outcomes
# - diagnostics expose scan, data coverage, WAIT reasons and ledger failures
# - tests assert that no-data flow is unavailable, never a fabricated 50 score
# =============================================================================
V62_PATCH_VERSION = "V62.1-LLL-PRO-MISSING-DATA-LEARNING-GUARDS"


def _v62_diagnostics_payload() -> dict[str, Any]:
    """Summarize observed runtime/DB state without inventing missing metrics."""
    out: dict[str, Any] = {
        "ok": True,
        "patch_version": V62_PATCH_VERSION,
        "timestamp_utc": _now_iso(),
        "scan": {},
        "data_coverage": {},
        "decisions": {},
        "ledger": {},
        "warnings": [],
    }
    try:
        cache_data = (CACHE.get("data") or []) if isinstance(CACHE, dict) else []
        out["scan"] = {
            "cached_symbols": len(cache_data),
            "cache_age_sec": round(max(0.0, time.time() - float(CACHE.get("timestamp") or time.time())), 2)
                if isinstance(CACHE, dict) else None,
            "last_scan_result": dict(globals().get("_LAST_SCAN_RESULT") or {})
                if isinstance(globals().get("_LAST_SCAN_RESULT"), dict) else None,
        }
        with DB_LOCK, db_conn() as con:
            tables = {r[0] for r in con.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()}
            if "v62_signal_snapshots" in tables:
                row = con.execute("""SELECT COUNT(*),
                    SUM(CASE WHEN taker_buy_pct IS NOT NULL THEN 1 ELSE 0 END),
                    SUM(CASE WHEN oi_delta IS NOT NULL THEN 1 ELSE 0 END),
                    SUM(CASE WHEN funding IS NOT NULL THEN 1 ELSE 0 END),
                    SUM(CASE WHEN cvd_pct IS NOT NULL THEN 1 ELSE 0 END),
                    SUM(CASE WHEN book_imbalance IS NOT NULL THEN 1 ELSE 0 END),
                    SUM(CASE WHEN decision='WAIT' THEN 1 ELSE 0 END)
                    FROM v62_signal_snapshots WHERE ts >= ?""", (time.time()-86400,)).fetchone()
                n = int(row[0] or 0)
                out["data_coverage"] = {
                    "window_hours": 24, "snapshots": n,
                    "taker_present": int(row[1] or 0), "oi_delta_present": int(row[2] or 0),
                    "funding_present": int(row[3] or 0), "cvd_present": int(row[4] or 0),
                    "book_imbalance_present": int(row[5] or 0),
                    "wait_snapshots": int(row[6] or 0),
                    "note": "NULL means unavailable; zero is a real observed value. Historical rows written by older versions may have encoded missing values as zero."
                }
            if "v52_decision_audit" in tables:
                rows = con.execute("SELECT decision,reasons,warnings FROM v52_decision_audit ORDER BY id DESC LIMIT 1000").fetchall()
                counts: dict[str, int] = {}
                warning_counts: dict[str, int] = {}
                decisions: dict[str, int] = {}
                for decision, reasons, warnings in rows:
                    d = str(decision or "UNKNOWN").upper()
                    decisions[d] = decisions.get(d, 0) + 1
                    for raw, target in ((reasons, counts), (warnings, warning_counts)):
                        try:
                            parsed = json.loads(raw or "[]")
                            if isinstance(parsed, list):
                                for reason in parsed:
                                    key = str(reason)
                                    target[key] = target.get(key, 0) + 1
                        except Exception:
                            _swallow(); continue
                out["decisions"] = {"sample_size": len(rows), "counts": decisions,
                                    "top_wait_reasons": sorted(counts.items(), key=lambda kv: -kv[1])[:12],
                                    "top_warnings": sorted(warning_counts.items(), key=lambda kv: -kv[1])[:12]}
            if "titan_v49_ledger" in tables:
                row = con.execute("""SELECT COUNT(*),
                    SUM(CASE WHEN published=1 THEN 1 ELSE 0 END),
                    SUM(CASE WHEN outcome_24h='PENDING' THEN 1 ELSE 0 END),
                    SUM(CASE WHEN outcome_24h IN ('WIN','LOSS') THEN 1 ELSE 0 END)
                    FROM titan_v49_ledger""").fetchone()
                out["ledger"] = {"rows": int(row[0] or 0), "published": int(row[1] or 0),
                                 "pending_24h": int(row[2] or 0), "resolved_24h": int(row[3] or 0)}
        if not out.get("data_coverage", {}).get("snapshots"):
            out["warnings"].append("No V62 snapshots in the last 24 hours; live analytics coverage cannot be assessed yet.")
        if out.get("ledger", {}).get("published", 0) and not out.get("ledger", {}).get("resolved_24h", 0):
            out["warnings"].append("Published signals have no resolved 24h outcomes yet; do not claim a live win rate.")
    except Exception as exc:
        LOGGER.exception("V62 diagnostics failed")
        out["ok"] = False
        out["error"] = str(exc)[:240]
    return out


try:
    @app.get("/api/v62/diagnostics")
    def api_v62_diagnostics():
        payload = _v62_diagnostics_payload()
        return jsonify(payload), (200 if payload.get("ok") else 500)
except Exception as _route_exc:
    LOGGER.warning("V62 diagnostics route registration failed: %s", _route_exc)


def _v62_patch_self_test() -> int:
    failures = []
    def check(name, condition):
        if not condition:
            failures.append(name)
            print("  FAIL", name)
        else:
            print("  PASS", name)
    check("missing string -> None", _v62_optional_float("N/A") is None)
    check("invalid numeric -> None", _v62_optional_float(float("nan")) is None)
    check("actual zero preserved", _v62_optional_float(0) == 0.0)
    empty = _v62_flow_score(None, None, None, None, None)
    check("no data is unavailable, not 50", empty.get("score") is None and empty.get("bias") == "unavailable")
    partial = _v62_flow_score(60.0, None, None, None, None)
    check("partial data counts only observed components", partial.get("live_components") == 1 and partial.get("score") == 70.0)
    check("flow weights remain normalized", abs(sum(_V62_FLOW_WEIGHTS.values()) - 1.0) < 0.02)
    if failures:
        print("V62.1 SELF-TEST FAILED:", ", ".join(failures))
        return 1
    print("V62.1 SELF-TEST PASSED")
    return 0
