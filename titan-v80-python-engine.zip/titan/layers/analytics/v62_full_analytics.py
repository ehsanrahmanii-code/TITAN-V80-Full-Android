# [TITAN V77 layer] analytics/v62_full_analytics - V62 full analytics (phases 1-3)
# Original V76 source lines 26208-27298 (kept verbatim unless listed in CHANGELOG.md).
# =============================================================================
# TITAN V62 — FULL ANALYTICS LAYER (Phases 1–3)
# CVD · Flow Score · Invalidation · History · Liquidity Map · OI multi-horizon
# Basis/Premium · Predicted funding · Outcome labels · AI Brief · Weight calib
# =============================================================================
V62_VERSION = "TITAN-V62-FULL-ANALYTICS"
V62_BUILD_ID = "V62.0-PRO-2026-10-FULL"
_V62_CVD_CACHE: dict[str, tuple[float, dict]] = {}
_V62_CVD_TTL = 12.0
_V62_BASIS_CACHE: dict[str, tuple[float, dict]] = {}
_V62_BASIS_TTL = 20.0
_V62_HIST_CACHE: dict[str, tuple[float, list]] = {}
_V62_FLOW_WEIGHTS = {
    "taker": 0.28,
    "oi_delta": 0.22,
    "book": 0.18,
    "cvd": 0.18,
    "funding": 0.14,
}
_V62_FLOW_WEIGHTS_LOCK = threading.RLock()


def _v62_init_db() -> None:
    """Create V62 analytical tables (idempotent)."""
    try:
        with DB_LOCK, db_conn() as con:
            con.execute(
                """CREATE TABLE IF NOT EXISTS v62_signal_snapshots(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol TEXT NOT NULL,
                    ts REAL NOT NULL,
                    price REAL,
                    score REAL,
                    bias TEXT,
                    decision TEXT,
                    taker_buy_pct REAL,
                    oi_delta REAL,
                    funding REAL,
                    flow_score REAL,
                    cvd_pct REAL,
                    book_imbalance REAL,
                    entry REAL,
                    sl REAL,
                    tp1 REAL,
                    tp2 REAL,
                    invalidation TEXT,
                    source TEXT,
                    payload TEXT
                )"""
            )
            con.execute(
                "CREATE INDEX IF NOT EXISTS idx_v62_snap_sym_ts ON v62_signal_snapshots(symbol, ts DESC)"
            )
            con.execute(
                """CREATE TABLE IF NOT EXISTS v62_outcomes(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    snapshot_id INTEGER,
                    symbol TEXT NOT NULL,
                    ts_open REAL,
                    ts_eval REAL,
                    horizon_h REAL,
                    price_open REAL,
                    price_eval REAL,
                    decision TEXT,
                    r_multiple REAL,
                    hit_tp1 INTEGER,
                    hit_sl INTEGER,
                    result TEXT,
                    UNIQUE(snapshot_id, horizon_h)
                )"""
            )
            con.execute(
                "CREATE INDEX IF NOT EXISTS idx_v62_out_sym ON v62_outcomes(symbol, ts_eval DESC)"
            )
            con.execute(
                """CREATE TABLE IF NOT EXISTS v62_flow_samples(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    symbol TEXT NOT NULL,
                    ts REAL NOT NULL,
                    taker_buy_pct REAL,
                    oi_delta REAL,
                    book_imbalance REAL,
                    cvd_pct REAL,
                    funding REAL,
                    flow_score REAL
                )"""
            )
            con.execute(
                """CREATE TABLE IF NOT EXISTS v62_edge_weights(
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    ts REAL NOT NULL,
                    weights_json TEXT,
                    sample_n INTEGER,
                    note TEXT
                )"""
            )
            con.commit()
    except Exception as exc:
        LOGGER.warning("v62_init_db: %s", exc)


def _v62_fetch_cvd(symbol: str) -> dict[str, Any]:
    """Cumulative Volume Delta proxy from recent aggTrades (Binance)."""
    pair = _binance_symbol(symbol)
    key = pair
    now = time.time()
    hit = _V62_CVD_CACHE.get(key)
    if hit and now - hit[0] < _V62_CVD_TTL:
        return hit[1]
    out: dict[str, Any] = {
        "available": False,
        "cvd": 0.0,
        "cvd_pct": 0.0,
        "buy_vol": 0.0,
        "sell_vol": 0.0,
        "trades": 0,
        "source": "N/A",
    }
    try:
        raw = _v61_get(
            "https://fapi.binance.com/fapi/v1/aggTrades",
            {"symbol": pair, "limit": 200},
            timeout=2.8,
        )
        if not isinstance(raw, list) or not raw:
            raw = _v61_get(
                "https://api.binance.com/api/v3/aggTrades",
                {"symbol": pair, "limit": 200},
                timeout=2.6,
            )
        if isinstance(raw, list) and raw:
            buy_v = sell_v = 0.0
            for t in raw:
                try:
                    q = float(t.get("q") or t.get("qty") or 0)
                    # m=True => buyer is maker => aggressive sell
                    is_sell = bool(t.get("m"))
                    if is_sell:
                        sell_v += q
                    else:
                        buy_v += q
                except Exception:
                    _swallow(); continue
            tot = buy_v + sell_v
            cvd = buy_v - sell_v
            cvd_pct = (cvd / tot * 100.0) if tot > 0 else 0.0
            out = {
                "available": True,
                "cvd": round(cvd, 4),
                "cvd_pct": round(cvd_pct, 3),
                "buy_vol": round(buy_v, 4),
                "sell_vol": round(sell_v, 4),
                "trades": len(raw),
                "source": "Binance-aggTrades LIVE",
            }
    except Exception:
        _swallow()
    _V62_CVD_CACHE[key] = (now, out)
    if len(_V62_CVD_CACHE) > 60:
        for k, _ in sorted(_V62_CVD_CACHE.items(), key=lambda x: x[1][0])[:15]:
            _V62_CVD_CACHE.pop(k, None)
    return out


def _v62_fetch_basis(symbol: str) -> dict[str, Any]:
    """Futures premium / mark basis + predicted funding."""
    pair = _binance_symbol(symbol)
    now = time.time()
    hit = _V62_BASIS_CACHE.get(pair)
    if hit and now - hit[0] < _V62_BASIS_TTL:
        return hit[1]
    out: dict[str, Any] = {
        "available": False,
        "mark_price": None,
        "index_price": None,
        "basis_pct": None,
        "last_funding": None,
        "predicted_funding": None,
        "source": "N/A",
    }
    try:
        prem = _v61_get(
            "https://fapi.binance.com/fapi/v1/premiumIndex",
            {"symbol": pair},
            timeout=2.5,
        )
        if isinstance(prem, dict):
            mark = _v62_optional_float(prem.get("markPrice"))
            idx = _v62_optional_float(prem.get("indexPrice"))
            last_f = _v62_optional_float(prem.get("lastFundingRate"))
            # interestRate / estimatedSettlePrice not always present; use lastFunding as proxy for next if missing
            pred = prem.get("interestRate")  # not ideal; Binance doesn't always expose next
            # Some endpoints expose nothing for predicted — leave null
            basis = None
            if mark is not None and idx is not None and mark > 0 and idx > 0:
                basis = (mark - idx) / idx * 100.0
            out = {
                "available": bool(mark is not None or idx is not None or last_f is not None),
                "mark_price": mark,
                "index_price": idx,
                "basis_pct": round(basis, 4) if basis is not None else None,
                "last_funding": round(last_f * 100.0, 5) if last_f is not None else None,
                "predicted_funding": round(safe_float(pred) * 100.0, 5) if pred is not None else None,
                "source": "Binance-premiumIndex LIVE",
            }
        # Try funding rate history for predicted-ish next
        try:
            fr = _v61_get(
                "https://fapi.binance.com/fapi/v1/fundingRate",
                {"symbol": pair, "limit": 3},
                timeout=2.2,
            )
            if isinstance(fr, list) and fr:
                rates = [safe_float(x.get("fundingRate")) for x in fr if x.get("fundingRate") is not None]
                rates = [r for r in rates if r is not None]
                if rates and out.get("predicted_funding") is None:
                    # simple EMA-ish of last rates as soft prediction
                    pred_r = rates[0] * 0.6 + (rates[1] if len(rates) > 1 else rates[0]) * 0.4
                    out["predicted_funding"] = round(pred_r * 100.0, 5)
                    out["predicted_note"] = "soft_ema_last_funding"
        except Exception:
            _swallow()
    except Exception:
        _swallow()
    _V62_BASIS_CACHE[pair] = (now, out)
    return out


def _v62_oi_horizons(symbol: str) -> dict[str, Any]:
    """OI change approx 1h and 4h from Binance openInterestHist."""
    pair = _binance_symbol(symbol)
    out = {"oi_change_1h": None, "oi_change_4h": None, "available": False, "source": "N/A"}
    try:
        # 5m hist → 12 bars ~1h, 48 bars ~4h
        raw = _v61_get(
            "https://fapi.binance.com/futures/data/openInterestHist",
            {"symbol": pair, "period": "5m", "limit": 48},
            timeout=3.0,
        )
        if isinstance(raw, list) and len(raw) >= 2:
            def _oi(i):
                try:
                    return float(raw[i].get("sumOpenInterest") or raw[i].get("sumOpenInterestValue") or 0)
                except Exception:
                    _swallow()
                    return 0.0
            last = _oi(-1)
            if last > 0:
                o1 = _oi(-min(12, len(raw)))
                o4 = _oi(0)
                out["oi_change_1h"] = round((last - o1) / o1 * 100.0, 3) if o1 > 0 else None
                out["oi_change_4h"] = round((last - o4) / o4 * 100.0, 3) if o4 > 0 else None
                out["available"] = True
                out["source"] = "Binance-OI-Hist LIVE"
    except Exception:
        _swallow()
    return out


def _v62_optional_float(value: Any) -> Optional[float]:
    """Parse a real numeric market value; missing/invalid values stay None, not zero."""
    if value is None or isinstance(value, str) and value.strip().upper() in {"", "N/A", "NA", "NONE", "NULL", "—", "-"}:
        return None
    try:
        value = float(value)
        return value if math.isfinite(value) else None
    except (TypeError, ValueError):
        return None


def _v62_flow_score(
    taker_buy_pct: Optional[float],
    oi_delta: Optional[float],
    book_imbalance: Optional[float],
    cvd_pct: Optional[float],
    funding_pct: Optional[float],
    weights: Optional[dict] = None,
) -> dict[str, Any]:
    """Composite 0–100 flow score with component breakdown."""
    w = dict(weights or _V62_FLOW_WEIGHTS)
    # Normalize components to roughly -1..+1 then map to 0..100 contribution
    def _nz(v, scale):
        if v is None:
            return 0.0, False
        try:
            x = float(v)
            if not math.isfinite(x):
                return 0.0, False
            return float(max(-1.0, min(1.0, x / scale))), True
        except Exception:
            _swallow()
            return 0.0, False

    t_s, t_ok = _nz((taker_buy_pct - 50.0) if taker_buy_pct is not None else None, 25.0)
    o_s, o_ok = _nz(oi_delta, 8.0)
    b_s, b_ok = _nz(book_imbalance, 0.35)  # imbalance often -1..1 already-ish
    c_s, c_ok = _nz(cvd_pct, 25.0)
    # funding: positive funding => longs pay => mild bearish for chase
    f_s, f_ok = _nz((-funding_pct) if funding_pct is not None else None, 0.05)

    parts = {
        "taker": (t_s, t_ok, w.get("taker", 0.28)),
        "oi_delta": (o_s, o_ok, w.get("oi_delta", 0.22)),
        "book": (b_s, b_ok, w.get("book", 0.18)),
        "cvd": (c_s, c_ok, w.get("cvd", 0.18)),
        "funding": (f_s, f_ok, w.get("funding", 0.14)),
    }
    num = den = 0.0
    breakdown = {}
    for name, (s, ok, wt) in parts.items():
        breakdown[name] = {"signal": round(s, 3), "ok": ok, "weight": wt}
        if ok:
            num += s * wt
            den += wt
    if den <= 0:
        # Missing inputs are not neutral evidence. Do not display a fabricated 50/100.
        score = None
        bias = "unavailable"
        live_n = 0
    else:
        score = float(clamp(50.0 + (num / den) * 50.0, 0, 100))
        bias = "buy" if score >= 58 else "sell" if score <= 42 else "neutral"
        live_n = sum(1 for _, ok, _ in parts.values() if ok)
    return {
        "score": round(score, 1) if score is not None else None,
        "bias": bias,
        "live_components": live_n,
        "breakdown": breakdown,
        "weights": w,
    }


def _v62_liquidity_map(
    price: float,
    depth: Optional[dict],
    support: Any,
    resistance: Any,
    atr: Optional[float] = None,
) -> dict[str, Any]:
    """Compact liquidity map for mobile: nearest levels + book pressure."""
    levels = []
    try:
        sp = safe_float(support) if support not in (None, "N/A") else None
        rs = safe_float(resistance) if resistance not in (None, "N/A") else None
        if sp and price > 0:
            levels.append({
                "side": "support",
                "price": sp,
                "dist_pct": round((price - sp) / price * 100.0, 3),
                "strength": "strong" if atr and abs(price - sp) <= 1.2 * atr else "normal",
            })
        if rs and price > 0:
            levels.append({
                "side": "resistance",
                "price": rs,
                "dist_pct": round((rs - price) / price * 100.0, 3),
                "strength": "strong" if atr and abs(rs - price) <= 1.2 * atr else "normal",
            })
    except Exception:
        _swallow()
    book = {}
    try:
        if isinstance(depth, dict):
            book = {
                "imbalance": depth.get("imbalance"),
                "bid_vol": depth.get("bid_vol"),
                "ask_vol": depth.get("ask_vol"),
                "bid_levels": depth.get("bids") or depth.get("bid_levels"),
                "ask_levels": depth.get("asks") or depth.get("ask_levels"),
                "source": depth.get("source") or "depth",
            }
    except Exception:
        _swallow()
    bias = "balanced"
    try:
        im = safe_float(book.get("imbalance"))
        if im is not None:
            if im >= 0.12:
                bias = "bid_heavy"
            elif im <= -0.12:
                bias = "ask_heavy"
    except Exception:
        _swallow()
    return {
        "price": price,
        "levels": levels[:6],
        "book": book,
        "bias": bias,
        "atr": atr,
    }


def _v62_invalidation(
    decision: str,
    price: float,
    sl: Any,
    structure_support: Any,
    structure_resistance: Any,
    atr: Optional[float] = None,
) -> dict[str, Any]:
    """Clear invalidation line for the active bias."""
    dec = (decision or "").upper()
    inv_price = None
    reason = "no clear invalidation"
    try:
        sl_f = safe_float(sl) if sl not in (None, "N/A") else None
        sup = safe_float(structure_support) if structure_support not in (None, "N/A") else None
        res = safe_float(structure_resistance) if structure_resistance not in (None, "N/A") else None
        if dec == "LONG":
            candidates = [v for v in (sl_f, sup) if v and v < price]
            if candidates:
                inv_price = max(candidates)  # closest below
                reason = "close below SL / structure support"
            elif atr and price > 0:
                inv_price = price - 1.5 * atr
                reason = "close below 1.5×ATR soft invalidation"
        elif dec == "SHORT":
            candidates = [v for v in (sl_f, res) if v and v > price]
            if candidates:
                inv_price = min(candidates)
                reason = "close above SL / structure resistance"
            elif atr and price > 0:
                inv_price = price + 1.5 * atr
                reason = "close above 1.5×ATR soft invalidation"
        else:
            reason = "WAIT — no directional invalidation"
    except Exception:
        _swallow()
    return {
        "price": round(inv_price, 6) if inv_price else None,
        "price_display": smart_format(inv_price) if inv_price else "—",
        "reason": reason,
        "decision": dec or "WAIT",
    }


def _v62_save_snapshot(item: dict) -> None:
    try:
        sym = str(item.get("symbol") or "")
        if not sym:
            return
        price = safe_float(item.get("price_raw"), safe_float(item.get("price")))
        score = safe_float(item.get("score"), 50)
        flow = item.get("flow_score") if isinstance(item.get("flow_score"), dict) else {}
        inv = item.get("invalidation") if isinstance(item.get("invalidation"), dict) else {}
        payload = {
            "flow": flow,
            "liquidity_map": item.get("liquidity_map"),
            "basis": item.get("basis"),
            "cvd": item.get("cvd"),
        }
        with DB_LOCK, db_conn() as con:
            con.execute(
                """INSERT INTO v62_signal_snapshots(
                    symbol, ts, price, score, bias, decision,
                    taker_buy_pct, oi_delta, funding, flow_score, cvd_pct, book_imbalance,
                    entry, sl, tp1, tp2, invalidation, source, payload
                ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    sym,
                    time.time(),
                    price,
                    score,
                    str(item.get("bias") or ""),
                    str(item.get("decision") or item.get("decision_tag") or ""),
                    _v62_optional_float(item.get("taker_buy_pct")),
                    _v62_optional_float(item.get("oi_delta")),
                    _v62_optional_float(item.get("funding_value")),
                    _v62_optional_float(flow.get("score")),
                    _v62_optional_float((item.get("cvd") or {}).get("cvd_pct") if isinstance(item.get("cvd"), dict) else None),
                    _v62_optional_float((item.get("depth") or {}).get("imbalance") if isinstance(item.get("depth"), dict) else None),
                    safe_float(item.get("entry_raw"), price),
                    safe_float(item.get("stop_loss_raw")),
                    safe_float(item.get("tp1_raw")),
                    safe_float(item.get("tp2_raw")),
                    inv.get("price_display") or inv.get("reason") or "",
                    str(item.get("source") or ""),
                    json.dumps(payload, ensure_ascii=False, default=str)[:4000],
                ),
            )
            # flow sample
            con.execute(
                """INSERT INTO v62_flow_samples(symbol, ts, taker_buy_pct, oi_delta, book_imbalance, cvd_pct, funding, flow_score)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (
                    sym,
                    time.time(),
                    _v62_optional_float(item.get("taker_buy_pct")),
                    _v62_optional_float(item.get("oi_delta")),
                    _v62_optional_float((item.get("depth") or {}).get("imbalance") if isinstance(item.get("depth"), dict) else None),
                    _v62_optional_float((item.get("cvd") or {}).get("cvd_pct") if isinstance(item.get("cvd"), dict) else None),
                    _v62_optional_float(item.get("funding_value")),
                    _v62_optional_float(flow.get("score")),
                ),
            )
            con.commit()
    except Exception as exc:
        LOGGER.debug("v62_save_snapshot: %s", exc)


def _v62_history(symbol: str, limit: int = 10) -> list[dict]:
    key = _normalize_symbol(symbol)
    now = time.time()
    hit = _V62_HIST_CACHE.get(key)
    if hit and now - hit[0] < 15.0:
        return hit[1][:limit]
    rows: list[dict] = []
    try:
        with DB_LOCK, db_conn() as con:
            cur = con.execute(
                """SELECT id, ts, price, score, bias, decision, taker_buy_pct, oi_delta, funding,
                          flow_score, entry, sl, tp1, tp2, invalidation, source
                   FROM v62_signal_snapshots WHERE symbol=? OR symbol=?
                   ORDER BY ts DESC LIMIT ?""",
                (symbol, key, int(limit)),
            )
            for r in cur.fetchall():
                rows.append({
                    "id": r[0],
                    "ts": r[1],
                    "age_min": round((now - r[1]) / 60.0, 1) if r[1] else None,
                    "price": r[2],
                    "score": r[3],
                    "bias": r[4],
                    "decision": r[5],
                    "taker_buy_pct": r[6],
                    "oi_delta": r[7],
                    "funding": r[8],
                    "flow_score": r[9],
                    "entry": r[10],
                    "sl": r[11],
                    "tp1": r[12],
                    "tp2": r[13],
                    "invalidation": r[14],
                    "source": r[15],
                })
            # attach outcomes if any
            if rows:
                ids = [str(r["id"]) for r in rows if r.get("id") is not None]
                if ids:
                    q = f"SELECT snapshot_id, horizon_h, r_multiple, hit_tp1, hit_sl, result FROM v62_outcomes WHERE snapshot_id IN ({','.join(['?']*len(ids))})"
                    oc = {}
                    for o in con.execute(q, ids).fetchall():
                        oc.setdefault(o[0], []).append({
                            "horizon_h": o[1],
                            "r_multiple": o[2],
                            "hit_tp1": o[3],
                            "hit_sl": o[4],
                            "result": o[5],
                        })
                    for r in rows:
                        r["outcomes"] = oc.get(r["id"], [])
    except Exception as exc:
        LOGGER.debug("v62_history: %s", exc)
    _V62_HIST_CACHE[key] = (now, rows)
    return rows[:limit]


def _v62_label_outcomes(horizons_h: tuple = (1.0, 4.0, 24.0)) -> int:
    """Label past snapshots with realized R / TP / SL using current live prices."""
    labeled = 0
    try:
        live = {}
        try:
            # reuse global live cache if present
            from_cache = globals().get("LIVE_PRICES") or globals().get("PRICE_CACHE") or {}
            if isinstance(from_cache, dict):
                live = from_cache
        except Exception:
            _swallow()
        now = time.time()
        with DB_LOCK, db_conn() as con:
            snaps = con.execute(
                """SELECT id, symbol, ts, price, decision, entry, sl, tp1, tp2
                   FROM v62_signal_snapshots
                   WHERE ts > ? ORDER BY ts DESC LIMIT 400""",
                (now - 3 * 86400,),
            ).fetchall()
            for row in snaps:
                sid, sym, ts_open, px_open, decision, entry, sl, tp1, tp2 = row
                if not sym or not ts_open:
                    continue
                age_h = (now - ts_open) / 3600.0
                # get eval price
                px_now = None
                try:
                    if isinstance(live, dict):
                        px_now = safe_float(live.get(sym) or live.get(_normalize_symbol(sym)))
                    if px_now is None:
                        # try CACHE data
                        data = (CACHE.get("data") or []) if isinstance(CACHE, dict) else []
                        for it in data:
                            if _normalize_symbol(str(it.get("symbol") or "")) == _normalize_symbol(sym):
                                px_now = safe_float(it.get("price_raw"), safe_float(it.get("price")))
                                break
                except Exception:
                    _swallow()
                    px_now = None
                if not px_now or not px_open:
                    continue
                dec = (decision or "").upper()
                e = safe_float(entry, px_open)
                s = safe_float(sl)
                t1 = safe_float(tp1)
                risk = abs(e - s) if s and e else None
                for h in horizons_h:
                    if age_h < h * 0.9:
                        continue
                    exists = con.execute(
                        "SELECT 1 FROM v62_outcomes WHERE snapshot_id=? AND horizon_h=?",
                        (sid, h),
                    ).fetchone()
                    if exists:
                        continue
                    r_mult = None
                    hit_tp1 = 0
                    hit_sl = 0
                    result = "FLAT"
                    if dec == "LONG" and risk and risk > 0:
                        r_mult = (px_now - e) / risk
                        if t1 and px_now >= t1:
                            hit_tp1 = 1
                        if s and px_now <= s:
                            hit_sl = 1
                        result = "WIN" if r_mult >= 0.8 else "LOSS" if r_mult <= -0.8 else "FLAT"
                    elif dec == "SHORT" and risk and risk > 0:
                        r_mult = (e - px_now) / risk
                        if t1 and px_now <= t1:
                            hit_tp1 = 1
                        if s and px_now >= s:
                            hit_sl = 1
                        result = "WIN" if r_mult >= 0.8 else "LOSS" if r_mult <= -0.8 else "FLAT"
                    else:
                        chg = (px_now - px_open) / px_open * 100.0 if px_open else 0
                        result = "UP" if chg > 0.3 else "DOWN" if chg < -0.3 else "FLAT"
                        r_mult = chg / 100.0
                    con.execute(
                        """INSERT OR IGNORE INTO v62_outcomes(
                            snapshot_id, symbol, ts_open, ts_eval, horizon_h,
                            price_open, price_eval, decision, r_multiple, hit_tp1, hit_sl, result
                        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (sid, sym, ts_open, now, h, px_open, px_now, dec, r_mult, hit_tp1, hit_sl, result),
                    )
                    labeled += 1
            con.commit()
    except Exception as exc:
        LOGGER.debug("v62_label_outcomes: %s", exc)
    return labeled


def _v62_calibrate_flow_weights() -> dict[str, Any]:
    """Adjust flow weights from historical outcomes (simple correlation proxy)."""
    global _V62_FLOW_WEIGHTS
    note = "insufficient_data"
    sample_n = 0
    try:
        with DB_LOCK, db_conn() as con:
            rows = con.execute(
                """SELECT s.taker_buy_pct, s.oi_delta, s.book_imbalance, s.cvd_pct, s.funding,
                          o.r_multiple, o.result
                   FROM v62_signal_snapshots s
                   JOIN v62_outcomes o ON o.snapshot_id = s.id
                   WHERE o.horizon_h >= 4.0 AND o.r_multiple IS NOT NULL
                     AND UPPER(COALESCE(s.decision,'')) IN ('LONG','SHORT')
                     AND UPPER(COALESCE(o.result,'')) IN ('WIN','LOSS')
                   ORDER BY o.ts_eval DESC LIMIT 300"""
            ).fetchall()
        sample_n = len(rows)
        if sample_n < 20:
            return {"weights": dict(_V62_FLOW_WEIGHTS), "sample_n": sample_n, "note": note}
        # Compute each feature edge only from rows where that feature was actually observed.
        # NULL is missing data, never an implicit neutral/zero reading.
        def edge(index, predicate):
            usable = [r for r in rows if r[index] is not None and r[5] is not None]
            bull = [r[5] for r in usable if predicate(_v62_optional_float(r[index]))]
            bear = [r[5] for r in usable if not predicate(_v62_optional_float(r[index]))]
            if len(bull) < 5 or len(bear) < 5:
                return 0.0
            return float(sum(bull) / len(bull) - sum(bear) / len(bear))

        edges = {
            "taker": abs(edge(0, lambda v: v is not None and v >= 55)),
            "oi_delta": abs(edge(1, lambda v: v is not None and v > 0.5)),
            "book": abs(edge(2, lambda v: v is not None and v > 0.05)),
            "cvd": abs(edge(3, lambda v: v is not None and v > 2)),
            "funding": abs(edge(4, lambda v: v is not None and v < 0)),  # negative funding can support longs
        }
        tot = sum(edges.values()) or 1.0
        # blend 70% learned + 30% prior
        prior = {"taker": 0.28, "oi_delta": 0.22, "book": 0.18, "cvd": 0.18, "funding": 0.14}
        learned = {k: edges[k] / tot for k in prior}
        blended = {k: round(0.30 * prior[k] + 0.70 * learned[k], 4) for k in prior}
        s = sum(blended.values()) or 1.0
        blended = {k: round(v / s, 4) for k, v in blended.items()}
        with _V62_FLOW_WEIGHTS_LOCK:
            _V62_FLOW_WEIGHTS = blended
        note = "calibrated"
        try:
            with DB_LOCK, db_conn() as con:
                con.execute(
                    "INSERT INTO v62_edge_weights(ts, weights_json, sample_n, note) VALUES (?,?,?,?)",
                    (time.time(), json.dumps(blended), sample_n, note),
                )
                con.commit()
        except Exception:
            _swallow()
        return {"weights": blended, "sample_n": sample_n, "note": note, "edges": edges}
    except Exception as exc:
        LOGGER.debug("v62_calibrate: %s", exc)
        return {"weights": dict(_V62_FLOW_WEIGHTS), "sample_n": sample_n, "note": str(exc)}


def _v62_ai_brief(item: dict) -> dict[str, Any]:
    """Short structured AI brief — only when Gemini key exists and symbol is priority / extreme score."""
    out = {"available": False, "text": "", "bias": None, "confidence": None, "source": "none"}
    if not GEMINI_API_KEY:
        out["text"] = "Gemini key not configured in secrets/"
        return out
    try:
        sym = str(item.get("symbol") or "")
        score = safe_float(item.get("score"), 50)
        base = sym.split("/")[0].upper() if sym else ""
        priority = base in {"BTC", "ETH", "SOL", "BNB", "XRP"} or score <= 35 or score >= 65
        if not priority:
            out["text"] = "AI brief reserved for priority / extreme scores"
            return out
        # Prefer cached ai_opinions if already present
        ai = item.get("ai_opinions") or item.get("ai") or {}
        if isinstance(ai, dict):
            internal = ai.get("internal") or ai.get("titan") or ""
            if internal and len(str(internal)) > 20:
                out.update({
                    "available": True,
                    "text": str(internal)[:600],
                    "bias": item.get("bias"),
                    "confidence": safe_float(item.get("decision_confidence"), score),
                    "source": "cached_ai_opinions",
                })
                return out
        # Lightweight template brief from quant (no extra HTTP if avoidable)
        flow = item.get("flow_score") or {}
        inv = item.get("invalidation") or {}
        parts = [
            f"{base}: score={score:.0f}, decision={item.get('decision') or item.get('decision_tag')}, bias={item.get('bias')}.",
            f"Flow={(flow.get('score') if flow.get('score') is not None else 'N/A')} ({flow.get('bias')}).",
            f"Taker={item.get('taker_buy_pct')} OIΔ={item.get('oi_delta')} Fund={item.get('funding')}.",
            f"Invalidation: {inv.get('price_display') or '—'} ({inv.get('reason') or ''}).",
        ]
        out.update({
            "available": True,
            "text": " ".join(parts)[:600],
            "bias": item.get("bias"),
            "confidence": safe_float(item.get("decision_confidence"), score),
            "source": "quant_brief_template",
        })
    except Exception as exc:
        out["text"] = f"brief_error: {exc}"
    return out


def _v62_enrich_item(x: dict) -> dict:
    """Attach CVD, basis, OI horizons, flow score, liquidity map, invalidation, history, AI brief."""
    if not isinstance(x, dict):
        return x
    try:
        sym = str(x.get("symbol") or "")
        price = safe_float(x.get("price_raw"), safe_float(x.get("price")))
        atr = safe_float(x.get("atr_raw"))
        # CVD
        cvd = _v62_fetch_cvd(sym) if sym else {"available": False}
        x["cvd"] = cvd
        # Basis / predicted funding
        basis = _v62_fetch_basis(sym) if sym else {"available": False}
        x["basis"] = basis
        if x.get("funding_value") is None and basis.get("last_funding") is not None:
            x["funding_value"] = basis.get("last_funding")
            if not x.get("funding") or x.get("funding") == "N/A":
                x["funding"] = f"{basis['last_funding']:+.4f}%"
        x["predicted_funding"] = basis.get("predicted_funding")
        # OI horizons
        oih = _v62_oi_horizons(sym) if sym else {}
        if oih.get("oi_change_1h") is not None:
            x["oi_change_1h"] = oih.get("oi_change_1h")
        if oih.get("oi_change_4h") is not None:
            x["oi_change_4h"] = oih.get("oi_change_4h")
        # Book imbalance
        depth = x.get("depth") if isinstance(x.get("depth"), dict) else {}
        book_im = _v62_optional_float(depth.get("imbalance"))
        # Flow score
        with _V62_FLOW_WEIGHTS_LOCK:
            w = dict(_V62_FLOW_WEIGHTS)
        flow = _v62_flow_score(
            taker_buy_pct=_v62_optional_float(x.get("taker_buy_pct")),
            oi_delta=_v62_optional_float(x.get("oi_delta")),
            book_imbalance=book_im,
            cvd_pct=_v62_optional_float(cvd.get("cvd_pct")) if cvd.get("available") else None,
            funding_pct=_v62_optional_float(x.get("funding_value")),
            weights=w,
        )
        x["flow_score"] = flow
        # Technical S/R for liquidity + invalidation
        tech = x.get("technical") if isinstance(x.get("technical"), dict) else {}
        sup = tech.get("support") or x.get("support")
        res = tech.get("resistance") or x.get("resistance")
        x["liquidity_map"] = _v62_liquidity_map(price or 0.0, depth, sup, res, atr)
        dec = str(x.get("decision") or x.get("decision_tag") or "WAIT")
        x["invalidation"] = _v62_invalidation(
            dec, price or 0.0,
            x.get("stop_loss_raw") or x.get("stop_loss") or x.get("sl"),
            sup, res, atr,
        )
        # History
        try:
            x["signal_history"] = _v62_history(sym, limit=8)
        except Exception:
            _swallow()
            x["signal_history"] = []
        # AI brief
        x["ai_brief"] = _v62_ai_brief(x)
        x["v62"] = True
        x["analytics_version"] = V62_VERSION
    except Exception as exc:
        LOGGER.debug("v62_enrich: %s", exc)
    return x


# ---- Hook enrich into finalize ----
_V62_PREV_FINALIZE = _dashboard_finalize_item

def _dashboard_finalize_item(item):  # noqa: F811
    x = _V62_PREV_FINALIZE(item)
    try:
        x = _v62_enrich_item(x) if isinstance(x, dict) else x
    except Exception:
        _swallow()
    return x


# ---- Snapshot on cache publish (best-effort wrap) ----
_V62_LAST_LABEL = 0.0
_V62_LAST_CALIB = 0.0

def _v62_on_scan_progress(items: list) -> None:
    global _V62_LAST_LABEL, _V62_LAST_CALIB
    if not items:
        return
    for it in items[:12]:
        if isinstance(it, dict) and it.get("symbol"):
            try:
                _v62_save_snapshot(it)
            except Exception:
                _swallow()
    now = time.time()
    if now - _V62_LAST_LABEL > 120:
        try:
            _v62_label_outcomes()
            _V62_LAST_LABEL = now
        except Exception:
            _swallow()
    if now - _V62_LAST_CALIB > 600:
        try:
            _v62_calibrate_flow_weights()
            _V62_LAST_CALIB = now
        except Exception:
            _swallow()


# Try wrap CACHE publisher if function exists
try:
    if "publish_scan_partial" in dir() or "publish_scan_partial" in globals():
        pass
except Exception:
    _swallow()

# Monkey-patch common publish path via CACHE setter pattern
_V62_ORIG_CACHE_SET = None

def _v62_watch_cache():
    """Periodic: when CACHE has data, snapshot top items + label outcomes."""
    global _V62_LAST_LABEL
    try:
        data = (CACHE.get("data") or []) if isinstance(CACHE, dict) else []
        if data:
            _v62_on_scan_progress(data)
    except Exception:
        _swallow()


# API routes
try:
    @app.get("/api/v62/history/<path:symbol>")
    def api_v62_history(symbol: str):
        return jsonify({"ok": True, "symbol": symbol, "history": _v62_history(symbol, limit=12)})

    @app.get("/api/v62/flow_weights")
    def api_v62_flow_weights():
        with _V62_FLOW_WEIGHTS_LOCK:
            w = dict(_V62_FLOW_WEIGHTS)
        return jsonify({"ok": True, "weights": w, "version": V62_VERSION})

    @app.post("/api/v62/calibrate")
    def api_v62_calibrate():
        return jsonify({"ok": True, **_v62_calibrate_flow_weights()})

    @app.get("/api/v62/status")
    def api_v62_status():
        return jsonify({
            "ok": True,
            "version": V62_VERSION,
            "build": V62_BUILD_ID,
            "weights": dict(_V62_FLOW_WEIGHTS),
            "features": [
                "cvd_aggtrades", "flow_score", "invalidation", "signal_history",
                "liquidity_map", "oi_1h_4h", "basis_premium", "predicted_funding",
                "outcome_labels", "ai_brief", "weight_calibration",
            ],
        })
except Exception as _v62_route_exc:
    LOGGER.warning("v62 routes: %s", _v62_route_exc)


# ---- UI: new tabs + richer Flow / Levels / History / AI brief ----
_V62_UI_JS = r"""
<script>
(function(){
  try{
    if(typeof CTABS!=='undefined'){
      var extra=[['hx','📜','History'],['lm','🗺️','Liquidity'],['cx','🔎','Context']];
      extra.forEach(function(t){
        if(!CTABS.some(function(x){return x[0]===t[0];})) CTABS.push(t);
      });
    }
    if(typeof TABS==='undefined') return;
    // Enhanced Flow
    var _oldFl=TABS.fl;
    TABS.fl=function(r,D){
      var h=_oldFl?_oldFl(r,D):'';
      var fs=D.flow_score||r.flow_score||{};
      var cvd=D.cvd||r.cvd||{};
      var bs=D.basis||r.basis||{};
      var sc=num(fs.score,50);
      var col=sc>=58?'#34d399':sc<=42?'#f87171':'#fbbf24';
      h+='<div class="v59-card neon-'+(sc>=58?'gr':sc<=42?'rd':'go')+'"><h3 class="v59-h"><i>💧</i>Flow Score</h3>';
      h+='<div style="display:flex;gap:12px;align-items:center;flex-wrap:wrap">'+gauge(sc,col,'Flow',90);
      h+='<div class="v59-grow">'+kv([
        ['Bias',fs.bias],['Live components',fs.live_components],
        ['CVD %',cvd.cvd_pct!=null?pct(cvd.cvd_pct,2):null],
        ['CVD source',cvd.source],
        ['Basis %',bs.basis_pct!=null?pct(bs.basis_pct,3):null],
        ['Pred. funding',bs.predicted_funding!=null?bs.predicted_funding+'%': (D.predicted_funding!=null?D.predicted_funding+'%':null)]
      )]+'</div></div>';
      if(cvd.available){
        h+=card('CVD (aggTrades)','📉',kv([
          ['CVD',cvd.cvd],['CVD %',pct(cvd.cvd_pct,2)],['Buy vol',cvd.buy_vol],['Sell vol',cvd.sell_vol],
          ['Trades',cvd.trades],['Source',cvd.source]
        ]));
      }
      return h;
    };
    // History tab
    TABS.hx=function(r,D){
      var hist=D.signal_history||r.signal_history||[];
      if(!hist.length) return empty('📜 No snapshot history yet — will fill after scans');
      var h=card('Signal history','📜','<div class="v60-scroll"><table class="v60-t"><thead><tr><th>Age</th><th>Dec</th><th>Score</th><th>Flow</th><th>Taker</th><th>OIΔ</th><th>Result</th></tr></thead><tbody>';
      hist.forEach(function(x){
        var oc=(x.outcomes||[])[0]||{};
        var res=oc.result||'—';
        var rc=res==='WIN'?'up':res==='LOSS'?'dn':'';
        h+='<tr><td>'+(x.age_min!=null?x.age_min+'m':'—')+'</td><td>'+esc(x.decision||'—')+'</td><td>'+(x.score!=null?Math.round(x.score):'—')+'</td><td>'+(x.flow_score!=null?Math.round(x.flow_score):'—')+'</td><td>'+(x.taker_buy_pct!=null?Math.round(x.taker_buy_pct)+'%':'—')+'</td><td>'+(x.oi_delta!=null?Number(x.oi_delta).toFixed(2):'—')+'</td><td class="'+rc+'">'+esc(res)+(oc.r_multiple!=null?' ('+Number(oc.r_multiple).toFixed(2)+'R)':'')+'</td></tr>';
      });
      h+='</tbody></table></div>';
      return h;
    };
    // Liquidity map tab
    TABS.lm=function(r,D){
      var lm=D.liquidity_map||r.liquidity_map||{};
      var inv=D.invalidation||r.invalidation||{};
      var levels=lm.levels||[];
      var h=card('Invalidation','⛔',kv([
        ['Decision',inv.decision],['Level',inv.price_display||inv.price],['Reason',inv.reason]
      ]));
      h+=card('Liquidity bias','🗺️',kv([
        ['Book bias',lm.bias],['ATR',lm.atr],
        ['Imbalance',lm.book&&lm.book.imbalance!=null?pct(num(lm.book.imbalance)*100,1):null],
        ['Bid vol',lm.book&&lm.book.bid_vol],['Ask vol',lm.book&&lm.book.ask_vol]
      ]));
      if(levels.length){
        h+='<div class="v59-card"><h3 class="v59-h"><i>📍</i>Nearest levels</h3><div class="v60-scroll"><table class="v60-t"><thead><tr><th>Side</th><th>Price</th><th>Dist %</th><th>Strength</th></tr></thead><tbody>';
        levels.forEach(function(L){
          h+='<tr><td>'+esc(L.side)+'</td><td>'+esc(String(L.price))+'</td><td>'+(L.dist_pct!=null?Number(L.dist_pct).toFixed(2)+'%':'—')+'</td><td>'+esc(L.strength||'—')+'</td></tr>';
        });
        h+='</tbody></table></div></div>';
      }
      return h;
    };
    // Context tab
    TABS.cx=function(r,D){
      var bs=D.basis||r.basis||{};
      var dq=D.data_quality||r.data_quality||{};
      var fs=D.flow_score||r.flow_score||{};
      var h=card('Market context','🔎',kv([
        ['BTC trend',D.btc_trend||r.btc_trend],
        ['Session',(D.session||r.session||{}).name||(D.session||r.session||{}).label],
        ['Data quality',dq.score!=null?dq.score:(dq.grade||null)],
        ['Price source',D.price_source||r.price_source],
        ['Analytics',D.analytics_version||r.analytics_version||'V62']
      ]));
      h+=card('Basis / Funding','💱',kv([
        ['Basis %',bs.basis_pct!=null?pct(bs.basis_pct,3):null],
        ['Mark',bs.mark_price],['Index',bs.index_price],
        ['Last funding',bs.last_funding!=null?bs.last_funding+'%':D.funding],
        ['Predicted funding',bs.predicted_funding!=null?bs.predicted_funding+'%':D.predicted_funding],
        ['Source',bs.source]
      ]));
      h+=card('OI horizons','📊',kv([
        ['OI Δ',D.oi_delta!=null?pct(D.oi_delta,2):null],
        ['OI 1h',D.oi_change_1h!=null?pct(D.oi_change_1h,2):null],
        ['OI 4h',D.oi_change_4h!=null?pct(D.oi_change_4h,2):null],
        ['Open interest',D.oi]
      ]));
      var bd=(fs.breakdown||{});
      var rows=Object.keys(bd).map(function(k){var x=bd[k]||{};return [k,(x.ok?'● ':'○ ')+ (x.signal!=null?Number(x.signal).toFixed(2):'—'),x.weight];});
      if(rows.length) h+=card('Flow breakdown','🧩',kv(rows.map(function(a){return [a[0],a[1]+'  w='+a[2]];})));
      return h;
    };
    // AI tab: prepend brief
    var _oldAi=TABS.ai;
    TABS.ai=function(r,D){
      var h='';
      var br=D.ai_brief||r.ai_brief||{};
      if(br.text){
        h+=card('AI Brief','🤖', '<div class="v59-sum">'+(br.available?'':'<span class="v59-sub">')+esc(br.text)+(br.available?'':'</span>')+
          '</div>'+kv([['Source',br.source],['Confidence',br.confidence],['Bias',br.bias]]));
      }
      h+=_oldAi?_oldAi(r,D):'';
      return h;
    };
    // Levels tab: add invalidation
    var _oldLv=TABS.lv;
    TABS.lv=function(r,D){
      var h=_oldLv?_oldLv(r,D):'';
      var inv=D.invalidation||r.invalidation||{};
      h+=card('Invalidation','⛔',kv([['Level',inv.price_display||inv.price],['Reason',inv.reason],['Decision',inv.decision]]));
      return h;
    };
  }catch(e){console&&console.warn&&console.warn('V62 UI',e)}
})();
</script>
"""

# Inject UI JS before closing body/markup if possible
try:
    if "_V59_UI_MARKUP" in globals() or True:
        pass
except Exception:
    _swallow()

# Initialize DB and log
try:
    _v62_init_db()
except Exception as _e:
    LOGGER.warning("V62 init db failed: %s", _e)

# Inject JS into markup
try:
    if "</body>" in _V59_UI_MARKUP:
        _V59_UI_MARKUP = _V59_UI_MARKUP.replace("</body>", _V62_UI_JS + "</body>", 1)
    elif "</script>" in _V59_UI_MARKUP:
        # append before last script end — safer: append at end
        _V59_UI_MARKUP = _V59_UI_MARKUP + _V62_UI_JS
    else:
        _V59_UI_MARKUP = _V59_UI_MARKUP + _V62_UI_JS
except Exception as _e:
    LOGGER.warning("V62 UI inject: %s", _e)

# Background soft tick for labeling (daemon)
def _v62_bg_loop():
    while True:
        try:
            time.sleep(90)
            _v62_watch_cache()
        except Exception:
            _swallow()
            time.sleep(120)

try:
    threading.Thread(target=_v62_bg_loop, name="v62-bg", daemon=True).start()
except Exception:
    _swallow()

LOGGER.info(
    "V62 full analytics armed · cvd/flow/invalidation/history/liquidity/basis/outcomes · gemini=%s coinglass=%s",
    bool(GEMINI_API_KEY), bool(COINGLASS_API_KEY),
)
