# [TITAN V77 layer] analytics/v71_pattern_validation - V71 pattern validation
# Original V76 source lines 28193-28343 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# V71: statistical validation of candle and chart patterns.
# De-overlapped events (min gap = horizon), forward return net of cost, Wilson 95% interval, t-test p-value,
# Benjamini-Hochberg FDR across patterns, 60/40 chronological split, pooled over several symbols.
# Entry = close of the signal bar; no look-ahead in detection (chart patterns re-detected on past data only).
# ============================================================
_V71_MEM: dict[str, dict] = {}
_V71_COST = 0.10   # percent, round trip (fees + slippage)
_V71_CL, _V71_CHL, _V71_Q, _V71_MINN, _V71_BARS = 5, 12, 0.10, 30, 1000


def _v71_symbols() -> list:
    syms: list = []
    try:
        with CACHE_LOCK:
            rows = list(CACHE.get("data") or [])
        syms = [str(r.get("symbol")) for r in rows if isinstance(r, dict) and r.get("symbol")][:8]
    except Exception:
        _swallow()
    return syms or ["BTC/USDT", "ETH/USDT", "SOL/USDT", "BNB/USDT"]


def _v71_events(symbol: str, tf: str) -> dict:
    """name -> list of (position_fraction, net_return_pct, kind) for one symbol."""
    df = fetch_klines(symbol, tf, _V71_BARS)
    out: dict = {}
    if df is None or len(df) < 260:
        return out
    n0 = len(df)
    raw: list = []
    _v64_candle_patterns(df, lookahead=_V71_CL, scan=n0, _raw=raw)
    if raw:
        found, c, n = raw
        last: dict = {}
        for i, name, bias in found:
            sg = 1 if bias == "صعودی" else -1 if bias == "نزولی" else 0
            if sg == 0 or i + _V71_CL >= n or i - last.get(name, -10 ** 9) < _V71_CL:
                continue
            last[name] = i
            out.setdefault(name, []).append((i / n, ((c[i + _V71_CL] / c[i] - 1) * 100) * sg - _V71_COST, "candle"))
    cl = df["close"].astype(float).to_numpy(); last = {}
    for e in range(160, n0 - _V71_CHL, 8):
        for p in _v64_chart_patterns(df.iloc[:e])[:2]:
            sg = 1 if p["bias"] == "صعودی" else -1 if p["bias"] == "نزولی" else 0
            nm = p["id"]
            if sg == 0 or (e - 1) - last.get(nm, -10 ** 9) < _V71_CHL:
                continue
            last[nm] = e - 1
            out.setdefault(nm, []).append(((e - 1) / n0, ((cl[e - 1 + _V71_CHL] / cl[e - 1] - 1) * 100) * sg - _V71_COST, "chart"))
    return out


def _v71_summarize(ev: dict) -> dict:
    rows = []
    for name, lst in ev.items():
        x = np.array([v[1] for v in lst], float); n = len(x)
        kind = lst[0][2]
        hits = int((x > 0).sum()); ph = hits / n; z = 1.96
        den = 1 + z * z / n; ctr = (ph + z * z / (2 * n)) / den; hw = z * math.sqrt(ph * (1 - ph) / n + z * z / (4 * n * n)) / den
        sd = float(x.std(ddof=1)) if n > 1 else 0.0
        t = float(x.mean() / (sd / math.sqrt(n))) if sd > 0 else 0.0
        p = math.erfc(abs(t) / math.sqrt(2)) if sd > 0 else 1.0
        srt = sorted(lst, key=lambda v: v[0]); cut = int(n * 0.6)
        te = np.array([v[1] for v in srt[cut:]], float)
        rows.append({"name": name, "kind": kind, "n": n, "hit": round(ph * 100, 1), "lo": round((ctr - hw) * 100, 1), "hi": round((ctr + hw) * 100, 1),
                     "mean": round(float(x.mean()), 3), "t": round(t, 2), "p": p,
                     "test_n": int(len(te)), "test_hit": round(float((te > 0).mean()) * 100, 1) if len(te) else None,
                     "test_mean": round(float(te.mean()), 3) if len(te) else None})
    elig = sorted([r for r in rows if r["n"] >= _V71_MINN], key=lambda r: r["p"])
    m = len(elig); kmax = 0
    for k, r in enumerate(elig, 1):
        if r["p"] <= k / m * _V71_Q:
            kmax = k
    passed = {id(r) for r in elig[:kmax]}
    for r in rows:
        r["fdr_pass"] = id(r) in passed
        if r["n"] < _V71_MINN:
            r["status"] = "کم‌نمونه"
        elif r["fdr_pass"] and r["mean"] > 0 and (r["test_mean"] or 0) > 0:
            r["status"] = "معتبر"
        else:
            r["status"] = "بی‌اثر"
        r["p"] = round(r["p"], 4)
    rows.sort(key=lambda r: (-r["n"]))
    return {"candle": [r for r in rows if r["kind"] == "candle"], "chart": [r for r in rows if r["kind"] == "chart"]}


def _v71_compute(tf: str) -> None:
    try:
        syms = _v71_symbols(); merged: dict = {}
        with ThreadPoolExecutor(max_workers=4) as ex:
            futs = [ex.submit(_v71_events, s, tf) for s in syms]
            for f in futs:
                try:
                    for k, v in f.result(timeout=120).items():
                        merged.setdefault(k, []).extend(v)
                except Exception:
                    _swallow()
        res = _v71_summarize(merged)
        res.update({"ok": True, "t": time.time(), "params": {"cl": _V71_CL, "chl": _V71_CHL, "cost": _V71_COST, "q": _V71_Q, "symbols": len(syms), "bars": _V71_BARS}})
        _V71_MEM[tf] = res
        _v64_save("val_" + tf, res)
    except Exception as exc:
        LOGGER.warning("v71 validation failed: %s", exc)
    finally:
        _V71_MEM.setdefault("busy", {})[tf] = False


def _v71_kick(tf: str, force: bool = False) -> bool:
    cur = _V71_MEM.get(tf)
    busy = _V71_MEM.setdefault("busy", {})
    if busy.get(tf) or (cur and not force and time.time() - cur["t"] < 6 * 3600):
        return False
    busy[tf] = True
    threading.Thread(target=_v71_compute, args=(tf,), daemon=True).start()
    return True


def _v71_status_map(tf: str, kind: str) -> dict:
    cur = _V71_MEM.get(tf) or {}
    return {r["name"]: r["status"] for r in cur.get(kind, [])}


def _v71_annotate(cp: dict, tf: str) -> dict:
    try:
        sm = _v71_status_map(tf, "candle")
        for s in cp.get("stats", []):
            s["status"] = sm.get(s["name"])
    except Exception:
        _swallow()
    return cp


@app.get("/api/v71/validate")
def api_v71_validate():
    tf = str(request.args.get("timeframe", "1h") or "1h")
    if tf not in {"15m", "1h", "4h", "1d"}:
        tf = "1h"
    try:
        if str(request.args.get("force", "0")) == "1":
            _v71_kick(tf, True)
        cur = _V71_MEM.get(tf)
        if not cur:
            _v71_kick(tf)
            return jsonify({"ok": True, "computing": True})
        _v71_kick(tf)
        return jsonify(dict(cur, age_min=round((time.time() - cur["t"]) / 60, 1)))
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)[:200]}), 500
