# [TITAN V77 layer] analytics/v69_probability_cone - V69 probability cone / calibration
# Original V76 source lines 28010-28122 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# V69: probability cone (bootstrap quantiles) + calibration tracking (coverage / pinball loss).
# Analysis only. The ledger lives in the LLL database.
# ============================================================
_V69_READY = False


def _v69_cone(df, path_closes, horizon: int = 48, n: int = 500) -> Optional[dict]:
    """10/25/50/75/90% bands for the next `horizon` closes.

    Bootstrap of the last ~250 demeaned log-returns, scaled by recent/sample volatility
    (clamped 0.6-1.8), plus half of the per-step drift implied by the forecast path.
    Ignores volatility clustering and jumps, so real tails can be wider than shown.
    """
    try:
        c = df["close"].astype(float).to_numpy()
        lr = np.diff(np.log(c))[-250:]
        if len(lr) < 40:
            return None
        lr = lr - lr.mean()
        scale = float(clamp(np.sqrt(np.mean(lr[-20:] ** 2)) / (lr.std() or 1e-9), 0.6, 1.8))
        last = float(c[-1])
        drift = np.zeros(horizon)
        if path_closes:
            d = np.diff(np.log(np.r_[last, np.array(path_closes[:horizon], float)]))
            drift[:len(d)] = d
        rng = np.random.default_rng(int(abs(last) * 1000) % (2 ** 32))
        steps = lr[rng.integers(0, len(lr), (n, horizon))] * scale + drift * 0.5
        paths = last * np.exp(np.cumsum(steps, axis=1))
        qs = np.percentile(paths, [10, 25, 50, 75, 90], axis=0)
        out = {k: [round(float(x), 8) for x in qs[i]] for i, k in enumerate(["q10", "q25", "q50", "q75", "q90"])}
        out["vol_scale"] = round(scale, 2)
        return out
    except Exception as exc:
        LOGGER.debug("v69 cone failed: %s", exc)
        return None


def _v69_init() -> None:
    global _V69_READY
    if _V69_READY:
        return
    with DB_LOCK, db_conn() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS v69_cone_ledger(
            id INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL NOT NULL, symbol TEXT NOT NULL, timeframe TEXT NOT NULL,
            last REAL NOT NULL, q10 TEXT, q50 TEXT, q90 TEXT, horizon_min INTEGER NOT NULL,
            outcome TEXT DEFAULT 'PENDING', coverage REAL, pinball REAL, evaluated_at REAL)""")
        con.execute("CREATE INDEX IF NOT EXISTS idx_v69_pending ON v69_cone_ledger(outcome, created_at)")
    _V69_READY = True


def _v69_record(symbol: str, tf: str, cone: Optional[dict], last: float) -> None:
    """One cone per symbol/timeframe per 12 candles, so samples overlap less."""
    try:
        if not cone or last <= 0:
            return
        _v69_init()
        now = time.time(); tfm = _V68_TFMIN.get(tf, 60)
        with DB_LOCK, db_conn() as con:
            prev = con.execute("SELECT created_at FROM v69_cone_ledger WHERE symbol=? AND timeframe=? ORDER BY created_at DESC LIMIT 1", (symbol, tf)).fetchone()
            if prev and now - float(prev["created_at"]) < tfm * 12 * 60:
                return
            con.execute("INSERT INTO v69_cone_ledger(created_at,symbol,timeframe,last,q10,q50,q90,horizon_min) VALUES(?,?,?,?,?,?,?,?)",
                        (now, symbol, tf, last, json.dumps(cone["q10"]), json.dumps(cone["q50"]), json.dumps(cone["q90"]), tfm * 24))
    except Exception:
        _swallow()


def _v69_label(max_rows: int = 10) -> int:
    _v69_init()
    done = 0
    with DB_LOCK, db_conn() as con:
        rows = con.execute("SELECT * FROM v69_cone_ledger WHERE outcome='PENDING' AND created_at+horizon_min*60<=? ORDER BY created_at LIMIT ?", (time.time(), max_rows)).fetchall()
    for r in rows:
        try:
            s = int(r["created_at"] * 1000); tfm = _V68_TFMIN.get(r["timeframe"], 60)
            df = fetch_klines(r["symbol"], r["timeframe"], 1000, start_ms=s, end_ms=s + 26 * tfm * 60000)
            if df is None or len(df) < 24:
                continue
            y = df["close"].astype(float).to_numpy()[:24]
            q10, q50, q90 = (np.array(json.loads(r[k])) for k in ("q10", "q50", "q90"))
            cov = float(np.mean((y >= q10) & (y <= q90))) * 100
            pin = float(np.mean([np.mean(np.maximum(q * (y - p), (q - 1) * (y - p))) for q, p in ((0.1, q10), (0.5, q50), (0.9, q90))])) / float(r["last"]) * 100
            with DB_LOCK, db_conn() as con:
                con.execute("UPDATE v69_cone_ledger SET outcome='DONE',coverage=?,pinball=?,evaluated_at=? WHERE id=?", (cov, pin, time.time(), r["id"]))
            done += 1
        except Exception:
            _swallow()
    return done


@app.get("/api/v69/cone-stats")
def api_v69_cone_stats():
    try:
        _v69_init(); _v68_kick()
        with DB_LOCK, db_conn() as con:
            rows = con.execute("SELECT timeframe,coverage,pinball FROM v69_cone_ledger WHERE outcome='DONE'").fetchall()
            pend = con.execute("SELECT COUNT(*) c FROM v69_cone_ledger WHERE outcome='PENDING'").fetchone()["c"]
        n = len(rows)
        cov = round(sum(r["coverage"] for r in rows) / n, 1) if n else None
        verdict = "کالیبره"
        if cov is not None:
            verdict = "بیش‌ازحد باریک" if cov < 70 else "بیش‌ازحد پهن" if cov > 90 else "کالیبره"
        by: dict = {}
        for r in rows:
            by.setdefault(r["timeframe"], []).append(float(r["coverage"]))
        return jsonify({"ok": True, "n": n, "pending": int(pend), "coverage": cov, "target": 80,
                        "pinball": round(sum(r["pinball"] for r in rows) / n, 3) if n else None, "verdict": verdict,
                        "by_tf": [{"k": k, "n": len(v), "cov": round(sum(v) / len(v), 1)} for k, v in by.items()]})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)[:200]}), 500
