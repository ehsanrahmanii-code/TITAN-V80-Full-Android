# [TITAN V77 layer] analytics/v68_shadow_ledger - V68 shadow ledger / source accuracy
# Original V76 source lines 27840-28009 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# V68: shadow ledger for the final verdict + per-source accuracy + learned weights.
# Display/analysis layer only: never changes engine signals or its learning ledger.
# Everything lives in the LLL database (DB_PATH).
# ============================================================
_V68_READY = False
_V68_W: dict[str, Any] = {"t": 0.0, "w": None, "mode": "prior"}
_V68_LAST = [0.0]
_V68_WC: dict[str, tuple] = {}
_V68_PRIOR = {"موتور TITAN": 0.40, "الگوی شمعی": 0.10, "الگوی نموداری": 0.10, "پیش‌بینی ۴۸ شمع": 0.15, "جریان CoinGlass": 0.15, "Gemini": 0.25}
_V68_TFMIN = {"15m": 15, "1h": 60, "4h": 240, "1d": 1440}


def _v68_init() -> None:
    global _V68_READY
    if _V68_READY:
        return
    with DB_LOCK, db_conn() as con:
        con.execute("""CREATE TABLE IF NOT EXISTS v68_final_ledger(
            id INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL NOT NULL, symbol TEXT NOT NULL,
            timeframe TEXT NOT NULL, decision TEXT NOT NULL, score REAL, conf REAL, price REAL NOT NULL,
            horizon_min INTEGER NOT NULL, parts TEXT, outcome TEXT DEFAULT 'PENDING', return_pct REAL,
            mfe REAL, mae REAL, evaluated_at REAL)""")
        con.execute("CREATE INDEX IF NOT EXISTS idx_v68_pending ON v68_final_ledger(outcome, created_at)")
        try:
            con.execute("ALTER TABLE v68_final_ledger ADD COLUMN regime TEXT")
        except Exception:
            _swallow()
    _V68_READY = True


def _v68_record(symbol: str, tf: str, out: dict, price: float) -> Optional[int]:
    """Log one final verdict (max one per symbol/timeframe per 15 minutes)."""
    try:
        _v68_init()
        now = time.time()
        with DB_LOCK, db_conn() as con:
            last = con.execute("SELECT created_at FROM v68_final_ledger WHERE symbol=? AND timeframe=? ORDER BY created_at DESC LIMIT 1", (symbol, tf)).fetchone()
            if last and now - float(last["created_at"]) < 900:
                return None
            cur = con.execute("INSERT INTO v68_final_ledger(created_at,symbol,timeframe,decision,score,conf,price,horizon_min,parts,regime) VALUES(?,?,?,?,?,?,?,?,?,?)",
                              (now, symbol, tf, out["decision"], out["score"], out["conf"], price, _V68_TFMIN.get(tf, 60) * 8,
                               json.dumps(out["parts"], ensure_ascii=False), out.get("regime")))
            return int(cur.lastrowid)
    except Exception:
        _swallow()
        return None


def _v68_label(max_rows: int = 25) -> int:
    """Resolve pending verdicts once their horizon (8 candles) has passed, using real klines."""
    _v68_init()
    done = 0
    with DB_LOCK, db_conn() as con:
        rows = con.execute("SELECT id,created_at,symbol,timeframe,decision,price,horizon_min FROM v68_final_ledger WHERE outcome='PENDING' AND created_at+horizon_min*60<=? ORDER BY created_at LIMIT ?", (time.time(), max_rows)).fetchall()
    for r in rows:
        try:
            s = int(r["created_at"] * 1000)
            df = fetch_klines(r["symbol"], r["timeframe"], 1000, start_ms=s, end_ms=s + int(r["horizon_min"]) * 60000)
            if df is None or len(df) < 2:
                continue
            px = float(r["price"]); end = float(df["close"].iloc[-1]); hi = float(df["high"].max()); lo = float(df["low"].min())
            sg = 1 if r["decision"] == "LONG" else -1 if r["decision"] == "SHORT" else 0
            ret = (end / px - 1) * 100
            if sg == 0:
                outcome = "WAIT"
            else:
                sr = ret * sg
                outcome = "WIN" if sr > 0.05 else "LOSS" if sr < -0.05 else "FLAT"
            mfe = (hi / px - 1) * 100 if sg >= 0 else (1 - lo / px) * 100
            mae = (lo / px - 1) * 100 if sg >= 0 else -(hi / px - 1) * 100
            with DB_LOCK, db_conn() as con:
                con.execute("UPDATE v68_final_ledger SET outcome=?,return_pct=?,mfe=?,mae=?,evaluated_at=? WHERE id=?", (outcome, ret, mfe, mae, time.time(), r["id"]))
            done += 1
        except Exception:
            _swallow()
    return done


def _v68_kick() -> None:
    if time.time() - _V68_LAST[0] < 300:
        return
    _V68_LAST[0] = time.time()
    threading.Thread(target=lambda: (_v68_label(), _v69_label()), daemon=True).start()


def _v68_stats(regime: Optional[str] = None) -> dict[str, Any]:
    _v68_init()
    with DB_LOCK, db_conn() as con:
        rows = con.execute("SELECT parts,return_pct,regime FROM v68_final_ledger WHERE outcome!='PENDING' AND return_pct IS NOT NULL AND (? IS NULL OR regime=?) ORDER BY created_at DESC LIMIT 3000", (regime, regime)).fetchall()
        cnt = {r["outcome"]: int(r["c"]) for r in con.execute("SELECT outcome,COUNT(*) c FROM v68_final_ledger GROUP BY outcome").fetchall()}
        rec = con.execute("SELECT symbol,timeframe,created_at,decision,score,outcome,return_pct FROM v68_final_ledger ORDER BY created_at DESC LIMIT 15").fetchall()
    comps: dict[str, dict] = {}
    gem = {"n": 0, "hits": 0, "brier": 0.0, "conf": 0.0}
    byr: dict = {}
    for r in rows:
        ret = float(r["return_pct"])
        rg = r["regime"] or "—"
        if abs(ret) <= 0.05:
            continue  # flat market carries no direction information
        for p in json.loads(r["parts"] or "[]"):
            v = float(p.get("val", 0))
            if abs(v) < 0.1:
                continue
            c = comps.setdefault(p["name"], {"name": p["name"], "n": 0, "hits": 0})
            hit = 1 if (v > 0) == (ret > 0) else 0
            c["n"] += 1; c["hits"] += hit
            b2 = byr.setdefault((rg, p["name"]), [0, 0]); b2[0] += 1; b2[1] += hit
            if p["name"] == "Gemini":
                cf = min(1.0, abs(v)); gem["n"] += 1; gem["hits"] += hit; gem["brier"] += (cf - hit) ** 2; gem["conf"] += cf
    for c in comps.values():
        c["hit"] = round(c["hits"] / c["n"] * 100, 1)
        c["shrunk"] = (c["hits"] + 5) / (c["n"] + 10)  # Bayesian shrink toward 50%
        c["edge"] = round((c["shrunk"] - 0.5) * 100, 1)
    g = {"n": gem["n"], "hit": round(gem["hits"] / gem["n"] * 100, 1) if gem["n"] else None,
         "brier": round(gem["brier"] / gem["n"], 3) if gem["n"] else None,
         "avg_conf": round(gem["conf"] / gem["n"] * 100, 1) if gem["n"] else None}
    w, l = cnt.get("WIN", 0), cnt.get("LOSS", 0)
    return {"counts": cnt, "win_rate": round(w / (w + l) * 100, 1) if w + l else None,
            "components": sorted(comps.values(), key=lambda z: -z["n"]), "gemini": g,
            "by_regime": [{"regime": k[0], "name": k[1], "n": v[0], "hit": round(v[1] / v[0] * 100, 1)} for k, v in sorted(byr.items(), key=lambda z: -z[1][0])],
            "recent": [{"s": r["symbol"], "tf": r["timeframe"], "t": float(r["created_at"]), "d": r["decision"], "score": r["score"], "o": r["outcome"], "ret": None if r["return_pct"] is None else round(float(r["return_pct"]), 2)} for r in rec]}


def _v68_calc(regime: Optional[str]) -> tuple:
    w = dict(_V68_PRIOR)
    use = [c for c in _v68_stats(regime)["components"] if c["n"] >= 30 and c["name"] in _V68_PRIOR]
    if len(use) < 3:
        return w, "prior"
    raw = {c["name"]: max(0.02, c["shrunk"] - 0.5) for c in use}
    tot = sum(raw.values()); mass = sum(_V68_PRIOR[k] for k in raw)
    for k, v in raw.items():
        w[k] = clamp(0.5 * _V68_PRIOR[k] + 0.5 * v / tot * mass, 0.05, 0.45)
    w["Gemini"] = min(w["Gemini"], 0.25)
    return w, "learned"


def _v68_weights(regime: Optional[str] = None) -> tuple:
    """Weights for the current regime when it has >=3 sources with >=30 samples; else global; else prior."""
    now = time.time()
    key = regime or "*"
    hit = _V68_WC.get(key)
    if hit and now - hit[0] < 600:
        return hit[1], hit[2]
    w, mode = dict(_V68_PRIOR), "prior"
    try:
        if regime:
            w, mode = _v68_calc(regime)
            if mode == "learned":
                mode = "learned:" + regime
        if mode == "prior":
            w, mode = _v68_calc(None)
    except Exception:
        _swallow()
        w, mode = dict(_V68_PRIOR), "prior"
    _V68_WC[key] = (now, w, mode)
    return w, mode


@app.get("/api/v68/learning")
def api_v68_learning():
    try:
        _v68_kick()
        st = _v68_stats(); w, mode = _v68_weights(None)
        return jsonify({"ok": True, **st, "weights": w, "mode": mode, "prior": _V68_PRIOR})
    except Exception as exc:
        LOGGER.warning("v68 learning failed: %s", exc)
        return jsonify({"ok": False, "error": str(exc)[:200]}), 500
