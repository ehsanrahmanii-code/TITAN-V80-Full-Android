# [TITAN V77 layer] analytics/v70_market_regime - V70 market regime
# Original V76 source lines 28123-28192 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# V70: market regime (ADX + efficiency ratio + volatility percentile) and regime-aware pattern confidence.
# The adjustment factors are heuristics; the learning ledger measures accuracy per regime to confirm them.
# ============================================================
_V70_FA = {"trend_up": "روند صعودی", "trend_down": "روند نزولی", "range": "رنج", "volatile": "نوسان بالا", "transition": "گذار"}


def _v70_regime(df) -> Optional[dict]:
    try:
        h = df["high"].astype(float).to_numpy(); l = df["low"].astype(float).to_numpy(); c = df["close"].astype(float).to_numpy()
        if len(c) < 80:
            return None
        up = h[1:] - h[:-1]; dn = l[:-1] - l[1:]
        pdm = np.where((up > dn) & (up > 0), up, 0.0); mdm = np.where((dn > up) & (dn > 0), dn, 0.0)
        tr = np.maximum(h[1:] - l[1:], np.maximum(abs(h[1:] - c[:-1]), abs(l[1:] - c[:-1])))

        def wil(x, p=14):
            o = np.zeros(len(x)); o[p - 1] = x[:p].sum()
            for i in range(p, len(x)):
                o[i] = o[i - 1] - o[i - 1] / p + x[i]
            return o
        atr = np.maximum(wil(tr), 1e-12)
        pdi = 100 * wil(pdm) / atr; mdi = 100 * wil(mdm) / atr
        dx = 100 * abs(pdi - mdi) / np.maximum(pdi + mdi, 1e-12)
        adx = np.zeros(len(dx)); adx[26] = dx[13:27].mean()
        for i in range(27, len(dx)):
            adx[i] = (adx[i - 1] * 13 + dx[i]) / 14
        a = float(adx[-1])
        er = float(abs(c[-1] - c[-31]) / max(np.abs(np.diff(c[-31:])).sum(), 1e-12))
        roll = pd.Series(np.diff(np.log(c))).rolling(20).std().dropna()
        vp = float((roll < roll.iloc[-1]).mean() * 100)
        slope = float(pd.Series(c).ewm(span=20).mean().iloc[-1] - pd.Series(c).ewm(span=50).mean().iloc[-1])
        if a >= 25 and er >= 0.30:
            key = "trend_up" if pdi[-1] > mdi[-1] else "trend_down"
        elif vp >= 85:
            key = "volatile"
        elif (a < 20 and er < 0.25) or (er < 0.20 and a < 30):
            key = "range"
        else:
            key = "transition"
        return {"key": key, "fa": _V70_FA[key], "adx": round(a, 1), "er": round(er, 2), "vol_pct": int(vp),
                "slope": "↑" if slope > 0 else "↓", "confidence": int(clamp(40 + abs(a - 22) * 1.5, 40, 95))}
    except Exception as exc:
        LOGGER.debug("v70 regime failed: %s", exc)
        return None


def _v70_adjust(pats: list, reg: Optional[dict], val: Optional[dict] = None) -> list:
    k = (reg or {}).get("key"); out = []
    for p in pats or []:
        q = dict(p); f = 1.0
        cont = q.get("id") in ("پرچم صعودی", "پرچم نزولی", "مثلث صعودی", "مثلث نزولی")
        if k == "trend_up":
            f = 1.10 if q.get("bias") == "صعودی" else 0.85 if q.get("bias") == "نزولی" else 1.0
        elif k == "trend_down":
            f = 1.10 if q.get("bias") == "نزولی" else 0.85 if q.get("bias") == "صعودی" else 1.0
        elif k == "range" and cont:
            f = 0.80
        elif k == "volatile":
            f = 0.85
        sv = (val or {}).get(q.get("id"))
        f *= 1.1 if sv == "معتبر" else 0.8 if sv == "بی‌اثر" else 1.0
        q["validation"] = sv
        q["confidence_raw"] = q.get("confidence", 50)
        q["confidence"] = int(clamp(q["confidence_raw"] * f, 30, 95)); q["regime_factor"] = round(f, 2)
        out.append(q)
    out.sort(key=lambda z: -z["confidence"])
    return out
