# [TITAN V77 layer] decision/neural_synapse_v9 - V9 neural synapse
# Original V76 source lines 3455-3810 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# TITAN V9 — NEURAL SYNAPSE (central nervous system)
# Connects: TF scores · structure · regime · confluence · precision ·
# patterns · forecast path · derivatives · AI ensemble · DQ · ladder ·
# calibration · portfolio. Produces one coherent decision + confidence.
# Analysis-only. Never invents edge — only fuses existing evidence.
# ============================================================

class TitanNeuralSynapseV9:
    """Advanced multi-layer fusion with explainable weighted synapses."""

    # Layer weights (sum ≈ 1.0) — tuned for reliability over aggressiveness
    W = {
        # V76: forecast is real decision input (range/history/analogue), AI hard-capped
        "tf_spine": 0.18,
        "structure": 0.10,
        "regime": 0.08,
        "confluence": 0.10,
        "precision": 0.11,
        "pattern": 0.06,
        "forecast": 0.14,       # V76 elevated — real multi-factor path
        "derivatives": 0.08,
        "ai": 0.07,             # <= TITAN_AI_MAX_WEIGHT effective
        "calibration": 0.08,
    }

    def _side_from_score(self, sc: float) -> str:
        # Tuned V28: 54/46 — fewer missed edges than 56/44, still avoids noise
        if sc >= 54:
            return "LONG"
        if sc <= 46:
            return "SHORT"
        return "WAIT"

    def _tf_vector(self, tf_scores: dict) -> tuple[float, str, float]:
        if not tf_scores:
            return 50.0, "WAIT", 0.0
        weights = {"15m": 0.18, "1h": 0.30, "4h": 0.28, "1d": 0.24}  # V28 balanced actionable
        keys = [k for k in weights if k in tf_scores]
        if not keys:
            vals = list(tf_scores.values())
            avg = float(sum(vals) / len(vals))
            return avg, self._side_from_score(avg), abs(avg - 50.0)
        wsum = sum(weights[k] for k in keys)
        avg = sum(safe_float(tf_scores[k], 50) * weights[k] for k in keys) / max(wsum, 1e-9)
        # agreement among TFs
        sides = [self._side_from_score(safe_float(tf_scores[k], 50)) for k in keys]
        maj = max(set(sides), key=sides.count)
        agree = sides.count(maj) / len(sides)
        return float(avg), maj, float(agree * abs(avg - 50.0))

    def _pattern_signal(self, patterns: dict) -> tuple[float, str]:
        primary = (patterns or {}).get("primary") or {}
        if not primary:
            return 50.0, "WAIT"
        bias = str((primary.get("guide") or {}).get("bias", "خنثی"))
        conf = safe_float(primary.get("confidence"), 50) / 100.0
        if bias == "صعودی":
            return 50.0 + 18.0 * conf, "LONG"
        if bias == "نزولی":
            return 50.0 - 18.0 * conf, "SHORT"
        return 50.0, "WAIT"

    def _forecast_signal(self, forecast: dict, path_stats: dict) -> tuple[float, str]:
        """V76: real path signal — move, strength, range position, analogue, accuracy scale."""
        if not forecast or not forecast.get("ok"):
            return 50.0, "WAIT"
        overall = str(forecast.get("overall_bias", "خنثی"))
        move = safe_float(forecast.get("expected_move_pct"), 0)
        strength = safe_float(forecast.get("path_strength"), 0)
        scale = safe_float((path_stats or {}).get("weight_scale"), 0.45)
        samples = safe_float((path_stats or {}).get("samples"), 0)
        # When we have enough path history, trust scale more; cold-start still contributes
        if samples >= float(globals().get("TITAN_FORECAST_MIN_SAMPLES_HARD", 10)):
            scale = max(scale, 0.55)
        else:
            scale = max(0.40, min(scale, 0.70))
        range_pos = safe_float(forecast.get("range_position"), 0.5)  # 0=low, 1=high of recent range
        analogue_corr = safe_float(forecast.get("analogue_corr"), 0)
        sr_bias = safe_float(forecast.get("sr_bias"), 0)  # -1..+1 from S/R interaction
        # Multi-factor tilt (bounded)
        tilt = float(np.clip(
            move * 3.2
            + strength * 0.22
            + analogue_corr * 8.0
            + sr_bias * 6.0
            + (0.5 - range_pos) * 4.0,  # mean-reversion lean near range extremes
            -22, 22
        )) * scale
        sc = 50.0 + tilt
        if overall == "صعودی" and sc >= 52:
            side = "LONG"
        elif overall == "نزولی" and sc <= 48:
            side = "SHORT"
        else:
            side = "WAIT"
        return float(clamp(sc, 5, 95)), side

    def _deriv_signal(self, derivatives: dict, wanted_hint: int = 0) -> tuple[float, str]:
        sc = 50.0
        funding = derivatives.get("funding_value")
        oi_d = safe_float(derivatives.get("oi_delta"), 0)
        ls_ratio = safe_float(derivatives.get("long_short_ratio"), 1.0)
        taker_buy = safe_float(derivatives.get("taker_buy_pct"), float("nan"))
        if not math.isfinite(taker_buy):
            taker_buy = 50.0  # neutral only when data missing; marked unavailable upstream
        if funding is not None:
            f = safe_float(funding, 0)
            # extreme funding is contrarian
            if f >= 0.06:
                sc -= 6
            elif f <= -0.06:
                sc += 6
            elif f >= 0.025:
                sc -= 2.5
            elif f <= -0.025:
                sc += 2.5
        if oi_d > 1.5:
            sc += 3.0 if wanted_hint >= 0 else -3.0
        elif oi_d < -1.5:
            sc -= 2.0 if wanted_hint >= 0 else 2.0
        # crowding
        if ls_ratio >= 1.6:
            sc -= 5  # long crowded → short bias
        elif ls_ratio <= 0.65:
            sc += 5
        # taker flow
        sc += float(np.clip((taker_buy - 50) * 0.12, -5, 5))
        sc = float(clamp(sc, 10, 90))
        return sc, self._side_from_score(sc)

    def _ai_signal(self, fusion: dict, ai_opinions: dict) -> tuple[float, str, float]:
        maj = str((fusion or {}).get("ai_majority") or "WAIT")
        agree = safe_float((fusion or {}).get("ai_agreement"), 0)
        if maj not in {"LONG", "SHORT", "WAIT"}:
            # parse from opinions if needed
            votes = []
            for key in ("gemini", "openai", "grok", "claude", "deepseek", "internal"):
                text = str((ai_opinions or {}).get(key) or "")
                if not text:
                    continue
                v = extract_structured_ai_vote(text)
                votes.append(v.get("side", "WAIT"))
            if votes:
                maj = max(set(votes), key=votes.count)
                agree = votes.count(maj) / len(votes) * 100.0
        if maj == "LONG":
            sc = 50.0 + min(28.0, agree * 0.28)
        elif maj == "SHORT":
            sc = 50.0 - min(28.0, agree * 0.28)
        else:
            sc = 50.0
        return float(clamp(sc, 15, 85)), maj if maj in {"LONG", "SHORT", "WAIT"} else "WAIT", float(agree)

    def fuse(self, *, tf_scores: dict, structure: dict, regime: dict, confluence: dict,
             precision: dict, patterns: dict, forecast: dict, path_stats: dict,
             derivatives: dict, fusion: dict, ai_opinions: dict,
             data_quality: dict, ladder: dict, calib: dict,
             quant_bias: str, quant_score: float) -> dict:
        """Full neural fuse → side, confidence, layer map, vetoes."""
        layers: dict[str, Any] = {}
        reasons: list[str] = []
        vetoes: list[str] = []

        tf_sc, tf_side, tf_agree_mag = self._tf_vector(tf_scores or {})
        layers["tf_spine"] = {"score": round(tf_sc, 1), "side": tf_side, "weight": self.W["tf_spine"]}

        struct_bias = str((structure or {}).get("bias", "خنثی"))
        struct_conf = safe_float((structure or {}).get("confirmation_score"), 50)
        if struct_bias == "صعودی":
            st_sc = 50 + min(22, struct_conf * 0.25)
            st_side = "LONG"
        elif struct_bias == "نزولی":
            st_sc = 50 - min(22, struct_conf * 0.25)
            st_side = "SHORT"
        else:
            st_sc, st_side = 50.0, "WAIT"
        layers["structure"] = {"score": round(st_sc, 1), "side": st_side, "weight": self.W["structure"]}

        reg_name = str((regime or {}).get("regime", "unknown")).lower()
        if "up" in reg_name or "bull" in reg_name:
            rg_sc, rg_side = 62.0, "LONG"
        elif "down" in reg_name or "bear" in reg_name:
            rg_sc, rg_side = 38.0, "SHORT"
        elif "high_vol" in reg_name:
            rg_sc, rg_side = 50.0, "WAIT"
            reasons.append("رژیم پرنوسان → کاهش اطمینان")
        else:
            rg_sc, rg_side = 50.0, "WAIT"
        layers["regime"] = {"score": rg_sc, "side": rg_side, "weight": self.W["regime"]}

        conf_sc = safe_float((confluence or {}).get("score"), 50)
        layers["confluence"] = {"score": conf_sc, "side": self._side_from_score(conf_sc), "weight": self.W["confluence"]}

        prec_sc = safe_float((precision or {}).get("score"), 50)
        layers["precision"] = {"score": prec_sc, "side": self._side_from_score(prec_sc), "weight": self.W["precision"]}
        for b in (precision or {}).get("hard_blocks") or []:
            vetoes.append(f"precision:{b}")

        p_sc, p_side = self._pattern_signal(patterns or {})
        layers["pattern"] = {"score": round(p_sc, 1), "side": p_side, "weight": self.W["pattern"]}

        f_sc, f_side = self._forecast_signal(forecast or {}, path_stats or {})
        layers["forecast"] = {"score": round(f_sc, 1), "side": f_side, "weight": self.W["forecast"]}

        wanted_hint = 1 if quant_bias == "صعودی" else -1 if quant_bias == "نزولی" else 0
        d_sc, d_side = self._deriv_signal(derivatives or {}, wanted_hint)
        layers["derivatives"] = {"score": round(d_sc, 1), "side": d_side, "weight": self.W["derivatives"]}

        a_sc, a_side, a_agree = self._ai_signal(fusion or {}, ai_opinions or {})
        layers["ai"] = {"score": round(a_sc, 1), "side": a_side, "weight": self.W["ai"], "agreement": a_agree}

        cal_sc = safe_float((calib or {}).get("calibrated"), safe_float((fusion or {}).get("success_probability"), 50))
        # map calibrated success (around 50-80) to directional lean via quant
        if quant_bias == "صعودی":
            c_sc = 40 + cal_sc * 0.35
        elif quant_bias == "نزولی":
            c_sc = 60 - cal_sc * 0.35
        else:
            c_sc = 50.0
        layers["calibration"] = {"score": round(c_sc, 1), "side": self._side_from_score(c_sc), "weight": self.W["calibration"]}

        # V76: hard-cap AI layer weight so quant cannot be dominated
        try:
            ai_cap = float(globals().get("TITAN_AI_MAX_WEIGHT", 0.12))
            if "ai" in layers:
                layers["ai"]["weight"] = min(safe_float(layers["ai"].get("weight"), 0.07), ai_cap)
            fc_cap = float(globals().get("TITAN_FORECAST_MAX_WEIGHT", 0.14))
            if "forecast" in layers:
                # allow forecast up to configured max (real path)
                layers["forecast"]["weight"] = min(
                    max(safe_float(layers["forecast"].get("weight"), 0.14), 0.10), fc_cap
                )
        except Exception:
            _swallow()

        # Weighted neural score
        neural_score = 0.0
        w_total = 0.0
        for name, layer in layers.items():
            w = float(layer.get("weight") or 0)
            neural_score += safe_float(layer.get("score"), 50) * w
            w_total += w
        neural_score = neural_score / max(w_total, 1e-9)

        # Blend with quant spine (prevents AI-only drift)
        quant_sc = safe_float(quant_score, 50)
        neural_score = 0.62 * neural_score + 0.38 * quant_sc
        neural_score = float(clamp(neural_score, 0, 100))

        # Side vote among layers (weighted)
        long_w = short_w = wait_w = 0.0
        for layer in layers.values():
            w = float(layer.get("weight") or 0)
            s = layer.get("side")
            if s == "LONG":
                long_w += w
            elif s == "SHORT":
                short_w += w
            else:
                wait_w += w
        # V59.2: soften residual WAIT — allow lean when directional layers dominate
        if long_w > short_w and long_w >= wait_w * 0.55:
            side = "LONG"
        elif short_w > long_w and short_w >= wait_w * 0.55:
            side = "SHORT"
        elif long_w > short_w * 1.08 and neural_score >= 52:
            side = "LONG"
        elif short_w > long_w * 1.08 and neural_score <= 48:
            side = "SHORT"
        elif long_w > short_w and neural_score >= 56:
            side = "LONG"
        elif short_w > long_w and neural_score <= 44:
            side = "SHORT"
        else:
            side = "WAIT"

        # Hard gates — only true hard_veto kills; soft DQ lowers confidence
        dq = data_quality or {}
        if dq.get("hard_veto"):
            side = "WAIT"
            vetoes.append("data_quality_veto")
            reasons.append("وتوی سخت Data quality → انتظار")
        elif safe_float(dq.get("score"), 100) < MIN_DATA_QUALITY_SCORE:
            vetoes.append("data_quality_soft")
            reasons.append("Data quality مرزی — جهت حفظ با کاهش اطمینان")

        ladder = ladder or {}
        if side in {"LONG", "SHORT"} and ladder and not ladder.get("passed", True):
            # Soft miss: keep direction if HTF not strongly against; only hard-WAIT on structural flip
            htf_s = safe_float(ladder.get("htf_score"), 50)
            structural = (
                (side == "LONG" and htf_s <= 34) or (side == "SHORT" and htf_s >= 66)
            )
            if structural:
                vetoes.append("entry_ladder")
                reasons.append("نردبان ورود HTF خلاف جهت قوی → انتظار")
                side = "WAIT"
            else:
                reasons.append("نردبان ورود ناقص — جهت حفظ شد با اطمینان کمتر")

        # Precision hard blocks
        if (precision or {}).get("hard_blocks") and side in {"LONG", "SHORT"}:
            if safe_float(prec_sc, 50) < 48:
                side = "WAIT"
                reasons.append("بلوک‌های سخت دقت ورود فعال")

        # AI hard conflict with weak quant
        if a_side in {"LONG", "SHORT"} and side in {"LONG", "SHORT"} and a_side != side and a_agree >= 88:
            if abs(neural_score - 50) < 12:
                side = "WAIT"
                reasons.append("تعارض قوی AI با سیگنال ضعیف → انتظار")
            else:
                reasons.append("تعارض AI لحاظ شد (جریمه اطمینان)")

        # Confidence from layer agreement + distance from 50 + calib
        side_agreement = max(long_w, short_w, wait_w) / max(long_w + short_w + wait_w, 1e-9)
        confidence = (
            0.35 * abs(neural_score - 50) * 2
            + 0.30 * side_agreement * 100
            + 0.20 * safe_float(dq.get("score"), 60)
            + 0.15 * cal_sc
        )
        if side == "WAIT":
            confidence = min(confidence, 55)
        if any("نردبان ورود ناقص" in str(r) for r in reasons):
            confidence = min(confidence, 78)
        confidence = float(clamp(confidence, 5, 92))

        bias = "صعودی" if side == "LONG" else "نزولی" if side == "SHORT" else "خنثی"

        # Human-readable synapse summary
        top_layers = sorted(layers.items(), key=lambda x: abs(safe_float(x[1].get("score"), 50) - 50), reverse=True)[:4]
        for name, layer in top_layers:
            reasons.append(f"{name}: {layer.get('side')} ({layer.get('score')})")

        return {
            "side": side,
            "bias": bias,
            "neural_score": round(neural_score, 1),
            "confidence": round(confidence, 1),
            "layers": layers,
            "long_weight": round(long_w, 3),
            "short_weight": round(short_w, 3),
            "wait_weight": round(wait_w, 3),
            "side_agreement": round(side_agreement, 3),
            "reasons": reasons[:8],
            "vetoes": vetoes,
            "param_version": TITAN_PARAM_VERSION,
        }



TITAN_NEURAL = TitanNeuralSynapseV9()
