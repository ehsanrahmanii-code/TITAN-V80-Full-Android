# [TITAN V77 layer] ui/v75_deep_coin_analysis - V75 deep coin analysis
# Original V76 source lines 24374-25567 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# V75 DEEP COIN ANALYSIS TAB — full professional desk brief
# Entry/exit, next-minutes path, reasons, invalidation, AI desk
# ============================================================
@app.get("/api/v75/deep")
def api_v75_deep_analysis():
    """Deep multi-horizon desk analysis for one symbol (analysis-only)."""
    symbol = _normalize_symbol(request.args.get("symbol") or "BTC/USDT")
    tf = str(request.args.get("timeframe") or "1h")
    if tf not in ("15m", "1h", "4h", "1d"):
        tf = "1h"
    try:
        frames = {}
        for t in ("15m", "1h", "4h", "1d"):
            try:
                frames[t] = fetch_klines(symbol, t, limit=220 if t in ("15m", "1h") else 180)
            except Exception:
                _swallow()
                frames[t] = None
        df = frames.get(tf)
        if df is None:
            df = frames.get("1h")
        if df is None or getattr(df, "empty", True) or len(df) < 40:
            return jsonify({"ok": False, "error": "insufficient_candles", "symbol": symbol}), 200

        close = df["close"].astype(float)
        high = df["high"].astype(float)
        low = df["low"].astype(float)
        last = float(close.iloc[-1])
        atr = float((high - low).tail(14).mean()) or last * 0.01
        rsi = wilder_rsi(close)
        rsi_v = float(rsi.iloc[-1]) if len(rsi) else 50.0
        macd = calc_macd(close)
        stoch = calc_stoch_rsi(close)
        patterns = detect_chart_patterns(df, rsi)
        structure = {"bias": "صعودی" if float(close.iloc[-1]) > float(close.ewm(span=20).mean().iloc[-1]) else "نزولی"}
        regime = {"regime": "trend_up" if rsi_v > 55 else "trend_down" if rsi_v < 45 else "range"}
        forecast = forecast_future_candles(
            df, horizon=48, patterns=patterns, macd=macd, stoch=stoch,
            structure=structure, regime=regime,
        )
        # V76: forecast is a first-class input to deep score (not display-only)
        _fc_impact = safe_float((forecast or {}).get("decision_impact"), 0)
        _fc_strength = safe_float((forecast or {}).get("path_strength"), 0)
        # Multi-TF scores
        tf_scores = {}
        for t, f in frames.items():
            if f is None or len(f) < 30:
                tf_scores[t] = 50.0
                continue
            c = f["close"].astype(float)
            pol = v59_tf_policy(t)
            ema_f = c.ewm(span=int(pol["fast"]), adjust=False).mean()
            ema_s = c.ewm(span=int(pol["slow"]), adjust=False).mean()
            gap = float(ema_f.iloc[-1] / ema_s.iloc[-1] - 1.0) if float(ema_s.iloc[-1]) else 0.0
            mom = float(c.iloc[-1] / c.iloc[-min(len(c)-1, int(pol["momentum_bars"]))] - 1.0) if len(c) > 5 else 0.0
            sc = 50.0 + gap * 400 + mom * 300
            tf_scores[t] = float(clamp(sc, 5, 95))

        # Decision with V75 stricter low-TF gates + V76 real forecast impact
        pol = v59_tf_policy(tf)
        score = tf_scores.get(tf, 50.0)
        # Blend multi-factor path into score (bounded)
        score = float(clamp(score + _fc_impact * min(_fc_strength, 30) * 0.25, 5, 95))
        htf_ok = True
        if pol.get("require_htf"):
            if tf == "15m":
                htf_ok = tf_scores.get("1h", 50) >= 54 and (score >= 64 if score >= 50 else score <= 36)
            elif tf == "1h":
                htf_ok = tf_scores.get("4h", 50) >= 52

        decision = "WAIT"
        if htf_ok and score >= float(pol.get("long", 58)):
            decision = "LONG"
        elif htf_ok and score <= float(pol.get("short", 42)):
            decision = "SHORT"
        # Forecast alignment gate for deep desk
        _fc_bias = str((forecast or {}).get("overall_bias") or "خنثی")
        if decision == "LONG" and _fc_bias == "نزولی" and _fc_strength >= 16:
            decision = "WAIT"
            score = min(score, 52)
        elif decision == "SHORT" and _fc_bias == "صعودی" and _fc_strength >= 16:
            decision = "WAIT"
            score = max(score, 48)
        elif decision == "WAIT" and htf_ok and _fc_strength >= 20:
            if _fc_bias == "صعودی" and score >= float(pol.get("long", 58)) - 3:
                decision = "LONG"
            elif _fc_bias == "نزولی" and score <= float(pol.get("short", 42)) + 3:
                decision = "SHORT"

        # Entry / SL / TP from ATR (professional levels)
        if decision == "LONG":
            entry = last
            sl = last - 1.4 * atr
            tp1 = last + 1.8 * atr
            tp2 = last + 3.0 * atr
        elif decision == "SHORT":
            entry = last
            sl = last + 1.4 * atr
            tp1 = last - 1.8 * atr
            tp2 = last - 3.0 * atr
        else:
            entry, sl, tp1, tp2 = last, last - atr, last + atr, last + 1.6 * atr

        risk = abs(entry - sl) / entry * 100 if entry else 0
        rr1 = abs(tp1 - entry) / abs(entry - sl) if abs(entry - sl) > 0 else 0
        rr2 = abs(tp2 - entry) / abs(entry - sl) if abs(entry - sl) > 0 else 0

        # Next-minutes narrative
        exp_move = safe_float(forecast.get("expected_move_pct"), 0)
        bias = forecast.get("overall_bias") or ("صعودی" if decision == "LONG" else "نزولی" if decision == "SHORT" else "خنثی")
        reasons_for, reasons_against = [], []
        if (forecast or {}).get("ok"):
            _fb = str(forecast.get("overall_bias") or "خنثی")
            _em = safe_float(forecast.get("expected_move_pct"), 0)
            _ps = safe_float(forecast.get("path_strength"), 0)
            if decision in {"LONG", "SHORT"}:
                if (decision == "LONG" and _fb == "صعودی") or (decision == "SHORT" and _fb == "نزولی"):
                    reasons_for.append(f"مسیر واقعی {forecast.get('horizon', 48)} کندل هم‌جهت ({_fb} · {_em:.2f}% · قدرت {_ps:.0f})")
                elif (decision == "LONG" and _fb == "نزولی") or (decision == "SHORT" and _fb == "صعودی"):
                    reasons_against.append(f"تعارض مسیر کندل آینده ({_fb}) با جهت تصمیم")
            if forecast.get("analogue_corr"):
                reasons_for.append(f"همبستگی الگوی تاریخی {safe_float(forecast.get('analogue_corr'), 0):.0%}")
            if forecast.get("range_position") is not None:
                reasons_for.append(f"موقعیت در رنج اخیر: {safe_float(forecast.get('range_position'), 0.5):.0%}")
        if decision == "LONG":
            reasons_for.append(f"امتیاز {tf} = {score:.0f} ≥ آستانه {pol.get('long')}")
            if tf_scores.get("4h", 50) >= 52:
                reasons_for.append(f"تأیید HTF 4h ({tf_scores.get('4h'):.0f})")
            if rsi_v < 45:
                reasons_for.append(f"RSI در ناحیه حمایتی ({rsi_v:.0f})")
            if macd.get("cross") == "bull":
                reasons_for.append("کراس صعودی MACD")
            if rsi_v > 70:
                reasons_against.append(f"RSI بیش‌خرید ({rsi_v:.0f})")
            if stretch := abs(last / float(close.ewm(span=20).mean().iloc[-1]) - 1) * 100:
                if stretch > 3:
                    reasons_against.append(f"کشیدگی از EMA20 حدود {stretch:.1f}٪")
        elif decision == "SHORT":
            reasons_for.append(f"امتیاز {tf} = {score:.0f} ≤ آستانه {pol.get('short')}")
            if tf_scores.get("4h", 50) <= 48:
                reasons_for.append(f"تأیید HTF 4h نزولی ({tf_scores.get('4h'):.0f})")
            if rsi_v > 55:
                reasons_for.append(f"RSI در ناحیه مقاومتی ({rsi_v:.0f})")
            if macd.get("cross") == "bear":
                reasons_for.append("کراس نزولی MACD")
            if rsi_v < 30:
                reasons_against.append(f"RSI بیش‌فروش ({rsi_v:.0f})")
        else:
            reasons_against.append("عدم هم‌راستایی چندتایم‌فریمی یا کیفیت ناکافی")
            reasons_against.append("هزینه و نویز تایم‌فریم پایین لبه را می‌بلعد — WAIT منطقی است")

        primary = (patterns or {}).get("primary")
        if primary:
            reasons_for.append(f"الگوی {primary.get('id')} با اطمینان {primary.get('confidence')}")

        invalidation = (
            f"بسته شدن زیر {smart_format(sl)}" if decision == "LONG"
            else f"بسته شدن بالای {smart_format(sl)}" if decision == "SHORT"
            else "شکست واضح ساختار چندتایم‌فریمی"
        )

        # Performance self-critique from DB
        critique = {"has_data": False}
        try:
            with DB_LOCK, db_conn() as con:
                row = con.execute(
                    """SELECT win_rate, expectancy, profit_factor, max_drawdown, sharpe, trades, metrics_json
                       FROM performance_snapshots
                       WHERE symbol=? AND timeframe=?
                       ORDER BY created_at DESC LIMIT 1""",
                    (symbol, tf),
                ).fetchone()
            if row:
                critique = {
                    "has_data": True,
                    "win_rate": row[0],
                    "expectancy": row[1],
                    "profit_factor": row[2],
                    "max_drawdown": row[3],
                    "sharpe": row[4],
                    "trades": row[5],
                    "verdict": (
                        "EDGE_SUPPORTED" if row[1] and row[1] > 0.25 and row[4] and row[4] > 0.15
                        else "WEAK" if row[1] and row[1] > 0 else "NO_EDGE"
                    ),
                    "lesson": (
                        "این ترکیب نماد/تایم‌فریم در گذشته expectancy منفی داشته — فقط سیگنال‌های با confluence خیلی بالا مجازند."
                        if (row[1] or 0) <= 0
                        else "لبه ضعیف/مثبت وجود دارد؛ فیلتر سخت‌تر و RR≥1.25 رعایت شود."
                    ),
                }
        except Exception:
            _swallow()

        next_minutes = {
            "horizon_candles": 48,
            "bias": bias,
            "expected_move_pct": exp_move,
            "path_strength": forecast.get("path_strength"),
            "narrative": forecast.get("narrative") or "",
            "vol_band_note": "باندهای ۱۰–۹۰ با مدل GARCH-lite و ATR برای نوسان واقعی کریپتو ساخته شده‌اند.",
            "candles_preview": (forecast.get("candles") or [])[:8],
        }

        # ---------- V75.3 AI DESK STRENGTHENING ----------
        reload_keys()
        ai_payload = {
            "symbol": symbol,
            "timeframe": tf,
            "price": last,
            "decision_candidate": decision,
            "score": round(score, 1),
            "tf_scores": {k: round(v, 1) for k, v in tf_scores.items()},
            "htf_confirmed": htf_ok,
            "rsi": round(rsi_v, 1),
            "macd": macd,
            "stoch": stoch,
            "atr": round(atr, 8),
            "atr_pct": round(atr / last * 100, 3) if last else 0,
            "patterns": (patterns or {}).get("primary"),
            "entry": round(entry, 8),
            "sl": round(sl, 8),
            "tp1": round(tp1, 8),
            "tp2": round(tp2, 8),
            "rr1": round(rr1, 2),
            "rr2": round(rr2, 2),
            "risk_pct": round(risk, 3),
            "expected_move_pct": exp_move,
            "forecast_bias": bias,
            "performance": critique,
            "cost_round_trip_pct": round(TOTAL_ENTRY_BUFFER * 2 * 100, 4),
            "reasons_for": reasons_for,
            "reasons_against": reasons_against,
        }
        desk_prompt = (
            "تو تحلیل‌گر ارشد میز معاملاتی TITAN هستی. فقط فارسی پاسخ بده. "
            "خروجی را دقیقاً به شکل JSON معتبر با کلیدهای زیر برگردان و هیچ متن اضافه ننویس:\n"
            "{"
            "\"side\":\"LONG|SHORT|WAIT\","
            "\"confidence\":0-100,"
            "\"scenarios\":["
            "{\"name\":\"صعودی\",\"prob\":0-100,\"target_pct\":number,\"note\":\"...\"},"
            "{\"name\":\"نزولی\",\"prob\":0-100,\"target_pct\":number,\"note\":\"...\"},"
            "{\"name\":\"خنثی\",\"prob\":0-100,\"target_pct\":number,\"note\":\"...\"}"
            "],"
            "\"entry_zone\":\"...\","
            "\"stop\":\"...\","
            "\"targets\":[\"...\",\"...\"],"
            "\"invalidation\":\"...\","
            "\"next_30_90_min\":\"توضیح کوتاه انتظار ۳۰ تا ۹۰ دقیقه آینده\","
            "\"risk_note\":\"...\","
            "\"summary\":\"۲ تا ۴ جمله جمع‌بندی حرفه‌ای فارسی\""
            "}\n"
            "قوانین: اگر داده‌ها لبه ضعیف یا expectancy منفی نشان می‌دهند، side را WAIT بگذار. "
            "هزینه رفت‌وبرگشت را در نظر بگیر. از ادعاهای بدون داده پرهیز کن.\n"
            "داده:\n" + json.dumps(ai_payload, ensure_ascii=False, default=str)
        )

        ai_votes: dict[str, Any] = {}
        ai_texts: dict[str, str] = {}
        providers_tried: list[str] = []

        def _safe_ai_json(raw: str) -> dict:
            if not raw:
                return {}
            try:
                t = raw.strip()
                if "```" in t:
                    t = t.split("```")[1]
                    if t.startswith("json"):
                        t = t[4:]
                if "{" in t and "}" in t:
                    t = t[t.find("{"): t.rfind("}") + 1]
                obj = json.loads(t)
                return obj if isinstance(obj, dict) else {}
            except Exception:
                _swallow()
                return {}

        # Gemini (primary)
        if GEMINI_API_KEY:
            providers_tried.append("gemini")
            try:
                cached = _cached_ai("gemini", "desk-v75", ai_payload, AI_CACHE_TTL) if "_cached_ai" in globals() else None
                if cached:
                    ai_texts["gemini"] = cached
                else:
                    gtext = None
                    models = _gemini_available_models() if "_gemini_available_models" in dir() else []
                    for model in (models or ["gemini-2.0-flash", "gemini-1.5-flash"]):
                        resp = _request_json(
                            "POST",
                            f"https://generativelanguage.googleapis.com/v1beta/models/{model}:generateContent",
                            headers={"x-goog-api-key": GEMINI_API_KEY, "Content-Type": "application/json"},
                            json={
                                "contents": [{"parts": [{"text": desk_prompt}]}],
                                "generationConfig": {"maxOutputTokens": 700, "temperature": 0.15},
                            },
                            timeout=40,
                        )
                        if resp:
                            gtext = _extract_gemini_text(resp)
                            if gtext:
                                break
                    if gtext:
                        ai_texts["gemini"] = gtext
                        try:
                            _store_ai("gemini", "desk-v75", ai_payload, gtext)
                        except Exception:
                            _swallow()
                if ai_texts.get("gemini"):
                    ai_votes["gemini"] = _safe_ai_json(ai_texts["gemini"])
                    if not ai_votes["gemini"]:
                        vote = extract_structured_ai_vote(ai_texts["gemini"])
                        ai_votes["gemini"] = {
                            "side": vote.get("side", "WAIT"),
                            "confidence": vote.get("confidence", 50),
                            "summary": ai_texts["gemini"][:500],
                        }
            except Exception as _e:
                LOGGER.debug("desk gemini failed: %s", _e)

        # OpenAI-compatible providers (optional, non-blocking if key missing)
        for prov, key, base, models in (
            ("openai", OPENAI_API_KEY, "https://api.openai.com/v1", ["gpt-4o-mini", "gpt-4o"]),
            ("grok", GROK_API_KEY, "https://api.x.ai/v1", ["grok-2-latest", "grok-beta"]),
            ("deepseek", DEEPSEEK_API_KEY, "https://api.deepseek.com", ["deepseek-chat"]),
        ):
            if not key:
                continue
            providers_tried.append(prov)
            try:
                if "_call_openai_compatible" in globals() and callable(_call_openai_compatible):
                    raw = _call_openai_compatible(prov, key, base, models, {
                        "messages": [
                            {"role": "system", "content": "پاسخ فقط JSON فارسی معتبر طبق قالب درخواستی کاربر."},
                            {"role": "user", "content": desk_prompt},
                        ],
                        "temperature": 0.15,
                        "max_tokens": 700,
                    })
                else:
                    raw = None
                    for m in models:
                        resp = _request_json(
                            "POST",
                            f"{base}/chat/completions",
                            headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
                            json={
                                "model": m,
                                "messages": [
                                    {"role": "system", "content": "پاسخ فقط JSON فارسی معتبر."},
                                    {"role": "user", "content": desk_prompt},
                                ],
                                "temperature": 0.15,
                                "max_tokens": 700,
                            },
                            timeout=35,
                        )
                        if resp:
                            raw = _extract_openai_response(resp) if "_extract_openai_response" in globals() else None
                            if not raw and isinstance(resp, dict):
                                try:
                                    raw = resp["choices"][0]["message"]["content"]
                                except Exception:
                                    _swallow()
                                    raw = None
                            if raw:
                                break
                if raw:
                    ai_texts[prov] = raw
                    ai_votes[prov] = _safe_ai_json(raw)
                    if not ai_votes[prov]:
                        vote = extract_structured_ai_vote(raw)
                        ai_votes[prov] = {
                            "side": vote.get("side", "WAIT"),
                            "confidence": vote.get("confidence", 50),
                            "summary": raw[:500],
                        }
            except Exception as _e:
                LOGGER.debug("desk %s failed: %s", prov, _e)

        # Claude optional
        if CLAUDE_API_KEY:
            providers_tried.append("claude")
            try:
                raw = _call_claude({
                    "messages": [{"role": "user", "content": desk_prompt}],
                    "max_tokens": 700,
                    "temperature": 0.15,
                }) if "_call_claude" in globals() else None
                if raw:
                    ai_texts["claude"] = raw
                    ai_votes["claude"] = _safe_ai_json(raw)
                    if not ai_votes["claude"]:
                        vote = extract_structured_ai_vote(raw)
                        ai_votes["claude"] = {
                            "side": vote.get("side", "WAIT"),
                            "confidence": vote.get("confidence", 50),
                            "summary": raw[:500],
                        }
            except Exception as _e:
                LOGGER.debug("desk claude failed: %s", _e)

        # Consensus
        side_votes = {"LONG": 0.0, "SHORT": 0.0, "WAIT": 0.0}
        conf_acc = {"LONG": [], "SHORT": [], "WAIT": []}
        for prov, obj in ai_votes.items():
            side = str(obj.get("side") or "WAIT").upper()
            if side in {"BUY", "صعودی"}:
                side = "LONG"
            elif side in {"SELL", "نزولی"}:
                side = "SHORT"
            elif side not in side_votes:
                side = "WAIT"
            conf = float(clamp(safe_float(obj.get("confidence"), 50), 0, 100))
            side_votes[side] += conf
            conf_acc[side].append(conf)

        # blend quant decision with AI (AI can only soften to WAIT, not invent opposite edge)
        quant_side = decision
        if side_votes["LONG"] + side_votes["SHORT"] + side_votes["WAIT"] <= 0:
            consensus_side = quant_side
            consensus_conf = 45.0
            agreement = 0.0
        else:
            consensus_side = max(side_votes, key=side_votes.get)
            consensus_conf = float(sum(conf_acc[consensus_side]) / max(1, len(conf_acc[consensus_side])))
            total_w = sum(side_votes.values()) or 1.0
            agreement = float(side_votes[consensus_side] / total_w * 100)
            # Conflict rule: if AI strongly disagrees with quant directional, demote to WAIT
            if quant_side in {"LONG", "SHORT"} and consensus_side not in {quant_side, "WAIT"}:
                if agreement >= 55:
                    consensus_side = "WAIT"
                    reasons_against.append("تعارض AI با منطق کمّی — احتیاط: WAIT")
                else:
                    consensus_side = quant_side
            elif quant_side == "WAIT" and consensus_side in {"LONG", "SHORT"} and agreement < 70:
                consensus_side = "WAIT"  # don't invent edge from weak AI alone

        # Prefer richest AI object for scenarios / narrative
        primary_ai = {}
        for pref in ("gemini", "openai", "grok", "claude", "deepseek"):
            if isinstance(ai_votes.get(pref), dict) and ai_votes[pref]:
                primary_ai = ai_votes[pref]
                break
        if not primary_ai and ai_votes:
            primary_ai = next(iter(ai_votes.values()))

        scenarios = primary_ai.get("scenarios") if isinstance(primary_ai.get("scenarios"), list) else []
        if not scenarios:
            # fallback scenarios from quant + forecast
            up_p = float(clamp(50 + (score - 50) * 0.8 + (exp_move if exp_move > 0 else 0) * 2, 8, 82))
            dn_p = float(clamp(50 - (score - 50) * 0.8 + (abs(exp_move) if exp_move < 0 else 0) * 2, 8, 82))
            flat_p = float(clamp(100 - up_p - dn_p, 5, 60))
            scenarios = [
                {"name": "صعودی", "prob": round(up_p, 1), "target_pct": round(max(0.3, abs(exp_move) if exp_move > 0 else atr / last * 100 * 1.2), 2), "note": "در صورت حفظ ساختار و تأیید HTF"},
                {"name": "نزولی", "prob": round(dn_p, 1), "target_pct": round(-max(0.3, abs(exp_move) if exp_move < 0 else atr / last * 100 * 1.2), 2), "note": "در صورت شکست حمایت / فشار فروش"},
                {"name": "خنثی", "prob": round(flat_p, 1), "target_pct": 0.0, "note": "نوسان محدود داخل رنج؛ هزینه معامله را می‌بلعد"},
            ]

        ai_summary = str(primary_ai.get("summary") or primary_ai.get("next_30_90_min") or "")
        if not ai_summary:
            ai_summary = (
                f"منطق کمّی: {decision} با امتیاز {score:.0f}. "
                f"اجماع AI: {consensus_side} (توافق {agreement:.0f}٪). "
                f"انتظار مسیر ۴۸ کندل: {bias} با حرکت تقریبی {exp_move:.2f}٪. "
                + ("عملکرد تاریخی این سلول ضعیف است؛ اولویت با WAIT." if critique.get("verdict") == "NO_EDGE" else "")
            )

        # Professional checklist
        checklist = [
            {"name": "کیفیت داده / تعداد کندل", "ok": len(df) >= 60, "detail": f"{len(df)} کندل"},
            {"name": "هم‌راستایی HTF", "ok": bool(htf_ok), "detail": "الزامی برای ۱۵m/۱h" if v59_tf_policy(tf).get("require_htf") else "اختیاری"},
            {"name": "آستانه امتیاز تایم‌فریم", "ok": (score >= float(v59_tf_policy(tf).get("long", 58)) or score <= float(v59_tf_policy(tf).get("short", 42))), "detail": f"score={score:.0f}"},
            {"name": "R:R حداقل ۱.۲۵", "ok": rr1 >= 1.25, "detail": f"RR1={rr1:.2f}"},
            {"name": "هزینه پس از اصطکاک", "ok": rr1 * (risk / 100 if risk else 0) * 100 > TOTAL_ENTRY_BUFFER * 2 * 100 * 1.5 if risk else False, "detail": f"هزینه رفت‌وبرگشت {TOTAL_ENTRY_BUFFER*2*100:.3f}٪"},
            {"name": "عدم کشیدگی افراطی", "ok": abs(last / float(close.ewm(span=20).mean().iloc[-1]) - 1) * 100 < 4.5 if float(close.ewm(span=20).mean().iloc[-1]) else True, "detail": "فاصله از EMA20"},
            {"name": "اجماع AI هم‌جهت یا WAIT", "ok": consensus_side in {decision, "WAIT"} or decision == "WAIT", "detail": f"AI={consensus_side} / Quant={decision}"},
            {"name": "عملکرد تاریخی سلول", "ok": critique.get("verdict") != "NO_EDGE" if critique.get("has_data") else True, "detail": critique.get("verdict") or "بدون نمونه"},
        ]
        checklist_pass = sum(1 for c in checklist if c["ok"])
        checklist_total = len(checklist)

        # Dynamic risk suggestion
        base_risk = 0.75
        if critique.get("verdict") == "NO_EDGE":
            base_risk = 0.25
        elif critique.get("verdict") == "WEAK":
            base_risk = 0.45
        if consensus_side == "WAIT" or not htf_ok:
            base_risk = min(base_risk, 0.2)
        if safe_float(critique.get("max_drawdown"), 0) > 25:
            base_risk *= 0.7
        suggested_risk_pct = round(float(clamp(base_risk, 0.1, 1.5)), 2)

        # Final desk decision after AI blend + V75.6 professional gates
        final_decision = consensus_side if consensus_side in {"LONG", "SHORT", "WAIT"} else decision
        min_ck = int(globals().get("TITAN_MANDATORY_CHECKLIST_MIN", 5))
        if checklist_pass < min_ck and final_decision in {"LONG", "SHORT"}:
            final_decision = "WAIT"
            reasons_against.append(f"چک‌لیست حرفه‌ای ناکافی ({checklist_pass}/{checklist_total}) — WAIT")

        # Threshold boost from past deep mistakes
        _boost = v75_threshold_boost(symbol, tf)
        if _boost > 0 and final_decision in {"LONG", "SHORT"}:
            _need = float(pol.get("long" if final_decision == "LONG" else "short", 58))
            if final_decision == "LONG":
                _need = float(pol.get("long", 58)) + _boost
                if score < _need:
                    final_decision = "WAIT"
                    reasons_against.append(f"آستانه خودتنظیم +{_boost:.0f} (score {score:.0f}<{_need:.0f}) از عملکرد ضعیف قبلی")
            else:
                _need = float(pol.get("short", 42)) - _boost
                if score > _need:
                    final_decision = "WAIT"
                    reasons_against.append(f"آستانه خودتنظیم -{_boost:.0f} (score {score:.0f}>{_need:.0f}) از عملکرد ضعیف قبلی")

        # Historical edge gate
        edge_info = v75_edge_grade(symbol, tf)
        _dq_proxy = 70.0 if len(df) >= 80 else 45.0
        pub = v75_publish_allowed(tf, final_decision, edge_info, checklist_pass, _dq_proxy)
        if final_decision in {"LONG", "SHORT"} and not pub.get("ok"):
            reasons_against.extend(pub.get("reasons") or [])
            final_decision = "WAIT"
            reasons_against.append("دروازه انتشار حرفه‌ای: WAIT")

        # Smarter levels from AI if provided (parse numbers softly), else keep ATR
        def _num_from(text_v, fallback):
            try:
                import re
                m = re.search(r"(\d+\.?\d*)", str(text_v).replace(",", ""))
                return float(m.group(1)) if m else fallback
            except Exception:
                _swallow()
                return fallback

        ai_entry = _num_from(primary_ai.get("entry_zone"), entry)
        ai_stop = _num_from(primary_ai.get("stop"), sl)
        ai_targets = primary_ai.get("targets") if isinstance(primary_ai.get("targets"), list) else []
        if ai_targets:
            tp1 = _num_from(ai_targets[0], tp1)
            if len(ai_targets) > 1:
                tp2 = _num_from(ai_targets[1], tp2)
        if ai_entry > 0 and abs(ai_entry - last) / last < 0.03:
            entry = ai_entry
        if ai_stop > 0 and abs(ai_stop - last) / last < 0.08:
            sl = ai_stop
        risk = abs(entry - sl) / entry * 100 if entry else risk
        rr1 = abs(tp1 - entry) / abs(entry - sl) if abs(entry - sl) > 0 else rr1
        rr2 = abs(tp2 - entry) / abs(entry - sl) if abs(entry - sl) > 0 else rr2

        invalidation = str(primary_ai.get("invalidation") or invalidation)
        next_30_90 = str(primary_ai.get("next_30_90_min") or next_minutes.get("narrative") or "")


        # V75.5: validity window — each decision is only valid for a defined horizon
        _TF_VALID = {
            "15m": {"bars": 8, "minutes": 120, "label": "معتبر تا ۸ کندل ۱۵دقیقه (~۲ ساعت)"},
            "1h":  {"bars": 6, "minutes": 360, "label": "معتبر تا ۶ کندل ۱ساعته (~۶ ساعت)"},
            "4h":  {"bars": 5, "minutes": 1200, "label": "معتبر تا ۵ کندل ۴ساعته (~۲۰ ساعت)"},
            "1d":  {"bars": 4, "minutes": 5760, "label": "معتبر تا ۴ کندل روزانه (~۴ روز)"},
        }
        _vv = _TF_VALID.get(tf, _TF_VALID["1h"])
        valid_from = time.time()
        valid_until = valid_from + int(_vv["minutes"]) * 60
        validity = {
            "timeframe": tf,
            "valid_bars": int(_vv["bars"]),
            "valid_minutes": int(_vv["minutes"]),
            "valid_from": valid_from,
            "valid_until": valid_until,
            "valid_until_iso": datetime.fromtimestamp(valid_until, tz=timezone.utc).isoformat(timespec="minutes"),
            "label": _vv["label"],
            "note": (
                f"این تصمیم فقط برای تایم‌فریم {tf} صادر شده و تا {_vv['label']} اعتبار دارد. "
                f"پس از انقضا یا رسیدن به SL/TP باید بازبینی شود. برای تایم‌فریم‌های دیگر تصمیم جداگانه بگیرید."
            ),
            "per_tf_snapshot": {
                t: {
                    "score": round(float(tf_scores.get(t, 50)), 1),
                    "bias": ("LONG" if tf_scores.get(t, 50) >= 55 else "SHORT" if tf_scores.get(t, 50) <= 45 else "WAIT"),
                    "valid_label": _TF_VALID.get(t, {}).get("label", ""),
                }
                for t in ("15m", "1h", "4h", "1d")
            },
        }

        # Multi-horizon path summary (near / mid / far)
        _candles = (forecast.get("candles") or [])
        def _seg(a, b):
            seg = _candles[a:b]
            if not seg:
                return {"bias": "خنثی", "move_pct": 0.0}
            last_c = float(seg[-1].get("close") or last)
            move = (last_c / last - 1.0) * 100 if last else 0
            up = sum(1 for x in seg if str(x.get("direction") or "").find("صعود") >= 0)
            return {
                "bias": "صعودی" if up > len(seg) * 0.55 else "نزولی" if up < len(seg) * 0.45 else "خنثی",
                "move_pct": round(move, 3),
                "steps": len(seg),
            }
        path_segments = {
            "near_1_8": _seg(0, 8),
            "mid_9_24": _seg(8, 24),
            "far_25_48": _seg(24, 48),
        }

        # Structure depth notes
        depth_notes = []
        depth_notes.append(f"ساختار قیمت نسبت به EMA20: {structure.get('bias', '—')}")
        depth_notes.append(f"رژیم تقریبی: {regime.get('regime', '—')} · RSI={rsi_v:.0f}")
        if macd.get("cross") and macd.get("cross") != "none":
            depth_notes.append(f"کراس MACD: {macd.get('cross')}")
        if stoch.get("zone") and stoch.get("zone") != "mid":
            depth_notes.append(f"Stoch RSI در ناحیه {stoch.get('zone')}")
        primary_pat = (patterns or {}).get("primary")
        if primary_pat:
            depth_notes.append(f"الگوی غالب: {primary_pat.get('id')} (اطمینان {primary_pat.get('confidence')})")
        depth_notes.append(f"نوسان ATR حدود {atr/last*100:.2f}٪ از قیمت" if last else "ATR نامشخص")
        depth_notes.append(validity["note"])

        # Persist deep decision for later accuracy tracking (dedupe ~same bar)
        deep_id = None
        try:
            with DB_LOCK, db_conn() as con:
                prev = con.execute(
                    "SELECT id, created_at FROM v75_deep_ledger WHERE symbol=? AND timeframe=? ORDER BY created_at DESC LIMIT 1",
                    (symbol, tf),
                ).fetchone()
                # avoid spam: one record per half validity window
                if not prev or (valid_from - float(prev[1])) > max(300, int(_vv["minutes"]) * 30):
                    cur = con.execute(
                        """INSERT INTO v75_deep_ledger(
                            created_at, symbol, timeframe, decision, quant_decision, consensus_side,
                            score, confidence, entry, sl, tp1, tp2, valid_from, valid_until,
                            valid_bars, valid_minutes, price_at, reasons_json, checklist_score,
                            ai_agreement, notes, build_id
                        ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                        (
                            valid_from, symbol, tf, final_decision, decision,
                            str(consensus_side),
                            round(score, 1), round(float(consensus_conf), 1),
                            round(entry, 8), round(sl, 8), round(tp1, 8), round(tp2, 8),
                            valid_from, valid_until, int(_vv["bars"]), int(_vv["minutes"]),
                            last, json.dumps(reasons_for + reasons_against, ensure_ascii=False),
                            f"{checklist_pass}/{checklist_total}",
                            round(float(agreement), 1),
                            validity["label"], TITAN_BUILD_ID,
                        ),
                    )
                    deep_id = cur.lastrowid
                    con.commit()
        except Exception as _le:
            LOGGER.debug("v75 deep ledger insert: %s", _le)

        desk = {
            "decision": final_decision,
            "quant_decision": decision,
            "score": round(score, 1),
            "tf_scores": {k: round(v, 1) for k, v in tf_scores.items()},
            "htf_confirmed": htf_ok,
            "entry": round(entry, 8),
            "sl": round(sl, 8),
            "tp1": round(tp1, 8),
            "tp2": round(tp2, 8),
            "risk_pct": round(risk, 3),
            "rr1": round(rr1, 2),
            "rr2": round(rr2, 2),
            "suggested_risk_pct": suggested_risk_pct,
            "rsi": round(rsi_v, 1),
            "macd": macd,
            "stoch": stoch,
            "patterns": patterns,
            "reasons_for": reasons_for,
            "reasons_against": reasons_against,
            "invalidation": invalidation,
            "next_minutes": next_minutes,
            "next_30_90_min": next_30_90,
            "performance_critique": critique,
            "cost_note": f"هزینه رفت‌وبرگشت تقریبی {TOTAL_ENTRY_BUFFER*2*100:.3f}٪ — فقط سیگنال‌هایی با RR خالص >1.0 پس از هزینه معتبرند.",
            "ai_desk": {
                "providers_tried": providers_tried,
                "providers_ok": list(ai_votes.keys()),
                "votes": {k: {"side": v.get("side"), "confidence": v.get("confidence"), "summary": str(v.get("summary") or "")[:280]} for k, v in ai_votes.items()},
                "consensus_side": consensus_side,
                "consensus_confidence": round(consensus_conf, 1),
                "agreement_pct": round(agreement, 1),
                "scenarios": scenarios,
                "summary": ai_summary,
                "risk_note": str(primary_ai.get("risk_note") or ""),
            },
            "checklist": checklist,
            "checklist_score": f"{checklist_pass}/{checklist_total}",
            "validity": validity,
            "path_segments": path_segments,
            "depth_notes": depth_notes,
            "deep_ledger_id": deep_id,
            "edge": edge_info,
            "threshold_boost": round(float(_boost), 1),
            "publish_gate": pub,
            "safe_mode": bool(globals().get("TITAN_SAFE_MODE", True)),
            "version": TITAN_PARAM_VERSION,
            "build": TITAN_BUILD_ID,
        }

        return jsonify({"ok": True, "symbol": symbol, "timeframe": tf, "price": last, "desk": desk, "forecast": forecast})

    except Exception as exc:
        LOGGER.exception("v75 deep analysis failed: %s", exc)
        return jsonify({"ok": False, "error": str(exc)[:240], "symbol": symbol}), 200






@app.get("/api/v75/pro-policy")
def api_v75_pro_policy():
    """Read/update professional edge policy (safe mode, edge gate, live TFs)."""
    try:
        if request.method == "GET" and str(request.args.get("set", "")):
            pass
        action = str(request.args.get("action") or "get")
        if action == "set":
            sm = str(request.args.get("safe_mode", "")).lower()
            re_ = str(request.args.get("require_edge", "")).lower()
            tfs = str(request.args.get("live_timeframes") or "")
            if sm in {"0", "1", "true", "false"}:
                USER_SETTINGS["safe_mode"] = sm in {"1", "true"}
                globals()["TITAN_SAFE_MODE"] = USER_SETTINGS["safe_mode"]
            if re_ in {"0", "1", "true", "false"}:
                USER_SETTINGS["require_edge"] = re_ in {"1", "true"}
                globals()["TITAN_REQUIRE_EDGE_SUPPORTED"] = USER_SETTINGS["require_edge"]
            if tfs:
                live = [t.strip() for t in tfs.split(",") if t.strip() in ("15m", "1h", "4h", "1d")]
                if live:
                    USER_SETTINGS["live_timeframes"] = live
            save_settings()
        return jsonify({
            "ok": True,
            "safe_mode": bool(globals().get("TITAN_SAFE_MODE", True)),
            "require_edge": bool(globals().get("TITAN_REQUIRE_EDGE_SUPPORTED", True)),
            "live_timeframes": USER_SETTINGS.get("live_timeframes") or list(globals().get("TITAN_LIVE_TIMEFRAMES", ("4h", "1d"))),
            "shadow_timeframes": list(globals().get("TITAN_SHADOW_TIMEFRAMES", ("15m", "1h"))),
            "min_oos_samples": int(globals().get("TITAN_MIN_OOS_SAMPLES", 30)),
            "min_edge_expectancy": float(globals().get("TITAN_MIN_EDGE_EXPECTANCY", 0.15)),
            "min_edge_sharpe": float(globals().get("TITAN_MIN_EDGE_SHARPE", 0.08)),
            "min_edge_trades": int(globals().get("TITAN_MIN_EDGE_TRADES", 25)),
            "ai_max_weight": float(globals().get("TITAN_AI_MAX_WEIGHT", 0.12)),
            "checklist_min": int(globals().get("TITAN_MANDATORY_CHECKLIST_MIN", 5)),
            "auto_threshold_boost": bool(globals().get("TITAN_AUTO_THRESHOLD_BOOST", True)),
            "cost_round_trip_pct": float(globals().get("TITAN_COST_ROUND_TRIP_PCT", 0.16)),
            "version": TITAN_PARAM_VERSION,
            "build": TITAN_BUILD_ID,
        })
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)[:200]}), 200


@app.get("/api/v75/deep-stats")
def api_v75_deep_stats():
    """Accuracy of deep-analysis decisions only (separate from general performance)."""
    try:
        with DB_LOCK, db_conn() as con:
            # ensure table exists
            con.execute("""CREATE TABLE IF NOT EXISTS v75_deep_ledger(
                id INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL NOT NULL, symbol TEXT NOT NULL,
                timeframe TEXT NOT NULL, decision TEXT NOT NULL, quant_decision TEXT, consensus_side TEXT,
                score REAL, confidence REAL, entry REAL, sl REAL, tp1 REAL, tp2 REAL,
                valid_from REAL, valid_until REAL, valid_bars INTEGER, valid_minutes INTEGER,
                price_at REAL, outcome TEXT DEFAULT 'PENDING', exit_price REAL, return_pct REAL,
                hit_type TEXT, evaluated_at REAL, reasons_json TEXT DEFAULT '[]',
                checklist_score TEXT, ai_agreement REAL, notes TEXT DEFAULT '', build_id TEXT)""")
            rows = con.execute(
                """SELECT id, created_at, symbol, timeframe, decision, score, confidence, entry, sl, tp1, tp2,
                          valid_until, price_at, outcome, exit_price, return_pct, hit_type, checklist_score,
                          ai_agreement, notes
                   FROM v75_deep_ledger ORDER BY created_at DESC LIMIT 300"""
            ).fetchall()
        pending = wins = losses = flats = 0
        rets = []
        by_tf: dict = {}
        recent = []
        for r in rows:
            o = str(r[13] or "PENDING")
            if o == "PENDING":
                pending += 1
            elif o == "WIN":
                wins += 1
            elif o == "LOSS":
                losses += 1
            else:
                flats += 1
            if r[15] is not None:
                rets.append(float(r[15]))
            tf = r[3]
            by_tf.setdefault(tf, {"n": 0, "wins": 0, "losses": 0, "pending": 0})
            by_tf[tf]["n"] += 1
            if o == "WIN":
                by_tf[tf]["wins"] += 1
            elif o == "LOSS":
                by_tf[tf]["losses"] += 1
            elif o == "PENDING":
                by_tf[tf]["pending"] += 1
            recent.append({
                "id": r[0], "t": r[1], "s": r[2], "tf": r[3], "d": r[4], "score": r[5],
                "conf": r[6], "entry": r[7], "sl": r[8], "tp1": r[9], "valid_until": r[11],
                "o": o, "ret": r[15], "hit": r[16], "check": r[17], "ai_agr": r[18], "notes": r[19],
            })
        decided = wins + losses
        wr = round(wins / decided * 100, 1) if decided else None
        avg_ret = round(sum(rets) / len(rets), 3) if rets else None
        for tf, v in by_tf.items():
            d = v["wins"] + v["losses"]
            v["win_rate"] = round(v["wins"] / d * 100, 1) if d else None
        return jsonify({
            "ok": True,
            "total": len(rows),
            "pending": pending,
            "wins": wins,
            "losses": losses,
            "flats": flats,
            "win_rate": wr,
            "avg_return_pct": avg_ret,
            "by_tf": by_tf,
            "recent": recent[:80],
            "note": "فقط تصمیمات تب تحلیل عمیق در این آمار ثبت می‌شوند.",
            "version": TITAN_PARAM_VERSION,
        })
    except Exception as exc:
        LOGGER.exception("deep-stats failed")
        return jsonify({"ok": False, "error": str(exc)[:200]}), 200


@app.post("/api/v75/deep-eval")
@app.get("/api/v75/deep-eval")
def api_v75_deep_eval():
    """Evaluate PENDING deep decisions against live price path (SL/TP/time)."""
    try:
        evaluated = 0
        with DB_LOCK, db_conn() as con:
            con.execute("""CREATE TABLE IF NOT EXISTS v75_deep_ledger(
                id INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL NOT NULL, symbol TEXT NOT NULL,
                timeframe TEXT NOT NULL, decision TEXT NOT NULL, quant_decision TEXT, consensus_side TEXT,
                score REAL, confidence REAL, entry REAL, sl REAL, tp1 REAL, tp2 REAL,
                valid_from REAL, valid_until REAL, valid_bars INTEGER, valid_minutes INTEGER,
                price_at REAL, outcome TEXT DEFAULT 'PENDING', exit_price REAL, return_pct REAL,
                hit_type TEXT, evaluated_at REAL, reasons_json TEXT DEFAULT '[]',
                checklist_score TEXT, ai_agreement REAL, notes TEXT DEFAULT '', build_id TEXT)""")
            pending = con.execute(
                "SELECT id, symbol, timeframe, decision, entry, sl, tp1, tp2, valid_until, price_at, created_at FROM v75_deep_ledger WHERE outcome='PENDING' ORDER BY created_at ASC LIMIT 80"
            ).fetchall()
        now = time.time()
        for row in pending:
            rid, symbol, tf, decision, entry, sl, tp1, tp2, valid_until, price_at, created = row
            decision = str(decision or "WAIT")
            if decision == "WAIT":
                # close as FLAT when validity ends
                if now >= float(valid_until or 0):
                    with DB_LOCK, db_conn() as con:
                        con.execute(
                            "UPDATE v75_deep_ledger SET outcome=?, exit_price=?, return_pct=?, hit_type=?, evaluated_at=? WHERE id=?",
                            ("FLAT", price_at, 0.0, "TIME_WAIT", now, rid),
                        )
                    evaluated += 1
                continue
            entry = safe_float(entry, 0)
            sl = safe_float(sl, 0)
            tp1 = safe_float(tp1, 0)
            if entry <= 0:
                continue
            try:
                df = fetch_klines(symbol, tf, limit=120)
            except Exception:
                _swallow(); continue
            if df is None or len(df) < 5:
                continue
            # only candles after decision
            ts_col = "t" if "t" in df.columns else None
            window = df
            if ts_col:
                window = df[df["t"] >= float(created) * 1000 - 60000]
            if window is None or len(window) == 0:
                window = df.tail(30)
            is_long = decision == "LONG"
            tag, px, _ts = _ft_simple(window, is_long, sl, tp1, guard_positive=True)
            outcome = "PENDING"
            hit = None
            ret = None
            exit_px = None
            if tag == "WIN":
                outcome, hit, exit_px = "WIN", "TP1", float(tp1)
            elif tag == "LOSS":
                outcome, hit, exit_px = "LOSS", "SL", float(sl)
            elif now >= float(valid_until or 0):
                # time exit
                exit_px = float(window["close"].iloc[-1])
                if is_long:
                    ret = (exit_px / entry - 1.0) * 100
                else:
                    ret = (entry / exit_px - 1.0) * 100 if exit_px else 0
                outcome = "WIN" if ret > 0.05 else "LOSS" if ret < -0.05 else "FLAT"
                hit = "TIME_EXIT"
            if outcome != "PENDING":
                if ret is None and exit_px:
                    if is_long:
                        ret = (exit_px / entry - 1.0) * 100
                    else:
                        ret = (entry / exit_px - 1.0) * 100 if exit_px else 0
                with DB_LOCK, db_conn() as con:
                    con.execute(
                        "UPDATE v75_deep_ledger SET outcome=?, exit_price=?, return_pct=?, hit_type=?, evaluated_at=? WHERE id=?",
                        (outcome, exit_px, round(float(ret or 0), 4), hit, now, rid),
                    )
                evaluated += 1
        return jsonify({"ok": True, "evaluated": evaluated, "version": TITAN_PARAM_VERSION})
    except Exception as exc:
        LOGGER.exception("deep-eval failed")
        return jsonify({"ok": False, "error": str(exc)[:200]}), 200



@app.get("/api/v75/performance-live")
def api_v75_performance_live():
    """Active per-symbol/TF performance with self-correction lessons (not passive)."""
    symbol = request.args.get("symbol") or ""
    tf = request.args.get("timeframe") or ""
    try:
        with DB_LOCK, db_conn() as con:
            if symbol and tf:
                rows = con.execute(
                    """SELECT symbol, timeframe, trades, wins, losses, win_rate, expectancy,
                              profit_factor, max_drawdown, sharpe, sortino, oos_status, metrics_json, created_at
                       FROM performance_snapshots
                       WHERE symbol=? AND timeframe=?
                       ORDER BY created_at DESC LIMIT 5""",
                    (_normalize_symbol(symbol), tf),
                ).fetchall()
            else:
                rows = con.execute(
                    """SELECT symbol, timeframe, trades, wins, losses, win_rate, expectancy,
                              profit_factor, max_drawdown, sharpe, sortino, oos_status, metrics_json, created_at
                       FROM performance_snapshots
                       WHERE id IN (SELECT MAX(id) FROM performance_snapshots GROUP BY symbol, timeframe)
                       ORDER BY expectancy DESC"""
                ).fetchall()
        out = []
        for r in rows:
            exp = safe_float(r[6], 0)
            lesson = []
            if exp <= 0:
                lesson.append("Expectancy منفی → فیلتر سخت‌تر + فقط با تأیید HTF")
                lesson.append("تایم‌فریم‌های ۱۵m/۱h فقط با score خیلی بالا و RR≥1.25")
            if safe_float(r[8], 0) > 25:
                lesson.append("Drawdown بالا → risk_multiplier دفاعی و کاهش سایز")
            if safe_float(r[9], 0) < 0.05:
                lesson.append("Sharpe ضعیف → لبه آماری اثبات‌نشده؛ WAIT پیش‌فرض")
            if safe_float(r[5], 0) < 45:
                lesson.append("Win-rate پایین → بهبود entry timing و کاهش time-exit")
            grade = (
                "EDGE_SUPPORTED" if exp > 0.25 and safe_float(r[9], 0) > 0.15
                else "WEAK_POSITIVE" if exp > 0
                else "NO_EDGE"
            )
            out.append({
                "symbol": r[0], "timeframe": r[1], "trades": r[2], "wins": r[3], "losses": r[4],
                "win_rate": r[5], "expectancy": r[6], "profit_factor": r[7],
                "max_drawdown": r[8], "sharpe": r[9], "sortino": r[10],
                "oos_status": r[11], "grade": grade, "lessons": lesson,
                "self_correct": (
                    "سیستم برای این سلول: آستانه score را +4 واحد و min RR را 1.25 اعمال می‌کند."
                    if grade == "NO_EDGE" else
                    "لبه ضعیف — فقط سیگنال‌های confluence بالا منتشر می‌شوند."
                    if grade == "WEAK_POSITIVE" else
                    "لبه پشتیبانی‌شده — با مدیریت ریسک استاندارد ادامه."
                ),
            })
        return jsonify({"ok": True, "count": len(out), "rows": out, "version": TITAN_PARAM_VERSION})
    except Exception as exc:
        return jsonify({"ok": False, "error": str(exc)[:200]}), 200


@app.get("/api/v59/coin")
def api_v59_coin():
    try:
        sym = _normalize_symbol(request.args.get("symbol", "BTC/USDT"))
        data, _summary, _macro = _fast_market_snapshot()
        item = next((x for x in (data or []) if isinstance(x, dict)
                     and _normalize_symbol(str(x.get("symbol"))) == sym), None)
        if not item:
            return jsonify({"ok": False, "error": "symbol_not_in_cache", "symbol": sym}), 404
        with LIVE_LOCK:
            live_map = dict(LIVE_PRICES)
        row = _v59_row(item, live_map)
        titan = item.get("titan_analysis") if isinstance(item.get("titan_analysis"), dict) else {}
        tech = item.get("technical") if isinstance(item.get("technical"), dict) else {}
        ai_ops = item.get("ai_opinions") if isinstance(item.get("ai_opinions"), dict) else {}
        pat = item.get("patterns") if isinstance(item.get("patterns"), dict) else {}
        fc = item.get("candle_forecast") if isinstance(item.get("candle_forecast"), dict) else {}
        edge = item.get("edge") if isinstance(item.get("edge"), dict) else {}
        fusion = item.get("fusion") if isinstance(item.get("fusion"), dict) else {}
        tfb = row["tfs"]
        vol = _v59_num(item.get("volatility_pct"), 0.0)
        gap = abs(_v59_num(item.get("score"), 50.0) - 50.0)
        align = _v59_num(titan.get("alignment"), _v59_num(item.get("alignment"), 0.0))
        h4 = tfb.get("4h", {}).get("dir", "WAIT")
        # AI ensemble (per provider vote + snippet)
        ens = edge.get("ai") if isinstance(edge.get("ai"), dict) else {}
        if not ens.get("details"):
            try:
                ens = TITAN_EDGE_SUITE.ai_ensemble(ai_ops, item.get("bias", "خنثی"))
            except Exception:
                _swallow()
                ens = {}
        ai_text = {str(k): str(v)[:1400] for k, v in ai_ops.items()
                   if isinstance(v, str) and v.strip() and k not in ("ai_status", "providers")}
        # neural layers
        neural = item.get("neural_v9") if isinstance(item.get("neural_v9"), dict) else {}
        layers = {}
        if isinstance(neural.get("layers"), dict):
            for k, v in neural["layers"].items():
                if isinstance(v, dict):
                    layers[str(k)] = {"score": v.get("score"), "side": v.get("side"), "weight": v.get("weight")}
        prec = item.get("precision") if isinstance(item.get("precision"), dict) else {}
        pat_list = []
        if isinstance(pat.get("patterns"), list):
            pat_list = [{"id": p.get("id"), "confidence": p.get("confidence")} for p in pat["patterns"][:6] if isinstance(p, dict)]
        elif isinstance(pat.get("primary"), dict):
            pat_list = [{"id": pat["primary"].get("id"), "confidence": pat["primary"].get("confidence")}]
        prim = pat.get("primary") if isinstance(pat.get("primary"), dict) else {}
        detail = {
            "entry": _v59_num(item.get("entry_raw"), row["price"]),
            "sl": _v59_num(item.get("stop_loss_raw"), 0.0),
            "tp1": _v59_num(item.get("tp1_raw"), 0.0),
            "tp2": _v59_num(item.get("tp2_raw"), 0.0),
            "rr1": _v59_num(item.get("rr_tp1"), 0.0),
            "rr2": _v59_num(item.get("rr_tp2"), 0.0),
            "risk_pct": _v59_num(item.get("risk_distance_pct"), 0.0),
            "trend": {"LONG": "Bullish", "SHORT": "Bearish"}.get(h4, "Neutral"),
            "momentum": "Strong" if gap >= 18 else "Moderate" if gap >= 8 else "Weak",
            "volatility": "Low" if vol < 1.0 else "Medium" if vol < 3.0 else "High",
            "regime": "Trending" if align >= 65 else "Ranging",
            "support": tech.get("support"), "resistance": tech.get("resistance"),
            "fib": tech.get("fibonacci") or {},
            "bollinger": tech.get("bollinger") or {},
            "summary": titan.get("summary") or "",
            "reasons_for": titan.get("reasons_for") or [],
            "reasons_against": titan.get("reasons_against") or [],
            "invalidation": titan.get("invalidation") or "",
            "conviction": titan.get("conviction") or "",
            "rsi": _v59_num(item.get("rsi_value"), _v59_num(item.get("rsi"), 50.0)),
            "macd": _v59_scalars(item.get("macd")),
            "stoch_rsi": _v59_scalars(item.get("stoch_rsi")),
            "volatility_pct": vol,
            "pivots": item.get("pivots") or {},
            "patterns": pat_list,
            "pattern_bias": prim.get("bias") or pat.get("bias"),
            "order_blocks": _v59_summarize(item.get("order_blocks_fvg")),
            "buy_sell": _v59_scalars(item.get("buy_sell")),
            "volume_delta": _v59_scalars(item.get("volume_delta")),
            "long_ratio": item.get("long_ratio"), "short_ratio": item.get("short_ratio"),
            "top_long_ratio": item.get("top_long_ratio"),
            "taker_buy_pct": item.get("taker_buy_pct"), "taker_sell_pct": item.get("taker_sell_pct"),
            "funding": item.get("coinglass_funding"), "oi": item.get("coinglass_oi"),
            "whale": _v59_scalars(item.get("whale")),
            "depth": _v59_scalars(item.get("depth")),
            "sentiment": _v59_scalars(item.get("sentiment")),
            "session": _v59_summarize(item.get("session")),
            "btc_corr": _v59_scalars(item.get("btc_correlation")),
            "prob": (lambda: (lambda _sc, _al, _nq, _nc, _sq, _sp, _tr, _opp, _meta, _conf, _ai: {
                # Never show blank 0 when underlying signals exist — derive honest composites
                "success": round(_sp if _sp > 1 else clamp(45 + abs(_sc - 50) * 0.7 + (_al - 50) * 0.15, 5, 92), 1),
                "quality": round(_sq if _sq > 1 else clamp(40 + abs(_sc - 50) * 0.9 + (_nq - 50) * 0.2, 5, 95), 1),
                "trust": round(_tr if _tr > 1 else clamp(35 + (_sp if _sp > 1 else 50) * 0.25 + (_al - 50) * 0.3 + (_ai * 0.15), 5, 95), 1),
                "opportunity": round(_opp if _opp > 1 else clamp(30 + abs(_sc - 50) * 1.1 + max(0, _conf - 45) * 0.35, 0, 95), 1),
                "neural": round(_nq if _nq > 1 else clamp(50 + (_sc - 50) * 0.8, 5, 95), 1),
                "neural_conf": round(_nc if _nc > 1 else clamp(40 + abs(_sc - 50) * 0.9, 5, 95), 1),
                "meta_prob": round(_meta if _meta > 1 else clamp(42 + abs(_sc - 50) * 0.75 + (_al - 50) * 0.2, 5, 90), 1),
                "confluence": round(_conf if _conf > 1 else clamp(40 + abs(_sc - 50) * 0.85 + (_al - 50) * 0.25, 5, 95), 1),
                "ai_agree": round(_ai if _ai > 0 else 0.0, 1),
            })(
                _v59_num(item.get("score"), row.get("score") or 50),
                _v59_num(item.get("alignment"), row.get("align") or 50),
                _v59_num(item.get("neural_score"), _v59_num((neural or {}).get("neural_score"), 0)),
                _v59_num(item.get("neural_confidence"), _v59_num((neural or {}).get("confidence"), 0)),
                _v59_num(item.get("signal_quality"), 0),
                _v59_num(item.get("success_probability"), _v59_num((item.get("fusion") or {}).get("success_probability") if isinstance(item.get("fusion"), dict) else 0, 0)),
                _v59_num(item.get("trust_index"), 0),
                _v59_num(item.get("opportunity_score"), 0),
                _v59_num((edge.get("meta") or {}).get("probability") if isinstance(edge.get("meta"), dict) else 0, 0),
                _v59_num((edge.get("confluence") or {}).get("score") if isinstance(edge.get("confluence"), dict) else 0, 0),
                _v59_num(ens.get("agreement"), 0),
            ))(),
            "grade": {
                "grade": item.get("grade"), "label": item.get("grade_label"), "action": item.get("grade_action"),
                "trust": item.get("trust_index"),
                "checklist": [{"name": c.get("name"), "ok": bool(c.get("ok")), "detail": c.get("detail")}
                              for c in (item.get("grade_checklist") or []) if isinstance(c, dict)][:12],
                "gates": _v59_scalars(item.get("confidence_gates")),
            },
            "edge": {k: _v59_scalars(edge.get(k)) for k in ("regime", "risk", "liquidity", "structure", "confluence", "meta", "governor")},
            "neural": {**_v59_scalars(neural), "layers": layers},
            "meta_v8": _v59_scalars(item.get("meta_v8")),
            "ladder": _v59_scalars(item.get("entry_ladder")),
            "data_quality": _v59_scalars(item.get("data_quality")),
            "forecast_acc": _v59_scalars(item.get("forecast_accuracy")),
            "precision": {**_v59_scalars(prec)},
            "ai": {
                "votes": ens.get("votes") or {}, "details": ens.get("details") or {},
                "agreement": ens.get("agreement"), "majority": ens.get("majority"),
                "majority_agreement": ens.get("majority_agreement"), "status": ens.get("status"),
                "tally": ens.get("tally") or {}, "text": ai_text,
                "fusion_majority": fusion.get("ai_majority"), "conflict": bool(fusion.get("ai_conflict")),
            },
            "forecast": {
                "ok": bool(fc.get("ok")), "bias": fc.get("overall_bias"),
                "expected_move_pct": fc.get("expected_move_pct"), "narrative": fc.get("narrative"),
                "path_strength": fc.get("path_strength"), "analogue_corr": fc.get("analogue_corr"),
                "candles": [{k: c.get(k) for k in ("step", "open", "high", "low", "close", "band_low", "band_high", "direction", "confidence")}
                            for c in (fc.get("candles") or [])[:14] if isinstance(c, dict)],
            },
        }
        return jsonify(_v59_clean({"ok": True, "row": row, "detail": detail}))
    except Exception as exc:
        LOGGER.exception("v59 coin failed: %s", exc)
        return jsonify({"ok": False, "error": str(exc)[:300]}), 500


@app.get("/api/v59/performance")
def api_v59_performance():
    try:
        days = int(request.args.get("days", 30) or 30)
        since = 0.0 if days <= 0 else time.time() - days * 86400.0
        with DB_LOCK, db_conn() as con:
            frows = con.execute(
                "SELECT created_at,outcome,timeframe,direction FROM forecasts "
                "WHERE outcome IN ('WIN','LOSS') AND created_at>=? ORDER BY created_at ASC", (since,)).fetchall()
            prows = con.execute(
                "SELECT r_multiple FROM paper_trades WHERE status='CLOSED' AND r_multiple IS NOT NULL AND created_at>=?",
                (since,)).fetchall()
        wins = sum(1 for r in frows if r["outcome"] == "WIN")
        total = len(frows)
        # win-rate trend: cumulative win rate sampled into <=36 buckets
        trend = []
        if total:
            step = max(1, total // 36)
            w = 0
            for i, r in enumerate(frows, 1):
                w += 1 if r["outcome"] == "WIN" else 0
                if i % step == 0 or i == total:
                    trend.append({"t": float(r["created_at"]), "wr": round(w / i * 100, 1)})

        def _grp(key_fn):
            acc: dict[str, list[int]] = {}
            for r in frows:
                k = key_fn(r)
                a = acc.setdefault(k, [0, 0])
                a[0] += 1
                a[1] += 1 if r["outcome"] == "WIN" else 0
            return acc

        by_tf = [{"tf": k, "trades": v[0], "wins": v[1], "wr": round(v[1] / v[0] * 100, 1)}
                 for k, v in sorted(_grp(lambda r: str(r["timeframe"])).items())]
        by_dir_raw = _grp(lambda r: "LONG" if str(r["direction"]) in ("صعودی", "LONG") else "SHORT")
        by_dir = [{"dir": k, "trades": v[0], "wins": v[1], "wr": round(v[1] / v[0] * 100, 1)}
                  for k, v in sorted(by_dir_raw.items())]
        series = _safe_return_series([_v59_num(r[0]) for r in prows])
        return jsonify(_v59_clean({
            "ok": True, "days": days, "total": total, "wins": wins, "losses": total - wins,
            "win_rate": round(wins / total * 100, 1) if total else 0.0,
            "expectancy": series.get("expectancy"), "profit_factor": series.get("profit_factor"),
            "paper_trades": series.get("trades"), "trend": trend, "by_tf": by_tf, "by_dir": by_dir,
        }))
    except Exception as exc:
        LOGGER.exception("v59 performance failed: %s", exc)
        return jsonify({"ok": False, "error": str(exc)[:300]}), 500



_V59_PAGE_HEAD = (
    '<!doctype html><html lang="en"><head><meta charset="utf-8">'
    '<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1, viewport-fit=cover">'
    '<meta name="theme-color" content="#02060f"><meta name="color-scheme" content="dark">'
    '<title>TITAN V59</title>'
    '<style>html,body{margin:0;height:100%;background:#02060f;color:#e8f1ff}html[data-layout=compact] .card{padding:8px}html[data-layout=wide] .wrap{max-width:1100px}html[data-density=dense] .card{margin:6px 0}html[data-card=solid] .glass{backdrop-filter:none}html[data-tabs=underline] .chip.on{border-bottom:2px solid var(--a)}html[data-menu=pill] .nav button{border-radius:999px}html[data-nav=top] .nav{order:-1}html.no-hero .tick{display:none}</style></head><body>'
)
_V59_PAGE_TAIL = '</body></html>'


def _v59_page_response():
    """The one and only dashboard page: TITAN V73 UI (dark colorful glass windows)."""
    return _V73_UI, 200, {
        "Content-Type": "text/html; charset=utf-8",
        "Cache-Control": "no-store",
    }
