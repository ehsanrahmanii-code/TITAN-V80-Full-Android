# [TITAN V77 layer] ui/v63_glass_v59_skin - V63 glass UI + V59 mobile skin
# Original V76 source lines 24021-24373 (kept verbatim unless listed in CHANGELOG.md).
# ============================================================
# TITAN V63 — GLASS UI (replaces the former V59 interface)
# Android-first glassmorphism dashboard: widgets, floating windows, full
# personalisation. Uses the existing read-only APIs (/api/v59/*, /api/klines,
# /api/ai-votes, /rescan, /update_settings). Analysis only; no order execution.
# Personalisation is stored in the browser (localStorage), not on disk.
# ============================================================
# _V63_GLASS_UI removed — only Pro UI remains (V72)
_V63_GLASS_UI = ''  # removed: classic dashboard deleted


# Legacy V59 markup was removed in V63; the name stays defined because the V61/V62
# patch blocks below still do string operations on it (they are now no-ops for the UI).
_V59_UI_MARKUP = '<!-- V59 UI replaced by V63 glass UI -->'

# ============================================================
# TITAN V59 MOBILE UI SKIN  (dashboard redesign matching the approved mockup)
# - Adds /api/v59/ui-data, /api/v59/coin, /api/v59/performance (read-only, cache based, no scan trigger)
# - Injects a full-screen mobile app (Home / Markets / Signals / Performance / Settings / Coin / Alerts)
#   on top of the classic dashboard. Classic dashboard stays intact (Settings -> "Classic Dashboard").
# - Analysis only. Nothing here writes to disk or places orders.
# ============================================================
_V59_UI_CACHE: dict[str, Any] = {"ts": 0.0, "payload": None}
_V59_UI_LOCK = threading.Lock()
_V59_UI_TTL = 1.2  # short so progressive partial scans appear quickly in the UI


def _v59_clean(obj: Any, depth: int = 0) -> Any:
    """JSON-safe copy: numpy scalars, NaN/inf, tuples, nested depth guard."""
    if depth > 6:
        return None
    if obj is None or isinstance(obj, (str, bool)):
        return obj
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (float, np.floating)):
        f = float(obj)
        return f if math.isfinite(f) else None
    if isinstance(obj, int):
        return obj
    if isinstance(obj, dict):
        return {str(k): _v59_clean(v, depth + 1) for k, v in list(obj.items())[:80]}
    if isinstance(obj, (list, tuple)):
        return [_v59_clean(v, depth + 1) for v in list(obj)[:80]]
    return str(obj)[:300]


def _v59_num(value: Any, default: float = 0.0) -> float:
    try:
        if value is None:
            return default
        if isinstance(value, (int, float, np.integer, np.floating)):
            f = float(value)
        else:
            f = float(str(value).replace(",", "").replace("$", "").replace("%", "").strip())
        return f if math.isfinite(f) else default
    except Exception:
        _swallow()
        return default


def _v59_dir_from_text(text: Any) -> str:
    t = str(text or "")
    if "صعود" in t or "LONG" in t.upper() or "BUY" in t.upper():
        return "LONG"
    if "نزول" in t or "SHORT" in t.upper() or "SELL" in t.upper():
        return "SHORT"
    return "WAIT"


def _v59_live_info(live_map: dict, symbol: str) -> dict:
    ns = _normalize_symbol(symbol)
    bare = _normalize_symbol_for_binance(ns)
    for key in (ns, bare, bare.replace("USDT", "/USDT")):
        if key in live_map:
            return live_map[key] or {}
    return {}


def _v59_tf_block(item: dict) -> dict:
    tfs = item.get("tfs") if isinstance(item.get("tfs"), dict) else {}
    scores = item.get("tf_scores") if isinstance(item.get("tf_scores"), dict) else {}
    out = {}
    for tf in ("15m", "1h", "4h", "1d"):
        d = _v59_dir_from_text(tfs.get(tf))
        s = _v59_num(scores.get(tf), _v59_num(item.get("score"), 50.0))
        out[tf] = {"dir": d, "conf": int(round(clamp(50.0 + abs(s - 50.0), 0, 100))), "score": round(s, 1)}
    return out


def _v59_primary_tf(tfb: dict) -> str:
    best, best_gap = "1h", -1.0
    for tf, v in tfb.items():
        gap = abs(_v59_num(v.get("score"), 50.0) - 50.0)
        if gap > best_gap:
            best, best_gap = tf, gap
    return best


def _v59_row(item: dict, live_map: dict) -> dict:
    sym = str(item.get("symbol") or "")
    info = _v59_live_info(live_map, sym)
    live_px = _v59_num(info.get("price"), 0.0)
    price = live_px if live_px > 0 else _v59_num(item.get("price"), 0.0)
    fam = _titan_ui_family(item)
    score = _v59_num(item.get("score"), 50.0)
    sp = _v59_num(item.get("success_probability"), 0.0)
    conf = sp if sp > 1.0 else 50.0 + abs(score - 50.0)
    tfb = _v59_tf_block(item)
    return {
        "symbol": sym,
        "base": str(item.get("base_symbol") or sym.split("/")[0]),
        "name": str(item.get("coin_name") or ""),
        "price": price,
        "change": round((lambda _ch: (
            _ch if abs(_ch) > 1e-9 else _v59_num(((get_24h_tickers_cached([sym]) or {}).get(sym) or {}).get("change_pct_24h"), 0.0)
        ))(_v59_num(info.get("change_pct_24h"), _v59_num(info.get("change_pct"), 0.0))), 3),
        "decision": fam,
        "conf": int(round(clamp(conf, 0, 100))),
        "score": round(score, 1),
        "grade": str(item.get("grade") or item.get("signal_grade") or ""),
        "tf": _v59_primary_tf(tfb),
        "tfs": tfb,
        "asof": str(item.get("analysis_asof_utc") or ""),
        "fresh": bool(info.get("ts") and (time.time() - _v59_num(info.get("ts"), 0)) <= 15),
        "rr": _v59_num(item.get("rr_tp1"), 0.0),
        "prob": int(round(clamp(_v59_num(item.get("success_probability"), 0.0), 0, 100))),
        "trust": _v59_num(item.get("trust_index"), 0.0),
        "grade_fa": str(item.get("grade_label") or ""),
        "funnel": (lambda f: {
            "score": round(float(f.get("score") or 0), 3),
            "quality": str(f.get("quality") or "F"),
            "action": str(f.get("action") or "WAIT"),
            "urgency": round(float(f.get("urgency") or 0), 3),
            "stage": str(f.get("stage") or ""),
            "stages": list(f.get("stages") or [])[:8],
            "reasons": list(f.get("reasons") or [])[:6],
        })(item.get("v78_funnel") or item.get("opportunity_funnel") or {}),

        "buy": int(round(_v59_num((item.get("buy_sell") or {}).get("buy_pct") if isinstance(item.get("buy_sell"), dict) else None, 50.0))),
        "whale_delta": _v59_num(
            (item.get("whale") or {}).get("oi_delta") if isinstance(item.get("whale"), dict) else None,
            _v59_num((item.get("whale") or {}).get("score") if isinstance(item.get("whale"), dict) else None, 50.0) - 50.0
        ),
        "whale_label": str((item.get("whale") or {}).get("label") or "") if isinstance(item.get("whale"), dict) else "",
        "whale_score": _v59_num((item.get("whale") or {}).get("score") if isinstance(item.get("whale"), dict) else None, 50.0),
        "funding": item.get("coinglass_funding"),
        "ai_majority": str(item.get("ai_majority") or ""),
        "vol": round(_v59_num(item.get("volatility_pct"), 0.0), 2),
        "bias": str(item.get("bias") or ""),
        "quality": _v59_num(item.get("signal_quality"), 0.0),
        "oi": item.get("coinglass_oi"),
        "rsi": round(_v59_num(item.get("rsi_value"), _v59_num(item.get("rsi"), 50.0)), 1),
        "align": round(_v59_num((item.get("titan_analysis") or {}).get("alignment") if isinstance(item.get("titan_analysis"), dict) else None,
                                _v59_num(item.get("alignment"), 50.0)), 1),
        "vspike": bool(item.get("volume_spike")),
    }


def _v59_scan() -> dict:
    try:
        s = _scan_progress_snapshot() or {}
        return {k: s.get(k) for k in ("status", "phase", "percent", "message", "completed", "total", "fresh")}
    except Exception:
        _swallow()
        return {}


def _v59_scalars(value: Any, limit: int = 24) -> dict:
    """Shallow, JSON-safe copy keeping only scalar values (and short lists of scalars)."""
    out: dict[str, Any] = {}
    if not isinstance(value, dict):
        return out
    for k, v in list(value.items())[:limit]:
        if isinstance(v, (str, int, float, bool, np.integer, np.floating)) or v is None:
            out[str(k)] = v
        elif isinstance(v, (list, tuple)) and v and all(isinstance(x, (str, int, float)) for x in v[:6]):
            out[str(k)] = list(v[:6])
    return out


def _v59_alerts(limit: int = 15) -> list:
    try:
        with DB_LOCK, db_conn() as con:
            rows = con.execute(
                "SELECT id,created_at,severity,symbol,category,message FROM alerts ORDER BY id DESC LIMIT ?",
                (int(limit),)).fetchall()
        return [dict(r) for r in rows]
    except Exception:
        _swallow()
        return []


def _v59_paper_summary() -> dict:
    try:
        with DB_LOCK, db_conn() as con:
            open_n = con.execute("SELECT COUNT(*) FROM paper_trades WHERE status='OPEN'").fetchone()[0]
            vals = [_v59_num(r[0]) for r in con.execute(
                "SELECT r_multiple FROM paper_trades WHERE status='CLOSED' AND r_multiple IS NOT NULL").fetchall()]
        series = _safe_return_series(vals)
        return {"open": int(open_n), "closed": len(vals), "profit_factor": series.get("profit_factor"),
                "expectancy": series.get("expectancy"), "win_rate": series.get("win_rate")}
    except Exception:
        _swallow()
        return {"open": 0, "closed": 0, "profit_factor": None, "expectancy": None, "win_rate": None}


def _v59_build_ui_payload() -> dict:
    data, summary, macro = _fast_market_snapshot()
    with LIVE_LOCK:
        live_map = dict(LIVE_PRICES)
    # Merge real 24h change into live map so rows never show empty change%
    try:
        t24 = get_24h_tickers_cached([str(x.get("symbol") or "") for x in (data or []) if isinstance(x, dict)])
        for sym, st in (t24 or {}).items():
            ns = _normalize_symbol(sym)
            row = live_map.get(ns) or live_map.get(sym) or {}
            ch = safe_float(st.get("change_pct_24h"), float("nan"))
            if math.isfinite(ch):
                row = dict(row)
                row["change_pct"] = ch
                row["change_pct_24h"] = ch
                if safe_float(row.get("price"), 0) <= 0 and safe_float(st.get("last"), 0) > 0:
                    row["price"] = float(st["last"])
                live_map[ns] = row
    except Exception:
        _swallow()
    rows = [_v59_row(x, live_map) for x in (data or []) if isinstance(x, dict)]
    counts = {"LONG": 0, "SHORT": 0, "WAIT": 0}
    for r in rows:
        counts[r["decision"]] = counts.get(r["decision"], 0) + 1
    up = sum(1 for r in rows if r["change"] > 0.05)
    down = sum(1 for r in rows if r["change"] < -0.05)
    try:
        audit = get_audit_stats()
    except Exception:
        _swallow()
        audit = {}
    macro = macro if isinstance(macro, dict) else {}
    with CACHE_LOCK:
        cache_ts = float(CACHE.get("timestamp") or 0)
    elite: dict = {}  # Elite Bots are computed client-side only (ephemeral, never persisted)
    return _v59_clean({
        "ok": True,
        "server_time": int(time.time() * 1000),
        "version": "V60",
        "storage": TITAN_FOLDER_NAME,
        "platform": "Android",
        "cache_age": round(max(0.0, time.time() - cache_ts), 1) if cache_ts else None,
        "rows": rows,
        "counts": counts,
        "breadth": {"up": up, "down": down, "flat": max(0, len(rows) - up - down)},
        "macro": {"fear": macro.get("fear_greed_val"), "fear_text": macro.get("fear_greed_text"),
                  "btc_dom": macro.get("dominance_btc"), "btc_trend": macro.get("btc_trend")},
        "risk": USER_SETTINGS.get("risk_multiplier"),
        "build": TITAN_BUILD_ID,
        "audit": {k: audit.get(k) for k in ("evaluated", "wins", "losses", "win_rate", "tier", "tier_label",
                                            "long_win_rate", "short_win_rate", "long_trades", "short_trades")},
        "paper": _v59_paper_summary(),
        "alerts": _v59_alerts(15),
        "coins": list(USER_SETTINGS.get("active_coins") or DEFAULT_COINS),
        "elite": elite,
        "summary": str(summary or "")[:1800],
        "scan": _v59_scan(),
        "avg_score": round(sum(r["score"] for r in rows) / len(rows), 1) if rows else 50.0,
    })



@app.get("/api/v60-edge-router")
def api_v60_edge_router():
    """V60 Edge Router inspection: Coin×TF matrix from real performance_snapshots."""
    try:
        force = str(request.args.get("refresh", "")).lower() in {"1", "true", "yes"}
        symbol = request.args.get("symbol") or ""
        tf = request.args.get("timeframe") or ""
        matrix = v60_get_matrix(force=force)
        cells = matrix.get("cells") or {}
        if symbol:
            sym = _v60_norm_sym(symbol)
            cells = {k: v for k, v in cells.items() if v.get("symbol") == sym}
        if tf:
            cells = {k: v for k, v in cells.items() if v.get("timeframe") == tf}
        # Rank for dashboard
        ranked = sorted(cells.values(), key=lambda c: safe_float(c.get("edge_score"), -99), reverse=True)
        summary = {
            "strong": sum(1 for c in ranked if c.get("grade") == "STRONG"),
            "positive": sum(1 for c in ranked if c.get("grade") == "POSITIVE"),
            "neutral": sum(1 for c in ranked if c.get("grade") == "NEUTRAL"),
            "weak": sum(1 for c in ranked if c.get("grade") == "WEAK"),
            "toxic": sum(1 for c in ranked if c.get("grade") == "TOXIC"),
            "sparse": sum(1 for c in ranked if c.get("grade") == "SPARSE"),
            "total_cells": len(ranked),
        }
        demo_route = None
        if symbol:
            demo_route = v60_route_decision(
                symbol=symbol,
                candidate=str(request.args.get("side") or "LONG").upper(),
                proposed=str(request.args.get("side") or "LONG").upper(),
                hard_reasons=[],
                soft_reasons=[],
                timeframe=tf or "1h",
                confidence=safe_float(request.args.get("confidence"), 55),
                effective_rr1=safe_float(request.args.get("rr"), 1.3),
                data_quality=safe_float(request.args.get("dq"), 55),
            )
        return jsonify(_v59_clean({
            "ok": True,
            "version": V60_VERSION,
            "build": V60_BUILD_ID,
            "source": "performance_snapshots@LLL",
            "matrix_age_sec": round(max(0.0, time.time() - float(matrix.get("ts") or 0)), 1),
            "tf_priors": matrix.get("tf_priors"),
            "summary": summary,
            "cells": ranked[:80],
            "route_demo": demo_route,
            "policy": {
                "hard_wait": "invalid levels / RR floor / live price / extreme vol / correlation",
                "soft_wait": "weak cell or insufficient score — lean preserved",
                "routed_action": "strong/positive hist cell + DQ/RR ok",
                "15m": "defensive weight when toxic/weak",
                "4h_1d": "preferred when edge positive",
            },
        }))
    except Exception as exc:
        LOGGER.exception("v60 edge router api: %s", exc)
        return jsonify({"ok": False, "error": str(exc)[:300]}), 500



@app.get("/api/v59/ui-data")
def api_v59_ui_data():
    try:
        now = time.time()
        with _V59_UI_LOCK:
            cached = _V59_UI_CACHE.get("payload")
            if cached is not None and now - float(_V59_UI_CACHE.get("ts") or 0) < _V59_UI_TTL:
                return jsonify(cached)
        payload = _v59_build_ui_payload()
        with _V59_UI_LOCK:
            _V59_UI_CACHE["payload"] = payload
            _V59_UI_CACHE["ts"] = time.time()  # FIX: stamp after build, not before
        return jsonify(payload)
    except Exception as exc:
        LOGGER.exception("v59 ui-data failed: %s", exc)
        return jsonify({"ok": False, "error": str(exc)[:300], "rows": []}), 500


def _v59_summarize(value: Any) -> Any:
    if isinstance(value, dict):
        out = {}
        for k, v in list(value.items())[:24]:
            if isinstance(v, (list, tuple)):
                out[str(k)] = len(v)
            elif isinstance(v, dict):
                continue
            else:
                out[str(k)] = v
        return out
    return value
