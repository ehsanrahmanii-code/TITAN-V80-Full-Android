# [TITAN V78.2 layer] ui/v78_personalization
# ============================================================
# TITAN V78.2 — ADVANCED UI PERSONALIZATION (Studio)
# Theme · Layout · Lighting · Schematic shapes · Chart style ·
# Shape language · Density · Live apply (no forced full reload)
# Settings persist in SQLite; CSS vars + data-* drive the desk.
# ============================================================
V78_UI_VERSION = "TITAN-V78.2-UI-STUDIO"

_V78_UI_DEFAULTS = {
    "theme": "midnight_glass",
    "layout": "pro_desk",  # pro_desk | compact | wide | focus | classic | mosaic
    "accent": "#00d4aa",
    "accent2": "#7c5cff",
    "bg_primary": "#0b0f19",
    "bg_card": "rgba(18,24,38,0.82)",
    "text_primary": "#e8eef7",
    "text_muted": "#8b9bb4",
    "color_up": "#1fce9a",
    "color_down": "#ff5d73",
    "border_radius": "14px",
    "font_scale": "1.0",
    "density": "comfortable",  # compact | comfortable | spacious
    "chart_style": "candles_pro",  # candles_pro | heikin | hollow | line | area | ohlc | baseline
    "chart_grid": True,
    "chart_volume": True,
    "chart_ema": True,
    "chart_bb": False,
    "chart_geometry": "zones",  # none | zones | channel | swings | fib
    "loading_style": "orbit",  # orbit | pulse | bars | skeleton | minimal
    "logo_url": "",
    "logo_text": "TITAN PRO",
    "logo_mark": "titan",  # titan | ring | hex | chevron | diamond | none
    "shape_style": "rounded",  # rounded | sharp | soft | pill | cut | bevel
    "schematic_style": "flow",  # flow | circuit | hex | orbital | diamond | neural | chevron
    "schematic_glow": True,
    "lighting": "studio",  # studio | rim | neon | candle | aurora | volumetric | moonlit | flat
    "light_intensity": 62,  # 0..100
    "animation_level": "full",  # full | reduced | none
    "sidebar_position": "start",  # start | end | hidden
    "show_forecast_candles": True,
    "show_probability_cone": True,
    "show_funnel_badge": True,
    "show_eval_panel": True,
    "show_schematic": True,
    "language": "fa",
    "number_format": "en",
}

_V78_THEMES = {
    "midnight_glass": {
        "bg_primary": "#0b0f19",
        "bg_card": "rgba(18,24,38,0.82)",
        "accent": "#00d4aa",
        "accent2": "#7c5cff",
        "text_primary": "#e8eef7",
        "text_muted": "#8b9bb4",
        "color_up": "#1fce9a",
        "color_down": "#ff5d73",
    },
    "pure_dark": {
        "bg_primary": "#050505",
        "bg_card": "rgba(20,20,20,0.95)",
        "accent": "#22c55e",
        "accent2": "#3b82f6",
        "text_primary": "#f5f5f5",
        "text_muted": "#a3a3a3",
        "color_up": "#22c55e",
        "color_down": "#ef4444",
    },
    "arctic": {
        "bg_primary": "#0f172a",
        "bg_card": "rgba(30,41,59,0.9)",
        "accent": "#38bdf8",
        "accent2": "#a78bfa",
        "text_primary": "#f1f5f9",
        "text_muted": "#94a3b8",
        "color_up": "#34d399",
        "color_down": "#fb7185",
    },
    "neon_pro": {
        "bg_primary": "#0a0a12",
        "bg_card": "rgba(15,15,30,0.88)",
        "accent": "#f472b6",
        "accent2": "#22d3ee",
        "text_primary": "#fdf4ff",
        "text_muted": "#c4b5fd",
        "color_up": "#2dd4bf",
        "color_down": "#fb7185",
    },
    "desert": {
        "bg_primary": "#1c1917",
        "bg_card": "rgba(41,37,36,0.9)",
        "accent": "#f59e0b",
        "accent2": "#ef4444",
        "text_primary": "#fafaf9",
        "text_muted": "#a8a29e",
        "color_up": "#84cc16",
        "color_down": "#f43f5e",
    },
    "obsidian": {
        "bg_primary": "#100e0c",
        "bg_card": "rgba(28,24,20,0.92)",
        "accent": "#d6a15a",
        "accent2": "#7dd3c7",
        "text_primary": "#f5f0e8",
        "text_muted": "#a8a095",
        "color_up": "#6ee7b7",
        "color_down": "#fb7185",
    },
    "daylight": {
        "bg_primary": "#f3efe6",
        "bg_card": "rgba(255,253,248,0.96)",
        "accent": "#0f766e",
        "accent2": "#b45309",
        "text_primary": "#1c1917",
        "text_muted": "#78716c",
        "color_up": "#047857",
        "color_down": "#be123c",
    },
}

_V78_LAYOUTS = ("pro_desk", "compact", "wide", "focus", "classic", "mosaic")
_V78_LIGHTS = ("studio", "rim", "neon", "candle", "aurora", "volumetric", "moonlit", "flat")
_V78_SHAPES = ("rounded", "sharp", "soft", "pill", "cut", "bevel")
_V78_SCHEMATICS = ("flow", "circuit", "hex", "orbital", "diamond", "neural", "chevron")
_V78_CHARTS = ("candles_pro", "heikin", "hollow", "line", "area", "ohlc", "baseline")
_V78_GEOMETRY = ("none", "zones", "channel", "swings", "fib")
_V78_LOADINGS = ("orbit", "pulse", "bars", "skeleton", "minimal")
_V78_MARKS = ("titan", "ring", "hex", "chevron", "diamond", "none")


def _v78_safe_css_string(value: str, limit: int = 48) -> str:
    """Escape user text for safe use inside CSS / attributes."""
    text = str(value or "")[:limit]
    return (
        text.replace("\\", "\\\\")
        .replace('"', "")
        .replace("'", "")
        .replace("<", "")
        .replace(">", "")
        .replace("\n", " ")
        .replace("\r", " ")
    )


def _v78_ui_ensure_schema(con) -> None:
    con.execute(
        """
        CREATE TABLE IF NOT EXISTS v78_ui_settings(
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL,
            updated_at REAL NOT NULL
        )
        """
    )


def _v78_ui_init() -> None:
    try:
        with DB_LOCK, db_conn() as con:
            _v78_ui_ensure_schema(con)
            now = time.time()
            for k, v in _V78_UI_DEFAULTS.items():
                con.execute(
                    "INSERT OR IGNORE INTO v78_ui_settings(key, value, updated_at) VALUES (?,?,?)",
                    (k, json.dumps(v, ensure_ascii=False), now),
                )
    except Exception:
        _swallow()


def _v78_ui_get_settings() -> dict:
    _v78_ui_init()
    out = dict(_V78_UI_DEFAULTS)
    try:
        with DB_LOCK, db_conn() as con:
            for row in con.execute("SELECT key, value FROM v78_ui_settings").fetchall():
                try:
                    out[row[0]] = json.loads(row[1])
                except Exception:
                    out[row[0]] = row[1]
    except Exception:
        _swallow()
    theme = out.get("theme", "midnight_glass")
    # Named themes apply their palette; custom keeps stored colors
    if theme in _V78_THEMES and theme != "custom":
        out.update(_V78_THEMES[theme])
    # Clamp intensity
    try:
        out["light_intensity"] = int(max(0, min(100, int(out.get("light_intensity", 62)))))
    except Exception:
        out["light_intensity"] = 62
    return out


def _v78_ui_save_settings(updates: dict) -> dict:
    _v78_ui_init()
    allowed = set(_V78_UI_DEFAULTS.keys())
    now = time.time()
    color_keys = {
        "accent",
        "accent2",
        "bg_primary",
        "bg_card",
        "text_primary",
        "text_muted",
        "color_up",
        "color_down",
    }
    try:
        with DB_LOCK, db_conn() as con:
            # If user tweaks colors while on a named theme, switch to custom
            if any(k in color_keys for k in updates) and updates.get("theme") is None:
                current = _v78_ui_get_settings()
                if current.get("theme") in _V78_THEMES:
                    updates = dict(updates)
                    updates["theme"] = "custom"
            for k, v in updates.items():
                if k not in allowed:
                    continue
                if k == "logo_text":
                    v = _v78_safe_css_string(v, 22) or "TITAN PRO"
                if k == "light_intensity":
                    try:
                        v = int(max(0, min(100, int(v))))
                    except Exception:
                        v = 62
                if k == "theme" and v not in _V78_THEMES and v != "custom":
                    continue
                if k == "layout" and v not in _V78_LAYOUTS:
                    continue
                if k == "lighting" and v not in _V78_LIGHTS:
                    continue
                if k == "shape_style" and v not in _V78_SHAPES:
                    continue
                if k == "schematic_style" and v not in _V78_SCHEMATICS:
                    continue
                if k == "chart_style" and v not in _V78_CHARTS:
                    continue
                con.execute(
                    "INSERT OR REPLACE INTO v78_ui_settings(key, value, updated_at) VALUES (?,?,?)",
                    (k, json.dumps(v, ensure_ascii=False), now),
                )
            # Applying a named theme also stores its palette so get stays consistent
            theme = updates.get("theme")
            if theme in _V78_THEMES:
                for ck, cv in _V78_THEMES[theme].items():
                    con.execute(
                        "INSERT OR REPLACE INTO v78_ui_settings(key, value, updated_at) VALUES (?,?,?)",
                        (ck, json.dumps(cv, ensure_ascii=False), now),
                    )
    except Exception:
        _swallow()
    return _v78_ui_get_settings()


def _v78_ui_css_vars(settings: dict | None = None) -> str:
    """Generate CSS custom properties from settings for live theming."""
    s = settings or _v78_ui_get_settings()
    shape = s.get("shape_style", "rounded")
    radius_map = {
        "sharp": "4px",
        "rounded": "14px",
        "soft": "22px",
        "pill": "28px",
        "cut": "0px",
        "bevel": "16px",
    }
    radius = radius_map.get(shape, s.get("border_radius", "14px"))
    density = s.get("density", "comfortable")
    pad = {"compact": "0.55rem", "comfortable": "0.85rem", "spacious": "1.15rem"}.get(density, "0.85rem")
    try:
        intensity = max(0, min(100, int(s.get("light_intensity", 62)))) / 100.0
    except Exception:
        intensity = 0.62
    logo = _v78_safe_css_string(s.get("logo_text", "TITAN PRO"), 22)
    return f"""
:root {{
  --titan-bg: {s.get('bg_primary', '#0b0f19')};
  --titan-card: {s.get('bg_card', 'rgba(18,24,38,0.82)')};
  --titan-accent: {s.get('accent', '#00d4aa')};
  --titan-accent2: {s.get('accent2', '#7c5cff')};
  --titan-text: {s.get('text_primary', '#e8eef7')};
  --titan-muted: {s.get('text_muted', '#8b9bb4')};
  --titan-up: {s.get('color_up', '#1fce9a')};
  --titan-down: {s.get('color_down', '#ff5d73')};
  --titan-radius: {radius};
  --titan-pad: {pad};
  --titan-font-scale: {s.get('font_scale', '1.0')};
  --titan-glow: {intensity:.3f};
  --titan-logo-text: "{logo}";
}}
"""


def _v78_ui_layout_css() -> str:
    """CSS that makes layout / lighting / shape / schematic actually visible."""
    return r"""
/* ---- V78.2 layout ---- */
html[data-layout="compact"] .desk-grid,
html[data-layout="classic"] .desk-grid { display:flex !important; flex-direction:column !important; }
html[data-layout="wide"] .desk-grid { display:grid !important; grid-template-columns:minmax(0,1fr) minmax(240px,300px) !important; }
html[data-layout="focus"] .side-rail { display:none !important; }
html[data-layout="focus"] .main-chart { grid-column:1 / -1 !important; min-height:70vh !important; }
html[data-layout="mosaic"] .desk-grid { display:grid !important; grid-template-columns:repeat(auto-fit,minmax(280px,1fr)) !important; }
html[data-layout="pro_desk"] .desk-grid { display:grid !important; grid-template-columns:minmax(220px,280px) minmax(0,1fr) minmax(250px,330px) !important; }
html[data-sidebar="end"][data-layout="pro_desk"] .desk-grid { direction:rtl; }
html[data-sidebar="hidden"] .watch-rail { display:none !important; }

/* ---- lighting atmospheres ---- */
html[data-light="studio"] body {
  background:
    radial-gradient(1200px 420px at 50% -10%, color-mix(in srgb, var(--titan-accent) calc(var(--titan-glow) * 18%), transparent), transparent 60%),
    var(--titan-bg) !important;
}
html[data-light="aurora"] body {
  background:
    radial-gradient(720px 380px at 0% -10%, color-mix(in srgb, var(--titan-accent) calc(var(--titan-glow) * 34%), transparent), transparent 62%),
    radial-gradient(640px 360px at 100% 0%, color-mix(in srgb, var(--titan-accent2) calc(var(--titan-glow) * 30%), transparent), transparent 58%),
    var(--titan-bg) !important;
}
html[data-light="volumetric"] body {
  background:
    radial-gradient(900px 520px at 50% 18%, color-mix(in srgb, var(--titan-accent) calc(var(--titan-glow) * 22%), transparent), transparent 68%),
    var(--titan-bg) !important;
}
html[data-light="moonlit"] body {
  background:
    radial-gradient(800px 460px at 80% -20%, color-mix(in srgb, #9ec9ff calc(var(--titan-glow) * 28%), transparent), transparent 60%),
    var(--titan-bg) !important;
}
html[data-light="candle"] body {
  background:
    radial-gradient(900px 480px at 50% 120%, color-mix(in srgb, #e8a15a calc(var(--titan-glow) * 26%), transparent), transparent 55%),
    var(--titan-bg) !important;
}
html[data-light="neon"] body {
  background:
    radial-gradient(500px 240px at 12% 0%, color-mix(in srgb, var(--titan-accent) calc(var(--titan-glow) * 24%), transparent), transparent 70%),
    var(--titan-bg) !important;
}
html[data-light="neon"] .card, html[data-light="neon"] .titan-card, html[data-light="neon"] .glass, html[data-light="neon"] .panel {
  box-shadow: 0 0 0 1px color-mix(in srgb, var(--titan-accent) calc(var(--titan-glow) * 35%), transparent),
              0 0 28px color-mix(in srgb, var(--titan-accent) calc(var(--titan-glow) * 18%), transparent) !important;
}
html[data-light="rim"] .card, html[data-light="rim"] .titan-card, html[data-light="rim"] .glass, html[data-light="rim"] .panel {
  box-shadow: inset 0 1px 0 color-mix(in srgb, white calc(var(--titan-glow) * 28%), transparent),
              inset 0 0 0 1px color-mix(in srgb, var(--titan-accent) calc(var(--titan-glow) * 35%), transparent) !important;
}
html[data-light="flat"] .card, html[data-light="flat"] .titan-card, html[data-light="flat"] .glass {
  box-shadow: none !important;
}

/* ---- shape language ---- */
html[data-shape="cut"] .card, html[data-shape="cut"] .titan-card, html[data-shape="cut"] .glass, html[data-shape="cut"] .panel,
html[data-shape="cut"] .chip, html[data-shape="cut"] button {
  border-radius: 0 !important;
  clip-path: polygon(12px 0, 100% 0, 100% calc(100% - 12px), calc(100% - 12px) 100%, 0 100%, 0 12px);
}
html[data-shape="bevel"] .card, html[data-shape="bevel"] .titan-card, html[data-shape="bevel"] .glass {
  border-radius: 3px 18px 3px 18px !important;
}
html[data-shape="sharp"] .chip, html[data-shape="sharp"] button { border-radius: 3px !important; }
html[data-shape="pill"] .chip, html[data-shape="pill"] button { border-radius: 999px !important; }

/* schematic stage nodes */
.v78-schematic { display:flex; flex-wrap:wrap; gap:8px; align-items:center; justify-content:center; padding:8px 0; }
.v78-schematic .node {
  min-width:72px; text-align:center; padding:8px 10px; font-size:11px;
  border:1px solid color-mix(in srgb, var(--titan-accent) 40%, transparent);
  background: color-mix(in srgb, var(--titan-accent) 12%, transparent);
  color: var(--titan-text);
}
html[data-schematic="flow"] .v78-schematic .node { border-radius:10px; }
html[data-schematic="circuit"] .v78-schematic .node { border-radius:50%; min-width:56px; min-height:56px; display:grid; place-items:center; }
html[data-schematic="hex"] .v78-schematic .node { clip-path: polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%); border-radius:0; padding:14px 12px; }
html[data-schematic="diamond"] .v78-schematic .node { transform: rotate(0deg); clip-path: polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%); border-radius:0; padding:16px 14px; }
html[data-schematic="chevron"] .v78-schematic .node { clip-path: polygon(0 0, 75% 0, 100% 50%, 75% 100%, 0 100%, 18% 50%); border-radius:0; }
html[data-schematic="orbital"] .v78-schematic .node { border-radius:50%; box-shadow: 0 0 0 6px color-mix(in srgb, var(--titan-accent2) 18%, transparent); }
html[data-schematic="neural"] .v78-schematic .node { border-radius:14px; box-shadow: 0 0 12px color-mix(in srgb, var(--titan-accent2) 25%, transparent); }
html[data-schematic-glow="1"] .v78-schematic .node.pass {
  box-shadow: 0 0 14px color-mix(in srgb, var(--titan-accent) calc(var(--titan-glow) * 70%), transparent);
}
.v78-schematic .node.fail { border-color: var(--titan-down); background: color-mix(in srgb, var(--titan-down) 14%, transparent); }
.v78-schematic .node.hot { border-color: var(--titan-accent2); background: color-mix(in srgb, var(--titan-accent2) 18%, transparent); }
.v78-schematic .node.skip { opacity: 0.45; }

html[data-anim="none"] *, html[data-anim="reduced"] .titan-load-orbit .orb { animation: none !important; }
"""


def _v78_ui_loading_html(style: str | None = None) -> str:
    style = style or _v78_ui_get_settings().get("loading_style", "orbit")
    if style == "pulse":
        return '<div class="titan-load titan-load-pulse"><div></div></div>'
    if style == "bars":
        return '<div class="titan-load titan-load-bars"><span></span><span></span><span></span><span></span></div>'
    if style == "skeleton":
        return '<div class="titan-load titan-load-skeleton"><div class="sk"></div><div class="sk"></div><div class="sk"></div></div>'
    if style == "minimal":
        return '<div class="titan-load titan-load-minimal">...</div>'
    return '<div class="titan-load titan-load-orbit"><div class="orb"></div><div class="orb"></div><div class="orb"></div></div>'


def _v78_ui_schematic_html(stages: list | None = None) -> str:
    """Default schematic pipeline visualization for the desk."""
    stages = stages or [
        ("data", "داده", "pass"),
        ("safety", "ایمنی", "pass"),
        ("regime", "رژیم", "hot"),
        ("confluence", "هم‌گرایی", "pass"),
        ("thresholds", "آستانه", "skip"),
        ("urgency", "فوریت", "skip"),
    ]
    nodes = "".join(
        f'<div class="node {state}" data-stage="{sid}">{label}</div>' for sid, label, state in stages
    )
    return f'<div class="v78-schematic" id="v78-schematic">{nodes}</div>'


def _opt(options, current, labels=None):
    labels = labels or {}
    out = []
    for k in options:
        sel = " selected" if current == k else ""
        label = labels.get(k, k)
        out.append(f'<option value="{k}"{sel}>{label}</option>')
    return "".join(out)


def _v78_ui_panel_html() -> str:
    """Rich personalization studio panel (injected into dashboard)."""
    s = _v78_ui_get_settings()
    theme_labels = {
        "midnight_glass": "شیشهٔ نیمه‌شب",
        "pure_dark": "تیرهٔ خالص",
        "arctic": "قطبی",
        "neon_pro": "نئون",
        "desert": "کویر",
        "obsidian": "ابسیدین",
        "daylight": "روز",
        "custom": "سفارشی",
    }
    layout_labels = {
        "pro_desk": "میز حرفه‌ای",
        "compact": "ستونی",
        "wide": "عریض",
        "focus": "تمرکز نمودار",
        "classic": "کلاسیک",
        "mosaic": "موزاییک",
    }
    light_labels = {
        "studio": "استودیو",
        "rim": "لبه",
        "neon": "نئون",
        "candle": "شمع",
        "aurora": "شفق",
        "volumetric": "حجمی",
        "moonlit": "مهتاب",
        "flat": "تخت",
    }
    shape_labels = {
        "rounded": "گرد",
        "sharp": "تیز",
        "soft": "نرم",
        "pill": "کپسولی",
        "cut": "برش",
        "bevel": "پخ",
    }
    sch_labels = {
        "flow": "جریان",
        "circuit": "مدار",
        "hex": "شش‌ضلعی",
        "orbital": "مداری",
        "diamond": "لوزی",
        "neural": "شبکه",
        "chevron": "شورون",
    }
    chart_labels = {
        "candles_pro": "کندل توپر",
        "heikin": "هایکین",
        "hollow": "توخالی",
        "line": "خط",
        "area": "ناحیه",
        "ohlc": "میله OHLC",
        "baseline": "خط مبنا",
    }
    geo_labels = {
        "none": "بدون شکل",
        "zones": "زون حمایت/مقاومت",
        "channel": "کانال",
        "swings": "سقف و کف",
        "fib": "فیبوناچی",
    }
    load_labels = {
        "orbit": "مدار",
        "pulse": "پالس",
        "bars": "میله",
        "skeleton": "اسکلت",
        "minimal": "حداقلی",
    }
    themes = _opt(list(_V78_THEMES.keys()) + ["custom"], s.get("theme"), theme_labels)
    layouts = _opt(_V78_LAYOUTS, s.get("layout"), layout_labels)
    lights = _opt(_V78_LIGHTS, s.get("lighting"), light_labels)
    shapes = _opt(_V78_SHAPES, s.get("shape_style"), shape_labels)
    schematics = _opt(_V78_SCHEMATICS, s.get("schematic_style"), sch_labels)
    charts = _opt(_V78_CHARTS, s.get("chart_style"), chart_labels)
    geos = _opt(_V78_GEOMETRY, s.get("chart_geometry"), geo_labels)
    loadings = _opt(_V78_LOADINGS, s.get("loading_style"), load_labels)
    intensity = int(s.get("light_intensity", 62))
    logo = _v78_safe_css_string(s.get("logo_text", "TITAN PRO"), 22)
    accent = s.get("accent", "#00d4aa")
    accent2 = s.get("accent2", "#7c5cff")
    density = s.get("density", "comfortable")
    schematic_html = _v78_ui_schematic_html()

    return f"""
<div id="v78-ui-panel" class="titan-card" style="display:none; max-width:440px; z-index:9999;">
  <h3 style="margin:0 0 8px; color:var(--titan-accent)">استودیوی شخصی‌سازی · V78.2</h3>
  <p style="margin:0 0 10px; font-size:12px; color:var(--titan-muted)">تغییرها بلافاصله اعمال می‌شوند؛ ذخیره برای ماندگاری در همین مرورگر/سرور.</p>
  <div class="v78-studio-preview" style="margin-bottom:10px; padding:10px; border:1px solid rgba(255,255,255,.08); border-radius:var(--titan-radius);">
    <div style="font-weight:600; margin-bottom:6px; color:var(--titan-accent)">{logo}</div>
    {schematic_html}
  </div>
  <label>تم</label><select id="v78-theme">{themes}</select>
  <label>چینش</label><select id="v78-layout">{layouts}</select>
  <label>نورپردازی</label><select id="v78-lighting">{lights}</select>
  <label>شدت نور ({intensity})</label>
  <input type="range" id="v78-intensity" min="0" max="100" value="{intensity}"/>
  <label>اشکال رابط</label><select id="v78-shape">{shapes}</select>
  <label>شکل شماتیک</label><select id="v78-schematic">{schematics}</select>
  <label>سبک نمودار</label><select id="v78-chart">{charts}</select>
  <label>اشکال روی نمودار</label><select id="v78-geometry">{geos}</select>
  <label>سبک بارگذاری</label><select id="v78-loading">{loadings}</select>
  <label>تراکم</label>
  <select id="v78-density">
    <option value="compact" {"selected" if density=="compact" else ""}>فشرده</option>
    <option value="comfortable" {"selected" if density=="comfortable" else ""}>عادی</option>
    <option value="spacious" {"selected" if density=="spacious" else ""}>باز</option>
  </select>
  <label>رنگ اصلی</label><input type="color" id="v78-accent" value="{accent}"/>
  <label>رنگ دوم</label><input type="color" id="v78-accent2" value="{accent2}"/>
  <label>متن لوگو</label><input type="text" id="v78-logo-text" maxlength="22" value="{logo}"/>
  <label style="display:flex;align-items:center;gap:8px;margin-top:10px;">
    <input type="checkbox" id="v78-schematic-glow" {"checked" if s.get("schematic_glow", True) else ""}/> درخشش شماتیک
  </label>
  <label style="display:flex;align-items:center;gap:8px;">
    <input type="checkbox" id="v78-forecast" {"checked" if s.get("show_forecast_candles", True) else ""}/> کندل‌های آینده
  </label>
  <label style="display:flex;align-items:center;gap:8px;">
    <input type="checkbox" id="v78-cone" {"checked" if s.get("show_probability_cone", True) else ""}/> مخروط احتمال
  </label>
  <div style="margin-top:14px; display:flex; gap:8px; flex-wrap:wrap;">
    <button type="button" onclick="v78ApplyLive()" class="titan-btn">اعمال زنده</button>
    <button type="button" onclick="v78SaveUI()" class="titan-btn">ذخیره</button>
    <button type="button" onclick="v78ResetUI()" class="titan-btn secondary">بازنشانی</button>
  </div>
</div>
<script>
(function(){{
  function body(){{
    return {{
      theme: document.getElementById('v78-theme').value,
      layout: document.getElementById('v78-layout').value,
      lighting: document.getElementById('v78-lighting').value,
      light_intensity: Number(document.getElementById('v78-intensity').value||62),
      shape_style: document.getElementById('v78-shape').value,
      schematic_style: document.getElementById('v78-schematic').value,
      chart_style: document.getElementById('v78-chart').value,
      chart_geometry: document.getElementById('v78-geometry').value,
      loading_style: document.getElementById('v78-loading').value,
      density: document.getElementById('v78-density').value,
      accent: document.getElementById('v78-accent').value,
      accent2: document.getElementById('v78-accent2').value,
      logo_text: document.getElementById('v78-logo-text').value,
      schematic_glow: document.getElementById('v78-schematic-glow').checked,
      show_forecast_candles: document.getElementById('v78-forecast').checked,
      show_probability_cone: document.getElementById('v78-cone').checked,
    }};
  }}
  function applyDom(s){{
    var h = document.documentElement;
    if(s.theme) h.setAttribute('data-theme', s.theme);
    if(s.layout) h.setAttribute('data-layout', s.layout);
    if(s.lighting) h.setAttribute('data-light', s.lighting);
    if(s.shape_style) h.setAttribute('data-shape', s.shape_style);
    if(s.schematic_style) h.setAttribute('data-schematic', s.schematic_style);
    if(s.chart_style) h.setAttribute('data-chart', s.chart_style);
    if(s.chart_geometry) h.setAttribute('data-geometry', s.chart_geometry);
    if(s.density) h.setAttribute('data-density', s.density);
    h.setAttribute('data-schematic-glow', s.schematic_glow ? '1' : '0');
    if(s.logo_text) document.title = s.logo_text + ' · V78.2';
    if(typeof s.light_intensity === 'number'){{
      document.documentElement.style.setProperty('--titan-glow', (s.light_intensity/100).toFixed(3));
    }}
    if(s.accent) document.documentElement.style.setProperty('--titan-accent', s.accent);
    if(s.accent2) document.documentElement.style.setProperty('--titan-accent2', s.accent2);
  }}
  window.v78ApplyLive = function(){{
    applyDom(body());
  }};
  window.v78SaveUI = async function(){{
    var payload = body();
    applyDom(payload);
    await fetch('/api/v78/ui', {{method:'POST', headers:{{'Content-Type':'application/json'}}, body: JSON.stringify(payload)}});
  }};
  window.v78ResetUI = async function(){{
    await fetch('/api/v78/ui/reset', {{method:'POST'}});
    location.reload();
  }};
  window.v78TogglePanel = function(){{
    var p = document.getElementById('v78-ui-panel');
    if(!p) return;
    p.style.display = p.style.display === 'none' ? 'block' : 'none';
  }};
  // live range label
  var r = document.getElementById('v78-intensity');
  if(r){{
    r.addEventListener('input', function(){{
      applyDom({{light_intensity: Number(r.value)}});
    }});
  }}
  ['v78-theme','v78-layout','v78-lighting','v78-shape','v78-schematic','v78-chart','v78-density'].forEach(function(id){{
    var el = document.getElementById(id);
    if(el) el.addEventListener('change', function(){{ applyDom(body()); }});
  }});
}})();
</script>
"""


def _v78_ui_self_test() -> int:
    print("  + v78_ui_defaults")
    s = _v78_ui_get_settings()
    assert "theme" in s
    assert "lighting" in s
    assert "schematic_style" in s
    print("  + v78_ui_css")
    css = _v78_ui_css_vars(s)
    assert "--titan-accent" in css
    assert "--titan-glow" in css
    print("  + v78_ui_layout_css")
    assert "data-light" in _v78_ui_layout_css() or "data-light=" in _v78_ui_layout_css() or "html[data-light" in _v78_ui_layout_css()
    print("  + v78_ui_panel")
    panel = _v78_ui_panel_html()
    assert "v78-lighting" in panel and "v78-schematic" in panel
    print("V78.2 UI Studio self-test: PASS")
    return 0


# ---- V78 UI API ----
try:
    @app.get("/api/v78/ui")
    def api_v78_ui_get():
        return jsonify(
            {
                "ok": True,
                "settings": _v78_ui_get_settings(),
                "themes": list(_V78_THEMES.keys()) + ["custom"],
                "layouts": list(_V78_LAYOUTS),
                "lighting": list(_V78_LIGHTS),
                "shapes": list(_V78_SHAPES),
                "schematics": list(_V78_SCHEMATICS),
                "charts": list(_V78_CHARTS),
                "geometry": list(_V78_GEOMETRY),
                "version": V78_UI_VERSION,
            }
        )

    @app.post("/api/v78/ui")
    def api_v78_ui_post():
        data = request.get_json(silent=True) or {}
        settings = _v78_ui_save_settings(data)
        return jsonify({"ok": True, "settings": settings, "version": V78_UI_VERSION})

    @app.post("/api/v78/ui/reset")
    def api_v78_ui_reset():
        try:
            with DB_LOCK, db_conn() as con:
                con.execute("DELETE FROM v78_ui_settings")
        except Exception:
            _swallow()
        return jsonify({"ok": True, "settings": _v78_ui_get_settings(), "version": V78_UI_VERSION})

    @app.get("/api/v78/ui/css")
    def api_v78_ui_css():
        from flask import Response

        body = _v78_ui_css_vars() + "\n" + _v78_ui_layout_css()
        return Response(body, mimetype="text/css")
except Exception:
    pass
