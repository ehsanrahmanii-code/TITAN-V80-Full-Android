# [TITAN V79.9] Service architecture — modular monolith, execution port, core wiring
"""Professional evolution of the layered engine without a big-bang rewrite.

What this changes vs "still the old 79.6 engine":

1. **Modular monolith** — explicit in-process services (ingest/features/decision/
   ledger/execution/api) with a registry. Same process, clear boundaries.
2. **Execution port** — Paper is first-class and auto-armed on validated signals.
   Live exchange orders remain OFF unless triple-gated (env + admin + validated).
3. **Core wiring** — quant/neural/governor outputs must pass contract + pipeline
   before any execution side-effect.
4. **Default experience** — always reports architecture_mode=modular_monolith and
   enterprise_defaults=on even without Postgres/Redis env vars.
"""
from __future__ import annotations

import os
import threading
import time
from typing import Any, Callable, Optional

V79_9_VERSION = "TITAN-V79.9-SERVICE-ARCH"
ARCHITECTURE_MODE = "modular_monolith"
PIPELINE_VERSION = "79.9.0-services"

# ---------------------------------------------------------------------------
# Service registry (in-process micro-boundaries)
# ---------------------------------------------------------------------------

_SERVICES: dict[str, dict[str, Any]] = {}
_SERVICES_LOCK = threading.RLock()


def register_service(name: str, *, version: str, capabilities: list[str], handler: Optional[Callable] = None) -> None:
    with _SERVICES_LOCK:
        _SERVICES[name] = {
            "name": name,
            "version": version,
            "capabilities": list(capabilities),
            "handler": handler,
            "registered_at": time.time(),
        }


def get_service(name: str) -> Optional[dict]:
    with _SERVICES_LOCK:
        row = _SERVICES.get(name)
        return dict(row) if row else None


def list_services() -> list[dict]:
    with _SERVICES_LOCK:
        return [
            {k: v for k, v in s.items() if k != "handler"}
            for s in _SERVICES.values()
        ]


def call_service(name: str, method: str, *args, **kwargs) -> Any:
    svc = get_service(name)
    if not svc or not callable(svc.get("handler")):
        raise RuntimeError(f"service_unavailable:{name}")
    fn = svc["handler"]
    if hasattr(fn, method):
        return getattr(fn, method)(*args, **kwargs)
    return fn(*args, **kwargs)


# ---------------------------------------------------------------------------
# Execution port — Paper default; Live hard-gated
# ---------------------------------------------------------------------------

_EXEC_LOCK = threading.RLock()
_EXEC_STATS = {
    "paper_attempts": 0,
    "paper_opened": 0,
    "paper_rejected": 0,
    "live_blocked": 0,
    "live_attempts": 0,
}


def _live_trading_allowed() -> tuple[bool, str]:
    """Triple gate: env flag + not analysis-only kill + explicit unlock file optional."""
    if str(os.environ.get("TITAN_LIVE_TRADING", "0")).lower() not in {"1", "true", "yes"}:
        return False, "TITAN_LIVE_TRADING not enabled"
    if str(os.environ.get("TITAN_ANALYSIS_ONLY", "1")).lower() in {"1", "true", "yes"}:
        return False, "TITAN_ANALYSIS_ONLY=1 (default) blocks live"
    # Optional second unlock
    unlock = str(os.environ.get("TITAN_LIVE_UNLOCK", "") or "").strip()
    if unlock != "I_UNDERSTAND_RISK":
        return False, "TITAN_LIVE_UNLOCK must be I_UNDERSTAND_RISK"
    return True, "ok"


def execution_evaluate_gates(item: dict) -> tuple[bool, str]:
    """Shared pre-trade gates for paper and live."""
    if not isinstance(item, dict):
        return False, "not_a_dict"
    auth = str(item.get("authoritative_decision") or item.get("decision") or "WAIT").upper()
    if auth not in {"LONG", "SHORT"}:
        return False, "not_directional"
    if item.get("decision_validated") is not True:
        return False, "not_validated"
    if item.get("trade_allowed") is not True:
        return False, "trade_not_allowed"
    if item.get("decision_vetoed") is True:
        return False, "vetoed"
    flags = item.get("status_flags") if isinstance(item.get("status_flags"), dict) else {}
    if flags.get("price") == "STALE":
        return False, "stale_price"
    if flags.get("decision") in {"UNVALIDATED", "BLOCKED"}:
        return False, f"flag:{flags.get('decision')}"
    return True, "ok"


def paper_execute(item: dict, *, account_size: float = 10000.0, risk_pct: float = 1.0) -> dict:
    """Open paper trade only through gates. Uses existing paper_open_signal when present."""
    with _EXEC_LOCK:
        _EXEC_STATS["paper_attempts"] += 1
    ok, reason = execution_evaluate_gates(item)
    if not ok:
        with _EXEC_LOCK:
            _EXEC_STATS["paper_rejected"] += 1
        return {"ok": False, "mode": "paper", "reason": reason, "opened": False}
    opened = False
    reject_reason = reason  # gate said ok; may be overwritten
    try:
        if callable(globals().get("paper_open_signal")):
            opened = bool(paper_open_signal(item, account_size=account_size, risk_pct=risk_pct))
            if not opened:
                reject_reason = "rejected_by_paper_rules"  # missing levels / RR / inverted SL-TP
        else:
            opened = False
            reject_reason = "paper_open_signal_missing"
    except Exception as exc:
        reject_reason = f"paper_error:{exc}"
        try:
            _record_engine_error("signal", reject_reason, symbol=str(item.get("symbol") or ""))
        except Exception:
            pass
        opened = False
    with _EXEC_LOCK:
        if opened:
            _EXEC_STATS["paper_opened"] += 1
        else:
            _EXEC_STATS["paper_rejected"] += 1
    return {
        "ok": opened,
        "mode": "paper",
        "reason": "opened" if opened else reject_reason,
        "opened": opened,
        "symbol": item.get("symbol"),
        "decision": item.get("authoritative_decision"),
    }


def live_execute(item: dict) -> dict:
    """Live path is intentionally non-executing unless triple-gated.

    Even when gated open, this records an *intent* only (no broker SDK).
    Real broker adapters must be plugged into live_submit_hook explicitly.
    """
    with _EXEC_LOCK:
        _EXEC_STATS["live_attempts"] += 1
    allowed, why = _live_trading_allowed()
    if not allowed:
        with _EXEC_LOCK:
            _EXEC_STATS["live_blocked"] += 1
        return {"ok": False, "mode": "live", "reason": why, "submitted": False}
    ok, reason = execution_evaluate_gates(item)
    if not ok:
        with _EXEC_LOCK:
            _EXEC_STATS["live_blocked"] += 1
        return {"ok": False, "mode": "live", "reason": reason, "submitted": False}
    # Intent log only — no exchange call in core distribution
    intent = {
        "ts": time.time(),
        "symbol": item.get("symbol"),
        "decision": item.get("authoritative_decision"),
        "pipeline_version": item.get("pipeline_version"),
        "status": "intent_recorded_not_sent",
    }
    try:
        if callable(globals().get("record_decision_ledger")):
            record_decision_ledger({
                **item,
                "decision": "LIVE_INTENT",
                "authoritative_decision": item.get("authoritative_decision"),
                "status_flags": {**(item.get("status_flags") or {}), "execution": "LIVE_INTENT"},
            })
    except Exception:
        pass
    hook = globals().get("live_submit_hook")
    if callable(hook):
        try:
            return {"ok": True, "mode": "live", "reason": "hook", "submitted": True, "result": hook(item)}
        except Exception as exc:
            return {"ok": False, "mode": "live", "reason": f"hook_error:{exc}", "submitted": False}
    return {"ok": True, "mode": "live", "reason": "intent_only_no_broker", "submitted": False, "intent": intent}


def maybe_auto_paper(item: dict) -> dict:
    """If TITAN_AUTO_PAPER=1 (default) and gates pass, open paper trade."""
    auto = str(os.environ.get("TITAN_AUTO_PAPER", "1")).lower() in {"1", "true", "yes"}
    if not auto:
        return {"ok": False, "mode": "paper", "reason": "auto_paper_off", "opened": False}
    return paper_execute(item)


# ---------------------------------------------------------------------------
# Core wiring: analyze → contract pipeline → optional paper
# ---------------------------------------------------------------------------

_PREV_ANALYZE_V79_9 = globals().get("analyze_asset")


def analyze_asset(*args, **kwargs):
    item = None
    sym = str(args[0] if args else kwargs.get("symbol") or "")
    try:
        item = _PREV_ANALYZE_V79_9(*args, **kwargs) if callable(_PREV_ANALYZE_V79_9) else {}
    except Exception as exc:
        try:
            _swallow("signal:analyze_v79_9")
            _record_engine_error("signal", f"analyze_v79_9:{exc}", symbol=sym)
        except Exception:
            pass
        item = item if isinstance(item, dict) else {"symbol": sym, "decision": "WAIT"}
    if not isinstance(item, dict):
        item = {"symbol": sym, "decision": "WAIT"}
    # Ensure contract fields
    try:
        if callable(globals().get("normalize_analysis_item")):
            item = normalize_analysis_item(item, symbol=sym)
    except Exception:
        pass
    item["architecture_mode"] = ARCHITECTURE_MODE
    item["pipeline_version"] = item.get("pipeline_version") or PIPELINE_VERSION
    item["enterprise_defaults"] = True
    # Auto paper on validated directional
    try:
        exec_result = maybe_auto_paper(item)
        item["execution"] = exec_result
        if exec_result.get("opened"):
            flags = item.get("status_flags") if isinstance(item.get("status_flags"), dict) else {}
            flags["execution"] = "PAPER_OPEN"
            item["status_flags"] = flags
    except Exception as exc:
        try:
            _record_engine_error("signal", f"auto_paper:{exc}", symbol=sym)
        except Exception:
            pass
        item["execution"] = {"ok": False, "mode": "paper", "reason": "exception"}
    return item


# ---------------------------------------------------------------------------
# Register services
# ---------------------------------------------------------------------------

register_service(
    "ingest",
    version=V79_9_VERSION,
    capabilities=["ohlcv", "live_price", "derivatives"],
    handler=globals().get("fetch_ohlcv"),
)
register_service(
    "features",
    version=V79_9_VERSION,
    capabilities=["technicals", "quant", "neural"],
    handler=None,
)
register_service(
    "decision",
    version=V79_9_VERSION,
    capabilities=["authority", "contract", "pipeline"],
    handler=globals().get("run_enterprise_pipeline") or globals().get("_v79_authoritative_decision"),
)
register_service(
    "ledger",
    version=V79_9_VERSION,
    capabilities=["decision_ledger", "fate"],
    handler=globals().get("record_decision_ledger"),
)
register_service(
    "execution",
    version=V79_9_VERSION,
    capabilities=["paper", "live_gated"],
    handler=paper_execute,
)
register_service(
    "api",
    version=V79_9_VERSION,
    capabilities=["rest", "rbac", "ops"],
    handler=None,
)


# ---------------------------------------------------------------------------
# HTTP
# ---------------------------------------------------------------------------

@app.get("/api/v79/architecture")
def api_v79_architecture():
    live_ok, live_why = _live_trading_allowed()
    with _EXEC_LOCK:
        stats = dict(_EXEC_STATS)
    return jsonify({
        "ok": True,
        "architecture_mode": ARCHITECTURE_MODE,
        "version": V79_9_VERSION,
        "pipeline_version": PIPELINE_VERSION,
        "enterprise_defaults": True,
        "services": list_services(),
        "execution": {
            "paper_default": True,
            "auto_paper": str(os.environ.get("TITAN_AUTO_PAPER", "1")).lower() in {"1", "true", "yes"},
            "live_allowed": live_ok,
            "live_block_reason": None if live_ok else live_why,
            "stats": stats,
        },
        "notes": [
            "In-process modular monolith — not distributed microservices.",
            "Paper execution is first-class; live requires TITAN_LIVE_TRADING=1, TITAN_ANALYSIS_ONLY=0, TITAN_LIVE_UNLOCK=I_UNDERSTAND_RISK.",
            "Core quant/neural still compute features; authority+contract gate all side effects.",
        ],
    })


@app.post("/api/v79/execution/paper")
def api_v79_execution_paper():
    body = request.get_json(silent=True) or {}
    # Prefer symbol re-analyze if provided
    sym = str(body.get("symbol") or "")
    item = body.get("item") if isinstance(body.get("item"), dict) else None
    if item is None and sym and callable(globals().get("analyze_asset")):
        try:
            item = analyze_asset(sym, str(body.get("btc_trend") or "خنثی"))
        except Exception:
            item = {"symbol": sym, "decision": "WAIT"}
    if not isinstance(item, dict):
        return jsonify({"ok": False, "error": "item_required"}), 400
    result = paper_execute(
        item,
        account_size=float(body.get("account_size") or 10000),
        risk_pct=float(body.get("risk_pct") or 1.0),
    )
    return jsonify({"ok": True, "result": result, "pipeline_version": PIPELINE_VERSION})


@app.post("/api/v79/execution/live")
def api_v79_execution_live():
    body = request.get_json(silent=True) or {}
    item = body.get("item") if isinstance(body.get("item"), dict) else None
    if not isinstance(item, dict):
        return jsonify({"ok": False, "error": "item_required"}), 400
    # RBAC: admin only when tokens configured
    try:
        roles_map = globals().get("_v79_load_token_roles")
        if callable(roles_map) and roles_map():
            role_fn = globals().get("_v79_request_role")
            role = role_fn() if callable(role_fn) else ""
            rank = globals().get("_v79_role_at_least")
            if callable(rank) and not rank(role, "admin"):
                return jsonify({"ok": False, "error": "forbidden_role", "required_role": "admin"}), 403
    except Exception:
        pass
    result = live_execute(item)
    return jsonify({"ok": True, "result": result, "pipeline_version": PIPELINE_VERSION})


def _v79_9_self_test() -> int:
    print("  + service_registry")
    assert get_service("execution") is not None
    assert get_service("decision") is not None
    print("  + gates_reject_unvalidated")
    ok, reason = execution_evaluate_gates({
        "authoritative_decision": "LONG",
        "decision_validated": False,
        "trade_allowed": True,
    })
    assert ok is False and reason == "not_validated"
    print("  + live_blocked_by_default")
    allowed, _ = _live_trading_allowed()
    assert allowed is False
    print("  + paper_reject_wait")
    r = paper_execute({"authoritative_decision": "WAIT", "decision_validated": True})
    assert r.get("opened") is False
    print("V79.9 Service Architecture self-test: PASS")
    return 0
